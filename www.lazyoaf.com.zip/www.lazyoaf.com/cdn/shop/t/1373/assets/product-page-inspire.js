document.addEventListener('DOMContentLoaded', function() {
    const inspireIcon = document.querySelector('.product-information__inspired');
    inspireIcon?.addEventListener('click', () =>{
        document.querySelector('.lazy-oaf-product-heading')?.scrollIntoView();
    });
});