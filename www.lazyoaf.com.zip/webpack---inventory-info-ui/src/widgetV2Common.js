export function expandableAllowed(settings) {
  return settings.expandable && !settings.drawer;
}

export function hasStockThresholdConfig(settings) {
  return (
    settings.threshold &&
    settings.stockMessageRules &&
    settings.stockMessageRules.length > 0
  );
}

export function getLocationName(location, locale) {
  let locationName = location.name;
  if (locationName) {
    if (
      location.name_locales &&
      Object.keys(location.name_locales).length > 0 &&
      location.name_locales[locale]
    ) {
      locationName = location.name_locales[locale];
    }
    return locationName;
  }
}

export function getLocalizedString(defaultString, localeStringObj, locale) {
  if (localeStringObj && localeStringObj[locale]) {
    return localeStringObj[locale];
  }
  return defaultString;
}

export function getLocationNote(settings, location, quantity, locale) {
  if (location.note) {
    let locationNote = location.note;
    if (
      location.note_locales &&
      Object.keys(location.note_locales).length > 0 &&
      location.note_locales[locale]
    ) {
      locationNote = location.note_locales[locale];
    }
    if (location.soldOutOnlyNote) {
      return quantity <= 0 ? locationNote : '';
    }

    const regEx = /{{(.*?)}}/;
    const jsMatch = locationNote.match(regEx);
    if (jsMatch) {
      const js = jsMatch[1];
      let jsNote = '';
      try {
        jsNote = eval(js);
      } catch (e) {
        console.error(
          'Error in eval of JavaScript expression in location note field: ',
          e.message
        );
      }
      if (settings.displayOnEmptyMetafield) {
        return locationNote.replace(regEx, jsNote);
      }
      return jsNote ? locationNote.replace(regEx, jsNote) : '';
    }
    return locationNote;
  }
  return '';
}

export function isGroupedByLocationList(settings, product) {
  return settings.groupedByLocation && product && !product.defaultVariantOnly;
}

export function getVariantTitleHtml(variantTitle) {
  const separator = '/';
  if (variantTitle) {
    const fragments = variantTitle.split(separator);
    return fragments
      .map(function(fragment, index) {
        return `<span class='iia-variant-part-${index +
          1}'>${fragment.trim()}</span>${index < fragments.length - 1 ? ` <span class="iia-variant-separator">${separator}</span> ` : ''}`;
      })
      .join('');
  }

  return '';
}

export function isGeoSearch(settings) {
  return (
    settings && settings.geo && settings.geo.enabled && settings.geo.apiKey
  );
}

export function debugLog(...args) {
  if (window.location.search.includes('iia_debug')) {
    console.log('[Inventory Info App]', ...args);
  }
}

export function log(...args) {
  console.log('[Inventory Info]', ...args);
}

export function hasLocationSelectionRuleEnabled() {
  return (
    window.inventoryInfo.settings &&
    window.inventoryInfo.settings.stockLocationRules &&
    window.inventoryInfo.settings.stockLocationRules.inCountryRule &&
    window.inventoryInfo.settings.stockLocationRules.inCountryRule
      .locationPicker !== 'none'
  );
}

export function hasBackInStockNotificationEnabled() {
  return (
    window.inventoryInfo.settings &&
    window.inventoryInfo.settings.backInStock &&
    window.inventoryInfo.settings.backInStock.enabled
  );
}

export function hasDefaultLocation(settings) {
  return (
    settings.defaultLocation &&
    (settings.defaultLocation.id || settings.defaultLocation.firstInStock)
  );
}
export function getDefaultLocationId(settings) {
  return settings.defaultLocation && !settings.defaultLocation.firstInStock
    ? settings.defaultLocation.id
    : null;
}

export function hasMarketRules() {
  return (
    window.inventoryInfo.settings &&
    window.inventoryInfo.settings.marketRules &&
    window.inventoryInfo.settings.marketRules.rules &&
    window.inventoryInfo.settings.marketRules.rules.length > 0
  );
}

export function hasCompanyLocationRules(settings) {
  return (
    settings &&
    settings.stockLocationRules &&
    settings.stockLocationRules.companyLocationRules &&
    settings.stockLocationRules.companyLocationRules.enabled
  );
}
export function isDisplayForB2BOnly(settings) {
  return (
    settings.stockLocationRules &&
    settings.stockLocationRules.companyLocationRules &&
    settings.stockLocationRules.companyLocationRules.widgetForB2bOnly
  );
}

export function shouldHideWidgetForMarket(settings) {
  return (
    settings.marketRules &&
    settings.marketRules.rules &&
    settings.marketRules.rules.length > 0 &&
    settings.marketRules.hideUnmapped &&
    window.inventoryInfo.markets &&
    window.inventoryInfo.markets.id &&
    settings.marketRules.rules.find(
      rule => rule.marketId === window.inventoryInfo.markets.id
    ) === undefined
  );
}

export function loadLocationSelectionUI() {
  return new Promise(resolve => {
    if (hasLocationSelectionRuleEnabled()) {
      import('./components/LocationSelectionUIManager').then(module => {
        debugLog('Location selection UI loading');
        module.default().then(() => {
          debugLog('Location selection UI loaded');
        });
        resolve();
      });
    } else {
      resolve();
    }
  });
}
