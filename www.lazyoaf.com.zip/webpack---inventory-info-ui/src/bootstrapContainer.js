import {
  isInDesignMode,
  waitForCondition,
  waitForElement
} from './common/commonUtils';

export const CONTAINER_ID = 'inventory-info-app';
export const CONTAINER_CLASS = 'iia-container';
import atcButton from './common/atcButton';
import { debugLog } from './widgetV2Common';

const DEFAULT_CONTAINER = `<div id="${CONTAINER_ID}" class="iia-container" iia-is-default="true"></div>`;
export default function bootstrapContainer(
  settings,
  parentContainer,
  forceBootstrapDefault
) {
  const containerSelector = `#${CONTAINER_ID}`;
  let containerResovled = false;
  return new Promise(resolve => {
    window.__iiaAppBlockLoaded = function() {
      if (!containerResovled) {
        debugLog('App block loaded callback invoked');
        const appBlockContainer = (parentContainer || document).querySelector(
          `#${CONTAINER_ID}`
        );
        resolve(appBlockContainer);
      }
    };

    if (isInDesignMode() || settings.appSection) {
      // Will have to wait for element to load
      waitForElement(
        parentContainer || document,
        containerSelector,
        function(element) {
          if (isInDesignMode()) {
            console.log('Found the app embedd in Design mode....');
          } else if (settings.appSection) {
            console.log(
              'Rendering Multi Location Inventory Info app based on a delayed loading of app section '
            );
          }
          containerResovled = true;
          resolve(element);
        },
        300,
        5000
      );
    } else if (forceBootstrapDefault) {
      bootstrapDefaultContainer(settings, parentContainer).then(container => {
        containerResovled = true;
        resolve(container);
      });
    } else {
      document.addEventListener('DOMContentLoaded', () => {
        const appBlockContainer = (parentContainer || document).querySelector(
          `#${CONTAINER_ID}`
        );
        if (!appBlockContainer) {
          bootstrapDefaultContainer(settings, parentContainer).then(
            container => {
              containerResovled = true;
              resolve(container);
            }
          );
        } else {
          containerResovled = true;
          resolve(appBlockContainer);
        }
      });
    }
  });
}

function bootstrapDefaultContainer(settings, parentContainer) {
  return new Promise(resolve => {
    waitForCondition(
      'bootstrapDefaultContainer',
      () => {
        const button = atcButton.getAddToCartButton(settings, parentContainer);
        if (button) {
          button.insertAdjacentHTML('beforebegin', DEFAULT_CONTAINER);
          return true;
        }
        return false;
      },
      () => {
        resolve(
          (parentContainer || document).querySelector(`#${CONTAINER_ID}`)
        );
      }
    );
  });
}
