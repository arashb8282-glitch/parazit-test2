import { fireEvent } from './utils';
export const PAGE_URL_CHANGED_EVENT = 'inventoryInfo.pageUrlChanged';

export default function replaceStatePatch(history) {
  const replaceState = history.replaceState;
  history.replaceState = function() {
    try {
      fireEvent(PAGE_URL_CHANGED_EVENT);
    } finally {
    }
    return replaceState.apply(history, arguments);
  };
}
