export default function isHiddenForCollection(settings, product) {
  let hide = false;
  if (
    settings.hiddenCollections &&
    settings.hiddenCollections.length > 0 &&
    product &&
    product.collections
  ) {
    for (let i = 0; i < settings.hiddenCollections.length; i++) {
      if (product.collections.indexOf(settings.hiddenCollections[i]) >= 0) {
        hide = true;
      }
    }
    return settings.collectionDisplayOnly ? !hide : hide;
  }

  return hide;
}
