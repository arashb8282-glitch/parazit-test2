import { DefaulText, InventoryDisplayOption, Tokens } from './domain';
import { isSoldOut } from './soldOut';

export function hasIncomingStock(currentVariant, settings, product) {
  if (
    !settings.drawer &&
    product &&
    settings.incomingStock &&
    hasIncoming(currentVariant, settings, product)
  ) {
    if (
      isSoldOut(currentVariant) ||
      shouldAlwaysShow(settings) ||
      settings.incomingStockDisplay === InventoryDisplayOption.HasIncoming
    ) {
      return true;
    }
  }
  return false;
}

export function getIncomingStockTitle(
  incomingInventoryItem,
  settings,
  variantId,
  product
) {
  const titleTemplate = settings.incomingTitleTemplate || DefaulText.Incoming;
  return titleTemplate
    .replace(Tokens.qty, incomingInventoryItem.incoming)
    .replace(Tokens.date, getIncomingDate(variantId, product));
}

export function getIncomingShipmentTitle(shipmentItem, settings) {
  const titleTemplate =
    settings.incomingItemTemplate || DefaulText.IncomingShippmentItem;
  return titleTemplate
    .replace(Tokens.qty, shipmentItem.quantity)
    .replace(
      Tokens.date,
      shipmentItem.arrivesAt ? formatUtcDate(shipmentItem.arrivesAt) : ''
    )
    .replace('-', !shipmentItem.arrivesAt ? '' : '-');
}
export function getEstimatedArrivalDate(incomingInventoryItem, settings) {
  if (!incomingInventoryItem.expectedAt) {
    return '';
  }
  const formattedExpectedAt = formatUtcDate(incomingInventoryItem.expectedAt);
  if (!formattedExpectedAt) {
    return '';
  }
  const estimatedArrivalTemplate =
    settings.incomingDateTemplate || DefaulText.EstimatedArrival;
  return estimatedArrivalTemplate.replace(Tokens.date, formattedExpectedAt);
}

export function getNetIncomingInventoryItem(
  incomingInventoryItem,
  currentVariant,
  settings
) {
  if (!settings || !settings.netIncomingStock) {
    return incomingInventoryItem;
  }

  const negativeInventoryByLocation = getNegativeInventoryByLocation(
    currentVariant
  );
  const locationId =
    incomingInventoryItem && incomingInventoryItem.location
      ? String(incomingInventoryItem.location.id)
      : null;
  const allocatedQuantity = locationId
    ? negativeInventoryByLocation[locationId] || 0
    : 0;

  if (allocatedQuantity <= 0) {
    return incomingInventoryItem;
  }

  if (
    incomingInventoryItem.incomingShipments &&
    incomingInventoryItem.incomingShipments.length > 0
  ) {
    let remainingAllocated = allocatedQuantity;
    const nettedIncomingShipments = incomingInventoryItem.incomingShipments.map(
      shipment => {
        const shipmentQuantity = Math.max(0, Number(shipment.quantity) || 0);

        if (remainingAllocated <= 0) {
          return shipment;
        }

        const netShipmentQuantity = Math.max(
          0,
          shipmentQuantity - remainingAllocated
        );
        remainingAllocated = Math.max(0, remainingAllocated - shipmentQuantity);

        return {
          ...shipment,
          quantity: netShipmentQuantity
        };
      }
    );

    const incomingShipments = nettedIncomingShipments.filter(
      shipment => (Number(shipment.quantity) || 0) > 0
    );

    const netIncomingQuantity = incomingShipments.reduce(
      (sum, shipment) => sum + (Number(shipment.quantity) || 0),
      0
    );

    return {
      ...incomingInventoryItem,
      incoming: netIncomingQuantity,
      incomingShipments
    };
  }

  const incomingQuantity = Math.max(
    0,
    Number(incomingInventoryItem.incoming) || 0
  );
  return {
    ...incomingInventoryItem,
    incoming: Math.max(0, incomingQuantity - allocatedQuantity)
  };
}

function getNegativeInventoryByLocation(currentVariant) {
  return (currentVariant && currentVariant.inventoryLocations
    ? currentVariant.inventoryLocations
    : []
  ).reduce((accumulator, inventoryLocation) => {
    const locationId =
      inventoryLocation && inventoryLocation.location
        ? String(inventoryLocation.location.id)
        : null;
    const quantity = Number(inventoryLocation.quantity) || 0;

    if (locationId && quantity < 0) {
      accumulator[locationId] = Math.abs(quantity);
    }

    return accumulator;
  }, {});
}

function formatUtcDate(value) {
  const formattedDate = new Date(value).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC'
  });

  return formattedDate === 'Invalid Date' ? '' : formattedDate;
}

function getIncomingDate(variantId, product) {
  if (product && product.variants) {
    const selectedVariant = product.variants.find(function(v) {
      return v.id === variantId;
    });
    return selectedVariant && selectedVariant.incomingDate
      ? new Date(selectedVariant.incomingDate).toDateString()
      : '';
  }
  return '';
}

function hasIncoming(currentVariant, settings, product) {
  return (
    shouldAlwaysShow(settings) ||
    product.variants.find(v => v.id === currentVariant.variant).incoming
  );
}

function shouldAlwaysShow(settings) {
  return (
    settings.alwaysShowIncoming ||
    settings.incomingStockDisplay === InventoryDisplayOption.Alwyas
  );
}
