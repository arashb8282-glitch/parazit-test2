import isHiddenForCollection from './isHiddenForCollection';
import removeInvalidLocations from './common/removeInvalidLocations';
import { getAssoicatedCountries } from './countryRules';
import { getLoctionsForCustomer } from './customerTagRules';
import { hasMarketRules } from './widgetV2Common';

export function groupByLocations(
  variantLocations,
  settings,
  marketId,
  product
) {
  return new Promise(function(resolve) {
    if (isHiddenForCollection(settings, product)) {
      resolve(null);
    }
    const grouped = variantLocations.reduce(function(
      accumulator,
      variantLocation
    ) {
      const validLocations = removeInvalidLocations(
        variantLocation.inventoryLocations,
        settings,
        product
      );

      validLocations.forEach(function(inventoryLocation) {
        if (!accumulator[inventoryLocation.location.id]) {
          accumulator[inventoryLocation.location.id] = {
            location: inventoryLocation.location,
            variants: []
          };
        }
        const variant = getVariant(
          variantLocation,
          inventoryLocation,
          settings,
          product
        );
        if (variant) {
          accumulator[inventoryLocation.location.id].variants.push(variant);
        }
      });
      return accumulator;
    },
    {});

    getAssoicatedCountries(settings).then(function(associatedLocationIds) {
      if (associatedLocationIds) {
        const groupedForCountry = filterGroupedBy(
          associatedLocationIds,
          grouped
        );
        if (groupedForCountry) {
          resolve(groupedForCountry);
          return;
        }
      } else {
        let promise = Promise.resolve(grouped);
        if (hasMarketRules(settings)) {
          promise = import('./markets/marketRules').then(marketRules => {
            const filteredGroupedLocations = marketRules.filterGroupedLocationsByMarketRules(
              settings,
              marketId,
              grouped
            );
            return filteredGroupedLocations;
          });
        }
        //filter by customer tags
        promise.then(function(grouped) {
          const assoicatedLocations = getLoctionsForCustomer(settings);
          const associatedGroup = filterGroupedBy(assoicatedLocations, grouped);
          if (associatedGroup) {
            resolve(associatedGroup);
            return;
          }
          resolve(grouped);
        });
      }
    });
  });
}

function filterGroupedBy(associatedLocationIds, grouped) {
  if (associatedLocationIds) {
    const groupedLocations = {};
    associatedLocationIds.forEach(function(locationId) {
      if (grouped[locationId]) {
        groupedLocations[locationId] = grouped[locationId];
      }
    });
    if (Object.keys(groupedLocations).length > 0) {
      return groupedLocations;
    }
  }
  return;
}

function getVariant(variantLocation, inventoryLocation, settings, product) {
  const variantDetails = product.variants.find(function(v) {
    return v.id === variantLocation.variant;
  });
  return settings.hideSoldOut && inventoryLocation.quantity <= 0
    ? undefined
    : {
        id: variantLocation.variant,
        policy: variantLocation.policy,
        inventoryManagement: variantLocation.inventoryManagement,
        quantity: inventoryLocation.quantity,
        name: product.defaultVariantOnly ? '' : variantDetails.title,
        incoming: variantDetails.incoming,
        available: variantDetails.available
      };
}
