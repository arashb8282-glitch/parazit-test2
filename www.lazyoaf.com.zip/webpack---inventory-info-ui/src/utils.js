import getCurrentVariant from './common/getCurrentVariant';

export function isProductPage() {
  return (
    window.location.href.toLowerCase().indexOf('/products/') >= 0 ||
    window.location.href.toLowerCase().indexOf('/tooted/') >= 0
  );
}

export function getProductIdentifiers(variant, product) {
  let handle;
  let id;

  if (product) {
    handle = product.handle;
    id = product.id;
  }
  const pathname = window.location.pathname;
  const index = pathname.lastIndexOf('/') + 1;
  if (!handle) {
    handle = pathname.substr(index);
  }
  var params = new URLSearchParams(window.location.search);
  //Another way to get variantId
  //ShopifyAnalytics.meta.selectedVariantId
  return {
    handle,
    id,
    variant: variant
      ? parseInt(variant)
      : params.get('variant')
      ? parseInt(params.get('variant').trim())
      : undefined
  };
}

export function fireEvent(eventToFire, detail) {
  if (supportsCustomEvents()) {
    const customEvent = new CustomEvent(eventToFire, { detail });
    document.dispatchEvent(customEvent);
  }

  //Fire various callbacks
  if (
    eventToFire === window.inventoryInfo.APP_LOADED_EVENT &&
    window.locationInventory_onAppLoaded
  ) {
    window.locationInventory_onAppLoaded(detail);
    return;
  }

  if (
    eventToFire === window.inventoryInfo.APP_RENDERED_EVENT &&
    window.locationInventory_onAppRendered
  ) {
    window.locationInventory_onAppRendered(detail);
    return;
  }

  if (
    eventToFire === window.inventoryInfo.APP_DATA_EVENT &&
    window.locationInventory_onData
  ) {
    window.locationInventory_onData(detail);
    return;
  }

  if (
    eventToFire === window.inventoryInfo.LOCATION_RULE_APPLIED &&
    window.locationInventory_appLocationRuleApplied
  ) {
    window.locationInventory_onLocationRuleApplied(detail);
    return;
  }
}

function supportsCustomEvents() {
  return typeof window.CustomEvent === 'function';
}

export function getProductTitle(variantId) {
  if (ShopifyAnalytics.meta.product) {
    const variant = ShopifyAnalytics.meta.product.variants.find(
      v => v.id === variantId
    );
    return variant ? variant.name : '';
  }

  return '';
}
export function isAllowedToOverSell(currentVariant) {
  if (!currentVariant.policy) {
    // We don't know if there is an old cache entry without policy
    return false;
  }
  return currentVariant.policy === 'continue';
}

export function isMobile() {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
    window.navigator.userAgent
  );
}

export function getLocationsInStock(identifier, variantLocations, settings, product) {
  const currentVariant = getCurrentVariant(variantLocations, identifier, settings, product);

  return currentVariant.inventoryLocations
    .filter(function(inventoryLocation) {
      return inventoryLocation.quantity > 0;
    })
    .map(function(inventoryLocation) {
      return inventoryLocation.location;
    });
}
