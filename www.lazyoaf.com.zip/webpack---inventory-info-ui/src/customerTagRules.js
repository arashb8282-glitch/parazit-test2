// const customerTagRules = {
//   blockOutOfStock: true,
//   tags: {
//     Newtown: { locations: [54556852389] },
//     KS: { locations: [54556852389] },
//     CO: { locations: [54556852389] }
//   }
// };

export function getValidLocationsByTag(inventoryLocations, tags) {
  const validLocationsByTag = [];
  const { taggeLocations, hasMatchingTag } = getMatchingTagRule(tags);

  for (let i = 0; i < inventoryLocations.length; i++) {
    if (isValid(inventoryLocations[i], taggeLocations)) {
      validLocationsByTag.push(inventoryLocations[i]);
    }
  }

  return { validLocationsByTag, hasMatchingTag };
}

export function getLoctionsForCustomer(settings) {
  const customerTagRules = getCustomerTagRules(settings);
  if (customerTagRules) {
    const { taggeLocations } = getMatchingTagRule(customerTagRules.tags);
    return taggeLocations.locations;
  }
  return null;
}

export function getCustomerTagRules(settings) {
  if (!settings.stockLocationRules) {
    return;
  }
  const customerTagRules = settings.stockLocationRules.customerTagRules;
  if (
    !customerTagRules ||
    !customerTagRules.tags ||
    Object.keys(customerTagRules.tags).length === 0
  ) {
    return;
  }
  if (
    !window.inventoryInfo.customerTags ||
    window.inventoryInfo.customerTags.length === 0
  ) {
    if (
      customerTagRules.version === 'V2' &&
      !hasDefaultLocation(customerTagRules.defaultLoc)
    ) {
      return;
    }
  }
  if (customerTagRules.version === 'V2' && !customerTagRules.enabled) {
    return;
  }
  return customerTagRules;
}

export function getDefaultLocations(defaultLoc) {
  if (defaultLoc) {
    if (Array.isArray(defaultLoc)) {
      return defaultLoc;
    }
    return [defaultLoc];
  }
  return [];
}

function isValid(inventoryLocation, tagRule) {
  if (tagRule && tagRule.locations && tagRule.locations.length > 0) {
    return tagRule.locations.indexOf(inventoryLocation.location.id) >= 0;
  }
  return false;
}

function getMatchingTagRule(customerTagRules) {
  const taggeLocations = { locations: [] };
  let hasMatchingTag = false;
  if (window.inventoryInfo.customerTags) {
    for (let i = 0; i < window.inventoryInfo.customerTags.length; i++) {
      const lowerCaseTag = window.inventoryInfo.customerTags[i].toLowerCase();
      const tag = window.inventoryInfo.customerTags[i];

      if (customerTagRules[lowerCaseTag] || customerTagRules[tag]) {
        const tagRule = customerTagRules[lowerCaseTag] || customerTagRules[tag];
        hasMatchingTag = true;
        taggeLocations.locations.push.apply(
          taggeLocations.locations,
          tagRule.locations
        );
      }
    }
  }

  return { taggeLocations, hasMatchingTag };
}

function hasDefaultLocation(defaultLoc) {
  return getDefaultLocations(defaultLoc).length > 0;
}
