export default function applyLocationPriority(settings, inventoryLocations) {
  // see if we have a location with primary
  const primaryLocation = inventoryLocations.find(
    inventoryLocation => inventoryLocation.location.isPrimary
  );

  if (primaryLocation) {
    if (primaryLocation.quantity > 0 || inventoryLocations.length === 1) {
      return [primaryLocation];
    }

    const index = inventoryLocations.indexOf(primaryLocation);
    inventoryLocations.splice(index, 1);
  } else if (settings.locationPriority) {
    const priorityLocation = getBestOrNoPriorityLocations(inventoryLocations);
    if (priorityLocation) {
      return priorityLocation;
    }
  }

  return inventoryLocations;
}

function getBestOrNoPriorityLocations(inventoryLocations) {
  // Filter locations with quantity > 0
  const inStock = inventoryLocations.filter(item => item.quantity > 0);

  // Separate in-stock locations by presence of priority
  const withPriority = inStock.filter(
    item =>
      item.location.priority !== undefined && item.location.priority !== null
  );
  const noPriority = inStock.filter(
    item =>
      item.location.priority === undefined || item.location.priority === null
  );

  // If any with priority, return the one with the highest priority
  if (withPriority.length > 0) {
    return [
      withPriority.reduce((best, current) => {
        return current.location.priority < best.location.priority
          ? current
          : best;
      })
    ];
  }

  // Else, return all in-stock locations with no priority
  return noPriority;
}
