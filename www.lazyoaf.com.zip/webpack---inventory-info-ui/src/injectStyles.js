export function injectStyles(css) {
  const styleNode = `<style type="text/css">${css}</style>`;
  document.querySelector('head').insertAdjacentHTML('beforeend', styleNode);
}
