import { debugLog } from '../widgetV2Common';
import { CommonTokens } from '../common/commonUi';

/**
 * Finds the first applicable rule from a set of threshold rules
 * @param {Array} rules - Array of threshold rules
 * @param {number} qty - Quantity to evaluate
 * @param {Object} location - Location object with id property
 * @param {Object} product - Product object with tags, vendor, type properties
 * @returns {Object|null} The first rule that applies, or null if no rule applies
 */
export function findApplicableRule(rules, qty, location, product) {
  for (let i = 0; i < rules.length; i++) {
    const rule = rules[i];
    const expression = createExpression(rule, qty);
    const defaultResult = eval(expression);

    if (!defaultResult) {
      continue;
    }

    const thresholdConditions = getThresholdConditions(rule);

    if (thresholdConditions) {
      const conditionalExpression = createConditionalExpression(
        thresholdConditions?.conditions,
        thresholdConditions?.matchType,
        product
      ).replaceAll(CommonTokens.locationId, `${location.id}`);

      debugLog(`Conditional Expression: ${conditionalExpression}`);
      const conditional = eval(conditionalExpression);

      if (conditional) {
        debugLog(
          `Threshold conditions matched for rule ${JSON.stringify(rule)}`
        );

        if (thresholdConditions.conditionAction === 'hide') {
          return null;
        }
        return rule;
      } else {
        debugLog(
          `Threshold conditions not matched for rule ${JSON.stringify(rule)}`
        );
        continue;
      }
    }

    return rule;
  }

  return null;
}

function createExpression(rule, qty) {
  return `${qty} ${rule.operator} ${rule.qty}`;
}

function createConditionalExpression(conditions, matchType, product) {
  const operator = matchType === 'OR' ? '||' : '&&';

  const expression = conditions
    .map((condition, index) => {
      const conditionStr = createConditionExpression(
        condition.key,
        condition.operator,
        condition.value,
        product
      );
      return index < conditions.length - 1
        ? conditionStr + ` ${operator} `
        : conditionStr;
    })
    .join('');

  return expression;
}

function getThresholdConditions(rule) {
  const conditionGroups =
    rule.thresholdConditions &&
    rule.thresholdConditions.matchType &&
    rule.thresholdConditions.conditionGroups
      ? rule.thresholdConditions.conditionGroups
      : null;

  if (conditionGroups && conditionGroups.length > 0) {
    const validConditions = conditionGroups
      .map(cg => cg.conditions[0]) //We only taking first one for now
      .filter(c => c.key && c.operator && c.value);

    if (validConditions.length > 0) {
      return {
        conditions: validConditions,
        matchType: rule.thresholdConditions.matchType,
        conditionAction: rule.thresholdConditions.conditionAction
      };
    }
  }
  return null;
}

function createConditionExpression(key, operator, value, product) {
  const exp = [];

  // Handle custom JavaScript expressions
  if (key === 'custom') {
    if (operator === 'is_true') {
      return `(${value})`;
    } else if (operator === 'is_false') {
      return `!(${value})`;
    } else {
      throw new Error(
        `Unsupported operator "${operator}" for custom condition`
      );
    }
  }

  const fieldExp = convertKeyToFieldExp(key, product);

  if (operator === 'contains') {
    if (key === 'tag' && value.includes(',')) {
      // Handle comma-separated tags - check if ANY tags exist
      const requiredTags = value
        .toLowerCase()
        .split(',')
        .map(tag => tag.trim());
      const tagChecks = requiredTags.map(
        tag => `${fieldExp}.indexOf("${tag}") >= 0`
      );
      return `(${tagChecks.join(' || ')})`;
    } else {
      exp.push(fieldExp);
      exp.push(`.indexOf("${value.toLowerCase()}") >= 0`);
    }
  } else if (operator === 'not_contains') {
    if (key === 'tag' && value.includes(',')) {
      // Handle comma-separated tags - check if ANY of the tags is missing
      const excludeTags = value
        .toLowerCase()
        .split(',')
        .map(tag => tag.trim());
      const tagChecks = excludeTags.map(
        tag => `${fieldExp}.indexOf("${tag}") === -1`
      );
      return `(${tagChecks.join(' || ')})`;
    } else {
      exp.push(fieldExp);
      exp.push(`.indexOf("${value.toLowerCase()}") === -1`);
    }
  } else {
    exp.push(fieldExp);
    exp.push(operator);
    exp.push(
      JSON.stringify(typeof value === 'string' ? value.toLowerCase() : value)
    );
  }
  return `(${exp.join('')})`;
}

function convertKeyToFieldExp(key, product) {
  switch (key) {
    case 'tag':
      return JSON.stringify((product?.tags || []).map(t => t.toLowerCase()));
    case 'vendor':
      return JSON.stringify((product?.vendor || '').toLowerCase());
    case 'type':
      return JSON.stringify((product?.type || '').toLowerCase());
    case 'location':
      return CommonTokens.locationId;
    default:
      return key;
  }
}
