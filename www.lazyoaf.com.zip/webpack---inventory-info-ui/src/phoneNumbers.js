import loadScript from './common/loadScript';
import { isMobile } from './utils';

const LIBPHONENUMBER_URL =
  'https://unpkg.com/libphonenumber-js@1.10.14/bundle/libphonenumber-min.js';

export function shouldFormatPhone(settings) {
  return !!(
    settings &&
    (settings.formatPhone || (settings.designVersion || 'v1') === 'v2')
  );
}

export function getDisplayPhone(settings, location, formattedPhones) {
  if (shouldFormatPhone(settings)) {
    return (formattedPhones && formattedPhones[location.id]) || '';
  }
  return location.phone;
}

export function getFormattedPhones(settings, locations) {
  return new Promise(resolve => {
    if (!shouldFormatPhone(settings)) {
      return resolve({});
    }
    loadScript(LIBPHONENUMBER_URL, () => {
      const formattedPhones = (locations || []).reduce((acc, location) => {
        if (location.phone) {
          let formatted = null;
          try {
            formatted = libphonenumber.parsePhoneNumber(
              location.phone,
              location.countryCode
            );
          } catch (e) {}

          acc[location.id] = formatted
            ? formatted.formatNational()
            : location.phone;
        }
        return acc;
      }, {});
      resolve(formattedPhones);
    });
  });
}

export function clickablePhoneNumber(settings, phoenNumber, formattedNumber) {
  if (!phoenNumber) {
    return '';
  }
  const displayNumber = formattedNumber || phoenNumber;

  if (settings.clickablePhone && isMobile()) {
    return `<a href=tel:${phoenNumber}>${displayNumber}</a>`;
  } else {
    return displayNumber;
  }
}
