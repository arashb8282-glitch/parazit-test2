import atcButton from './common/atcButton';
import { fireEvent } from './utils';
export const VARIANT_CHANGED_EVENT = 'inventoryInfo.variantChanged';
export default function watchHiddenInputChange(
  settings,
  parentContainer,
  onInputChanged
) {
  const form = atcButton.getCartForm(settings, parentContainer);
  if (form) {
    const variantElement = settings.hiddenVariantIdSelector
      ? form.querySelector(settings.hiddenVariantIdSelector)
      : form.querySelector('input[name="id"]') || form.elements.namedItem('id');
    if (!variantElement) {
      atcButton.logMissingElement('Unable to find hidden id input field ');
      return;
    }

    let variantValue = variantElement.value;

    window.setInterval(function() {
      if (variantElement.value !== variantValue) {
        variantValue = variantElement.value;
        if (onInputChanged) {
          onInputChanged(parseInt(variantValue));
        }
        fireEvent(VARIANT_CHANGED_EVENT, { variantId: parseInt(variantValue) });
      }
    }, 300);
  }
}

export function getSelectedvariant(settings, parentContainer) {
  if (settings) {
    const form = atcButton.getCartForm(settings, parentContainer);
    if (form) {
      const variantElement =
        form.querySelector('input[name="id"]') || form.elements.namedItem('id');

      return variantElement ? parseInt(variantElement.value) : undefined;
    }
  }
}
