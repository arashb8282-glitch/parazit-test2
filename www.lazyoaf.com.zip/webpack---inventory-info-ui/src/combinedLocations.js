import {
  debugLog,
  hasLocationSelectionRuleEnabled,
  isGeoSearch
} from './widgetV2Common';

export function getCombinedVariantLocations(variantLocations, settings) {
  const combinedLocations = getCombinedLocations(settings);
  if (combinedLocations.length === 0) {
    return variantLocations;
  }

  // Process each variant in the array
  return variantLocations.map(variantItem => {
    // Apply location combining logic to the inventoryLocations of this variant
    const combinedInventoryLocations = getAggregatedLocations(
      variantItem.inventoryLocations,
      combinedLocations
    );

    // Return the variant item with updated inventoryLocations
    return {
      ...variantItem,
      inventoryLocations: combinedInventoryLocations
    };
  });
}

export function getCombinedInventoryLocations(inventoryLocations) {
  const combinedLocations = getCombinedLocations();

  if (combinedLocations.length === 0) {
    return inventoryLocations;
  }
  return getAggregatedLocations(inventoryLocations, combinedLocations);
}

function getCombinedLocations() {
  if (
    isGeoSearch(window.inventoryInfo.settings) ||
    hasLocationSelectionRuleEnabled()
  ) {
    return [];
  }
  const locationDetails = window.inventoryInfo.locationSettings
    ? window.inventoryInfo.locationSettings.details
    : null;

  if (!locationDetails) {
    return [];
  }

  const combinedLocations = locationDetails.filter(
    location =>
      location.isCombined &&
      location.combinedLocations &&
      location.combinedLocations.length >= 2
  );

  debugLog('Combined Locations Configured:', combinedLocations);
  return combinedLocations;
}

function getAggregatedLocations(inventoryLocations, combinedLocations) {
  const result = [];
  const processedLocationIds = new Set();

  // Process each combined location group
  combinedLocations.forEach((combinedLocation, idx) => {
    const combinedLocationIds = combinedLocation.combinedLocations;
    let totalQuantity = 0;
    let combinedLocationInfo = null;

    // Sum quantities for locations in this combined group
    inventoryLocations.forEach(inventoryLocation => {
      if (combinedLocationIds.includes(inventoryLocation.location.id)) {
        totalQuantity += inventoryLocation.quantity;
        processedLocationIds.add(inventoryLocation.location.id);
      }
    });

    // Use the combined location info directly
    combinedLocationInfo = combinedLocation;

    // Add the combined location to result if any locations were found
    if (combinedLocationInfo) {
      const resultedCombinedLocation = {
        quantity: totalQuantity,
        location: combinedLocationInfo
      };
      debugLog(
        `Resulted Combined Location ${idx + 1}:`,
        resultedCombinedLocation
      );
      result.push(resultedCombinedLocation);
    }
  });

  // Add remaining individual locations that weren't part of any combined location
  inventoryLocations.forEach(inventoryLocation => {
    if (!processedLocationIds.has(inventoryLocation.location.id)) {
      result.push(inventoryLocation);
    }
  });

  return result;
}
