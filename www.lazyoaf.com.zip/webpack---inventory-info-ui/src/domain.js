export const Type = {
  LIST: 1,
  LOCATION_SEGMENTS: 2
};

export const FulfillmentRule = {
  SELECTED_LOCATION: 1
};

export const Events = {
  BLOCK_ATC_BUTTON: 'inventoryInfo.blockAtcButton',
  UNBLOCK_ATC_BUTTON: 'inventoryInfo.unblockAtcButton',
  APP_LOADED_EVENT: 'inventoryInfo.appLoaded',
  APP_RENDERED_EVENT: 'inventoryInfo.appRendered',
  APP_DATA_EVENT: 'inventoryInfo.appData'
};
export const AtcBlockType = {
  PRODUCT_PAGE_LOCATION_SELECTION: 'ProductPageLocationSelection',
  CUSTOMER_TAGS_RULE: 'CustomerTagsRule',
  SELECTED_LOCATION_RULE: 'SelectedLocationRule'
};
export const InventoryDisplayOption = {
  OutOfStockAndHasIncoming: 1,
  HasIncoming: 2,
  Alwyas: 3
};

export const DefautlColors = {
  iconColor: '#5C5F62',
  notificationsIconColor: '#fff'
};

export const Tokens = {
  qty: '{{qty}}',
  locationName: '{{location-name}}',
  titleText: '{{titleText}}',
  address1: '{{address1}}',
  address2: '{{address2}}',
  province: '{{province}}',
  city: '{{city}}',
  zip: '{{zip}}',
  phone: '{{phone}}',
  info: '{{info}}',
  note: '{{note}}',
  threshold: '{{threshold-message}}',
  thresholdColor: '{{thresholdColor}}',
  thresholdColorStyle: '{{thresholdColorStyle}}',
  options: '{{options}}',
  name: '{{name}}',
  date: '{{date}}'
};

export const DefaulText = {
  available: 'available',
  header: 'Availability',
  Description: '',
  StockMessageError:
    'Invalid rule found in inventory threshold configuration. Please check the configuration and try again.',
  Incoming: `Incoming - ${Tokens.qty}`,
  IncomingShippmentItem: `${Tokens.qty} Incoming - ${Tokens.date}`,
  EstimatedArrival: `Estimated Arrival - ${Tokens.date}`,
  NoNetIncomingInventory:
    'No incoming inventory is available or it has already been sold out.'
};

export const HtmlFragments = {
  locationName: `<span class="iia-location">${Tokens.locationName}</span>`,
  name: `<span class="iia-name">${Tokens.name}</span>`,
  qty: `<span class="iia-qty">${Tokens.qty}</span>`,
  threshold: `<span class='iia-stock-threshold' ${Tokens.thresholdColorStyle}>${Tokens.threshold}</span>`,
  thresholdColorStyle: `style=color:${Tokens.thresholdColor};`
};

export function wrapTextTemplatesWithHtml(textTemplate) {
  if (textTemplate.indexOf('</') < 0) {
    return textTemplate
      .replace(Tokens.locationName, HtmlFragments.locationName)
      .replace(Tokens.name, HtmlFragments.name)
      .replace(Tokens.qty, HtmlFragments.qty)
      .replace(Tokens.threshold, HtmlFragments.threshold);
  }
  return textTemplate;
}
