import { useState, useEffect } from '../../common/preact-setup';

export default function useDynamicComponentLoader(componentName) {
  const [DynamicComponent, setDynamicComponent] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!componentName) {
      setDynamicComponent(null);
      return;
    }

    // Use dynamic import for production
    setLoading(true);

    let importPromise;
    switch (componentName) {
      case 'GeoSearch':
        importPromise = import('../GeoSearch');
        break;
      case 'IncomingInventory':
        importPromise = import('../IncomingInventory');
        break;
      case 'LocationGeoSearch':
        importPromise = import('../locationSelection/LocationGeoSearch');
        break;
      default:
        console.error(`Unknown component: ${componentName}`);
        setLoading(false);
        return;
    }

    importPromise
      .then(module => {
        setDynamicComponent(() => module.default);
        setLoading(false);
      })
      .catch(err => {
        console.error(`Failed to load ${componentName} component:`, err);
        setLoading(false);
      });
  }, [componentName]);

  return !loading ? DynamicComponent : null;
}
