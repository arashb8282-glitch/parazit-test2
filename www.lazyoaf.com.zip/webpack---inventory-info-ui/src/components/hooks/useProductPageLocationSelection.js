import { useState, useContext, useEffect } from '../../common/preact-setup';
import { AtcBlockType, Events, FulfillmentRule } from '../../domain';
import { injectStyles } from '../../injectStyles';
import { fireEvent } from '../../utils';
import ProductPageContext from '../context/ProductPageContext';

export default function useProductPageLocationSelection() {
  const { settings } = useContext(ProductPageContext);

  const [state, setState] = useState({
    ProductPageLocationSelection: null,
    LocationSelectoinWrapper: null,
    selectedLocationId: 0
  });
  useEffect(() => {
    if (
      isProductPageLocationSelectionEnabled(settings) &&
      !state.ProductPageLocationSelection
    ) {
      import('../ProductPageLocationSelection').then(module => {
        injectStyles(
          ' .iia-location-info {margin-left:5px;} .iia-list-item {display: flex;}'
        );
        const selectedLocationId = module.getSelectedLocationId();

        setState(prevState => ({
          ...prevState,
          ProductPageLocationSelection: module.default,
          LocationSelectoinWrapper: module.LocationSelectoinWrapper,
          selectedLocationId
        }));

        if (settings.requireLocationSelection && !selectedLocationId) {
          fireEvent(Events.BLOCK_ATC_BUTTON, {
            type: AtcBlockType.PRODUCT_PAGE_LOCATION_SELECTION
          });
        }
      });
    }
  }, []);

  return {
    ProductPageLocationSelection: state.ProductPageLocationSelection,
    LocationSelectoinWrapper: state.LocationSelectoinWrapper,
    selectedLocationId: state.selectedLocationId
  };
}

function isProductPageLocationSelectionEnabled(settings) {
  return settings.fulfillmentRule === FulfillmentRule.SELECTED_LOCATION;
}
