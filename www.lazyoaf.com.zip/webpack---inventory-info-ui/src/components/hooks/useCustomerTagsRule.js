import {
  getCustomerTagRules,
  getDefaultLocations,
  getValidLocationsByTag
} from '../../customerTagRules';
import { AtcBlockType, Events } from '../../domain';
import { fireEvent } from '../../utils';
import { debugLog } from '../../widgetV2Common';
export default function useCustomerTagsRule(settings) {
  const getValidLocationsByCustomer = (availableLocations, currentVariant) => {
    const customerTagRules = getCustomerTagRules(settings);
    let shouldDeny = currentVariant.policy === 'deny';
    if (!customerTagRules) {
      return { validLocationsByTag: availableLocations, shouldDeny };
    }

    // see if we have defautlLocs
    const defaultLocs = getDefaultLocations(customerTagRules.defaultLoc);
    const customerLoggedIn = window.inventoryInfo.customerLoggedIn;

    let validLocationsByTag;
    function setDefaultLocationsResults() {
      if (defaultLocs.length === 0) {
        //not logged in and has no default locations
        debugLog(
          'No default locations, using  all locations',
          validLocationsByTag
        );
        validLocationsByTag = availableLocations;
      } else {
        // use default locations
        validLocationsByTag = availableLocations.filter(function(
          availableLocation
        ) {
          return defaultLocs.indexOf(availableLocation.location.id) >= 0;
        });
        debugLog('Default locations', validLocationsByTag);
      }

      if (validLocationsByTag.length > 0) {
        if (!shouldDeny) {
          shouldDeny = customerTagRules.blockContinue;
        }
      }
    }

    if (!customerLoggedIn) {
      debugLog('Customer not logged in');
      setDefaultLocationsResults();
    } else {
      const customerRuleResults = getValidLocationsByTag(
        availableLocations,
        customerTagRules.tags
      );
      if (!customerRuleResults.hasMatchingTag) {
        // logged in but has no matching tags, do  defaultLocation logic
        setDefaultLocationsResults();
        debugLog(
          'Customer logged in but has no matching tags, using default locations',
          validLocationsByTag
        );
      } else {
        validLocationsByTag = customerRuleResults.validLocationsByTag;
        debugLog(
          'Customer logged in and has matching tags, using valid locations',
          validLocationsByTag
        );
      }
    }

    return { validLocationsByTag, shouldDeny };
  };

  const handleAtcBlocking = (
    validLocationsByTag,
    shouldDeny,
    customerTagRules
  ) => {
    if (customerTagRules.blockOutOfStock || customerTagRules.version === 'V2') {
      const inStockLocations = validLocationsByTag.filter(function(
        locationByTag
      ) {
        return locationByTag && locationByTag.quantity > 0;
      });

      if ((!inStockLocations || inStockLocations.length === 0) && shouldDeny) {
        fireEvent(Events.BLOCK_ATC_BUTTON, {
          type: AtcBlockType.CUSTOMER_TAGS_RULE
        });
      } else {
        fireEvent(Events.UNBLOCK_ATC_BUTTON, {
          type: AtcBlockType.CUSTOMER_TAGS_RULE
        });
      }
    }
  };

  const getLoctionsForCustomer = (availableLocations, currentVariant) => {
    const locationResult = getValidLocationsByCustomer(
      availableLocations,
      currentVariant
    );
    const customerTagRules = getCustomerTagRules(settings);

    if (customerTagRules) {
      handleAtcBlocking(
        locationResult.validLocationsByTag,
        locationResult.shouldDeny,
        customerTagRules
      );
    }

    return locationResult.validLocationsByTag;
  };

  return {
    getLoctionsForCustomer,
    getValidLocationsByCustomer,
    handleAtcBlocking
  };
}
