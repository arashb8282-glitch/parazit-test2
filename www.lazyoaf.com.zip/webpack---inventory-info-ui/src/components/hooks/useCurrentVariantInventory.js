import { CommonEvents } from '../../common/commonUi';
import getCurrentVariant from '../../common/getCurrentVariant';
import { useState, useEffect } from '../../common/preact-setup';
import removeInvalidLocations from '../../common/removeInvalidLocations';
import sort from '../../common/sort';
import { VARIANT_CHANGED_EVENT } from '../../hiddenVariantIdWatcher';
import applyLocationPriority from '../../locationsPriority';
import netInventory from '../../netInventory';
import { hideForSoldOut } from '../../soldOut';
import {
  debugLog,
  hasStockThresholdConfig,
  hasMarketRules,
  hasCompanyLocationRules
} from '../../widgetV2Common';
import useCustomerTagsRule from './useCustomerTagsRule';
import { getCombinedInventoryLocations } from '../../combinedLocations';
import { findApplicableRule } from '../../utils/thresholdRuleEvaluator';
export default function useCurrentVariantInventory(
  variantId,
  settings,
  variantLocations,
  product,
  marketId,
  b2bLinkedLocations
) {
  const [state, setState] = useState({
    currentVariant: null,
    inventoryLocations: []
  });
  const { getLoctionsForCustomer } = useCustomerTagsRule(settings);

  const fetchInventoryLocations = async variantId => {
    const currentVariant = getCurrentVariant(
      variantLocations,
      { variant: variantId },
      settings,
      product
    );

    debugLog('Current Variant:', currentVariant);

    if (window.inventoryInfo.hooks.useSelectedLocationRule) {
      const {
        applySelectedLocationRule
      } = window.inventoryInfo.hooks.useSelectedLocationRule(settings);
      applySelectedLocationRule(currentVariant, settings, product);
    }

    const netInventoryLocations = netInventory(
      currentVariant.inventoryLocations,
      settings
    );

    let availableLocations = netInventoryLocations;
    if (currentVariant.inventoryManagement) {
      availableLocations = getCombinedInventoryLocations(availableLocations);
    }
    debugLog('All Available locations', availableLocations);
    if (hasMarketRules(settings)) {
      const marketRules = await import('../../markets/marketRules');
      availableLocations = marketRules.filterLocationsByMarketRules(
        settings,
        marketId,
        availableLocations
      );
      debugLog(
        'Available locations after applying market rules',
        availableLocations
      );
    }
    if (hasCompanyLocationRules(settings)) {
      const companyLocationRules = await import('../../companyLocationRules');
      availableLocations = companyLocationRules.filterLocationsByCompanyLocationRules(
        settings,
        b2bLinkedLocations,
        availableLocations
      );
      debugLog(
        'Available locations after applying company location rules',
        availableLocations
      );
    }
    availableLocations = getLoctionsForCustomer(
      availableLocations,
      currentVariant
    );

    debugLog(
      'Available locations after applying customer tags locations',
      availableLocations
    );
    if (hideForSoldOut(currentVariant, settings)) {
      debugLog('Hiding for sold out variant');
      availableLocations = [];
    } else {
      availableLocations = removeInvalidLocations(
        availableLocations,
        settings,
        product
      );
      debugLog(
        'Available locations after removing invalid locations',
        availableLocations
      );
      if (window.inventoryInfo.internalApis.getSelectedLocations) {
        availableLocations = window.inventoryInfo.internalApis.getSelectedLocations(
          availableLocations,
          settings
        );
        debugLog(
          'Available locations after applying selected locations',
          availableLocations
        );
      }

      availableLocations = applyLocationPriority(settings, availableLocations);

      debugLog(
        'Available locations after applying location priority',
        availableLocations
      );
      if (settings.showLocationByRules) {
        const countryRules = await import('../../countryRules');

        availableLocations = await countryRules.getLocationsForCurrentCountry(
          settings,
          availableLocations
        );
        debugLog(
          'Available locations after applying country rules',
          availableLocations
        );
      }

      if (window.inventoryInfo.api.filterLocations) {
        availableLocations = window.inventoryInfo.api.filterLocations(
          availableLocations,
          settings
        );
        debugLog(
          'Available locations after applying custom filters',
          availableLocations
        );
      }
      availableLocations = sort(availableLocations);
      debugLog('Available locations after sorting', availableLocations);

      // Apply threshold-based filtering as final step
      const isThresholdConfigured = hasStockThresholdConfig(settings);
      if (isThresholdConfigured) {
        availableLocations = availableLocations.filter(inventoryLocation => {
          const applicableRule = findApplicableRule(
            settings.stockMessageRules,
            inventoryLocation.quantity || 0,
            inventoryLocation.location,
            product
          );
          return applicableRule !== null;
        });
        debugLog(
          'Available locations after applying threshold rules',
          availableLocations
        );
      }
    }

    setState(prevState => ({
      ...prevState,
      currentVariant,
      inventoryLocations: availableLocations
    }));
  };
  useEffect(() => {
    fetchInventoryLocations(variantId);
    document.addEventListener(VARIANT_CHANGED_EVENT, e => {
      if (e.detail.variantId) {
        fetchInventoryLocations(e.detail.variantId);
      }
    });
    document.addEventListener(CommonEvents.SELECTED_LOCATION_ID_CHANGED, e => {
      if (e.detail.locationId) {
        fetchInventoryLocations(e.detail.variantId);
      }
    });
  }, []);

  return {
    currentVariant: state.currentVariant,
    inventoryLocations: state.inventoryLocations
  };
}
