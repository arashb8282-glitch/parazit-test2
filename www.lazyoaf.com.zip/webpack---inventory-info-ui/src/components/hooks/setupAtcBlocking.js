import { AtcBlockType, Events } from '../../domain';
import atcButton from '../../common/atcButton';
import {
  toggleAddToCartButton,
  waitForCondition
} from '../../common/commonUtils';
export function setupAtcBlocking(settings, parentContainer) {
  const getAtcButton = () =>
    new Promise(resolve => {
      waitForCondition(
        'atcButton',
        function() {
          const foundButton = atcButton.getAddToCartButton(
            settings,
            parentContainer
          );
          if (!foundButton) {
            return false;
          }
          resolve(foundButton);
          return true;
        },
        () => {}
      );
    });

  // Event handlers
  const handleBlockAtc = async e => {
    const button = await getAtcButton();
    if (button) {
      if (e.detail.type === AtcBlockType.PRODUCT_PAGE_LOCATION_SELECTION) {
        atcButton.blockLocationSelection(button);
      } else {
        toggleAddToCartButton(
          atcButton.getAddToCartButton(settings, parentContainer),
          true,
          settings
        );
      }
    }
  };

  const handleUnblockAtc = async () => {
    const button = await getAtcButton();
    if (button) {
      if (atcButton.isBlockedByLocationSelection(button)) {
        atcButton.unBlockLocationSelection(button);
      } else {
        toggleAddToCartButton(button, false, settings);
      }
    }
  };

  // Add event listeners
  document.addEventListener(Events.BLOCK_ATC_BUTTON, handleBlockAtc);
  document.addEventListener(Events.UNBLOCK_ATC_BUTTON, handleUnblockAtc);
}
