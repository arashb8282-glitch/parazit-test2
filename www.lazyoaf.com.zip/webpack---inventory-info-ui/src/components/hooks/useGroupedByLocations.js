import ProductPageContext from '../context/ProductPageContext';
import { useContext, useEffect, useState } from '../../common/preact-setup';
import { groupByLocations } from '../../mapper';
import sort from '../../common/sort';
import {
  debugLog,
  isGroupedByLocationList,
  hasStockThresholdConfig
} from '../../widgetV2Common';
import { getCombinedVariantLocations } from '../../combinedLocations';
import { findApplicableRule } from '../../utils/thresholdRuleEvaluator';

export default function useGroupedByLocations({ variantLocations }) {
  const { settings, product, marketId, currentVariant } = useContext(
    ProductPageContext
  );
  const hasGroupedByLocation = isGroupedByLocationList(settings, product);
  const [state, setState] = useState({
    groupedByLocations: []
  });
  useEffect(() => {
    if (hasGroupedByLocation) {
      getGroupedByLocations(
        currentVariant && currentVariant.inventoryManagement
          ? getCombinedVariantLocations(variantLocations)
          : variantLocations,
        settings,
        marketId,
        product
      ).then(groupedLocations => {
        setState({
          ...state,
          groupedLocations
        });
      });
    }
  }, [variantLocations, hasGroupedByLocation]);

  return {
    hasGroupedByLocation,
    groupedLocations: state.groupedLocations
  };
}

export function getGroupedByLocations(
  variantLocations,
  settings,
  marketId,
  product
) {
  return groupByLocations(variantLocations, settings, marketId, product).then(
    groupedByLocations => {
      const locations = Object.values(groupedByLocations);
      const sortedLocations = sort(locations);

      const groupedBySortedLocations = {};
      sortedLocations.forEach(locationGroup => {
        groupedBySortedLocations[locationGroup.location.id] = locationGroup;
      });
      let groupedLocations = Object.values(groupedBySortedLocations);

      // Apply threshold-based filtering as final step
      const isThresholdConfigured = hasStockThresholdConfig(settings);
      if (isThresholdConfigured) {
        // Filter each location group's variants first
        groupedLocations = groupedLocations.map(grouped => ({
          ...grouped,
          variants: grouped.variants.filter(variant => {
            const applicableRule = findApplicableRule(
              settings.stockMessageRules,
              variant.quantity || 0,
              grouped.location,
              product
            );
            return applicableRule !== null;
          })
        }));

        // Then filter out location groups that have no variants after threshold filtering
        groupedLocations = groupedLocations.filter(
          grouped => grouped.variants.length > 0
        );

        debugLog(
          'Grouped locations after applying threshold rules',
          groupedLocations
        );
      }

      debugLog('Grouped locations', groupedLocations);
      return groupedLocations;
    }
  );
}
