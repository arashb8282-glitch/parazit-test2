import { useEffect, useState } from '../../common/preact-setup';
import { getFormattedPhones } from '../../phoneNumbers';

export default function useFormattedPhones(settings, locations) {
  const [formattedPhones, setFormattedPhones] = useState({});
  const locationKey = (locations || [])
    .map(
      location =>
        `${location.id}:${location.phone || ''}:${location.countryCode || ''}`
    )
    .join(',');

  useEffect(() => {
    if (!locations || locations.length === 0) {
      return;
    }
    let cancelled = false;
    getFormattedPhones(settings, locations).then(phones => {
      if (!cancelled && Object.keys(phones).length > 0) {
        setFormattedPhones(phones);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [locationKey]);

  return formattedPhones;
}
