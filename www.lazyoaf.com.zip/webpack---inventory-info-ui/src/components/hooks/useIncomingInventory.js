import { hasIncomingStock } from '../../incomingStock';
import { useContext } from '../../common/preact-setup';
import ProductPageContext from '../context/ProductPageContext';

export default function useIncomingInventory() {
  const { currentVariant, settings, product } = useContext(ProductPageContext);

  const hasIncomingInventory = currentVariant
    ? hasIncomingStock(currentVariant, settings, product)
    : false;

  return { hasIncomingInventory };
}
