import {
  getLocationName,
  getLocationNote,
  hasStockThresholdConfig
} from '../widgetV2Common';
import { h, useState, useEffect, useContext } from '../common/preact-setup';
import LocationThresholdItem, {
  getLocationThresholdItemHtml
} from './LocationThresholdItem';
import LocationQtyItem, { getLocationQtyItemHtml } from './LocationQtyItem';
import {
  clickablePhoneNumber,
  getDisplayPhone,
  getFormattedPhones
} from '../phoneNumbers';
import useFormattedPhones from './hooks/useFormattedPhones';
import { HtmlFragments, Tokens } from '../domain';
import ProductPageContext from './context/ProductPageContext';
import { CommonTokens } from '../common/commonUi';
import useProductPageLocationSelection from './hooks/useProductPageLocationSelection';
import { ONLINE_LOCATION_ID } from '../common/commonUtils';
import { LocationPinIcon, PhoneIcon, DistanceIcon } from './common/Icons';
import { CommonEvents } from '../common/commonUi';
export default function LocationInventoryList({
  inventoryLocations,
  enableLocationSelection = false
}) {
  const { settings, shopLocale, currentVariant, product } = useContext(
    ProductPageContext
  );
  const isThresholdConfigured = hasStockThresholdConfig(settings);
  const [state, setState] = useState({
    locationError: { error: null, locationId: null }
  });
  const formattedPhones = useFormattedPhones(
    settings,
    inventoryLocations
      ? inventoryLocations.map(inventoryLocation => inventoryLocation.location)
      : null
  );

  const NotifyMeButton = window.inventoryInfo.components.NotifyMeButton;
  const SelectedLocationInfoLink =
    window.inventoryInfo.components.SelectedLocationInfoLink;
  useEffect(() => {
    const onLocationSelectionError = event => {
      const { error, locationId } = event.detail || {};
      setState(prevState => ({
        ...prevState,
        locationError: { error, locationId }
      }));
    };
    const onSelectedLocationIdChanged = () => {
      setState(prevState => ({
        ...prevState,
        locationError: { error: null, locationId: null }
      }));
    };
    document.addEventListener(
      CommonEvents.LOCATION_SELECTION_ERROR,
      onLocationSelectionError
    );
    document.addEventListener(
      CommonEvents.SELECTED_LOCATION_ID_CHANGED,
      onSelectedLocationIdChanged
    );
    return () => {
      document.removeEventListener(
        CommonEvents.LOCATION_SELECTION_ERROR,
        onLocationSelectionError
      );
      document.removeEventListener(
        CommonEvents.SELECTED_LOCATION_ID_CHANGED,
        onSelectedLocationIdChanged
      );
    };
  }, []);
  const {
    ProductPageLocationSelection,
    LocationSelectoinWrapper,
    selectedLocationId
  } = useProductPageLocationSelection();

  const designVersion = settings.designVersion || 'v1';
  const AddressText = ({ address }) =>
    settings.googleMapsLink ? (
      <a
        href={`https://maps.google.com/?q=${encodeURIComponent(address)}`}
        target="_blank"
        rel="noopener noreferrer"
      >
        {address}
      </a>
    ) : (
      address
    );
  const PhoneNumberHtml = ({ location }) => (
    <div
      class="iia-phone"
      dangerouslySetInnerHTML={{
        __html: clickablePhoneNumber(
          settings,
          getDisplayPhone(settings, location, formattedPhones)
        )
      }}
    />
  );
  return inventoryLocations
    ? inventoryLocations.map(inventoryLocation => {
        const location = inventoryLocation.location;
        const locatioNote = getLocationNote(
          settings,
          location,
          inventoryLocation.quantity,
          shopLocale
        );

        const address = `${location.address1 || ''} ${location.address2 ||
          ''} ${location.city ? `${location.city},` : ''} ${location.province ||
          ''} ${location.zip || ''}`.trim();
        return (
          <div class={`iia-list-item iia-id-${location.id}`}>
            {ProductPageLocationSelection && (
              <ProductPageLocationSelection
                inventoryLocation={inventoryLocation}
                selectedLocationId={selectedLocationId}
              />
            )}
            <div class="iia-location-info">
              {isThresholdConfigured ? (
                <LocationThresholdItem
                  settings={settings}
                  inventoryItem={{
                    quantity: inventoryLocation.quantity,
                    nameOrTitleText: getLocationName(location, shopLocale),
                    location: inventoryLocation.location
                  }}
                  shopLocale={shopLocale}
                  product={product}
                  Wrapper={LocationSelectoinWrapper}
                />
              ) : (
                <LocationQtyItem
                  settings={settings}
                  inventoryItem={{
                    quantity: inventoryLocation.quantity,
                    nameOrTitleText: getLocationName(location, shopLocale),
                    nameHtml: HtmlFragments.locationName,
                    location: inventoryLocation.location
                  }}
                  shopLocale={shopLocale}
                  Wrapper={LocationSelectoinWrapper}
                />
              )}
              {!settings.hideLocationDetails &&
                address &&
                (designVersion === 'v2' ? (
                  <div class="iia-address-container">
                    <LocationPinIcon />

                    <span class="iia-address">
                      <AddressText address={address} />
                    </span>
                  </div>
                ) : (
                  <div class="iia-address">
                    <AddressText address={address} />
                  </div>
                ))}
              {location.distance &&
                location.distance.text &&
                (designVersion === 'v2' ? (
                  <div class="iia-address-distance-container">
                    <DistanceIcon />
                    <span class="iia-address-distance">
                      {location.distance.text}
                    </span>
                  </div>
                ) : (
                  <div class="iia-address-distance">
                    {location.distance.text}
                  </div>
                ))}
              {!settings.hideLocationDetails &&
                location.phone &&
                (designVersion === 'v2' ? (
                  <div class="iia-phone-container">
                    <PhoneIcon />
                    <PhoneNumberHtml location={location} />
                  </div>
                ) : (
                  <PhoneNumberHtml location={location} />
                ))}
              {locatioNote && (
                <div
                  class="iia-note"
                  dangerouslySetInnerHTML={{ __html: locatioNote }}
                ></div>
              )}
              {enableLocationSelection && SelectedLocationInfoLink && (
                <SelectedLocationInfoLink
                  currentVariant={currentVariant}
                  settings={settings}
                  locationId={location.id}
                />
              )}
            </div>
            {state.locationError.error &&
              parseInt(state.locationError.locationId, 10) === location.id && (
                <div class="iia-location-error">
                  {state.locationError.error.message}
                </div>
              )}
            {NotifyMeButton &&
              location.id !== ONLINE_LOCATION_ID &&
              inventoryLocation.quantity <= 0 && (
                <NotifyMeButton
                  variantId={currentVariant.variant}
                  location={location}
                />
              )}
          </div>
        );
      })
    : null;
}

export async function LocationInventoryListHtml(
  settings,
  inventoryLocations,
  shopLocale,
  product
) {
  // Load default template dynamically only if itemTemplate is not set
  let itemTemplate;
  if (settings.itemTemplate) {
    itemTemplate = decodeURIComponent(settings.itemTemplate);
  } else {
    // Dynamic import - this will be loaded over network only when needed
    const defaultListTemplateModule = await import(
      './defaultListItemTemplate.html'
    );
    itemTemplate = defaultListTemplateModule.default;
  }

  const isThresholdConfigured = hasStockThresholdConfig(settings);
  const formattedPhones = await getFormattedPhones(
    settings,
    inventoryLocations.map(inventoryLocation => inventoryLocation.location)
  );
  const html = inventoryLocations
    .map(inventoryLocation => {
      const location = inventoryLocation.location;
      const locatioNote = getLocationNote(
        settings,
        location,
        inventoryLocation.quantity,
        shopLocale
      );
      let titleText = null;
      if (isThresholdConfigured) {
        titleText = getLocationThresholdItemHtml(
          settings,
          {
            quantity: inventoryLocation.quantity,
            nameOrTitleText: getLocationName(location, shopLocale),
            location
          },
          shopLocale,
          product
        );
      } else {
        titleText = getLocationQtyItemHtml(
          settings,
          {
            quantity: inventoryLocation.quantity,
            nameOrTitleText: getLocationName(location, shopLocale),
            nameHtml: HtmlFragments.locationName
          },
          shopLocale
        );
      }
      return itemTemplate
        .replaceAll(Tokens.titleText, titleText)
        .replaceAll(CommonTokens.locationId, location.id)
        .replaceAll(Tokens.address1, location.address1 || '')
        .replaceAll(Tokens.address2, location.address2 || '')
        .replaceAll(Tokens.city, location.city || '')
        .replaceAll(Tokens.province, location.province || '')
        .replaceAll(Tokens.zip, location.zip || '')
        .replaceAll(
          Tokens.phone,
          formattedPhones[location.id] || location.phone || ''
        )
        .replaceAll(Tokens.note, locatioNote || '')
        .replaceAll(Tokens.info, location.info || '');
    })
    .join('');

  return Promise.resolve(html);
}
