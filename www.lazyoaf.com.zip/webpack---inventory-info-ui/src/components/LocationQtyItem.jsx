import { Fragment, h } from '../common/preact-setup';
import {
  DefaulText,
  HtmlFragments,
  Tokens,
  wrapTextTemplatesWithHtml
} from '../domain';
import { getLocalizedString } from '../widgetV2Common';
export default function LocationQtyItem({
  settings,
  inventoryItem,
  shopLocale,
  Wrapper = null
}) {
  const { nameOrTitleText, quantity, nameHtml, location } = inventoryItem;
  const titleText = getLocationQtyItemHtml(
    settings,
    { nameOrTitleText, quantity, nameHtml },
    shopLocale
  );
  const Parent = Wrapper || Fragment;

  return (
    <Parent location={location}>
      <div
        class="iia-title-text"
        dangerouslySetInnerHTML={{ __html: titleText }}
      ></div>
    </Parent>
  );
}

export function getLocationQtyItemHtml(
  settings,
  { nameOrTitleText, quantity, nameHtml },
  shopLocale
) {
  let optionTextTemplate;
  if (settings.optionTemplateType === 'default') {
    optionTextTemplate = getLocalizedString(
      settings.defaultItemQtyTemplate,
      settings.defaultItemQtyTemplate_locales,
      shopLocale
    );
  } else if (settings.optionTemplateType === 'badge') {
    optionTextTemplate =
      getLocalizedString(
        settings.badgeItemQtyTemplate,
        settings.badgeItemQtyTemplate_locales,
        shopLocale
      ) ||
      `<span class="iia-location">${nameHtml}</span> <span class="iia-availability iia-badge iia-align-right"><span class="iia-qty">${Tokens.qty}</span> <span class="iia-available-text">${DefaulText.available}</span></span>`;
  } else {
    optionTextTemplate = getLocalizedString(
      settings.optionTextTemplate,
      settings.optionTextTemplate_locales,
      shopLocale
    );
  }

  const itemHtml = wrapTextTemplatesWithHtml(
    optionTextTemplate ||
      `${nameHtml} - ${HtmlFragments.qty} ${DefaulText.available}`
  );

  return itemHtml
    .replaceAll(Tokens.name, nameOrTitleText)
    .replaceAll(Tokens.locationName, nameOrTitleText)
    .replaceAll(
      Tokens.qty,
      quantity !== undefined ? (quantity < 0 ? 0 : quantity) : ''
    );
}
