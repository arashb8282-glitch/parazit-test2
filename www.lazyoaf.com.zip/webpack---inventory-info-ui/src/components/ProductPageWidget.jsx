import { getCurrentShop } from '../common/commonUtils';
import { h } from '../common/preact-setup';
import createOnlineStoreLocation from '../common/createOnlineStoreLocation';
import ProductPageContext from './context/ProductPageContext';
import useCurrentVariantInventory from './hooks/useCurrentVariantInventory';
import { hideSoldOutOnlinLocaiton } from '../soldOut';
import { hasStockThresholdConfig, debugLog } from '../widgetV2Common';
import { findApplicableRule } from '../utils/thresholdRuleEvaluator';

export default function ProductPageWidget({
  variantId,
  product,
  settings,
  variantLocations,
  shopLocale,
  marketId,
  b2bLinkedLocations,
  children
}) {
  const { currentVariant, inventoryLocations } = useCurrentVariantInventory(
    variantId,
    settings,
    variantLocations,
    product,
    marketId,
    b2bLinkedLocations
  );
  let onlineLocation = currentVariant
    ? createOnlineStoreLocation(
        currentVariant.inventoryLocations,
        settings,
        currentVariant
      )
    : null;

  if (onlineLocation && !onlineLocation.untracked) {
    if (hideSoldOutOnlinLocaiton(onlineLocation, settings)) {
      debugLog('Online location filtered out due to sold out rules');
      onlineLocation = null;
    }

    // Apply threshold filtering to online location
    const isThresholdConfigured = hasStockThresholdConfig(settings);
    if (isThresholdConfigured && onlineLocation) {
      const applicableRule = findApplicableRule(
        settings.stockMessageRules,
        onlineLocation.quantity || 0,
        onlineLocation.location,
        product
      );
      if (applicableRule === null) {
        debugLog(
          'Online location filtered out due to threshold rule',
          onlineLocation
        );
        onlineLocation = null;
      } else {
        debugLog(
          'Online location kept to due match threshold rule: ',
          onlineLocation
        );
      }
    }
  }

  const shop = getCurrentShop();
  return (
    <ProductPageContext.Provider
      value={{
        currentVariant,
        product,
        inventoryLocations,
        onlineLocation,
        settings,
        shopLocale,
        shop,
        marketId,
        variantLocations,
        b2bLinkedLocations
      }}
    >
      {children}
    </ProductPageContext.Provider>
  );
}
