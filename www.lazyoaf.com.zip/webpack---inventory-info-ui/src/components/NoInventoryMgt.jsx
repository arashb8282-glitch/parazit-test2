import { h } from '../common/preact-setup';
export default function NoInventoryMgt() {
  return (
    <div class="iia-list" style="padding:5px;">
      <div style="display:flex">
        <img
          style="height:32px;width:32px"
          src="https://storefront.locationinventory.info/logo.webp"
        />
        <div style="font-weight: 700;margin-left:5px;color:#cc0000">
          Errors detected
        </div>
      </div>
      <div>
        No inventory tracking found for this product, you must track inventory
        for the product within Shopify and allocate inventory to one or more
        locations, in order to use
        <strong> Kark: Multi-Location Inventory Info App.</strong>
      </div>
      <div>
        Please refer to following links from Shopify help center:
        <ul>
          <li>
            <a
              href="https://help.shopify.com/en/manual/products/inventory/transfers/enable-tracking"
              target="_shopifyHelp"
            >
              Enable inventory tracking
            </a>
          </li>
          <li>
            <a
              href="https://help.shopify.com/en/manual/locations/assigning-inventory-to-locations"
              target="_shopifyHelp"
            >
              Assigning inventory to locations
            </a>
          </li>
        </ul>
      </div>
      <div>This is visible only in design mode</div>
    </div>
  );
}
