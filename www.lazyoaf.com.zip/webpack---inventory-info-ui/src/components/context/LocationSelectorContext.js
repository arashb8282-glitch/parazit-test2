import { createContext } from '../../common/preact-setup';

const LocationSelectorContext = createContext({
  locations: null,
  settings: null,
  locationSettings: null,
  shopLocale: null,
  shop: null,
  selectedLocationId: null,
  selectionError: null,
  onLocationChange: null
});

export default LocationSelectorContext;
