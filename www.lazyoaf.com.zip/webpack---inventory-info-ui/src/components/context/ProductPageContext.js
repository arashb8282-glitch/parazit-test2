import { createContext } from '../../common/preact-setup';

const ProductPageContext = createContext({
  currentVariant: null,
  product: null,
  variantLocations: [],
  inventoryLocations: [],
  onlineLocation: null,
  settings: null,
  shopLocale: null,
  shop: null,
  marketId: null,
  b2bLinkedLocations: []
});

export default ProductPageContext;
