/** @jsx h */
import {
  h,
  Fragment,
  useState,
  useEffect,
  useContext
} from '../common/preact-setup';
import { Tokens } from '../domain';
import ProductPageContext from './context/ProductPageContext';

export default function LocationListView({
  children,
  inventoryLocations,
  htmlChildrenFunc,
  containerCssClass,
  footerSlot
}) {
  const [state, setState] = useState({
    htmlChildren: null
  });

  const { currentVariant, settings, shopLocale, product } = useContext(
    ProductPageContext
  );
  useEffect(() => {
    if (settings.itemTemplate || settings.containerTemplate) {
      htmlChildrenFunc(settings, inventoryLocations, shopLocale, product).then(
        html => setState({ ...state, htmlChildren: html })
      );
    }
  }, [currentVariant, inventoryLocations]);

  return settings.containerTemplate ? (
    <Fragment>
      <div
        dangerouslySetInnerHTML={{
          __html: decodeURIComponent(settings.containerTemplate).replaceAll(
            Tokens.options,
            state.htmlChildren || ''
          )
        }}
      />
      {footerSlot}
    </Fragment>
  ) : (
    <Fragment>
      <div
        className={containerCssClass}
        dangerouslySetInnerHTML={
          state.htmlChildren ? { __html: state.htmlChildren } : undefined
        }
      >
        {!settings.itemTemplate && children}
      </div>
      {footerSlot}
    </Fragment>
  );
}
