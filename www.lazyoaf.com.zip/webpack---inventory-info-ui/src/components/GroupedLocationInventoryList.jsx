/** @jsx h */
import { Fragment, h, useContext } from '../common/preact-setup';
import { HtmlFragments } from '../domain';
import {
  getLocationName,
  getLocationNote,
  getVariantTitleHtml,
  hasStockThresholdConfig
} from '../widgetV2Common';
import ProductPageContext from './context/ProductPageContext';
import LocationQtyItem from './LocationQtyItem';
import LocationThresholdItem from './LocationThresholdItem';

export default function GroupedLocationInventoryList({
  groupedLocations,
  footerSlot
}) {
  const { settings, shopLocale, currentVariant, product } = useContext(
    ProductPageContext
  );
  const isThresholdConfigured = hasStockThresholdConfig(settings);
  const SelectedLocationInfoLink =
    window.inventoryInfo.components.SelectedLocationInfoLink;
  const LocationSelectionError =
    window.inventoryInfo.components.LocationSelectionError;
  const NotifyMeButton = window.inventoryInfo.components.NotifyMeButton;

  return groupedLocations ? (
    <Fragment>
      <div class="iia-list">
        {groupedLocations.map(grouped => {
          const locatioNote = getLocationNote(
            settings,
            grouped.location,
            undefined,
            shopLocale
          );
          return (
            <div class={`iia-list-item iia-id-${grouped.location.id}`}>
              <div class="iia-groupby-header-container">
                <div
                  class="iia-groupby-header iia-location"
                  dangerouslySetInnerHTML={{
                    __html: getLocationName(grouped.location, shopLocale)
                  }}
                ></div>
                {grouped.location.distance &&
                  grouped.location.distance.text && (
                    <div class="iia-address-distance">
                      {grouped.location.distance.text}
                    </div>
                  )}
                {locatioNote && (
                  <div
                    class="iia-note"
                    dangerouslySetInnerHTML={{ __html: locatioNote }}
                  ></div>
                )}
                {SelectedLocationInfoLink && (
                  <SelectedLocationInfoLink
                    currentVariant={currentVariant}
                    settings={settings}
                    locationId={grouped.location.id}
                  />
                )}
              </div>
              {grouped.variants.map(variant => {
                const varaintTitleHtml = getVariantTitleHtml(variant.name);
                const showBis = NotifyMeButton && variant.quantity <= 0;
                return (
                  <div
                    class={`iia-grouped-item${
                      showBis ? ' iia-grouped-item-notify' : ''
                    }`}
                  >
                    {isThresholdConfigured ? (
                      <LocationThresholdItem
                        settings={settings}
                        inventoryItem={{
                          quantity: variant.quantity,
                          nameOrTitleText: varaintTitleHtml,
                          location: grouped.location
                        }}
                        shopLocale={shopLocale}
                        product={product}
                      />
                    ) : (
                      <LocationQtyItem
                        settings={settings}
                        inventoryItem={{
                          quantity: variant.quantity,
                          nameOrTitleText: varaintTitleHtml,
                          nameHtml: HtmlFragments.name
                        }}
                        shopLocale={shopLocale}
                      />
                    )}
                    {showBis && (
                      <NotifyMeButton
                        variantId={variant.id}
                        location={grouped.location}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
      {footerSlot}
      {LocationSelectionError && <LocationSelectionError />}
    </Fragment>
  ) : null;
}
