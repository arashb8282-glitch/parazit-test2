import { Fragment, h } from '../common/preact-setup';
import {
  HtmlFragments,
  Tokens,
  wrapTextTemplatesWithHtml,
  DefaulText
} from '../domain';
import { findApplicableRule } from '../utils/thresholdRuleEvaluator';
import { getLocalizedString } from '../widgetV2Common';
import { CrossIcon, DotIcon, ExclamationIcon, TickIcon } from './common/Icons';
export default function LocationThresholdItem({
  settings,
  inventoryItem,
  shopLocale,
  product,
  Wrapper = null
}) {
  const { nameOrTitleText, quantity, location } = inventoryItem;
  const Parent = Wrapper || Fragment;

  const thresholdHtml = getLocationThresholdItemHtml(
    settings,
    { nameOrTitleText, quantity, location },
    shopLocale,
    product
  );

  return thresholdHtml ? (
    <Parent location={location}>
      <div
        class="iia-title-text"
        dangerouslySetInnerHTML={{
          __html: thresholdHtml
        }}
      />
    </Parent>
  ) : null;
}

export function getLocationThresholdItemHtml(
  settings,
  { nameOrTitleText, quantity, location },
  shopLocale,
  product
) {
  const stockInfo = stockMessage(
    settings.thresholdMessageTemplateType,
    settings.stockMessageRules,
    nameOrTitleText,
    quantity || 0,
    location,
    shopLocale,
    product
  );

  return stockInfo
    ? stockInfo.titleMsg
    : `<span class="iia-stockMsg-error">${DefaulText.StockMessageError}</span>`;
}

function stockMessage(
  thresholdMessageTemplateType,
  rules,
  name,
  qty,
  location,
  shopLocale,
  product
) {
  const applicableRule = findApplicableRule(rules, qty, location, product);

  if (applicableRule) {
    const rule = buildRuleMessage(
      thresholdMessageTemplateType,
      applicableRule,
      name,
      qty,
      shopLocale
    );
    return rule;
  }

  return null;
}

function buildRuleMessage(
  thresholdMessageTemplateType,
  rule,
  name,
  qty,
  shopLocale
) {
  const displayQty = qty < 0 ? 0 : qty;

  let thresholdTemplate =
    rule.msg || `${Tokens.locationName} - ${Tokens.threshold}`;

  if (thresholdMessageTemplateType === 'shopify-style') {
    thresholdTemplate = rule.shopifyThresholdTmpl || getShopifyStyleHtml(rule);
  } else if (thresholdMessageTemplateType === 'badge') {
    thresholdTemplate =
      rule.badgeThresholdTmpl ||
      `<span class="iia-location">${Tokens.locationName}</span> <span class="iia-availability iia-badge iia-align-right"><span class="iia-stock-threshold">${Tokens.threshold}</span></span>`;
  } else if (
    thresholdMessageTemplateType === 'default' &&
    rule.defaultThresholdTmpl
  ) {
    thresholdTemplate = rule.defaultThresholdTmpl;
  }

  let threshold = getLocalizedString(
    rule.threshold,
    rule.threshold_locales,
    shopLocale
  );

  rule.titleMsg = wrapTextTemplatesWithHtml(thresholdTemplate)
    .replace(Tokens.locationName, name)
    .replace(Tokens.name, name)
    .replace(Tokens.qty, displayQty)
    .replace(
      Tokens.threshold,
      threshold ? threshold.replace(Tokens.qty, qty) : ''
    )
    .replace(
      Tokens.thresholdColorStyle,
      rule.thresholdColor
        ? HtmlFragments.thresholdColorStyle.replace(
            Tokens.thresholdColor,
            rule.thresholdColor
          )
        : ''
    );

  return rule;
}

function getShopifyStyleHtml(rule) {
  let icon = TickIcon();
  let iconClass = 'iia-threshold-icon-tick';
  let iconColor = '#22C55E';
  if (rule.iconKind === 'cross') {
    icon = CrossIcon();
    iconClass = 'iia-threshold-icon-cross';
    iconColor = '#FD1A20';
  } else if (rule.iconKind === 'exclamation') {
    icon = ExclamationIcon();
    iconClass = 'iia-threshold-icon-exclamation';
    iconColor = '#F59E0B';
  } else if (rule.iconKind === 'dot') {
    icon = DotIcon();
    iconClass = 'iia-threshold-icon-dot';
    iconColor = '#000000';
  }
  return `<div class="iia-threshold-shopify"><span class="iia-location">${Tokens.locationName}</span>
        <div class="iia-threshold-shopify-row">
          <span class="iia-threshold-icon ${iconClass}" style="color: ${iconColor}">${icon}</span>
          <span class="iia-stock-threshold">${Tokens.threshold}</span>
        </div>
      </div>`;
}
