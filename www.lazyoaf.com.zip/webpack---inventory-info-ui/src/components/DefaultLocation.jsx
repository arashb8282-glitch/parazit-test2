import { ONLINE_LOCATION_ID } from '../common/commonUtils';
import { h, useContext, useEffect, useState } from '../common/preact-setup';
import { getDefaultLocationId, hasDefaultLocation } from '../widgetV2Common';
import ProductPageContext from './context/ProductPageContext';
import LocationInventoryList from './LocationInventoryList';
export default function DefaultLocation() {
  const { settings, inventoryLocations, onlineLocation } = useContext(
    ProductPageContext
  );

  const getDefaultLocation = () => {
    if (hasDefaultLocation(settings)) {
      let selectedLocationId;
      if (window.inventoryInfo.api.getSelectedLocationId) {
        selectedLocationId = window.inventoryInfo.api.getSelectedLocationId();
      }

      const defaultLocation = inventoryLocations.find(inventoryLocation =>
        settings.defaultLocation.firstInStock && !selectedLocationId
          ? inventoryLocation.quantity > 0
          : inventoryLocation.location.id ===
            (selectedLocationId || settings.defaultLocation.id)
      );
      if (
        !defaultLocation &&
        getDefaultLocationId(settings) === ONLINE_LOCATION_ID
      ) {
        return onlineLocation;
      }
      return defaultLocation;
    }
  };
  const [defaultLocation, setDefaultLocation] = useState(null);
  useEffect(() => {
    setDefaultLocation(getDefaultLocation());
  }, [inventoryLocations]);
  return defaultLocation ? (
    <div class="iia-default-loc">
      <LocationInventoryList inventoryLocations={[defaultLocation]} />
    </div>
  ) : null;
}
