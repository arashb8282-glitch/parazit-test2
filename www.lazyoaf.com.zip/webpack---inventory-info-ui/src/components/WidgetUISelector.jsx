import {
  Fragment,
  h,
  useContext,
  useEffect,
  useState,
  useLayoutEffect
} from '../common/preact-setup';
import ProductPageContext from './context/ProductPageContext';
import DrawerView from './DrawerView';
import ExpandableView from './common/ExpandableView';
import ListComponent from './ListComponent';
import useDynamicComponentLoader from './hooks/useDyanmicComponentLoader';
import {
  debugLog,
  expandableAllowed,
  getDefaultLocationId,
  hasDefaultLocation,
  isGeoSearch,
  isGroupedByLocationList
} from '../widgetV2Common';
import Footer from './common/Footer';
import GroupedLocationInventoryList from './GroupedLocationInventoryList';
import { fireEvent } from '../utils';
import { Events } from '../domain';
import useIncomingInventory from './hooks/useIncomingInventory';
import NoInventoryMgt from './NoInventoryMgt';
import { isInDesignMode, ONLINE_LOCATION_ID } from '../common/commonUtils';
import useGroupedByLocations from './hooks/useGroupedByLocations';
import isHiddenForCollection from '../isHiddenForCollection';
import DefaultLocation from './DefaultLocation';
import NoLocationsMessage from './NoLocationsMessage';
export default function WidgetUISelector() {
  const {
    currentVariant,
    settings,
    inventoryLocations,
    variantLocations,
    onlineLocation,
    shopLocale,
    product
  } = useContext(ProductPageContext);
  const { hasIncomingInventory } = useIncomingInventory();
  // Call hook at top level - always call it
  const hasGeoSearch = isGeoSearch(settings);
  const GeoSearch = useDynamicComponentLoader(
    hasGeoSearch ? 'GeoSearch' : null
  );
  const IncomingInventory = useDynamicComponentLoader(
    hasIncomingInventory ? 'IncomingInventory' : null
  );

  const [state, setState] = useState({
    inventoryLocations,
    isGroupedByLocationRendering: false
  });

  useEffect(() => {
    setState({ inventoryLocations });
  }, [inventoryLocations]);

  useLayoutEffect(() => {
    fireEvent(Events.APP_RENDERED_EVENT);
  }, [state.inventoryLocations]);

  if (
    currentVariant &&
    !currentVariant.inventoryManagement &&
    isInDesignMode() &&
    !onlineLocation
  ) {
    return <NoInventoryMgt />;
  }

  let onlineLocationToUse = onlineLocation;
  let DefaultLocationSlot = null;
  if (
    (settings.drawer || expandableAllowed(settings)) &&
    hasDefaultLocation(settings) &&
    !isGroupedByLocationList(settings, product)
  ) {
    DefaultLocationSlot = <DefaultLocation />;
    if (getDefaultLocationId(settings) === ONLINE_LOCATION_ID) {
      onlineLocationToUse = null;
    }
  }
  const LocationSelectionError =
    window.inventoryInfo.components.LocationSelectionError;
  let children =
    state.inventoryLocations.length > 0 || onlineLocationToUse ? (
      <ListComponent
        onlineLocation={onlineLocationToUse}
        inventoryLocations={state.inventoryLocations}
        footerSlot={
          <Fragment>
            <Footer />
            {LocationSelectionError && <LocationSelectionError />}
            {hasIncomingInventory && IncomingInventory && <IncomingInventory />}
          </Fragment>
        }
      />
    ) : null;

  const isIncomingOnly =
    state.inventoryLocations.length === 0 &&
    !onlineLocationToUse &&
    hasIncomingInventory;

  const { hasGroupedByLocation, groupedLocations } = useGroupedByLocations({
    variantLocations
  });

  if (hasGeoSearch) {
    if (!GeoSearch) {
      return null;
    }
    if (isHiddenForCollection(settings, product)) {
      debugLog(
        'Hiding Geo Search View Based on collection visibility settings'
      );
      return null;
    }
    children = <GeoSearch />;
  } else if (hasGroupedByLocation) {
    children =
      groupedLocations && groupedLocations.length > 0 ? (
        <GroupedLocationInventoryList
          groupedLocations={groupedLocations}
          footerSlot={<Footer settings={settings} shopLocale={shopLocale} />}
        />
      ) : null;
  }

  switch (true) {
    case settings.hideWidget:
      debugLog('Widget is hidden via settings');
      return LocationSelectionError ? <LocationSelectionError /> : null;
    case isIncomingOnly:
      debugLog('Rendering Incoming Only View');
      return IncomingInventory ? <IncomingInventory /> : null;
    case !children && !DefaultLocationSlot:
      debugLog('Widget has no inventory locations to display');
      if (settings.noLocationsMsg) {
        //Bug fix: If no locations message is set, show the no locations message
        return <NoLocationsMessage />;
      }
      return LocationSelectionError ? <LocationSelectionError /> : null;
    case settings.drawer:
      debugLog(
        children ? 'Rendering Drawer View' : 'Drawer View has no content'
      );
      return (
        <DrawerView defaultLocationSlot={DefaultLocationSlot}>
          {children}
        </DrawerView>
      );

    default:
      if (children || DefaultLocationSlot) {
        debugLog('Rendering Default ExpandableView');
        return (
          <ExpandableView defaultLocationSlot={DefaultLocationSlot}>
            {children}
          </ExpandableView>
        );
      }
      debugLog('No content to display');

      return null;
  }
}
