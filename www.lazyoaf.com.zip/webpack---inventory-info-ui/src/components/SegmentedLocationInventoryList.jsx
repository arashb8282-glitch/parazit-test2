import { h, Fragment, useContext } from '../common/preact-setup';
import ProductPageContext from './context/ProductPageContext';
import LocationInventoryList from './LocationInventoryList';
export default function SegmentedLocationInventoryList({
  inventoryLocations,
  onlineLocation
}) {
  const { settings, shopLocale } = useContext(ProductPageContext);
  let onlineLocationHeaderText = settings.onlineLocationHeader;
  if (
    settings.onlineLocationHeader_locales &&
    Object.keys(settings.onlineLocationHeader_locales).length > 0 &&
    settings.onlineLocationHeader_locales[shopLocale]
  ) {
    onlineLocationHeaderText =
      settings.onlineLocationHeader_locales[shopLocale];
  }

  let storeLocationHeaderText = settings.storeLocationHeader;
  if (
    settings.storeLocationHeader_locales &&
    Object.keys(settings.storeLocationHeader_locales).length > 0 &&
    settings.storeLocationHeader_locales[shopLocale]
  ) {
    storeLocationHeaderText = settings.storeLocationHeader_locales[shopLocale];
  } else {
    storeLocationHeaderText = 'In store';
  }

  const OnlineLocationFragment = () => {
    return onlineLocation ? (
      <Fragment>
        {onlineLocationHeaderText && (
          <div
            class="iia-location-header iia-online-header"
            dangerouslySetInnerHTML={{ __html: onlineLocationHeaderText }}
          />
        )}
        <div class="iia-online-location">
          <LocationInventoryList
            inventoryLocations={[onlineLocation]}
            enableLocationSelection={true}
          />
        </div>
      </Fragment>
    ) : null;
  };
  const StoreLocationFragment = () => {
    return inventoryLocations && inventoryLocations.length > 0 ? (
      <Fragment>
        {storeLocationHeaderText && (
          <div
            class="iia-location-header iia-store-header"
            dangerouslySetInnerHTML={{ __html: storeLocationHeaderText }}
          />
        )}
        <div class="iia-list-stores">
          <LocationInventoryList
            inventoryLocations={inventoryLocations}
            enableLocationSelection={true}
          />
        </div>
      </Fragment>
    ) : null;
  };
  return inventoryLocations || onlineLocation ? (
    <Fragment>
      <OnlineLocationFragment />
      <StoreLocationFragment />
    </Fragment>
  ) : null;
}
