import {
  Fragment,
  h,
  useContext,
  useState,
  useEffect
} from '../common/preact-setup';
import ProductPageContext from './context/ProductPageContext';
import { StoreIcon } from './common/Icons';
import Drawer from './common/Drawer';

import { CommonEvents } from '../common/commonUi';
import trackUsage, { USAGE_KEYS } from '../common/trackUsage';
import { isGeoSearch } from '../widgetV2Common';
import loadGoogleMapsApi from '../common/loadGoogleMapsApi';

export default function DrawerView({ children, defaultLocationSlot }) {
  const { settings, shopLocale, product } = useContext(ProductPageContext);
  const [state, setState] = useState({
    open: false
  });
  const headerText =
    settings.header_locales && settings.header_locales[shopLocale]
      ? settings.header_locales[shopLocale]
      : settings.header;
  const showHeader = settings.showDrawerHeader && headerText;
  const drawerDescription =
    settings.drawerDesc_locales && settings.drawerDesc_locales[shopLocale]
      ? settings.drawerDesc_locales[shopLocale]
      : settings.drawerDesc;

  const drawerLinkLabel =
    settings.drawerLabel_locales && settings.drawerLabel_locales[shopLocale]
      ? settings.drawerLabel_locales[shopLocale]
      : settings.drawerLabel || 'Store Availability';

  const preloadGoogleMaps = () => {
    if (isGeoSearch(settings)) {
      loadGoogleMapsApi(settings.geo.apiKey);
    }
  };

  const openDrawer = () => {
    preloadGoogleMaps();
    setState(prevState => ({ ...prevState, open: true }));
  };

  document.addEventListener(CommonEvents.SELECTED_LOCATION_ID_CHANGED, e => {
    if (e.detail.locationId) {
      setState(prevState => ({ ...prevState, open: false }));
    }
  });
  useEffect(() => {
    window.inventoryInfo.showAvailabilityDrawer = () => {
      openDrawer();
    };
  }, []);
  useEffect(() => {
    if (state.open) {
      trackUsage(USAGE_KEYS.drawerOpened, product);
    }
  }, [state.open]);
  return (
    <Fragment>
      <div class="iia-drawer-link-parent">
        {defaultLocationSlot}

        {children && (
          <div class="iia-drawer-link-container">
            <StoreIcon iconColor={settings.iconColor} />

            <a
              class="iia-drawer-link"
              href="#"
              onMouseEnter={preloadGoogleMaps}
              onFocus={preloadGoogleMaps}
              onClick={e => {
                e.preventDefault();
                openDrawer();
              }}
              dangerouslySetInnerHTML={{ __html: drawerLinkLabel }}
            ></a>
          </div>
        )}
      </div>

      {state.open && (
        <Drawer
          open={state.open}
          title={showHeader ? headerText : null}
          descritpion={drawerDescription}
          onClose={() => setState({ ...state, open: false })}
        >
          {children}
        </Drawer>
      )}
    </Fragment>
  );
}
