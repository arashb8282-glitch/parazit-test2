import SegmentedLocationInventoryList from './SegmentedLocationInventoryList';
import { h, useContext } from '../common/preact-setup';
import { Type } from '../domain';
import LocationInventoryList, {
  LocationInventoryListHtml
} from './LocationInventoryList';
import LocationListView from './LocationListView';
import ProductPageContext from './context/ProductPageContext';
export default function ListComponent({
  inventoryLocations,
  containerCssClass = 'iia-list',
  footerSlot,
  onlineLocation
}) {
  const { settings } = useContext(ProductPageContext);

  const children =
    onlineLocation && settings.templateType === Type.LOCATION_SEGMENTS ? (
      <SegmentedLocationInventoryList
        inventoryLocations={inventoryLocations}
        onlineLocation={onlineLocation}
      />
    ) : (
      <LocationInventoryList
        enableLocationSelection={true}
        inventoryLocations={
          onlineLocation
            ? [onlineLocation, ...inventoryLocations]
            : inventoryLocations
        }
      />
    );
  return (
    <LocationListView
      inventoryLocations={
        onlineLocation
          ? [onlineLocation, ...inventoryLocations]
          : inventoryLocations
      }
      htmlChildrenFunc={LocationInventoryListHtml}
      containerCssClass={containerCssClass}
      footerSlot={footerSlot}
    >
      {children}
    </LocationListView>
  );
}
