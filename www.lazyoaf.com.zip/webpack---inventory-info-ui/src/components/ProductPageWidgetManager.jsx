/** @jsx h */
import { get, getLocations } from '../common/api';
import { h, render, useLayoutEffect } from '../common/preact-setup';
import styles from '../styles.scss';
import { injectStyles } from '../injectStyles';
import {
  getCurrentShopLocale,
  getCurrentMarketId,
  getB2BLinkedLocations
} from '../common/commonUtils';
import watchHiddenInputChange, {
  VARIANT_CHANGED_EVENT
} from '../hiddenVariantIdWatcher';
import { PAGE_URL_CHANGED_EVENT } from '../replaceStatePatch';
import { fireEvent } from '../utils';
import ProductPageWidget from '././ProductPageWidget';

import WidgetUISelector from './WidgetUISelector';
import trackUsage, { USAGE_KEYS } from '../common/trackUsage';
import { debugLog, isDisplayForB2BOnly } from '../widgetV2Common';
import { isB2bCustomer } from '../common/commonUtils';
// Pure Preact component - no hooks, no state, just JSX templating
function ProductPageWidgetManager({
  productIdentifier,
  product,
  settings,
  variantLocations
}) {
  const shopLocale = getCurrentShopLocale();
  const marketId = getCurrentMarketId();
  const b2bLinkedLocations = getB2BLinkedLocations();
  useLayoutEffect(() => {
    trackUsage(USAGE_KEYS.impression, product);
  }, []);
  return (
    <ProductPageWidget
      product={product}
      variantId={productIdentifier.variant}
      settings={settings}
      variantLocations={variantLocations}
      shopLocale={shopLocale}
      marketId={marketId}
      b2bLinkedLocations={b2bLinkedLocations}
    >
      <WidgetUISelector />
    </ProductPageWidget>
  );
}

export default async function renderProductPageWidget(
  container,
  shop,
  product,
  productIdentifier,
  parentContainer
) {
  if (isDisplayForB2BOnly(window.inventoryInfo.settings) && !isB2bCustomer()) {
    debugLog('Widget is not displayed for B2C customer');
    return;
  }
  const data = await getProductInventory(
    shop,
    productIdentifier.handle,
    productIdentifier.id
  );
  const settings = data.settings;
  const variantLocations = data.variantLocations;
  if (settings.loggedInOnly && !window.inventoryInfo.customerLoggedIn) {
    return;
  }

  // hoook up various ways to detect variant change
  if (settings.onHiddenIdChange) {
    watchHiddenInputChange(settings, parentContainer);
  } else if (settings && settings.variantSelector) {
    const variantSelectorElements = parentContainer.querySelectorAll(
      settings.variantSelector
    );
    if (variantSelectorElements) {
      for (let i = 0; i < variantSelectorElements.length; i++) {
        handleVariantChange(variantSelectorElements[i]);
      }
    }
  } else {
    document.addEventListener(PAGE_URL_CHANGED_EVENT, () => {
      window.setTimeout(() => {
        const urlSearchParams = new URLSearchParams(window.location.search);
        if (urlSearchParams.has('variant')) {
          const variantId = parseInt(urlSearchParams.get('variant'));
          if (!isNaN(variantId) && variantId) {
            {
              fireEvent(VARIANT_CHANGED_EVENT, { variantId });
            }
          }
        }
      });
    });
  }
  if (settings.lineItemLocations) {
    import('../trackLocationsInLineItemProps').then(module => {
      module.default(
        productIdentifier,
        settings,
        variantLocations,
        parentContainer,
        product
      );
    });
  }
  addStyles(settings);
  // Use Preact as pure templating engine (no hooks, no state)
  render(
    <ProductPageWidgetManager
      productIdentifier={productIdentifier}
      product={product}
      settings={settings}
      variantLocations={variantLocations}
    />,
    container
  );
}

export function resetProductPageWidget(container) {
  render(null, container);
  debugLog('Component unmounted, container reset');
}

async function getProductInventory(shop, productHandle, id) {
  const knownSettings = window.inventoryInfo && window.inventoryInfo.settings;
  if (knownSettings && knownSettings.showUnConnected) {
    const [data, locationsData, unconnectedLocations] = await Promise.all([
      get(shop, productHandle, id),
      getLocations(shop),
      import('../unconnectedLocations')
    ]);
    return {
      ...data,
      variantLocations: unconnectedLocations.addUnconnectedLocations(
        data.variantLocations,
        locationsData.locations
      )
    };
  }
  return get(shop, productHandle, id);
}

function handleVariantChange(variantSelectorElement) {
  const handler = () =>
    window.setTimeout(function() {
      const variantId = ShopifyAnalytics.meta.selectedVariantId
        ? parseInt(ShopifyAnalytics.meta.selectedVariantId)
        : undefined;
      fireEvent(VARIANT_CHANGED_EVENT, { variantId });
    });
  variantSelectorElement.addEventListener('change', handler);
}

function addStyles(settings) {
  injectStyles(styles[0][1]);

  const overrides = getStyleOverride(settings);
  if (overrides) {
    injectStyles(overrides);
  }
  if (settings.css) {
    debugLog('Injecting custom CSS for product page widget');
    injectStyles(decodeURIComponent(settings.css));
  }
}

function getStyleOverride(settings) {
  let overrides = '';

  if (settings.hideBorders) {
    overrides +=
      ' .iia-store-header, .iia-online-header, .iia-list {border-width:0px;} .iia-list > .iia-list-item ~ .iia-list-item {border-top-width:0px;}';
  }

  if (settings.hideLocationDetails) {
    overrides += ' .iia-address, .iia-phone {display:none;}';
  }

  if (settings.qtyColor || settings.qtyBold) {
    overrides += ` .iia-qty {${settings.qtyBold ? 'font-weight:700;' : ''} ${
      settings.qtyColor ? 'color:' + settings.qtyColor + ';' : ''
    }}`;
  }

  if (settings.locationColor || settings.locationBold) {
    overrides += ` .iia-location {${
      settings.locationBold ? 'font-weight:700;' : ''
    } ${
      settings.locationColor ? 'color:' + settings.locationColor + ';' : ''
    }}`;
  }

  if (settings.infoColor || settings.infoBold) {
    overrides += ` .iia-info, .iia-note{${
      settings.infoBold ? 'font-weight:700;' : ''
    } ${settings.infoColor ? 'color:' + settings.infoColor + ';' : ''}}`;
  }

  if (
    settings.optionTemplateType === 'badge' ||
    settings.optionTemplateType === 'default' ||
    settings.thresholdMessageTemplateType === 'badge' ||
    settings.thresholdMessageTemplateType === 'default'
  ) {
    overrides += ' .iia-title-text { display: flex; gap: 6px; }';
  }

  return overrides;
}
