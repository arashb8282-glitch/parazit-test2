import { h, useContext } from '../common/preact-setup';
import { StoreIcon } from './common/Icons';
import ProductPageContext from './context/ProductPageContext';

export default function NoLocationMessage() {
  const { settings, shopLocale } = useContext(ProductPageContext);
  const noLocationsMsgText =
    settings.noLocationsMsg_locales &&
    settings.noLocationsMsg_locales[shopLocale]
      ? settings.noLocationsMsg_locales[shopLocale]
      : settings.noLocationsMsg;
  return (
    <div class="iia-no-locations-msg-container">
      <StoreIcon iconColor="currentColor" />
      <div
        class="iia-no-locations-msg-text"
        dangerouslySetInnerHTML={{
          __html: noLocationsMsgText
        }}
      />
    </div>
  );
}
