//om sai ram

import bootstrapContainer, { CONTAINER_ID } from './bootstrapContainer';
import { get } from './common/api';
import { getCurrentShop, waitForElementOnDoc } from './common/commonUtils';
import { setupAtcBlocking } from './components/hooks/setupAtcBlocking.js';
import renderProductPageWidget, {
  resetProductPageWidget
} from './components/ProductPageWidgetManager';
import { Events } from './domain.js';
import {
  getSelectedvariant,
  VARIANT_CHANGED_EVENT
} from './hiddenVariantIdWatcher.js';
import { isPreview, setUpPreview } from './isPreview.js';
import replaceStatePatch from './replaceStatePatch.js';
import { fireEvent, getProductIdentifiers, isProductPage } from './utils';
import {
  debugLog,
  hasBackInStockNotificationEnabled,
  loadLocationSelectionUI,
  shouldHideWidgetForMarket,
  log
} from './widgetV2Common.js';

async function loadOnProductPage(
  identifier,
  parentContainerSelector,
  forceBootstrapDefault,
  unmount,
  product
) {
  const parentContainer = parentContainerSelector
    ? document.querySelector(parentContainerSelector)
    : document;
  let container;
  let settings = window.inventoryInfo.settings;
  const shop = getCurrentShop();
  if (window.inventoryInfo && window.inventoryInfo.legacyApi) {
    const data = await get(shop, identifier.handle, identifier.id);
    settings = data.settings;
  }

  if (settings && !settings.uiEnabled && !isPreview()) {
    return;
  }

  container = await bootstrapContainer(
    settings,
    parentContainer,
    forceBootstrapDefault || unmount
  );

  if (container) {
    if (unmount) {
      resetProductPageWidget(container);
    }
    debugLog('Found container to render the product page widget');
    setupAtcBlocking(settings, parentContainer);
    return loadLocationSelectionUI().then(() => {
      renderProductPageWidget(
        container,
        shop,
        product || window.inventoryInfo.product,
        identifier,
        parentContainer
      );
      return container;
    });
  } else {
    log('No container found to render the product page widget');
    return null;
  }
}
setUpPreview();
bootstrapCommonApis();

if (hasBackInStockNotificationEnabled()) {
  import('./components/BackInStockUIManager').then(() => {
    debugLog(
      'Back in stock notification enabled, APIs and components registered'
    );
  });
}
if (isProductPage()) {
  bootstrapProductPageApis();
  if (
    window.inventoryInfo.settings &&
    !window.inventoryInfo.settings.apiLoadOnly
  ) {
    if (shouldHideWidgetForMarket(window.inventoryInfo.settings)) {
      debugLog('Widget hidden for unmapped market');
    } else {
      const identifier = getProductIdentifiers(
        null,
        window.inventoryInfo.product
      );
      loadOnProductPage(identifier).then(container => {
        if (container) {
          document.addEventListener(VARIANT_CHANGED_EVENT, e => {
            if (e.detail.variantId) {
              //ensure container is still in the DOM
              if (document.getElementById(container.id)) {
                return;
              } else {
                log(
                  'Container removed from DOM, reloading the app for variant ' +
                    e.detail.variantId
                );
                window.setTimeout(() => {
                  loadOnProductPage(
                    {
                      ...identifier,
                      variant: e.detail.variantId
                    },
                    null,
                    true
                  );
                }, window.inventoryInfo.settings.reloadDelay || 0);
              }
            }
          });
        }
      });
      replaceStatePatch(window.history);
    }
  }
} else {
  loadLocationSelectionUI().then(() => {
    debugLog('Location selection UI loaded');
  });
}
window.inventoryInfo.api.loadApp = (
  productIdentifier,
  parentContainerSelector,
  sectionId
) => {
  if (
    !window.inventoryInfo.product ||
    productIdentifier.handle !== window.inventoryInfo.product.handle
  ) {
    import('./loadProductFromSection').then(module => {
      module.default(productIdentifier.handle, sectionId).then(product => {
        loadOnProductPage(
          {
            ...productIdentifier,
            id: product.id,
            variant: product.variant
              ? parseInt(product.variant, 10)
              : product.variant
          },
          parentContainerSelector,
          false,
          true,
          product
        );
      });
    });
  } else {
    loadOnProductPage(
      {
        ...productIdentifier,
        variant: productIdentifier.variant
          ? parseInt(productIdentifier.variant, 10)
          : productIdentifier.variant
      },
      parentContainerSelector,
      false,
      true
    );
  }
};

window.inventoryInfo.api.unloadApp = parentContainerSelector => {
  const parentContainer = parentContainerSelector
    ? document.querySelector(parentContainerSelector)
    : document;
  if (!parentContainer) {
    log('unloadApp: parent container not found', parentContainerSelector);
    return;
  }
  const container = parentContainer.querySelector(`#${CONTAINER_ID}`);
  if (!container) {
    debugLog('unloadApp: app container not found');
    return;
  }
  resetProductPageWidget(container);
};

function bootstrapProductPageApis() {
  window.inventoryInfo.api.getProductIdentifiers = variant => {
    return getProductIdentifiers(variant, window.inventoryInfo.product);
  };
  window.inventoryInfo.api.getSelectedvariant = function(
    parentContainerSelector
  ) {
    return getSelectedvariant(
      window.inventoryInfo.settings,
      document.querySelector(parentContainerSelector)
    );
  };
}

function bootstrapCommonApis() {
  window.inventoryInfo = window.inventoryInfo || {};
  window.inventoryInfo.api = window.inventoryInfo.api || {};
  window.inventoryInfo.components = window.inventoryInfo.components || {};
  window.inventoryInfo.hooks = window.inventoryInfo.hooks || {};
  window.inventoryInfo.internalApis = window.inventoryInfo.internalApis || {};
  window.inventoryInfo.api.waitForElementOnDoc = waitForElementOnDoc;
}

fireEvent(Events.APP_LOADED_EVENT);
