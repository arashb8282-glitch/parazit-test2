import { euCountries, euAndEeaCountries } from './eu';
export function getLocationsForCurrentCountry(settings, inventoryLocations) {
  return new Promise(function(resolve) {
    if (!settings.showLocationByRules) {
      resolve(inventoryLocations);
      return;
    }
    getAssoicatedCountries(settings).then(function(associatedCountries) {
      if (!associatedCountries || associatedCountries.length === 0) {
        resolve(inventoryLocations);
        return;
      }
      const countryLocations = getInventoryLocationsForCountry(
        associatedCountries,
        inventoryLocations
      );
      resolve(countryLocations);
    });
  });
}
function getCodeForMarkets(settings) {
  return settings.marketsCountryCode &&
    window.inventoryInfo.markets &&
    window.inventoryInfo.markets.isoCode
    ? window.inventoryInfo.markets.isoCode
    : settings.marketsCountryCode && window.Shopify.country;
}

function determineCountryCode(settings, countryCode) {
  return new Promise(function(resolve) {
    if (countryCode) {
      resolve(countryCode);
      return;
    }
    if (window.inventoryInfo.currentCountryCode) {
      resolve(window.inventoryInfo.currentCountryCode);
      return;
    }

    const marketCountryCode = getCodeForMarkets(settings);
    if (marketCountryCode) {
      window.inventoryInfo.currentCountryCode = marketCountryCode;
      resolve(window.inventoryInfo.currentCountryCode);
      return;
    }
    const xhr = new XMLHttpRequest();
    xhr.open('GET', '/browsing_context_suggestions.json');
    xhr.onload = function() {
      if (xhr.status === 200) {
        const context = JSON.parse(xhr.responseText);
        window.inventoryInfo.currentCountryCode =
          context.detected_values.country.handle;
        resolve(window.inventoryInfo.currentCountryCode);
      }
    };
    xhr.send();
  });
}

function getInventoryLocationsForCountry(
  associatedCountries,
  inventoryLocations
) {
  return inventoryLocations.filter(function(inventoryLocation) {
    return associatedCountries.indexOf(inventoryLocation.location.id) >= 0;
  });
}

function getStockLocationRules(settings) {
  if (!settings.stockLocationRules) {
    return;
  }
  const blockCountryPurchaseRules =
    settings.stockLocationRules.blockCountryPurchaseRules;

  if (!blockCountryPurchaseRules || blockCountryPurchaseRules.length === 0) {
    return;
  }

  return blockCountryPurchaseRules;
}

export function getAssoicatedCountries(settings, code) {
  return new Promise(function(resolve) {
    const blockCountryPurchaseRules = getStockLocationRules(settings);

    if (!blockCountryPurchaseRules) {
      resolve(null);
      return;
    }
    determineCountryCode(settings, code).then(function(code) {
      let associatedLocationIds = blockCountryPurchaseRules
        .filter(function(rule) {
          return (
            code === rule.countryCode || isInARegion(code, rule.countryCode)
          );
        })
        .map(bpr => bpr.locationId);

      // Check for Rest of the world
      if (associatedLocationIds.length === 0) {
        associatedLocationIds = blockCountryPurchaseRules
          .filter(function(rule) {
            return '__ROW__' === rule.countryCode;
          })
          .map(bpr => bpr.locationId);
      }
      resolve(associatedLocationIds);
    });
  });
}

function isInARegion(visitorCountryCode, regionCode) {
  if (regionCode === '__EU__') {
    return euCountries.indexOf(visitorCountryCode) >= 0;
  }

  if (regionCode === '__EEA__') {
    return euAndEeaCountries.indexOf(visitorCountryCode) >= 0;
  }
  return false;
}
