// Transport helpers shared by the modular client and rpc-light. Keep this file
// import-free so light pulls no zod.

export function rpcUrl(baseURL: URL, path: string): URL {
  return new URL(`${baseURL.pathname.replace(/\/$/, "")}/${path}`, baseURL);
}

export function inputToSearchParams(serialized: unknown): URLSearchParams {
  const input =
    serialized && typeof serialized === "object" && "input" in serialized
      ? (serialized as { input: unknown }).input
      : undefined;
  if (typeof input !== "object") {
    throw new Error("GET RPC input must be an object");
  }
  const searchParams = new URLSearchParams();
  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  const record = input as Record<string, unknown> | null;
  if (record) {
    for (const key in record) {
      const value = record[key];
      if (value === undefined) {
        continue;
      }
      searchParams.append(key, value === null ? "" : JSON.stringify(value));
    }
  }
  return searchParams;
}
