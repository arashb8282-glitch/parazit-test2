import { ZodError } from "zod";
import { RpcError } from "./errors";

export function serializeError(error: unknown): string {
  if (error instanceof ZodError) {
    return JSON.stringify(error.format());
  } else if (error instanceof RpcError) {
    return JSON.stringify({ error: error.message, code: error.code });
  } else if (error instanceof Error) {
    return error.message;
  } else {
    return JSON.stringify(error, null, 2);
  }
}
