import { Json } from "@redotech/json/json";
import { ndjsonParse } from "@redotech/json/ndjson";
import { Serializable, serializeJsonFormat } from "@redotech/json/serialize";
import { streamAsyncIterator } from "@redotech/streams-util/async-iterator";
import { abortRace } from "@redotech/util/abort";
import {
  ExponentialBackoffOptions,
  exponentialBackoffRetry,
} from "@redotech/util/retry";
import type * as z from "zod";
import { ZodError } from "zod";
import {
  InferRpcDefinition,
  RpcClientDefinition,
  RpcClientSchema,
  RpcDefinition,
  RpcSchema,
  UnaryRpcSchema,
  UnaryStreamRpcSchema,
} from "./definition";
import { ClientError, clientErrorFromResponse } from "./errors";
import { inputToSearchParams, rpcUrl } from "./http";
import { serializeError } from "./serialize-error";

type MockResolver = (
  name: string,
  outputSchema: z.ZodTypeAny,
  inlineMock?: unknown,
  input?: unknown,
) => Promise<unknown>;

let mockResolver: MockResolver | null = null;
let schemaRegistrar:
  | ((name: string, outputSchema: z.ZodTypeAny, inlineMock?: unknown) => void)
  | null = null;
let _shouldMockRpc: (name: string) => boolean = () => false;
let _trackRpcCall: (name: string) => void = () => {};
let _registerKnownRpcs: (names: string[]) => void = () => {};

export function registerMockResolver(
  resolver: MockResolver,
  onSchemaRegistered?: typeof schemaRegistrar,
  hooks?: {
    shouldMockRpc?: (name: string) => boolean;
    trackRpcCall?: (name: string) => void;
    registerKnownRpcs?: (names: string[]) => void;
  },
): void {
  mockResolver = resolver;
  schemaRegistrar = onSchemaRegistered ?? null;
  if (hooks?.shouldMockRpc) {
    _shouldMockRpc = hooks.shouldMockRpc;
  }
  if (hooks?.trackRpcCall) {
    _trackRpcCall = hooks.trackRpcCall;
  }
  if (hooks?.registerKnownRpcs) {
    _registerKnownRpcs = hooks.registerKnownRpcs;
  }
}

export type InferRpcClient<D extends RpcDefinition> = RpcClient<
  InferRpcDefinition<D>
>;

export type RpcClient<D extends RpcClientDefinition> = {
  [key in keyof D]: RpcMethod<D[key]>;
};

export type RpcMethod<S> = [S] extends [
  RpcClientSchema<infer Name, infer Input, infer Output>,
]
  ? S["method"] extends "unary"
    ? UnaryRpcMethod<Name, Input, Output>
    : S["method"] extends "unary-stream"
      ? UnaryStreamRpcMethod<Name, Input, Output>
      :
          | UnaryRpcMethod<Name, Input, Output>
          | UnaryStreamRpcMethod<Name, Input, Output>
  : never;

export interface UnaryRpcMethod<Name extends string, Input, Output> {
  (input: Input, options?: RpcRequestOptions): Promise<Output>;
  method: "unary";
  _name: Name;
}

export interface UnaryStreamRpcMethod<Name extends string, Input, Output> {
  (input: Input, options?: RpcRequestOptions): AsyncIterableIterator<Output>;
  method: "unary-stream";
  _name: Name;
}

export interface ClientOptions<D> {
  baseURL: URL;
  defaultMethod?: "GET" | "POST";
  headers?: Record<string, string>;
  onError?: (rpcName: keyof D, error: unknown) => Promise<void> | void;
  targetAddressSpace?: "public" | "local" | "loopback";
  retryOptions?: ExponentialBackoffOptions;
}

export interface RpcRequestOptions {
  requestHeaders?: Record<string, string>;
  method?: "GET" | "POST";
  files?: File[];
  signal?: AbortSignal;
  timeout?: Temporal.Duration | Temporal.DurationLike;
  targetAddressSpace?: "public" | "local" | "loopback";
}

export function createRpcClient<D extends RpcDefinition>(
  def: D,
  clientOptions: ClientOptions<D>,
): InferRpcClient<D> {
  if (process.env.NODE_ENV === "development") {
    const names = Object.keys(def);
    _registerKnownRpcs(names);
    if (schemaRegistrar) {
      for (const name of names) {
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        const rpc = def[name]!;
        schemaRegistrar(name, rpc.output, rpc.mock);
      }
    }
  }
  const clientCache = new Map<string, any>();

  // Create a proxy object that will lazily initialize the RPC client functions
  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  return new Proxy({} as InferRpcClient<D>, {
    get(_target, key) {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      const rpcName = key as string;

      // If we've already created this client function, return it from cache
      if (clientCache.has(rpcName)) {
        return clientCache.get(rpcName);
      }

      // Get the RPC definition
      const rpc = def[rpcName];
      if (!rpc) {
        return undefined;
      }

      // Create the appropriate RPC caller function
      let clientFn;
      if (rpc.method === "unary-stream") {
        clientFn = unaryStreamRpcCaller(rpcName, rpc, clientOptions);
      } else {
        clientFn = unaryRpcCaller(rpcName, rpc, clientOptions);
      }

      // Store in cache for future use
      clientCache.set(rpcName, clientFn);
      return clientFn;
    },
  });
}

/**
 * Creates a client typed by `C`, a contract that the `rpc_contract` rule
 * generates from `def` and checks against it. The client does not repeat that
 * check: a stale contract would then fail its package's compile, which the
 * contract generators of dependent packages need.
 */
export function createRpcContractClient<C>(
  def: RpcDefinition,
  clientOptions: ClientOptions<C>,
): C {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion -- the contract's method names are the definition's
  const options = clientOptions as ClientOptions<RpcDefinition>;
  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion -- the rpc_contract generator checks C against def
  return createRpcClient(def, options) as C;
}

export type ModularRpcClient<D extends RpcClientDefinition> = <
  K extends keyof D & string,
>(
  rpc: RpcSchema<K, D[K]["input"], D[K]["output"]>,
  input: D[K]["input"],
  options?: RpcRequestOptions,
) => D[K]["method"] extends "unary-stream"
  ? AsyncIterableIterator<D[K]["output"]>
  : D[K]["method"] extends "unary"
    ? Promise<D[K]["output"]>
    : Promise<D[K]["output"]>;

export function createModularRpcClient<D extends RpcClientDefinition>(
  clientOptions: ClientOptions<D>,
): ModularRpcClient<D> {
  const clientCache = new Map<string, any>();

  return <K extends keyof D & string>(
    rpc: RpcSchema<K, D[K]["input"], D[K]["output"]>,
    input: D[K]["input"],
    options?: RpcRequestOptions,
  ) => {
    const rpcName = rpc.name;

    // Check if we have a cached client function for this RPC
    let clientFn = clientCache.get(rpcName);

    if (!clientFn) {
      // Create the appropriate RPC caller function
      if (rpc.method === "unary-stream") {
        clientFn = unaryStreamRpcCaller(rpcName, rpc, clientOptions);
      } else {
        clientFn = unaryRpcCaller(rpcName, rpc, clientOptions);
      }

      // Store in cache for future use
      clientCache.set(rpcName, clientFn);
    }

    // Execute the RPC call
    return clientFn(input, options);
  };
}

async function doRequest<
  Name extends string,
  Input extends Serializable,
  Output extends Serializable,
>(
  url: URL,
  name: Name,
  def: RpcSchema<Name, Input, Output>,
  params: Input,
  options: {
    method: string;
    files?: File[];
    headers: Record<string, string>;
    signal?: AbortSignal;
    targetAddressSpace?: "public" | "local" | "loopback";
  },
) {
  let input;
  try {
    const zod = def.input.safeParse(params);
    if (!zod.success) {
      throw zod.error;
    }
    input = serializeJsonFormat.write({ input: zod.data });
  } catch (error) {
    throw new Error(
      `RPC Input Validation Error ${name}: ${serializeError(error)}`,
    );
  }
  const method = options.method;

  let response;
  if (method === "POST") {
    let body: BodyInit;
    if (options.files?.length) {
      const formData = new FormData();
      formData.append("input", JSON.stringify(input));
      for (const file of options.files) {
        formData.append("files", file);
      }
      body = formData;
    } else {
      body = JSON.stringify(input);
    }
    response = await fetch(url.toString(), {
      method: "POST",
      headers: {
        ...options.headers,
        ...(body instanceof FormData
          ? {} // Content-Type set automatically for FormData to include multipart boundary
          : { "Content-Type": "application/json" }),
      },
      body,
      signal: options.signal,
      ...(options.targetAddressSpace && {
        targetAddressSpace: options.targetAddressSpace,
      }),
    } as RequestInit);
  } else if (method === "GET") {
    if (options.files?.length) {
      throw new Error("File uploads are not supported for GET requests");
    }
    const getUrl = new URL(url);
    const params = inputToSearchParams(input);
    getUrl.search = params.toString();

    response = await fetch(getUrl.toString(), {
      method: "GET",
      headers: { ...options.headers },
      signal: options?.signal,
      ...(options.targetAddressSpace && {
        targetAddressSpace: options.targetAddressSpace,
      }),
    } as RequestInit);
  } else {
    throw new Error(`Unsupported HTTP method ${method}`);
  }
  if (!response?.ok) {
    throw response;
  }
  return response;
}

// @hono/node-server (used by the MCP SDK) can replace the global Response, so
// fetch's own Response then fails `instanceof Response`.
function isResponse(value: unknown): value is Response {
  return (
    value instanceof Response ||
    Object.prototype.toString.call(value) === "[object Response]"
  );
}

async function handleRpcError(
  name: string,
  error: any,
  onError: ClientOptions<any>["onError"],
) {
  if (error instanceof Error && error.name === "AbortError") {
    throw new Error(`Request aborted for RPC method ${name}`);
  }

  // Handle timeout and abort scenarios with more descriptive messages
  if (error instanceof Error) {
    if (error.message.includes("aborted due to timeout")) {
      throw new Error(`Request timed out for RPC method ${name}`);
    }
    if (error.message.includes("operation was aborted")) {
      throw new Error(`Request aborted for RPC method ${name}`);
    }
  }

  await onError?.(name, isResponse(error) ? error.clone() : error);
  if (isResponse(error)) {
    throw await clientErrorFromResponse(error);
  } else if (error instanceof ZodError) {
    throw new Error(`RPC Validation Error ${name}: ${serializeError(error)}`);
  } else if (typeof error === "object") {
    const e = "error" in error ? String(error.error) : undefined;
    const m = "message" in error ? String(error.message) : undefined;
    const code = "code" in error ? String(error.code) : undefined;
    const message = e || m;

    // Check if this object error is about timeout or abort
    if (message?.includes("aborted due to timeout")) {
      throw new Error(`Request timed out for RPC method ${name}`);
    }
    if (message?.includes("operation was aborted")) {
      throw new Error(`Request aborted for RPC method ${name}`);
    }

    throw new ClientError(0, message ?? "Unknown error", code);
  }
}

function unaryRpcCaller<
  Name extends string,
  Input extends Serializable,
  Output extends Serializable,
>(
  name: Name,
  def: UnaryRpcSchema<Name, Input, Output>,
  {
    baseURL,
    defaultMethod = "POST",
    headers,
    onError,
    targetAddressSpace: defaultTargetAddressSpace,
    retryOptions,
  }: ClientOptions<any>,
): UnaryRpcMethod<Name, Input, Output> {
  const url = rpcUrl(baseURL, name);
  const func = async (
    params: Input,
    options?: RpcRequestOptions,
  ): Promise<Output> => {
    _trackRpcCall(name);
    if (_shouldMockRpc(name) && mockResolver) {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      return (await mockResolver(name, def.output, def.mock, params)) as Output;
    }
    const executeRequest = async (): Promise<Output> => {
      try {
        const response = await doRequest(url, name, def, params, {
          method: options?.method ?? defaultMethod,
          files: options?.files,
          headers: { ...headers, ...options?.requestHeaders },
          signal: getAbortSignal(options?.signal, options?.timeout),
          targetAddressSpace:
            options?.targetAddressSpace ?? defaultTargetAddressSpace,
        });
        const json: Json = await response.json();
        if (!json || typeof json !== "object" || !("output" in json)) {
          throw new TypeError("Network response did not contain RPC output");
        }

        let data: Output;
        try {
          const hydratedOutput = serializeJsonFormat.read(json.output);
          const zod = def.output.safeParse(hydratedOutput);
          if (!zod.success) {
            throw zod.error;
          }
          data = zod.data;
        } catch (error) {
          throw new Error(
            `RPC Output Validation Error ${name}: ${serializeError(error)}`,
          );
        }

        return data;
      } catch (error) {
        await handleRpcError(name, error, onError);
        throw error;
      }
    };

    // If retry options are provided, wrap with retry logic
    if (retryOptions) {
      return exponentialBackoffRetry(executeRequest, retryOptions);
    }

    return executeRequest();
  };

  func.method = "unary" as const;
  func._name = name;

  return func;
}

function unaryStreamRpcCaller<
  Name extends string,
  Input extends Serializable,
  Output extends Serializable,
>(
  name: Name,
  def: UnaryStreamRpcSchema<Name, Input, Output>,
  {
    baseURL,
    defaultMethod = "POST",
    headers,
    onError,
    targetAddressSpace: defaultTargetAddressSpace,
  }: ClientOptions<any>,
): UnaryStreamRpcMethod<Name, Input, Output> {
  const url = rpcUrl(baseURL, `${name}/stream`);
  const func = async function* (
    params: Input,
    options?: RpcRequestOptions,
  ): AsyncIterableIterator<Output> {
    _trackRpcCall(name);
    if (_shouldMockRpc(name) && mockResolver) {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      yield (await mockResolver(name, def.output, def.mock, params)) as Output;
      // Real streaming RPCs hold the connection open until the consumer
      // aborts. Block on the signal here so consumers like useWatchStream
      // (which loop on stream completion without backoff) don't spin in a
      // tight loop reopening a single-yield mock thousands of times per
      // second.
      const signal = options?.signal;
      if (signal && !signal.aborted) {
        await new Promise<void>((resolve) => {
          signal.addEventListener("abort", () => resolve(), { once: true });
        });
      }
      return;
    }
    try {
      const response = await doRequest(url, name, def, params, {
        method: options?.method ?? defaultMethod,
        files: options?.files,
        headers: { ...headers, ...options?.requestHeaders },
        signal: getAbortSignal(options?.signal, options?.timeout),
        targetAddressSpace:
          options?.targetAddressSpace ?? defaultTargetAddressSpace,
      });
      const data: ReadableStream<any> | null = response.body;
      if (data) {
        const reader = data.pipeThrough(new TextDecoderStream());
        for await (const result of ndjsonParse(streamAsyncIterator(reader))) {
          if (!result || typeof result !== "object" || Array.isArray(result)) {
            throw new TypeError("Network response did not contain RPC output");
          }
          if ("output" in result) {
            try {
              const hydratedOutput = serializeJsonFormat.read(result.output);
              const zod = def.output.safeParse(hydratedOutput);
              if (!zod.success) {
                throw zod.error;
              }
              yield zod.data;
            } catch (error) {
              throw new Error(
                `RPC Output Validation Error ${name}: ${serializeError(error)}`,
              );
            }
          } else if ("heartbeat" in result) {
            continue;
          } else if ("error" in result) {
            await handleRpcError(name, result, onError);
            return;
          }
        }
      }
    } catch (error) {
      await handleRpcError(name, error, onError);
      throw error;
    }
  };

  func.method = "unary-stream" as const;
  func._name = name;

  return func;
}

function getAbortSignal(
  signal?: AbortSignal,
  timeout?: Temporal.Duration | Temporal.DurationLike,
): AbortSignal | undefined {
  try {
    const timeoutSignal = timeout
      ? AbortSignal.timeout(
          Temporal.Duration.from(timeout).total("milliseconds"),
        )
      : undefined;
    const signals = [signal, timeoutSignal].filter(
      (s): s is AbortSignal => s !== undefined,
    );
    if (signals.length === 0) {
      return undefined;
    }
    if (signals.length === 1) {
      return signals[0];
    }
    return abortRace(signals);
  } catch (error) {
    return undefined;
  }
}
