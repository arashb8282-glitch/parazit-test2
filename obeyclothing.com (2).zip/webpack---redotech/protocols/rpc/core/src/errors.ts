import {
  HttpError,
  InternalServerErrorStatus,
  Status,
} from "@redotech/http/semantics";

export class RpcError<Code extends string> extends Error {
  override name = "RpcError";

  constructor(
    readonly status: Status,

    override readonly message: string,
    readonly code?: Code,
  ) {
    super(message);
  }

  static from(error: unknown): RpcError<string> {
    if (error instanceof RpcError) {
      return error;
    }

    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    const anyError = error as any;

    /**
     * implicitly, AxiosErrors will have error.response.status, error.response.statusText, and error.response.data.message
     * (didn't want to add axios as a dependency for this library)
     **/
    return new RpcError(
      new Status(
        anyError?.response?.status ?? 500,
        anyError?.response?.statusText ?? "Unknown Error",
      ),
      anyError?.response?.data?.message ??
        anyError?.response?.data?.error ??
        anyError?.message ??
        anyError?.toString() ??
        "(No error message provided)",
    );
  }
}

interface BoomError {
  isBoom: true;
  output: { statusCode: number; payload: { message: string } };
}

// Duck-typed like the Axios handling in `RpcError.from` to avoid depending on
// @hapi/boom; unrecognized Boom errors would otherwise collapse into a 500.
function isBoomError(e: unknown): e is BoomError {
  return (
    typeof e === "object" && e !== null && "isBoom" in e && e.isBoom === true
  );
}

export interface RpcErrorResponse {
  status: number;
  error: string;
  code: string | number | undefined;
  isServerError: boolean;
}

// Single mapping from a thrown handler error to the wire response, so every
// server catch site surfaces the same status and client message.
export function toRpcErrorResponse(e: unknown): RpcErrorResponse {
  if (e instanceof RpcError) {
    const status = e.status.code;
    return {
      status,
      error: e.message,
      code: e.code,
      isServerError: status >= 500,
    };
  }
  if (isBoomError(e)) {
    const status = e.output.statusCode;
    return {
      status,
      error: e.output.payload.message,
      code: status,
      isServerError: status >= 500,
    };
  }
  if (e instanceof HttpError) {
    const status = e.statusCode;
    return {
      status,
      error: e.message,
      code: status,
      isServerError: status >= 500,
    };
  }
  return {
    status: InternalServerErrorStatus.code,
    error: "Internal server error",
    code: undefined,
    isServerError: true,
  };
}

export class ClientError<Code extends string> extends Error {
  override name = "ClientError";

  constructor(
    readonly statusCode: number,

    override readonly message: string,
    readonly code: Code | undefined,
  ) {
    super(message);
  }
}

/**
 * Map a non-ok RPC `Response` to a ClientError — the one shared mapping for
 * every RPC client (modular and rpc-light), so their error shapes can't drift.
 */
export async function clientErrorFromResponse(
  response: Response,
): Promise<ClientError<string>> {
  let message: string | undefined;
  let code: string | undefined;
  if (response.headers.get("Content-Type")?.includes("application/json")) {
    const json: unknown = await response.json();

    if (json && typeof json === "object") {
      const error = "error" in json ? String(json.error) : undefined;
      const m = "message" in json ? String(json.message) : undefined;
      code = "code" in json ? String(json.code) : undefined;
      message = error || m;
    }
  } else {
    message = await response.text();
  }
  return new ClientError(response.status, message ?? "Unknown error", code);
}

// The server-provided message is safe to show for client (4xx) errors; 5xx
// responses are masked, so fall back to a caller-supplied message.
export function clientErrorMessage(e: unknown, fallback: string): string {
  return e instanceof ClientError && e.statusCode < 500 ? e.message : fallback;
}
