import { Big } from "big.js";
import * as z from "zod";
import { ZodTypeAny } from "zod";

export function big(params?: z.core.$ZodCustomParams) {
  return z
    .custom<Big.Big>(
      (data) =>
        data instanceof Big ||
        typeof data === "string" ||
        typeof data === "number",
      params,
    )
    .transform<Big.Big>(Big);
}

export function instant(params?: z.core.$ZodCustomParams) {
  return z
    .custom<Temporal.Instant>((data) => {
      if (data instanceof Temporal.Instant) {
        return true;
      }
      if (typeof data === "string") {
        try {
          Temporal.Instant.from(data);
          return true;
        } catch (e) {
          // it isn't a valid instant string
        }
      }
      return false;
    }, params)
    .transform<Temporal.Instant>((data) => Temporal.Instant.from(data));
}

export function plainDate(params?: z.core.$ZodCustomParams) {
  return z
    .custom<Temporal.PlainDate>((data) => {
      if (data instanceof Temporal.PlainDate) {
        return true;
      }
      if (typeof data === "string") {
        try {
          Temporal.PlainDate.from(data);
          return true;
        } catch (e) {
          // it isn't a valid date string
        }
      }
      return false;
    }, params)
    .transform<Temporal.PlainDate>((data) => Temporal.PlainDate.from(data));
}

export function plainTime(params?: z.core.$ZodCustomParams) {
  return z
    .custom<Temporal.PlainTime>((data) => {
      if (data instanceof Temporal.PlainTime) {
        return true;
      }
      if (typeof data === "string") {
        try {
          Temporal.PlainTime.from(data);
          return true;
        } catch (e) {
          // it isn't a valid time string
        }
      }
      return false;
    }, params)
    .transform<Temporal.PlainTime>((data) => Temporal.PlainTime.from(data));
}

/**
 * Takes a Zod schema and returns a Zod schema that parses arrays,
 * filtering out invalid items and only returning valid ones.
 */
export function filterToValidArray<T extends ZodTypeAny>(itemSchema: T) {
  return z.array(z.any()).transform((items) => {
    return items
      .map((item) => itemSchema.safeParse(item))
      .filter(
        (result): result is z.ZodSafeParseSuccess<z.infer<T>> => result.success,
      )
      .map((result) => result.data);
  });
}

export function filterToValid<T extends ZodTypeAny>(itemSchema: T) {
  return z.any().transform((item) => {
    return itemSchema.safeParse(item).data;
  });
}

/**
 * @param ref - Referenced collection name for FK generation (e.g., "teams", "orders")
 */
export function objectId(ref?: string, params?: z.core.$ZodCustomParams) {
  return z
    .custom<string>(
      (id) =>
        typeof id === "string" ||
        (typeof id === "object" && id && "toString" in id),
      params,
    )
    .transform<string>((id) => (typeof id === "string" ? id : String(id)))
    .meta({ annotation: "ObjectId", ...(ref && { ref }) });
}

export function coercedResult<T extends ZodTypeAny>(okType: T) {
  return z.union([
    z.object({ ok: z.literal(true), value: okType }),
    z.object({
      ok: z.literal(false),
      error: z.object({
        message: z.string(),
        name: z.string(),
        stack: z.optional(z.string()),
      }),
    }),
  ]);
}

/**
 * Recursively converts every `.optional()` in a schema to
 * required + nullable so that no field can be `undefined`
 * (OpenAI‑JSON compliant) but all may be `null`.
 *
 * From https://github.com/colinhacks/zod/discussions/2050#discussioncomment-13818536
 */
export function optionalToNullable<S extends z.ZodTypeAny>(schema: S): S {
  if (schema instanceof z.ZodOptional) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return optionalToNullable(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      schema.unwrap() as any,
    ).nullable() as unknown as S;
  }

  if (schema instanceof z.ZodObject) {
    const transformed = Object.fromEntries(
      Object.entries(schema.shape).map(([k, v]) => [k, optionalToNullable(v)]),
    );
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return z.object(transformed) as unknown as S;
  }

  if (schema instanceof z.ZodArray) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return z.array(optionalToNullable(schema.element as any)) as unknown as S;
  }
  if (schema instanceof z.ZodRecord) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return z.record(
      z.string(),
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      optionalToNullable(schema.valueType as any),
    ) as unknown as S;
  }
  if (schema instanceof z.ZodTuple) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return z.tuple(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      schema.def.items.map((x) => optionalToNullable(x as any)) as any,
    ) as unknown as S;
  }
  if (schema instanceof z.ZodUnion) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return z.union(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      schema.def.options.map((x) => optionalToNullable(x as any)),
    ) as unknown as S;
  }
  if (schema instanceof z.ZodIntersection) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return z.intersection(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      optionalToNullable(schema.def.left as any),
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      optionalToNullable(schema.def.right as any),
    ) as unknown as S;
  }

  if (schema instanceof z.ZodMap) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return z.map(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      optionalToNullable(schema.def.keyType as any),
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      optionalToNullable(schema.def.valueType as any),
    ) as unknown as S;
  }
  if (schema instanceof z.ZodSet) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return z.set(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      optionalToNullable(schema.def.valueType as any),
    ) as unknown as S;
  }
  if (schema instanceof z.ZodPromise) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return z.promise(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      optionalToNullable(schema.def.type as any),
    ) as unknown as S;
  }

  return schema;
}

/** Allow parsing when field is missing, but require it at the Typescript-level */
export function coerceNull<T extends z.ZodTypeAny>(schema: T) {
  return schema.nullish().transform((val) => val ?? null);
}

export function numericString() {
  return (
    z
      .string()
      .refine((val) => /^[0-9]+$/.test(val), {
        message: "Must contain only digits",
      })
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      .transform((x) => x as `${number}`)
  );
}
