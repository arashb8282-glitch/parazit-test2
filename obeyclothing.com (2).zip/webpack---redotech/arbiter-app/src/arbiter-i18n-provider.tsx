import { ArbiterProvider } from "@redotech/arbiter/provider";
import { type ReactNode, useCallback } from "react";
import { useTranslation } from "react-i18next";

/** Renders Arbiter's own text in the app's react-i18next language. */
export function RedoArbiterI18nProvider({ children }: { children: ReactNode }) {
  const { t, i18n } = useTranslation();
  const translate = useCallback(
    (key: string, options?: Record<string, unknown>) =>
      String(options ? t(key, options) : t(key)),
    [t],
  );
  return (
    <ArbiterProvider locale={i18n.language} translate={translate}>
      {children}
    </ArbiterProvider>
  );
}
