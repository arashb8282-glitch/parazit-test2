import { CoverageTreatmentIdSource } from "@redotech/redo-ab-testing-common/coverage-treatment-id";
import { createEnum } from "@redotech/zod-util/zod-enum";

export const coverageTreatmentIdSourceSchema = createEnum(
  CoverageTreatmentIdSource,
  { enumName: "CoverageTreatmentIdSource" },
);
