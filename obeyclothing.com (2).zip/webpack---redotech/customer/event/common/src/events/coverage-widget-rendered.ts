import { parseCoverageTreatmentAttribution } from "@redotech/redo-ab-testing-common/coverage-treatment-id";
import {
  CART_PLACEMENT_CONTAINER_TYPES,
  PlacementContainerType,
} from "@redotech/redo-storefront-common/widget-config";
import { createEnum } from "@redotech/zod-util/zod-enum";
import * as z from "zod";
import { baseCustomerEventSchema, CustomerEventType } from "./base";
import { coverageTreatmentIdSourceSchema } from "./coverage-treatment-id-source";

const coverageWidgetRenderedFields = {
  anonymousId: z.string(),
  sessionId: z.string(),
  coverageTreatmentId: z.string(),
  coverageTreatmentIdSource: coverageTreatmentIdSourceSchema,
  cartSurface: createEnum(CART_PLACEMENT_CONTAINER_TYPES, {
    enumName: "PlacementContainerType",
    isPartial: true,
    originalEnum: PlacementContainerType,
  }),
  eventId: z.string(),
};

/** What the storefront sends; the server adds team, event type and timestamp. */
export const CoverageWidgetRenderedPayloadSchema = z
  .object(coverageWidgetRenderedFields)
  .refine(
    ({ coverageTreatmentId, coverageTreatmentIdSource }) =>
      parseCoverageTreatmentAttribution(
        coverageTreatmentId,
        coverageTreatmentIdSource,
      ) !== undefined,
    {
      message: "coverageTreatmentId must match its coverageTreatmentIdSource",
      path: ["coverageTreatmentId"],
    },
  );

export interface CoverageWidgetRenderedPayload extends z.infer<
  typeof CoverageWidgetRenderedPayloadSchema
> {}

export const CoverageWidgetRenderedShoppingEventSchema_ =
  baseCustomerEventSchema.extend({
    eventType: z.literal(CustomerEventType.COVERAGE_WIDGET_RENDERED),
    ...coverageWidgetRenderedFields,
  });
