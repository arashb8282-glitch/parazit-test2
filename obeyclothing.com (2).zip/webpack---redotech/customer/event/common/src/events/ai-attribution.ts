import { createEnum } from "@redotech/zod-util/zod-enum";
import * as z from "zod";

export enum AiAttributionType {
  GENERATE_CONTENT = "GENERATE_CONTENT",
  GENERATE_SUGGESTIONS = "GENERATE_SUGGESTIONS",
  DATA_ANALYSIS = "DATA_ANALYSIS",
  CUSTOMER_RECORD = "CUSTOMER_RECORD",
  AUTOMATED_DECISION = "AUTOMATED_DECISION",
  CLASSIFICATION = "CLASSIFICATION",
}

const baseAiAttributionSchema = z.object({
  type: createEnum(AiAttributionType, { enumName: "AiAttributionType" }),
});

export const generateContentAiAttributionSchema =
  baseAiAttributionSchema.extend({
    type: z.literal(AiAttributionType.GENERATE_CONTENT),
  });

export const generateSuggestionsAiAttributionSchema =
  baseAiAttributionSchema.extend({
    type: z.literal(AiAttributionType.GENERATE_SUGGESTIONS),
  });

export const dataAnalysisAiAttributionSchema = baseAiAttributionSchema.extend({
  type: z.literal(AiAttributionType.DATA_ANALYSIS),
});

export const automatedDecisionAiAttributionSchema =
  baseAiAttributionSchema.extend({
    type: z.literal(AiAttributionType.AUTOMATED_DECISION),
  });

export const classificationAiAttributionSchema = baseAiAttributionSchema.extend(
  { type: z.literal(AiAttributionType.CLASSIFICATION) },
);

export const customerRecordAiAttributionSchema = baseAiAttributionSchema.extend(
  { type: z.literal(AiAttributionType.CUSTOMER_RECORD) },
);

export type GenerateContentAiAttribution = z.infer<
  typeof generateContentAiAttributionSchema
>;
export type GenerateSuggestionsAiAttribution = z.infer<
  typeof generateSuggestionsAiAttributionSchema
>;
export type DataAnalysisAiAttribution = z.infer<
  typeof dataAnalysisAiAttributionSchema
>;
export type AutomatedDecisionAiAttribution = z.infer<
  typeof automatedDecisionAiAttributionSchema
>;
export type ClassificationAiAttribution = z.infer<
  typeof classificationAiAttributionSchema
>;
export type CustomerRecordAiAttribution = z.infer<
  typeof customerRecordAiAttributionSchema
>;

export const aiAttributionSchema = z.discriminatedUnion("type", [
  generateContentAiAttributionSchema,
  generateSuggestionsAiAttributionSchema,
  dataAnalysisAiAttributionSchema,
  automatedDecisionAiAttributionSchema,
  classificationAiAttributionSchema,
  customerRecordAiAttributionSchema,
]);

export type AIAttribution = z.infer<typeof aiAttributionSchema>;
