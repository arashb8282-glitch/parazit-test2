import * as zExt from "@redotech/rpc/ext";
import { dateOrStringAsDate } from "@redotech/zod-util/db-coercion";
import { createEnum } from "@redotech/zod-util/zod-enum";
import * as z from "zod";
import { botClassificationSchema } from "../bot-classification";
import {
  type CustomerIdentifiers,
  CustomerIdentifiersSchema,
} from "../customer-identifiers";
import { EventProducer } from "../shopify-storefront-event-payload";
import { aiAttributionSchema } from "./ai-attribution";
export const CUSTOMER_EVENT_DISCRIMINATOR_KEY = "eventType" as const;

export const attributableDiscountCodesSchema = z.array(z.string()).nullish();

/** Numeric Shopify gift card ids, for joining outreach to the orders it drove. */
export const attributableGiftCardIdsSchema = z.array(z.string()).nullish();

/** Both the reminder dedupe key and what attributes a reminded card's spend. */
export const giftCardIdsRemindedAboutSchema = z.array(z.string()).nullish();

export const outreachStampSchema = z.object({
  discountCodes: attributableDiscountCodesSchema,
  giftCardIds: attributableGiftCardIdsSchema,
  giftCardIdsRemindedAbout: giftCardIdsRemindedAboutSchema,
});
export type OutreachStamp = z.infer<typeof outreachStampSchema>;

export const outreachStampKeys = outreachStampSchema.keyof().options;
export type OutreachStampKey = (typeof outreachStampKeys)[number];

export type NonEmptyOutreachStamp = { [K in keyof OutreachStamp]?: string[] };

export function nonEmptyOutreachStamp(
  stamp: OutreachStamp,
): NonEmptyOutreachStamp {
  const nonEmpty: NonEmptyOutreachStamp = {};
  for (const key of outreachStampKeys) {
    const ids = stamp[key];
    if (ids?.length) {
      nonEmpty[key] = ids;
    }
  }
  return nonEmpty;
}

/**
 * Flat keys come from payloads recorded before bundling. Delete with the
 * deprecated fields once workflows started before September 2026 are gone.
 */
export function outreachStampOrFlatKeys(payload: {
  stamp?: OutreachStamp | null;
  discountCodes?: string[] | null;
  giftCardIds?: string[] | null;
}): OutreachStamp | undefined {
  if (payload.stamp) {
    return payload.stamp;
  }
  const flat = nonEmptyOutreachStamp({
    discountCodes: payload.discountCodes,
    giftCardIds: payload.giftCardIds,
  });
  return Object.keys(flat).length ? flat : undefined;
}

/** Every id either stamp carries, per key; undefined when neither carries one. */
export function mergeOutreachStamps(
  a: OutreachStamp | undefined,
  b: OutreachStamp | undefined,
): OutreachStamp | undefined {
  const merged = nonEmptyOutreachStamp(
    readOutreachStamp((key) => [
      ...new Set([...(a?.[key] ?? []), ...(b?.[key] ?? [])]),
    ]),
  );
  return Object.keys(merged).length ? merged : undefined;
}

export function readOutreachStamp(
  read: (key: OutreachStampKey) => string[] | null | undefined,
): OutreachStamp {
  const stamp: OutreachStamp = {};
  for (const key of outreachStampKeys) {
    stamp[key] = read(key);
  }
  return stamp;
}

export enum CustomerEventType {
  ORDER_CREATED = "ORDER_CREATED",
  ORDER_STATUS_UPDATED = "ORDER_STATUS_UPDATED",
  ORDER_UPDATED = "ORDER_UPDATED",
  PAYMENT_FAILED = "PAYMENT_FAILED",

  RETURN_CREATED = "RETURN_CREATED",
  RETURN_STATUS_UPDATED = "RETURN_STATUS_UPDATED",
  RETURN_COMMENT_CREATED = "RETURN_COMMENT_CREATED",
  RETURN_PROCESSED = "RETURN_PROCESSED",

  CLAIM_CREATED = "CLAIM_CREATED",
  CLAIM_STATUS_UPDATED = "CLAIM_STATUS_UPDATED",
  CLAIM_COMMENT_CREATED = "CLAIM_COMMENT_CREATED",

  CONVERSATION_CREATED = "CONVERSATION_CREATED",
  CONVERSATION_STATUS_UPDATED = "CONVERSATION_STATUS_UPDATED",
  CONVERSATION_MESSAGE_CREATED = "CONVERSATION_MESSAGE_CREATED",
  EXTERNAL_PLATFORM_CUSTOMER_CREATED = "EXTERNAL_PLATFORM_CUSTOMER_CREATED",

  STOREFRONT_LOGIN = "STOREFRONT_LOGIN",

  MARKETING_SUBSCRIBED = "MARKETING_SUBSCRIBED",
  MARKETING_CONFIRMED = "MARKETING_CONFIRMED",
  MARKETING_UNSUBSCRIBED = "MARKETING_UNSUBSCRIBED",

  PRODUCT_VIEWED = "PRODUCT_VIEWED",
  PRODUCT_ADDED_TO_CART = "PRODUCT_ADDED_TO_CART",
  PRODUCT_REMOVED_FROM_CART = "PRODUCT_REMOVED_FROM_CART",
  CHECKOUT_STARTED = "CHECKOUT_STARTED",
  CHECKOUT_CONTACT_INFO_SUBMITTED = "CHECKOUT_CONTACT_INFO_SUBMITTED",
  CHECKOUT_INFO_CHANGED = "CHECKOUT_INFO_CHANGED",
  CHECKOUT_RATES_SHOWN = "CHECKOUT_RATES_SHOWN",
  CHECKOUT_PROBABILITY_CALCULATED = "CHECKOUT_PROBABILITY_CALCULATED",
  PACKAGE_PROTECTION_PRICE_EXPOSED = "PACKAGE_PROTECTION_PRICE_EXPOSED",
  COVERAGE_INFO_MODAL_OPENED = "COVERAGE_INFO_MODAL_OPENED",
  COVERAGE_WIDGET_RENDERED = "COVERAGE_WIDGET_RENDERED",
  CHECKOUT_COMPLETED = "CHECKOUT_COMPLETED",
  STORE_PAGE_VIEWED = "STORE_PAGE_VIEWED",
  COLLECTION_VIEWED = "COLLECTION_VIEWED",

  OUTREACH_SEND = "OUTREACH_SEND",
  OUTREACH_DELIVERY = "OUTREACH_DELIVERY",
  OUTREACH_OPEN = "OUTREACH_OPEN",
  OUTREACH_CLICK = "OUTREACH_CLICK",
  OUTREACH_BOUNCE = "OUTREACH_BOUNCE",
  OUTREACH_COMPLAINT = "OUTREACH_COMPLAINT",
  OUTREACH_FAILED = "OUTREACH_FAILED",

  INBOUND_RECEIVED = "INBOUND_RECEIVED",

  CUSTOMER_GROUP_ENTER = "CUSTOMER_GROUP_ENTER",
  CUSTOMER_GROUP_EXIT = "CUSTOMER_GROUP_EXIT",

  AUTOMATION_ENTERED = "AUTOMATION_ENTERED",
  AUTOMATION_EXITED = "AUTOMATION_EXITED",
  AUTOMATION_SKIPPED = "AUTOMATION_SKIPPED",

  CUSTOMER_INFORMATION_UPDATE = "CUSTOMER_INFORMATION_UPDATE",

  OMS_ORDER_READY_FOR_PICKUP = "OMS_ORDER_READY_FOR_PICKUP",
  ADDRESS_VERIFICATION_FAILED = "ADDRESS_VERIFICATION_FAILED",

  LOYALTY_EARN = "LOYALTY_EARN",
  LOYALTY_EARN_REVIEW = "LOYALTY_EARN_REVIEW",
  LOYALTY_EARN_PURCHASE = "LOYALTY_EARN_PURCHASE",
  LOYALTY_REDEEM = "LOYALTY_REDEEM",
  LOYALTY_RETURN_REFUND = "LOYALTY_RETURN_REFUND",
  LOYALTY_RETURN_CLAWBACK = "LOYALTY_RETURN_CLAWBACK",
  LOYALTY_CANCEL_PURCHASE_REFUND = "LOYALTY_CANCEL_PURCHASE_REFUND",
  LOYALTY_CANCEL_PURCHASE_CLAWBACK = "LOYALTY_CANCEL_PURCHASE_CLAWBACK",
  LOYALTY_EXPIRE = "LOYALTY_EXPIRE",
  LOYALTY_MANUAL_ADJUSTMENT = "LOYALTY_MANUAL_ADJUSTMENT",

  PRODUCT_SUBSCRIPTION_ACTION = "PRODUCT_SUBSCRIPTION_ACTION",

  SUBSCRIBED_TO_BACK_IN_STOCK = "SUBSCRIBED_TO_BACK_IN_STOCK",
  TRIGGERED_BACK_IN_STOCK_NOTIFICATION = "TRIGGERED_BACK_IN_STOCK_NOTIFICATION",

  PERSONA_ASSIGNMENT = "PERSONA_ASSIGNMENT",

  SIGNUP_FORM_VIEWED = "SIGNUP_FORM_VIEWED",
  SIGNUP_FORM_SUBMITTED = "SIGNUP_FORM_SUBMITTED",

  RESCUE_PANEL_VIEWED = "RESCUE_PANEL_VIEWED",
  RESCUE_PANEL_CTA_CLICKED = "RESCUE_PANEL_CTA_CLICKED",

  FAILED_DISCOUNT_DETECTED = "FAILED_DISCOUNT_DETECTED",
  FAILED_DISCOUNT_RESCUE_SHOWN = "FAILED_DISCOUNT_RESCUE_SHOWN",
  FAILED_DISCOUNT_RESCUE_CLAIMED = "FAILED_DISCOUNT_RESCUE_CLAIMED",

  PRODUCT_VISUALIZATION_GENERATED = "PRODUCT_VISUALIZATION_GENERATED",

  MEANINGFUL_RECOVER_CONVERSATION = "MEANINGFUL_RECOVER_CONVERSATION",

  PRODUCT_SUBSCRIPTION_CREATED = "PRODUCT_SUBSCRIPTION_CREATED",
  PRODUCT_SUBSCRIPTION_CANCELLED = "PRODUCT_SUBSCRIPTION_CANCELLED",
  PRICE_DROP_INTEREST_INFERRED = "PRICE_DROP_INTEREST_INFERRED",

  REFUND_RETURN_SUBMITTED = "REFUND_RETURN_SUBMITTED",
  EXCHANGE_PROCESSED_WITH_CREDIT = "EXCHANGE_PROCESSED_WITH_CREDIT",
  WARRANTY_REGISTERED = "WARRANTY_REGISTERED",
  POST_PURCHASE_PAGE_VIEWED = "POST_PURCHASE_PAGE_VIEWED",
  POST_PURCHASE_OFFER_ACCEPTED = "POST_PURCHASE_OFFER_ACCEPTED",

  TRACKING_PAGE_VIEWED = "TRACKING_PAGE_VIEWED",
  TRACKING_PAGE_CLICKED = "TRACKING_PAGE_CLICKED",

  REVIEW_CREATED = "REVIEW_CREATED",

  SHOPPER_AGENT_RETURN_CREATED = "SHOPPER_AGENT_RETURN_CREATED",
  SHOPPER_AGENT_ORDER_CANCELLED = "SHOPPER_AGENT_ORDER_CANCELLED",
  SHOPPER_AGENT_ORDER_ITEMS_UPDATED = "SHOPPER_AGENT_ORDER_ITEMS_UPDATED",
  SHOPPER_AGENT_SHIPPING_ADDRESS_UPDATED = "SHOPPER_AGENT_SHIPPING_ADDRESS_UPDATED",
  SHOPPER_AGENT_RETURN_LABEL_RESENT = "SHOPPER_AGENT_RETURN_LABEL_RESENT",
  SHOPPER_AGENT_GIFT_CARD_RESENT = "SHOPPER_AGENT_GIFT_CARD_RESENT",
  SHOPPER_AGENT_DISCOUNT_CODE_GENERATED = "SHOPPER_AGENT_DISCOUNT_CODE_GENERATED",
  SHOPPER_AGENT_CHECKOUT_CREATED = "SHOPPER_AGENT_CHECKOUT_CREATED",
  SHOPPER_AGENT_KNOWLEDGE_RETRIEVED = "SHOPPER_AGENT_KNOWLEDGE_RETRIEVED",
  SHOPPER_AGENT_ORDER_TRACKING_PROVIDED = "SHOPPER_AGENT_ORDER_TRACKING_PROVIDED",
  SHOPPER_AGENT_BACK_IN_STOCK_SUBSCRIBED = "SHOPPER_AGENT_BACK_IN_STOCK_SUBSCRIBED",
  SHOPPER_AGENT_PRODUCTS_SEARCHED = "SHOPPER_AGENT_PRODUCTS_SEARCHED",
  SHOPPER_AGENT_LINK_FOLLOWED = "SHOPPER_AGENT_LINK_FOLLOWED",

  MESSAGE_READ = "MESSAGE_READ",
  PERSONALIZED_INSERT_LINK_FOLLOWED = "PERSONALIZED_INSERT_LINK_FOLLOWED",

  CUSTOM_EVENT = "CUSTOM_EVENT",
}

/**
 * Why an automation run stopped. All but `FLOW_DELETED_BEFORE_START` reach the
 * terminal `<END>` write; that one is log-only.
 */
export enum AutomationExitReason {
  COMPLETED = "COMPLETED",
  ERRORED = "ERRORED",
  FLOW_DELETED_BEFORE_START = "FLOW_DELETED_BEFORE_START",
  FLOW_DELETED_MID_RUN = "FLOW_DELETED_MID_RUN",
  STEP_REMOVED_MID_RUN = "STEP_REMOVED_MID_RUN",
  YIELD_TIMEOUT = "YIELD_TIMEOUT",
}

export enum PaymentFailureStage {
  NO_ORDER_CREATED = "no_order_created",
  AFTER_ORDER_CREATED = "after_order_created",
}

export enum ImportSource {
  KLAVIYO = "klaviyo",
}

/**
 * Defines the possible sources that events can come from.
 * This allows handling the same event type from multiple sources.
 */
export enum CustomerEventSource {
  SES = "SES",
  SMS_WEBHOOK = "SMS_WEBHOOK",
  LINK_SHORTENER = "LINK_SHORTENER",
  SHOPIFY_STOREFRONT = "SHOPIFY_STOREFRONT",
  COMMENTSOLD_STOREFRONT = "COMMENTSOLD_STOREFRONT",
  SYSTEM = "SYSTEM",
  SHOPIFY_WEBHOOK = "SHOPIFY_WEBHOOK",
  RECHARGE_WEBHOOK = "RECHARGE_WEBHOOK",
  TRACKING_PAGE = "TRACKING_PAGE",
  EMAIL = "EMAIL",
  MERCHANT_API = "MERCHANT_API",
  YOTPO = "YOTPO",
  JUDGEME = "JUDGEME",
  BIGCOMMERCE_WEBHOOK = "BIGCOMMERCE_WEBHOOK",
  BIGCOMMERCE_STOREFRONT = "BIGCOMMERCE_STOREFRONT",
  COMMERCE_CLOUD_STOREFRONT = "COMMERCE_CLOUD_STOREFRONT",
}

export const baseCustomerEventSchema = CustomerIdentifiersSchema.omit({
  redoCustomerId: true,
}).extend({
  _id: zExt.objectId().transform((id) => id.toString()),
  team: zExt.objectId().transform((id) => id.toString()),
  email: z.string().optional(),
  customer: zExt
    .objectId()
    .optional() // probably redundant, but it's been here for a while and too scared to remove it
    .transform((id) => id?.toString())
    .optional(),
  // TODO: the potential identifiers on an event need to exactly match the potential identifiers on a customer
  // except it should be `redoId` instead of `_id`
  // This is different from the `customer` field,
  // because redoId is the id at the time of event creation (and will not change),
  // while customer is the current id (which may change if the customer is merged)
  timestamp: dateOrStringAsDate,
  idempotencyKey: z.string().optional(), // TODO: make required when we implement idempotency for every event type
  // Whether this event is a duplicate of another event. We do this because we want to make sure every customer with a particular identifier has the same event.
  // this is used currently for phone number events (sends and unsubscribes) so that we can duplicate them to all customers with the same phone number.
  // These duplicates will have the same idempotency key as the original event, but the sparse unique key on idempotencyKey does not include it.
  // These should be excluded from any aggregated metrics we calculate.
  isDuplicate: z.boolean().optional(),
  [CUSTOMER_EVENT_DISCRIMINATOR_KEY]: CustomerEventType, // TODO: do we need this field if every subtype has it?
  importSource: createEnum(ImportSource, {
    enumName: "ImportSource",
  }).optional(),
  aiAttributions: z.array(aiAttributionSchema).optional(),
  // NOTE: eventSource is defined in the schema but does not appear to be used anywhere in the codebase.
  // It is not populated when events are created and no queries filter by it.
  eventSource: createEnum(CustomerEventSource, {
    enumName: "CustomerEventSource",
  }).nullish(),
  /**
   * System that produced the event (orthogonal to `eventSource`, which
   * names the ingress channel/kind). Unset → EventProducer.REDO when the
   * filter evaluator applies defaults. Contextual-routed events override
   * to EventProducer.CONTEXTUAL.
   */
  producer: createEnum(EventProducer, { enumName: "EventProducer" }).optional(),
  botClassification: botClassificationSchema.optional(),
});

export type BaseCustomerEvent = z.infer<typeof baseCustomerEventSchema>;

/**
 * The identifier fields inherited from CustomerIdentifiersSchema
 * (minus redoCustomerId, which is omitted from baseCustomerEventSchema).
 */
export const EVENT_IDENTIFIER_KEYS: readonly (keyof Omit<
  CustomerIdentifiers,
  "redoCustomerId"
>)[] = [
  "shopifyCustomerId",
  "commentsoldCustomerId",
  "email",
  "facebookUserId",
  "instagramUserId",
  "tiktokUserId",
  "postscriptSubscriberId",
  "anonymousId",
  "phoneNumber",
] as const;

// Compile-time check: fails if a new identifier is added to CustomerIdentifiers
// but not to EVENT_IDENTIFIER_KEYS.
type _ExhaustiveCheck =
  Exclude<
    keyof Omit<CustomerIdentifiers, "redoCustomerId">,
    (typeof EVENT_IDENTIFIER_KEYS)[number]
  > extends never
    ? true
    : never;
export const _eventIdentifierKeysAreExhaustive: _ExhaustiveCheck = true;

/**
 * Returns true if the event has at least one customer identifier set.
 * Events without identifiers (e.g. Shopify POS orders) cannot be
 * associated with a customer and should be skipped.
 */
export function eventHasCustomerIdentifiers(
  event: Partial<BaseCustomerEvent>,
): boolean {
  return !!event.customer || EVENT_IDENTIFIER_KEYS.some((key) => !!event[key]);
}
