import type {
  PixelEventsCheckoutCompleted,
  PixelEventsCheckoutContactInfoSubmitted,
  PixelEventsCheckoutStarted,
  PixelEventsProductRemovedFromCart,
  PixelEventsProductViewed,
} from "@redotech/redo-common-model/common/shopify-pixel-types";
import {
  AlertDisplayedType,
  PixelEventsAlertDisplayed,
  PixelEventsProductAddedToCartData,
  RegisterInit,
} from "@shopify/web-pixels-extension";
import { ShopifyPixelEventCart } from "./events/storefront-event-primitives";

export enum ShopifyPixelEventName {
  PRODUCT_ADDED_TO_CART = "product_added_to_cart",
  PRODUCT_REMOVED_FROM_CART = "product_removed_from_cart",
  PRODUCT_VIEWED = "product_viewed",
  CHECKOUT_STARTED = "checkout_started",
  CHECKOUT_COMPLETED = "checkout_completed",
  CHECKOUT_CONTACT_INFO_SUBMITTED = "checkout_contact_info_submitted",
  CHECKOUT_ADDRESS_INFO_SUBMITTED = "checkout_address_info_submitted",
  CHECKOUT_SHIPPING_INFO_SUBMITTED = "checkout_shipping_info_submitted",
  PAGE_VIEWED = "page_viewed",
  COLLECTION_VIEWED = "collection_viewed",
  ALERT_DISPLAYED = "alert_displayed",
}

export const SHOPIFY_PAYMENT_ALERT_TYPE = AlertDisplayedType.PaymentError;

export type ShopifyStorefrontEventPayload =
  | AddedToCartEvent
  | ViewedEvent
  | CheckoutCompletedEvent
  | CheckoutStartedEvent
  | CollectionViewedEvent
  | PageViewedEvent
  | AlertDisplayedPaymentFailedEvent
  | CheckoutContactInfoSubmittedEvent
  | CheckoutAddressInfoSubmittedEvent
  | CheckoutShippingInfoSubmittedEvent
  | RemovedFromCartEvent;

/**
 * System that produced the event — orthogonal to `eventSource`
 * (CustomerEventSource), which names the ingress channel / event kind.
 *
 * A Shopify storefront checkout_completed routed through Contextual is
 * stored as { eventSource: SHOPIFY_STOREFRONT, producer: CONTEXTUAL }.
 * Filtering by producer is how merchants target "only events Contextual
 * routed" regardless of the underlying event kind.
 *
 * Values:
 * - REDO: produced by redo's own code paths (Shopify web pixel, SMS/SES
 *   webhooks, signup forms, backend emitters). The implicit default when
 *   the field is unset on an event.
 * - CONTEXTUAL: produced by Contextual's pipeline.
 * - THIRD_PARTY: produced by anything the merchant pointed at redo's
 *   public ingress — merchant's own backend scripts, Klaviyo/Segment/Zapier
 *   style integrations, etc. Redo cannot distinguish these from each
 *   other at ingress and should not try to.
 */
export enum EventProducer {
  REDO = "redo",
  CONTEXTUAL = "contextual",
  THIRD_PARTY = "third_party",
}

/**
 * Provenance of an identifier (email or phone) attached to an event. Stored
 * at provider-level granularity so analytics and audits can distinguish
 * specific resolvers (e.g., LiveIntent) rather than collapsing everything
 * into a single "third party" bucket. The flow-builder UI groups these into
 * coarse first/third-party choices for merchants who don't need that detail.
 *
 * - FIRST_PARTY: collected from the merchant's own surfaces (form fill,
 *   account login, checkout entry).
 * - LIVE_INTENT: resolved via LiveIntent.
 *
 * Add new resolvers as additional enum values; do not collapse them into a
 * shared "third party" value at the data layer.
 */
export enum IdentityResolver {
  FIRST_PARTY = "first_party",
  LIVE_INTENT = "live_intent",
}

export interface EventIdentifier {
  customer: NonNullable<RegisterInit["data"]["customer"]> | null;
  anonymousId?: string;
  customerEmail?: string;
  customerPhone?: string;
  sessionId?: string;
  /**
   * System that produced the event. Absent for events from redo-native
   * ingress paths (treated as REDO by default downstream). Non-browser
   * callers (e.g., Contextual routing through the pixel endpoint) set
   * this to override the default.
   */
  producer?: EventProducer;
  /** How the email was resolved (e.g., merchant-collected vs LiveIntent). */
  emailIdentityResolver?: IdentityResolver;
  /** How the phone was resolved. */
  phoneIdentityResolver?: IdentityResolver;
  /** Which system provided the email on this event. Differs from producer
   *  when the checkout buffer merges a redo base event with a contextual
   *  identity enrichment. */
  emailIdentityProducer?: EventProducer;
  /** Which system provided the phone on this event. */
  phoneIdentityProducer?: EventProducer;
}

export interface TestAttribution {
  pricingTestTreatmentId?: string;
  /** Coverage A/B treatment the shopper was assigned when the event fired. */
  coverageTreatmentId?: string;
  /** Id space of `coverageTreatmentId`; the server drops both unless they match. */
  coverageTreatmentIdSource?: string;
}

export type AddedToCartEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.PRODUCT_ADDED_TO_CART;
    eventId: string;
    timestamp: string;
    cartLine: PixelEventsProductAddedToCartData["cartLine"];
    cart?: ShopifyPixelEventCart | null;
  };

export type ViewedEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.PRODUCT_VIEWED;
    eventId: string;
    timestamp: string;
    productVariant: PixelEventsProductViewed["data"]["productVariant"];
    cart: { id?: string } | null;
  };

export type CheckoutCompletedEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.CHECKOUT_COMPLETED;
    eventId: string;
    timestamp: string;
    checkout: PixelEventsCheckoutCompleted["data"]["checkout"];
  };

export type CheckoutStartedEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.CHECKOUT_STARTED;
    eventId: string;
    timestamp: string;
    checkout: PixelEventsCheckoutStarted["data"]["checkout"];
    cart?: ShopifyPixelEventCart | null;
  };

export type PageViewedEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.PAGE_VIEWED;
    eventId: string;
    timestamp: string;
    urlWithoutParams?: string;
    urlWithParams?: string;
    /**
     * Klaviyo's onsite `$exchange_id`, sent about once per browser per week.
     * Logged server-side to size phone/email lift; never persisted.
     */
    klaviyoExchangeId?: string;
  };

export type CollectionViewedEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.COLLECTION_VIEWED;
    eventId: string;
    timestamp: string;
    collection: { id: string; title: string };
  };

export type AlertDisplayedPaymentFailedEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.ALERT_DISPLAYED;
    eventId: string;
    timestamp: string;
    alertType: PixelEventsAlertDisplayed["data"]["alert"]["type"];
  };

export type CheckoutContactInfoSubmittedEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.CHECKOUT_CONTACT_INFO_SUBMITTED;
    eventId: string;
    timestamp: string;
    checkout: PixelEventsCheckoutContactInfoSubmitted["data"]["checkout"];
  };

export type CheckoutAddressInfoSubmittedEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.CHECKOUT_ADDRESS_INFO_SUBMITTED;
    eventId: string;
    timestamp: string;
    checkout: PixelEventsCheckoutContactInfoSubmitted["data"]["checkout"];
  };

export type CheckoutShippingInfoSubmittedEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.CHECKOUT_SHIPPING_INFO_SUBMITTED;
    eventId: string;
    timestamp: string;
    checkout: PixelEventsCheckoutContactInfoSubmitted["data"]["checkout"];
  };

export type RemovedFromCartEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.PRODUCT_REMOVED_FROM_CART;
    eventId: string;
    timestamp: string;
    cart?: ShopifyPixelEventCart | null;
    cartLine: PixelEventsProductRemovedFromCart["data"]["cartLine"];
  };

/**
 * Fired by the failed-discount-rescue Web Pixel handler when Shopify's
 * native checkout discount input shows a `DISCOUNT_ERROR` alert — i.e.
 * the buyer typed a code that Shopify rejected.
 *
 * NOT part of the {@link ShopifyStorefrontEventPayload} union because this
 * event has its own dedicated server route (`POST /widgets/:id/
 * failed-discount-attempt`) and does not flow through the generic
 * customer-event dispatch pipeline that consumes the union.
 */
export type FailedDiscountRescueAttemptedEvent = EventIdentifier &
  TestAttribution & {
    eventName: ShopifyPixelEventName.ALERT_DISPLAYED;
    eventId: string;
    timestamp: string;
    /**
     * Stable checkout session identifier — matches `useCheckoutToken()`
     * in the checkout UI extension. Join key between the pixel's POST
     * and the long-poll subscriber on the backend. Nullable so null-
     * token attempts can still be reported for server-side telemetry.
     */
    checkoutToken: string | null;
    /**
     * The exact string the buyer typed into Shopify's discount input.
     * May be null if the platform's `alert_displayed` event did not
     * surface the field value.
     */
    attemptedCode: string | null;
  };
