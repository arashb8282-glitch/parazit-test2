import { createEnum } from "@redotech/zod-util/zod-enum";
import * as z from "zod";

export enum BotClassificationReason {
  SELF_IDENTIFIED_AUTOMATION = "self_identified_automation",
  STALE_OR_FORGED_USER_AGENT = "stale_or_forged_user_agent",
  MISSING_USER_AGENT = "missing_user_agent",
  GOOGLE_SMS_SCANNER = "google_sms_scanner",
  AUTOMATED_PREVIEW = "automated_preview",
  EMAIL_HONEYPOT = "email_honeypot",
  EMAIL_CRAWL = "email_crawl",
  EMAIL_BURST = "email_burst",
}

export const BOT_CLASSIFICATION_RULE_VERSION = 1;

export const botClassificationSchema = z
  .object({
    isBot: z.boolean(),
    reasons: z.array(
      createEnum(BotClassificationReason, {
        enumName: "BotClassificationReason",
      }),
    ),
    ruleVersion: z.number().int().positive(),
  })
  .superRefine((classification, context) => {
    const hasReasons = classification.reasons.length > 0;
    if (classification.isBot !== hasReasons) {
      context.addIssue({
        code: "custom",
        message: "isBot must be true if and only if reasons is nonempty",
        path: ["isBot"],
      });
    }
  });

export type BotClassification = z.infer<typeof botClassificationSchema>;

export type BotClassificationEvaluation =
  | { status: "unevaluated" }
  | {
      status: "evaluated";
      candidateReasons: readonly BotClassificationReason[];
    };

const botClassificationReasonOrder = Object.values(BotClassificationReason);

export function createBotClassification(
  evaluation: BotClassificationEvaluation,
): BotClassification | undefined {
  if (evaluation.status === "unevaluated") {
    return undefined;
  }

  const candidateReasonSet = new Set(evaluation.candidateReasons);
  const reasons = botClassificationReasonOrder.filter((reason) =>
    candidateReasonSet.has(reason),
  );

  return {
    isBot: reasons.length > 0,
    reasons,
    ruleVersion: BOT_CLASSIFICATION_RULE_VERSION,
  };
}
