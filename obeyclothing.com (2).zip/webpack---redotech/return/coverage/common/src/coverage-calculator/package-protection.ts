import {
  CoverageCalculator,
  CoverageCalculatorOptions,
  CoveragePayer,
  CoveragePriceResult,
  CustomerInfo,
  GetCoverageParams,
  GetCoverageResult,
  getItemEligibilityInfoParams,
  isProductEnabledParams,
  IsProductEnabledResult,
  ItemInfo,
} from ".";
import {
  CoverageFeeProductMatchType,
  isCoverageFeeProduct,
} from "../is-coverage-fee-product";
import {
  cartTotalValidForProtection,
  getVariantMetafieldIdentifiers,
  itemHasInvalidMetafields,
  itemValidForProtection,
} from "./check-product";
import {
  getPackageProtectionEligibleCountries,
  isCountryCoverageExcluded,
} from "./country-check";
import { CoverageIneligibilityReason } from "./ineligibility-reasons";
import { isCoveragePausedAt } from "./utils/coverage-pause";
import { getPackageProtectionPrice } from "./utils/get-package-protection-price";
import { getCoverageMlModelInference } from "./utils/get-price-bracket-price";
import { getPricingRulesInLocalCurrency } from "./utils/get-pricing-rules-in-local-currency";
import { listsHaveMatchingElement } from "./utils/lists-have-matching-element";

export function getPackageProtectionPayer(
  settings: CoverageCalculatorOptions["settings"]["packageProtection"],
  total: number,
  rate = 1,
  date = new Date(),
): CoveragePayer {
  const threshold = settings?.packageProtectionMerchantPaidCartThreshold;
  const cartTotalValid = cartTotalValidForProtection({
    cartTotal: total,
    minCoverageEligibleCartTotal: settings?.minCoverageEligibleCartTotal,
    maxCoverageEligibleCartTotal: settings?.maxCoverageEligibleCartTotal,
  }).valid;
  const inMerchantPaidWindow =
    !!settings?.packageProtectionPlusMerchantPaidPerOrderEnabled &&
    (settings.packageProtectionPlusMerchantPaidEnabledDates ?? []).some(
      ({ start, end }) =>
        start != null &&
        new Date(start) <= date &&
        (end == null || date <= new Date(end)),
    );
  const meetsThreshold = threshold == null || total >= threshold * rate;
  const canBeMerchantPaid =
    cartTotalValid && !!settings?.packageProtectionPlusEnabled;
  const merchantPays =
    canBeMerchantPaid && inMerchantPaidWindow && meetsThreshold;
  return merchantPays ? "merchant" : "shopper";
}

const isProductEnabled = ({
  team,
  coveragePausedDates,
  coverageDate,
}: isProductEnabledParams): IsProductEnabledResult => ({
  enabled: !!(
    !isCoveragePausedAt(coveragePausedDates, coverageDate) &&
    team.settings.packageProtection?.enabled
  ),
  // Without a cart, only the merchant can pay when shoppers aren't offered it.
  payer: team.settings.packageProtection?.coverage ? "shopper" : "merchant",
});

const getShopperEligibilityInfo = (
  customerInfo: CustomerInfo,
  team: CoverageCalculatorOptions,
) => {
  if (customerInfo.disableRedoForCustomer) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.CUSTOMER_TAGS,
    };
  }

  if (
    listsHaveMatchingElement(
      customerInfo.customerTags,
      team.settings.coverageExcludeCustomerTags,
    )
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.CUSTOMER_TAGS,
    };
  }

  const packageEligibleCountries = getPackageProtectionEligibleCountries(
    team.settings.packageProtection?.pricingRuleSet,
    team.settings?.packageProtection?.countries,
  );

  const ValidCountry =
    !isCountryCoverageExcluded(
      customerInfo.country,
      team.settings.packageProtection?.pricingRuleSet,
    ) &&
    (packageEligibleCountries.includes(customerInfo.country) ||
      packageEligibleCountries.length === 0);
  if (!ValidCountry) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.SHOPPER_INELIGIBLE_COUNTRY,
    };
  }

  if (
    customerInfo.isBusinessAccount &&
    team.settings.shopifyExtension?.disableBusinessAccountInStorefront
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.BUSINESS_ACCOUNT_EXCLUDED,
    };
  }

  if (customerInfo.usingInStorePickup) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.IN_STORE_PICKUP_EXCLUDED,
    };
  }

  return { isEligible: true, reasonIneligible: undefined };
};

const getItemEligibilityInfo = ({
  item,
  team,
  redoCoverageProductIds,
}: getItemEligibilityInfoParams) => {
  if (
    isCoverageFeeProduct({
      product: item,
      redoCoverageProductIds: new Set(redoCoverageProductIds ?? []),
      matchType: CoverageFeeProductMatchType.REDO_ONLY,
    })
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.REDO_PRODUCT_EXCLUDED,
    };
  }

  if (item.requiresShipping === false) {
    return {
      isEligible: false,
      reasonIneligible:
        CoverageIneligibilityReason.ITEM_DOES_NOT_REQUIRE_SHIPPING,
    };
  }

  if (item.productLookupFailed) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.PRODUCT_LOOKUP_FAILED,
    };
  }

  const excludedCollections =
    team.settings.packageProtection?.coverageExcludedCollections ?? [];
  const itemValidResult = itemValidForProtection({
    itemInfo: {
      productTags: item.productTags,
      collections: item.collections,
      properties: item.properties,
    },
    invalidProductTags: team.settings.protectionExcludeTags ?? [],
    invalidCollections: excludedCollections,
  });

  if (!itemValidResult.valid) {
    return { isEligible: false, reasonIneligible: itemValidResult.reason };
  }

  const invalidMetafields = getVariantMetafieldIdentifiers(
    team.settings.packageProtection?.coverageExcludedVariantMetafields ?? [],
  );
  if (
    itemHasInvalidMetafields({
      itemMetafields: item.variantMetafields,
      invalidMetafields,
    })
  ) {
    return {
      isEligible: false,
      reasonIneligible:
        CoverageIneligibilityReason.ITEM_INVALID_VARIANT_METAFIELDS,
    };
  }

  return { isEligible: true, reasonIneligible: undefined };
};

const calculateCoveragePrice = ({
  team,
  country,
  numProducts,
  amount,
  conversionRate,
  hasSubscriptionItem,
  priceOverrideForCoverageMlModelCacheOnly,
  priceCalculationContext,
}: {
  team: CoverageCalculatorOptions;
  country: string | undefined;
  numProducts: number;
  amount: number;
  conversionRate?: number;
  hasSubscriptionItem?: boolean;
  priceOverrideForCoverageMlModelCacheOnly?: { price: number };
  priceCalculationContext?: { checkoutProbability: number | undefined };
}): CoveragePriceResult => {
  if (conversionRate) {
    if (team.settings.packageProtection?.minPrice) {
      team.settings.packageProtection.minPrice *= conversionRate;
    }
    if (team.settings.packageProtection?.maxPrice) {
      team.settings.packageProtection.maxPrice *= conversionRate;
    }

    if (team.settings.packageProtection?.pricingRuleSet) {
      team.settings.packageProtection.pricingRuleSet =
        getPricingRulesInLocalCurrency(
          team.settings.packageProtection.pricingRuleSet,
          conversionRate,
        );
    }

    if (team.settings.packageProtection?.pricePerItem) {
      const pricePerItem = team.settings.packageProtection.pricePerItem;
      pricePerItem.basePrice *= conversionRate;
      pricePerItem.pricePerAdditionalItem *= conversionRate;
      pricePerItem.maxPrice *= conversionRate;
    }
  }

  if (team.settings.packageProtection) {
    const ruleSets = team.settings.packageProtection?.pricingRuleSet;
    const minPrice = team.settings.packageProtection.minPrice;
    const maxPrice = team.settings.packageProtection.maxPrice;
    const backupPercentage = team.settings.packageProtection.percentage;
    const fixedSubscriptionPrice =
      team.settings.packageProtection.fixedSubscriptionPrice ?? undefined;
    const coverageMlModel = getCoverageMlModelInference({
      mlModel: team.settings.packageProtection.coverageMlModel ?? undefined,
      sessionInferenceParams: {
        checkoutProbability: priceCalculationContext?.checkoutProbability,
      },
    });

    return getPackageProtectionPrice({
      pricingStrategy: team.settings.packageProtection.pricingStrategy,
      pricePerItem: team.settings.packageProtection.pricePerItem,
      numItems: numProducts,
      cartTotal: amount,
      pricingRuleSets: ruleSets,
      country,
      minPrice,
      maxPrice,
      backupPercentage,
      fixedSubscriptionPrice,
      cartHasSubscriptionItem: hasSubscriptionItem,
      coverageMlModel,
      priceOverrideForCoverageMlModelCacheOnly,
    });
  }

  return { price: 0, source: "unspecified" };
};

// returns a price if coverage is valid. otherwise returns undefined
const getCoverage = ({
  team,
  customerInfo,
  items,
  conversionRate,
  priceOverrideForCoverageMlModelCacheOnly,
  commentsoldIntegration,
  priceCalculationContext,
  redoCoverageProductIds,
  coverageDate,
  coveragePausedDates,
}: GetCoverageParams): GetCoverageResult => {
  // Also covered by isProductEnabled; checked here so a pause is reported as
  // itself rather than as the merchant having coverage switched off.
  if (isCoveragePausedAt(coveragePausedDates, coverageDate)) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible: CoverageIneligibilityReason.COVERAGE_PAUSED,
      eligibleItems: [],
    };
  }

  if (
    !isProductEnabled({
      team,
      commentsoldIntegration,
      coveragePausedDates,
      coverageDate,
    }).enabled
  ) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible: CoverageIneligibilityReason.PRODUCT_NOT_ENABLED,
      eligibleItems: [],
    };
  }

  const shopperEligibleInfo = getShopperEligibilityInfo(customerInfo, team);
  if (!shopperEligibleInfo.isEligible) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible: shopperEligibleInfo.reasonIneligible,
      eligibleItems: [],
    };
  }

  const usePreDiscountCartValue =
    team.settings.shopifyExtension?.cartValueCalculationMethod ===
    "cart_value_pre_discount";

  let totalPrice = 0;
  let totalValidPrice = 0;
  let numValidItems = 0;
  let numInvalidItems = 0;
  const eligibleItems: ItemInfo[] = [];

  const ineligibleItemReasons = [];

  for (const item of items) {
    // Redo's own coverage item is in the cart, but it is neither a covered nor an invalid product.
    if (
      isCoverageFeeProduct({
        product: item,
        redoCoverageProductIds: new Set(redoCoverageProductIds ?? []),
        matchType: CoverageFeeProductMatchType.REDO_ONLY,
      })
    ) {
      continue;
    }
    const unitPrice = usePreDiscountCartValue
      ? item.preDiscountPrice
      : item.price;
    const itemPrice = unitPrice * item.quantity;
    totalPrice += itemPrice;
    const itemEligibleInfo = getItemEligibilityInfo({
      item,
      team,
      commentsoldIntegration,
      redoCoverageProductIds,
    });
    if (itemEligibleInfo.isEligible) {
      totalValidPrice += itemPrice;
      numValidItems += item.quantity;
      eligibleItems.push(item);
    } else {
      numInvalidItems += item.quantity;
      ineligibleItemReasons.push(itemEligibleInfo.reasonIneligible);
    }
  }

  const cartEligibleInfo = getCartEligibilityInfo(
    numValidItems,
    numInvalidItems,
    totalPrice,
    team,
  );
  if (!cartEligibleInfo.isEligible) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible:
        cartEligibleInfo.reasonIneligible || ineligibleItemReasons.join(", "),
      eligibleItems: [],
    };
  }

  const payer = getPackageProtectionPayer(
    team.settings.packageProtection,
    totalValidPrice,
    conversionRate,
    coverageDate,
  );
  // Shoppers can only pay for package protection the store offers them.
  if (payer === "shopper" && !team.settings.packageProtection?.coverage) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible: CoverageIneligibilityReason.PRODUCT_NOT_ENABLED,
      eligibleItems: [],
    };
  }
  const priceResult = calculateCoveragePrice({
    team,
    country: customerInfo.country,
    numProducts: numValidItems,
    amount: totalValidPrice,
    conversionRate,
    hasSubscriptionItem: eligibleItems.some((item) => item.hasSubscription),
    priceOverrideForCoverageMlModelCacheOnly,
    priceCalculationContext,
  });

  return {
    eligible: true,
    payer,
    priceResult,
    reasonIneligible: undefined,
    eligibleItems,
    insuredValue: totalValidPrice,
  };
};

const getCartEligibilityInfo = (
  numValidItems: number,
  numInvalidItems: number,
  cartTotal: number,
  team: CoverageCalculatorOptions,
) => {
  const cartTotalValidity = cartTotalValidForProtection({
    cartTotal,
    minCoverageEligibleCartTotal:
      team.settings.packageProtection?.minCoverageEligibleCartTotal,
    maxCoverageEligibleCartTotal:
      team.settings.packageProtection?.maxCoverageEligibleCartTotal,
  });
  if (!cartTotalValidity.valid) {
    return { isEligible: false, reasonIneligible: cartTotalValidity.reason };
  }

  if (team.settings.excludeCoverageIfAnyInvalidProduct && numInvalidItems > 0) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.CART_HAS_INVALID_PRODUCT,
    };
  }

  return { isEligible: numValidItems > 0, reasonIneligible: undefined };
};

export const packageProtectionCoverageCalculator: CoverageCalculator = {
  type: "Package Protection",
  isProductEnabled,
  getShopperEligibilityInfo,
  getItemEligibilityInfo,
  getCartEligibilityInfo,
  // need to handle non usd here.
  calculateCoveragePrice,
  getCoverage,
};
