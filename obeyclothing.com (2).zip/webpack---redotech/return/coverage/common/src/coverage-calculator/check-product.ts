import { createSkuMatcher } from "@redotech/util/sku-matcher";
import {
  CoverageIneligibilityReason,
  invalidCollectionReason,
  invalidPropertiesReason,
  invalidTagsReason,
} from "./ineligibility-reasons";

export function itemHasExcludedSku({
  sku,
  excludedSkus,
}: {
  sku: string | null | undefined;
  excludedSkus: string[];
}): boolean {
  return createSkuMatcher(excludedSkus).matches(sku);
}

export function getMatchingElementFromLists(list1: string[], list2: string[]) {
  for (const key of list1) {
    for (const attribute of list2) {
      if (attribute.toLowerCase().trim() === key.toLowerCase().trim()) {
        return attribute;
      }
    }
  }

  return undefined;
}

/**
 * Returns the exclusion lists for returns coverage.
 *
 * If final sale returns coverage is enabled, then we exclude items that are eligible for final sale returns coverage.
 * This is because and item cannot be eligible for both returns coverage and final sale returns coverage.
 *
 * @param returnsCoverage - The exclusions for returns coverage.
 * @param finalSaleReturnsCoverage - The inclusions for final sale returns coverage.
 * @returns The exclusions for returns coverage.
 */
export function getReturnsCoverageExclusions({
  returnsCoverage,
  finalSaleReturnsCoverage,
}: {
  returnsCoverage: {
    coverageExcludeProperties: string[];
    coverageExcludeCollections: string[];
    invalidProductTags: string[];
  };
  finalSaleReturnsCoverage: {
    coverageEnabled: boolean;
    validProductTags: string[];
    validCollectionTitles: string[];
  };
}): {
  coverageExcludeProperties: string[];
  coverageExcludeCollections: string[];
  invalidProductTags: string[];
} {
  const coverageExclusions = {
    coverageExcludeProperties: returnsCoverage.coverageExcludeProperties,
    coverageExcludeCollections: returnsCoverage.coverageExcludeCollections,
    invalidProductTags: returnsCoverage.invalidProductTags,
  };
  if (finalSaleReturnsCoverage.coverageEnabled) {
    coverageExclusions.invalidProductTags =
      coverageExclusions.invalidProductTags
        .concat(finalSaleReturnsCoverage.validProductTags)
        .filter(Boolean);
    coverageExclusions.coverageExcludeCollections =
      coverageExclusions.coverageExcludeCollections
        .concat(finalSaleReturnsCoverage.validCollectionTitles)
        .filter(Boolean);
  }
  return coverageExclusions;
}

export function itemValidForReturnsInfo({
  coverageExcludeProperties,
  coverageExcludeCollections,
  itemInfo,
  invalidProductTags,
  invalidMetafields,
}: {
  coverageExcludeProperties: string[];
  coverageExcludeCollections: string[];
  itemInfo: {
    properties: string[];
    productTags: string[];
    collections: string[];
    variantMetafields: { key: string; namespace: string; value: string }[];
  };
  invalidProductTags: string[];
  invalidMetafields: { key: string; namespace: string; value?: string }[];
}): { isEligible: boolean; reasonIneligible?: string } {
  const hasInvalidCollection = getMatchingElementFromLists(
    itemInfo.collections,
    coverageExcludeCollections,
  );
  const hasInvalidProperties = getMatchingElementFromLists(
    itemInfo.properties,
    coverageExcludeProperties,
  );
  const hasInvalidTags = getMatchingElementFromLists(
    itemInfo.productTags,
    invalidProductTags,
  );
  const hasInvalidMetafields = itemHasInvalidMetafields({
    itemMetafields: itemInfo.variantMetafields,
    invalidMetafields,
  });

  if (hasInvalidMetafields) {
    return {
      isEligible: false,
      reasonIneligible:
        CoverageIneligibilityReason.ITEM_INVALID_VARIANT_METAFIELDS,
    };
  }
  if (hasInvalidTags) {
    return {
      isEligible: false,
      reasonIneligible: invalidTagsReason(hasInvalidTags),
    };
  }
  if (hasInvalidCollection) {
    return {
      isEligible: false,
      reasonIneligible: invalidCollectionReason(hasInvalidCollection),
    };
  }
  if (hasInvalidProperties) {
    return {
      isEligible: false,
      reasonIneligible: invalidPropertiesReason(hasInvalidProperties),
    };
  }
  return { isEligible: true, reasonIneligible: undefined };
}

export function itemValidForProtection({
  itemInfo,
  invalidProductTags,
  invalidCollections,
}: {
  itemInfo: {
    productTags: string[];
    collections: string[];
    properties?: string[];
  };
  invalidProductTags: string[];
  invalidCollections: string[];
}): { valid: true } | { valid: false; reason: CoverageIneligibilityReason } {
  const hasInvalidTags = getMatchingElementFromLists(
    itemInfo.productTags,
    invalidProductTags,
  );
  if (hasInvalidTags) {
    return {
      valid: false,
      reason: CoverageIneligibilityReason.EXCLUDED_PRODUCT_TAGS,
    };
  }

  if (invalidCollections.length && itemInfo.collections.length) {
    const hasInvalidCollection = getMatchingElementFromLists(
      itemInfo.collections,
      invalidCollections,
    );
    if (hasInvalidCollection) {
      return {
        valid: false,
        reason: CoverageIneligibilityReason.EXCLUDED_PRODUCT_COLLECTIONS,
      };
    }
  }

  return { valid: true };
}

export function cartTotalValidForProtection({
  cartTotal,
  minCoverageEligibleCartTotal,
  maxCoverageEligibleCartTotal,
}: {
  cartTotal: number;
  minCoverageEligibleCartTotal: number | null | undefined;
  maxCoverageEligibleCartTotal: number | null | undefined;
}): { valid: true } | { valid: false; reason: CoverageIneligibilityReason } {
  if (
    minCoverageEligibleCartTotal &&
    cartTotal < minCoverageEligibleCartTotal
  ) {
    return {
      valid: false,
      reason: CoverageIneligibilityReason.CART_TOTAL_BELOW_MINIMUM,
    };
  }
  if (
    maxCoverageEligibleCartTotal &&
    cartTotal > maxCoverageEligibleCartTotal
  ) {
    return {
      valid: false,
      reason: CoverageIneligibilityReason.CART_TOTAL_ABOVE_MAXIMUM,
    };
  }
  return { valid: true };
}

export function itemValidForFinalSaleReturns({
  itemInfo,
  validProductTags,
  validCollections,
  allEligible = false,
  eligibleDiscountThreshold,
}: {
  itemInfo: {
    price: number;
    preDiscountPrice: number;
    productTags: string[];
    collections: string[];
  };
  validProductTags: string[];
  validCollections: string[];
  allEligible?: boolean;
  eligibleDiscountThreshold?: number | null | undefined;
}): boolean {
  if (allEligible) {
    return true;
  }

  if (
    isItemPastCouponThreshold(
      itemInfo.price,
      itemInfo.preDiscountPrice,
      eligibleDiscountThreshold,
    )
  ) {
    return true;
  }

  const hasValidTags = getMatchingElementFromLists(
    itemInfo.productTags,
    validProductTags,
  );

  const hasValidCollections = getMatchingElementFromLists(
    itemInfo.collections,
    validCollections,
  );

  return !!hasValidTags || !!hasValidCollections;
}

export function isItemPastCouponThreshold(
  price: number,
  preCouponPrice: number,
  couponedItemsDiscountThreshold: number | null | undefined,
): boolean {
  if (!couponedItemsDiscountThreshold) {
    return false;
  }
  if (preCouponPrice === 0) {
    return false;
  }
  const threshold = couponedItemsDiscountThreshold * 0.01;

  return (preCouponPrice - price) / preCouponPrice > threshold;
}

export function getVariantMetafieldIdentifiers(
  metafieldExclusionStrings: string[],
): { key: string; namespace: string; value?: string }[] {
  const seen = new Set<string>();
  const results: { key: string; namespace: string; value?: string }[] = [];

  for (const entry of metafieldExclusionStrings) {
    const [metafieldPart, ...valueParts] = entry.split(":");
    const value = valueParts.join(":").trim() || undefined;
    if (!metafieldPart || !metafieldPart.includes(".")) {
      continue;
    }
    const parts = metafieldPart.split(".");
    const namespace = parts.slice(0, -1).join(".");
    const key = parts.at(-1) ?? "";
    if (!namespace || !key) {
      continue;
    }
    const dedupeKey = `${namespace}.${key}:${value ?? ""}`;
    if (!seen.has(dedupeKey)) {
      seen.add(dedupeKey);
      results.push({ key, namespace, value });
    }
  }

  return results;
}

export function itemHasInvalidMetafields({
  itemMetafields,
  invalidMetafields,
}: {
  itemMetafields: { key: string; namespace: string; value: string }[];
  invalidMetafields: { key: string; namespace: string; value?: string }[];
}): boolean {
  return itemMetafields.some((itemMf) =>
    invalidMetafields.some(
      (invalidMf) =>
        itemMf.namespace === invalidMf.namespace &&
        itemMf.key === invalidMf.key &&
        (!invalidMf.value ||
          itemMf.value.toLowerCase() === invalidMf.value.toLowerCase()),
    ),
  );
}
