import {
  CoverageCalculator,
  CoverageCalculatorOptions,
  CoveragePriceResult,
  CustomerInfo,
  GetCoverageParams,
  GetCoverageResult,
  getItemEligibilityInfoParams,
  isProductEnabledParams,
  IsProductEnabledResult,
  ItemInfo,
} from ".";
import {
  CoverageFeeProductMatchType,
  isCoverageFeeProduct,
} from "../is-coverage-fee-product";
import {
  cartTotalValidForProtection,
  itemValidForFinalSaleReturns,
} from "./check-product";
import { CoverageIneligibilityReason } from "./ineligibility-reasons";
import { isCoveragePausedAt } from "./utils/coverage-pause";
import { getFinalSaleReturnsPrice } from "./utils/get-final-sale-returns-price";
import { getPricingRulesInLocalCurrency } from "./utils/get-pricing-rules-in-local-currency";
import { listsHaveMatchingElement } from "./utils/lists-have-matching-element";

const isProductEnabled = ({
  team,
  commentsoldIntegration,
  coveragePausedDates,
  coverageDate,
}: isProductEnabledParams): IsProductEnabledResult => ({
  enabled:
    !isCoveragePausedAt(coveragePausedDates, coverageDate) &&
    !!team.settings.returns?.finalSaleReturns?.enabled &&
    commentsoldIntegration?.returnsSettings?.enableFinalSaleCoverage !== false,
  payer: "shopper",
});

const getShopperEligibilityInfo = (
  customerInfo: CustomerInfo,
  team: CoverageCalculatorOptions,
) => {
  if (customerInfo.disableRedoForCustomer) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.CUSTOMER_TAGS,
    };
  }

  if (
    listsHaveMatchingElement(
      customerInfo.customerTags,
      team.settings.coverageExcludeCustomerTags,
    )
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.CUSTOMER_TAGS,
    };
  }

  const finalSaleReturnsEligibleCountries =
    getAllFinalSaleReturnsEligibleCountries(team);

  const ValidCountry =
    finalSaleReturnsEligibleCountries.includes(customerInfo.country) ||
    finalSaleReturnsEligibleCountries.length === 0;

  if (!ValidCountry) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.SHOPPER_INELIGIBLE_COUNTRY,
    };
  }

  if (
    customerInfo.isBusinessAccount &&
    team.settings.shopifyExtension?.disableBusinessAccountInStorefront
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.BUSINESS_ACCOUNT_EXCLUDED,
    };
  }

  if (
    customerInfo.usingInStorePickup &&
    team.settings.shopifyExtension?.coverageExcludePickup !== false
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.IN_STORE_PICKUP_EXCLUDED,
    };
  }

  return { isEligible: true, reasonIneligible: undefined };
};

const getItemEligibilityInfo = ({
  item,
  team,
  redoCoverageProductIds,
}: getItemEligibilityInfoParams) => {
  if (
    isCoverageFeeProduct({
      product: item,
      redoCoverageProductIds: new Set(redoCoverageProductIds ?? []),
      matchType: CoverageFeeProductMatchType.REDO_ONLY,
    })
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.REDO_PRODUCT_EXCLUDED,
    };
  }

  if (item.requiresShipping === false) {
    return {
      isEligible: false,
      reasonIneligible:
        CoverageIneligibilityReason.ITEM_DOES_NOT_REQUIRE_SHIPPING,
    };
  }

  if (item.productLookupFailed) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.PRODUCT_LOOKUP_FAILED,
    };
  }

  // for commentsold final sale eligibility use their is_final_sale property to consider something valid for FSR
  if (item.isFinalSale) {
    return { isEligible: true, reasonIneligible: undefined };
  }

  const isItemValid = itemValidForFinalSaleReturns({
    itemInfo: {
      price: item.price,
      preDiscountPrice: item.preDiscountPrice,
      productTags: item.productTags,
      collections: item.collections,
    },
    validCollections:
      team.settings.returns?.finalSaleReturns?.validCollectionTitles ?? [],
    validProductTags:
      team.settings.returns?.finalSaleReturns?.validProductTags ?? [],
    allEligible:
      team.settings.returns?.finalSaleReturns?.allEligible ?? undefined,
    eligibleDiscountThreshold:
      team.settings.returns?.finalSaleReturns?.eligibleDiscountThreshold ??
      undefined,
  });

  if (!isItemValid) {
    return {
      isEligible: false,
      reasonIneligible:
        CoverageIneligibilityReason.ITEM_NOT_VALID_FOR_FINAL_SALE_RETURNS,
    };
  }

  return { isEligible: true, reasonIneligible: undefined };
};

// returns a list of countries. Empty list means all countries
export function getAllFinalSaleReturnsEligibleCountries(
  team: CoverageCalculatorOptions,
) {
  if (team.settings.returns?.finalSaleReturns?.pricingRuleSet?.length) {
    // The second set of pricing is international. so all countries are eligible.
    if (
      team.settings.returns?.finalSaleReturns?.pricingRuleSet[1] &&
      !team.settings.returns?.finalSaleReturns?.pricingRuleSet[1].countries
        .length
    ) {
      return [];
    } else {
      // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
      return team.settings.returns?.finalSaleReturns?.pricingRuleSet[0]
        .countries;
    }
  }
  return [];
}

const calculateCoveragePrice = ({
  team,
  country,
  numProducts,
  amount,
  conversionRate,
  hasSubscriptionItem,
}: {
  team: CoverageCalculatorOptions;
  country: string | undefined;
  numProducts: number;
  amount: number;
  conversionRate?: number;
  hasSubscriptionItem?: boolean;
}): CoveragePriceResult => {
  if (conversionRate && team.settings.returns?.finalSaleReturns) {
    team.settings.returns.finalSaleReturns.minPrice *= conversionRate;
    team.settings.returns.finalSaleReturns.maxPrice *= conversionRate;

    if (team.settings.returns.finalSaleReturns.shippingLabelCoveragePrice) {
      team.settings.returns.finalSaleReturns.shippingLabelCoveragePrice *=
        conversionRate;
    }

    if (team.settings.returns.finalSaleReturns.pricingRuleSet) {
      team.settings.returns.finalSaleReturns.pricingRuleSet =
        getPricingRulesInLocalCurrency(
          team.settings.returns.finalSaleReturns.pricingRuleSet,
          conversionRate,
        );
    }
  }

  if (team.settings.returns?.finalSaleReturns) {
    return getFinalSaleReturnsPrice({
      cartTotal: amount,
      pricingRuleSets: team.settings.returns.finalSaleReturns.pricingRuleSet,
      shippingLabelCoveragePrice:
        team.settings.returns.finalSaleReturns.shippingLabelCoveragePrice,
      country,
      minPrice: team.settings.returns.finalSaleReturns.minPrice,
      maxPrice: team.settings.returns.finalSaleReturns.maxPrice,
      backupPercentage: team.settings.returns.finalSaleReturns.percentage,
    });
  }
  return { price: 0, source: "unspecified" };
};

// returns a price if coverage is valid. otherwise returns undefined
const getCoverage = ({
  team,
  customerInfo,
  items,
  conversionRate,
  commentsoldIntegration,
  redoCoverageProductIds,
  coveragePausedDates,
  coverageDate,
}: GetCoverageParams): GetCoverageResult => {
  // Also covered by isProductEnabled; checked here so a pause is reported as
  // itself rather than as the merchant having coverage switched off.
  if (isCoveragePausedAt(coveragePausedDates, coverageDate)) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible: CoverageIneligibilityReason.COVERAGE_PAUSED,
      eligibleItems: [],
    };
  }

  if (
    !isProductEnabled({
      team,
      commentsoldIntegration,
      coveragePausedDates,
      coverageDate,
    }).enabled
  ) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible: CoverageIneligibilityReason.PRODUCT_NOT_ENABLED,
      eligibleItems: [],
    };
  }

  const shopperEligibleInfo = getShopperEligibilityInfo(customerInfo, team);
  if (!shopperEligibleInfo.isEligible) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible: shopperEligibleInfo.reasonIneligible,
      eligibleItems: [],
    };
  }

  const usePreDiscountCartValue =
    team.settings.shopifyExtension?.cartValueCalculationMethod ===
    "cart_value_pre_discount";

  let totalPrice = 0;
  const eligibleItems: ItemInfo[] = [];
  let totalValidPrice = 0;
  let numValidItems = 0;
  let numInvalidItems = 0;

  const ineligibleItemReasons = [];

  for (const item of items) {
    // Redo's own coverage item is in the cart, but it is neither a covered nor an invalid product.
    if (
      isCoverageFeeProduct({
        product: item,
        redoCoverageProductIds: new Set(redoCoverageProductIds ?? []),
        matchType: CoverageFeeProductMatchType.REDO_ONLY,
      })
    ) {
      continue;
    }
    const unitPrice = usePreDiscountCartValue
      ? item.preDiscountPrice
      : item.price;
    const itemPrice = unitPrice * item.quantity;
    totalPrice += itemPrice;
    const itemEligibleInfo = getItemEligibilityInfo({
      item,
      team,
      commentsoldIntegration,
      redoCoverageProductIds,
    });
    if (itemEligibleInfo.isEligible) {
      eligibleItems.push(item);
      totalValidPrice += itemPrice;
      numValidItems += item.quantity;
    } else {
      numInvalidItems += item.quantity;
      ineligibleItemReasons.push(itemEligibleInfo.reasonIneligible);
    }
  }

  const cartEligibleInfo = getCartEligibilityInfo(
    numValidItems,
    numInvalidItems,
    totalPrice,
    team,
  );
  if (!cartEligibleInfo.isEligible) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible:
        cartEligibleInfo.reasonIneligible || ineligibleItemReasons.join(", "),
      eligibleItems: [],
    };
  }

  const priceResult = calculateCoveragePrice({
    team,
    country: customerInfo.country,
    numProducts: numValidItems,
    amount: totalValidPrice,
    conversionRate,
    hasSubscriptionItem: items.some((item) => item.hasSubscription),
  });

  return {
    eligible: true,
    payer: "shopper",
    priceResult,
    reasonIneligible: undefined,
    eligibleItems,
  };
};

const getCartEligibilityInfo = (
  numValidItems: number,
  numInvalidItems: number,
  cartTotal: number,
  team: CoverageCalculatorOptions,
) => {
  const cartTotalValidity = cartTotalValidForProtection({
    cartTotal,
    minCoverageEligibleCartTotal:
      team.settings.returns?.finalSaleReturns?.minCoverageEligibleCartTotal,
    maxCoverageEligibleCartTotal:
      team.settings.returns?.finalSaleReturns?.maxCoverageEligibleCartTotal,
  });
  if (!cartTotalValidity.valid) {
    return { isEligible: false, reasonIneligible: cartTotalValidity.reason };
  }

  return { isEligible: numValidItems > 0, reasonIneligible: undefined };
};

export const finalSaleReturnsCoverageCalculator: CoverageCalculator = {
  type: "Final Sale",
  isProductEnabled,
  getShopperEligibilityInfo,
  getItemEligibilityInfo,
  getCartEligibilityInfo,
  // need to handle non usd here.
  calculateCoveragePrice,
  getCoverage,
};

/**
 * FSR has its own country list on `finalSaleReturns.pricingRuleSet`, independent
 * of the regular-returns list; `[]` means all countries are allowed.
 */
export function isLocationValidForFinalSale({
  team,
  shippingAddress,
}: {
  team: CoverageCalculatorOptions;
  shippingAddress: { country_code?: string | null } | null | undefined;
}): boolean {
  const finalSaleCountries = getAllFinalSaleReturnsEligibleCountries(team);
  return (
    !finalSaleCountries.length ||
    !shippingAddress ||
    finalSaleCountries.includes(shippingAddress.country_code ?? "")
  );
}
