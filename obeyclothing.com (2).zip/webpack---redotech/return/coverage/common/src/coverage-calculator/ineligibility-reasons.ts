// Stable tokens for `reasonIneligible` values returned by coverage calculators
// (Returns, Package Protection, Final Sale Returns) and shared item/cart
// helpers. Centralized so downstream consumers — storefront debug tooling,
// logs, analytics — can match against named constants instead of human strings
// scattered across the calculator files.
//
// Existing string values are preserved verbatim to avoid breaking any external
// consumer that already matches on the legacy strings.
export enum CoverageIneligibilityReason {
  CUSTOMER_TAGS = "customer_tags",
  SHOPPER_INELIGIBLE_COUNTRY = "shopper is in an ineligible country",
  BUSINESS_ACCOUNT_EXCLUDED = "business account excluded",
  IN_STORE_PICKUP_EXCLUDED = "in store pickup excluded",
  REDO_PRODUCT_EXCLUDED = "redo product excluded",
  ITEM_FINAL_SALE = "item marked as final sale",
  ITEM_DOES_NOT_REQUIRE_SHIPPING = "item does not require shipping",
  EXCLUDED_CENT_ENDING = "excluded cent ending",
  DISCOUNT_CODE = "discount code",
  DISCOUNTED_ALL_FINAL_SALE = "Item is discounted and all discounts are final sales",
  DISCOUNTED_PAST_COUPON_THRESHOLD = "Item is discounted and past the coupon threshold",
  FINAL_SALE_RETURNS_VIA_COUPON_THRESHOLD = "Item is eligible for final sale returns via coupon threshold",
  EXCLUDED_PRODUCT_TAGS = "excluded product tags",
  ITEM_EXCLUDED_SKU = "item excluded by sku",
  EXCLUDED_PRODUCT_COLLECTIONS = "excluded product collections",
  ITEM_INVALID_VARIANT_METAFIELDS = "Item has invalid variant metafields",
  ITEM_NOT_VALID_FOR_FINAL_SALE_RETURNS = "item not valid for final sale returns",
  CART_TOTAL_BELOW_MINIMUM = "cart total below minimum",
  CART_TOTAL_ABOVE_MAXIMUM = "cart total above maximum",
  CART_HAS_INVALID_PRODUCT = "cart has at least one invalid product",
  PRODUCT_NOT_ENABLED = "product not enabled",
  INVALID_TAGS = "invalid tags",
  INVALID_COLLECTION = "invalid collection",
  INVALID_PROPERTIES = "invalid properties",
  ORDER_TAGS = "order_tags",
  COVERAGE_PAUSED = "coverage paused",
  FRAUD_ZIP_CODE = "fraud_zip_code",
  FRAUD_BLOCKED_CUSTOMER = "fraud_blocked_customer",
  PRE_PROTECTED = "customer is pre-protected",
  MERCHANT_PAID = "merchant pays for coverage",
  PRODUCT_LOOKUP_FAILED = "product lookup failed",
}

const DEFAULT_DESCRIPTION = "order is not eligible for coverage";

/**
 * Merchant-facing copy for reasons that can auto-refund coverage during order
 * sync; these end up in the Shopify refund note.
 */
const INELIGIBILITY_DESCRIPTIONS: Partial<
  Record<CoverageIneligibilityReason, string>
> = {
  [CoverageIneligibilityReason.PRODUCT_NOT_ENABLED]: "coverage is not enabled",
  [CoverageIneligibilityReason.SHOPPER_INELIGIBLE_COUNTRY]:
    "shipping country not eligible for coverage",
  [CoverageIneligibilityReason.ORDER_TAGS]: "order tag excluded from coverage",
  [CoverageIneligibilityReason.CUSTOMER_TAGS]:
    "customer has a tag which makes them ineligible for coverage",
  [CoverageIneligibilityReason.EXCLUDED_PRODUCT_TAGS]:
    "product(s) have a tag which make them ineligible for coverage",
  [CoverageIneligibilityReason.ITEM_NOT_VALID_FOR_FINAL_SALE_RETURNS]:
    "product(s) are not eligible for final sale coverage",
  [CoverageIneligibilityReason.REDO_PRODUCT_EXCLUDED]:
    "order contains only Redo products (possible fraud)",
  [CoverageIneligibilityReason.FRAUD_ZIP_CODE]:
    "order is not eligible for coverage due to high fraud risk",
  [CoverageIneligibilityReason.FRAUD_BLOCKED_CUSTOMER]:
    "order is not eligible for coverage due to high fraud risk",
};

/** Unmapped reasons get the default so raw tokens never reach merchants. */
export function describeIneligibilityReason(
  reason: string | undefined,
): string {
  if (!reason) {
    return DEFAULT_DESCRIPTION;
  }
  const lookup: Record<string, string | undefined> = INELIGIBILITY_DESCRIPTIONS;
  return lookup[reason] ?? DEFAULT_DESCRIPTION;
}

// Dynamic reasons format as `${enum prefix}: '${detail}'` so callers can still
// match on the enum value while keeping the offending value visible.
export function invalidTagsReason(tags: string): string {
  return `${CoverageIneligibilityReason.INVALID_TAGS}: '${tags}'`;
}
export function invalidCollectionReason(collection: string): string {
  return `${CoverageIneligibilityReason.INVALID_COLLECTION}: '${collection}'`;
}
export function invalidPropertiesReason(properties: string): string {
  return `${CoverageIneligibilityReason.INVALID_PROPERTIES}: '${properties}'`;
}
