import {
  CoverageCalculator,
  CoverageCalculatorOptions,
  CoveragePriceResult,
  CustomerInfo,
  GetCoverageParams,
  GetCoverageResult,
  getItemEligibilityInfoParams,
  isProductEnabledParams,
  IsProductEnabledResult,
  ItemInfo,
} from ".";
import {
  DynamicReturnTypes,
  InternationalReturnPricing,
} from "../coverage-types";
import {
  CoverageFeeProductMatchType,
  isCoverageFeeProduct,
} from "../is-coverage-fee-product";
import {
  getReturnsCoverageExclusions,
  getVariantMetafieldIdentifiers,
  isItemPastCouponThreshold,
  itemHasExcludedSku,
  itemValidForReturnsInfo,
} from "./check-product";
import {
  getAllReturnEligibleCountries,
  getInternationalPrice,
  isCountryCoverageExcluded,
} from "./country-check";
import { CoverageIneligibilityReason } from "./ineligibility-reasons";
import { calculateDynamicReturnsPrice } from "./utils/calculate-dynamic-returns-price";
import { isCoveragePausedAt } from "./utils/coverage-pause";
import { derivePaymentModel } from "./utils/derive-payment-model";
import { getPricingRulesInLocalCurrency } from "./utils/get-pricing-rules-in-local-currency";
import { listsHaveMatchingElement } from "./utils/lists-have-matching-element";

const isProductEnabled = ({
  team,
  coveragePausedDates,
  coverageDate,
}: isProductEnabledParams): IsProductEnabledResult => ({
  enabled: !!(
    !isCoveragePausedAt(coveragePausedDates, coverageDate) &&
    team.settings.enabled &&
    team.settings.returns?.enabled &&
    team.settings.coverageEnabled &&
    (team.pricePerOrder || team.settings.returns.dynamicPricing)
  ),
  payer:
    derivePaymentModel(team.settings.merchantPaidEnabledDates, coverageDate) ===
    "merchant_paid"
      ? "merchant"
      : "shopper",
});

const getShopperEligibilityInfo = (
  customerInfo: CustomerInfo,
  team: CoverageCalculatorOptions,
) => {
  if (customerInfo.disableRedoForCustomer) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.CUSTOMER_TAGS,
    };
  }

  if (
    listsHaveMatchingElement(
      customerInfo.customerTags,
      team.settings.coverageExcludeCustomerTags,
    )
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.CUSTOMER_TAGS,
    };
  }

  const returnCountries = getAllReturnEligibleCountries(
    team.settings.countries,
    team.settings.returns?.internationalPricing,
  );
  const ValidCountry =
    !isCountryCoverageExcluded(
      customerInfo.country,
      team.settings.returns?.internationalPricing,
      team.settings.countries,
    ) &&
    (returnCountries.includes(customerInfo.country) ||
      returnCountries.length == 0);

  if (!ValidCountry) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.SHOPPER_INELIGIBLE_COUNTRY,
    };
  }

  if (
    customerInfo.isBusinessAccount &&
    team.settings.shopifyExtension?.disableBusinessAccountInStorefront
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.BUSINESS_ACCOUNT_EXCLUDED,
    };
  }

  if (
    customerInfo.usingInStorePickup &&
    team.settings.shopifyExtension?.coverageExcludePickup !== false
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.IN_STORE_PICKUP_EXCLUDED,
    };
  }

  return { isEligible: true, reasonIneligible: undefined };
};

const getItemEligibilityInfo = ({
  item,
  team,
  commentsoldIntegration,
  redoCoverageProductIds,
}: getItemEligibilityInfoParams) => {
  if (
    isCoverageFeeProduct({
      product: item,
      redoCoverageProductIds: new Set(redoCoverageProductIds ?? []),
      matchType: CoverageFeeProductMatchType.REDO_ONLY,
    })
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.REDO_PRODUCT_EXCLUDED,
    };
  }

  if (item.isFinalSale) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.ITEM_FINAL_SALE,
    };
  }

  if (item.requiresShipping === false) {
    return {
      isEligible: false,
      reasonIneligible:
        CoverageIneligibilityReason.ITEM_DOES_NOT_REQUIRE_SHIPPING,
    };
  }

  if (item.productLookupFailed) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.PRODUCT_LOOKUP_FAILED,
    };
  }

  if (
    commentsoldIntegration &&
    item.preDiscountPrice &&
    team.settings.coverageExcludeCentEnding.length
  ) {
    const cents = item.preDiscountPrice.toFixed(2).split(".")[1];
    const centExclusions = team.settings.coverageExcludeCentEnding;
    const exclusionMatch = centExclusions.find(
      (centExclusion) => cents === centExclusion,
    );

    if (exclusionMatch) {
      return {
        isEligible: false,
        reasonIneligible: CoverageIneligibilityReason.EXCLUDED_CENT_ENDING,
      };
    }
  }

  // This handles the case where the discount only has a name and not a code
  const hasExcludedDiscount = item.discounts.some((code) =>
    team.settings.discountCodePartialMatch
      ? team.settings.coverageExcludeDiscountCodes.some((exclude) =>
          (code.code || code.name).includes(exclude),
        )
      : team.settings.coverageExcludeDiscountCodes.includes(
          code.code || code.name,
        ),
  );
  if (hasExcludedDiscount) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.DISCOUNT_CODE,
    };
  }

  // this settings is misnamed. it actually means products with a compare at price is ineligible.
  if (
    team.settings.publicapi?.discountsAreFinalSales &&
    item.compareAtPrice &&
    item.preDiscountPrice < item.compareAtPrice
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.DISCOUNTED_ALL_FINAL_SALE,
    };
  }

  if (
    isItemPastCouponThreshold(
      item.price,
      item.preDiscountPrice,
      team.settings.publicapi?.couponedItemsDiscountThreshold,
    )
  ) {
    return {
      isEligible: false,
      reasonIneligible:
        CoverageIneligibilityReason.DISCOUNTED_PAST_COUPON_THRESHOLD,
    };
  }

  const finalSaleCoverageEnabled =
    !!team.settings.returns?.finalSaleReturns?.enabled &&
    commentsoldIntegration?.returnsSettings?.enableFinalSaleCoverage !== false;

  // this checks if the item is eligible for final sale returns via coupon threshold
  // this makes final sale and returns mutually exclusive when using this setting just like tags / collections
  if (
    finalSaleCoverageEnabled &&
    isItemPastCouponThreshold(
      item.price,
      item.preDiscountPrice,
      team.settings.returns?.finalSaleReturns?.eligibleDiscountThreshold,
    )
  ) {
    return {
      isEligible: false,
      reasonIneligible:
        CoverageIneligibilityReason.FINAL_SALE_RETURNS_VIA_COUPON_THRESHOLD,
    };
  }

  const coverageExclusions = getReturnsCoverageExclusions({
    returnsCoverage: {
      coverageExcludeProperties: team.settings.coverageExcludeProperties,
      coverageExcludeCollections: team.settings.coverageExcludeCollections,
      invalidProductTags: team.settings.coverageExcludeProductTags,
    },
    finalSaleReturnsCoverage: {
      coverageEnabled: finalSaleCoverageEnabled,
      validProductTags:
        team.settings.returns?.finalSaleReturns?.validProductTags ?? [],
      validCollectionTitles:
        team.settings.returns?.finalSaleReturns?.validCollectionTitles ?? [],
    },
  });

  const isItemValidInfo = itemValidForReturnsInfo({
    ...coverageExclusions,
    itemInfo: { ...item },
    invalidMetafields: getVariantMetafieldIdentifiers(
      team.settings.returns?.coverageExcludedVariantMetafields ?? [],
    ),
  });
  if (!isItemValidInfo.isEligible) {
    return {
      isEligible: false,
      reasonIneligible: isItemValidInfo.reasonIneligible,
    };
  }

  if (
    itemHasExcludedSku({
      sku: item.sku,
      excludedSkus: team.settings.returns?.returnsCoverageExcludedSkus ?? [],
    })
  ) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.ITEM_EXCLUDED_SKU,
    };
  }

  return { isEligible: true, reasonIneligible: undefined };
};

const calculateCoveragePrice = ({
  team,
  country,
  numProducts,
  amount,
  conversionRate,
}: {
  team: CoverageCalculatorOptions;
  country: string | undefined;
  numProducts: number;
  amount: number;
  conversionRate?: number;
}): CoveragePriceResult => {
  const dynamicPricing = team.settings.returns?.dynamicPricing;

  if (conversionRate) {
    if (
      dynamicPricing &&
      dynamicPricing.type === DynamicReturnTypes.ITEM_COUNT
    ) {
      dynamicPricing.maxPrice = dynamicPricing.maxPrice * conversionRate;
      dynamicPricing.pricePerAdditonalItem =
        dynamicPricing.pricePerAdditonalItem * conversionRate;
    } else if (
      dynamicPricing &&
      dynamicPricing.type === DynamicReturnTypes.CART_VALUE
    ) {
      dynamicPricing.maxPrice = dynamicPricing.maxPrice * conversionRate;
      // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
      dynamicPricing.pricingRuleSet = getPricingRulesInLocalCurrency(
        [dynamicPricing.pricingRuleSet],
        conversionRate,
      )[0];
    }

    if (team.pricePerOrder) {
      team.pricePerOrder = (
        parseFloat(team.pricePerOrder) * conversionRate
      ).toString();
    }
  }

  const basePrice = parseFloat(team.pricePerOrder || "0");
  if (isNaN(basePrice) || (!basePrice && !dynamicPricing)) {
    return { price: 0, source: "unspecified" };
  }
  let coveragePrice = basePrice;

  if (dynamicPricing) {
    coveragePrice = calculateDynamicReturnsPrice(
      dynamicPricing,
      basePrice,
      numProducts,
      amount,
    ).price;
  }

  if (team.settings.returns?.internationalPricing && country) {
    coveragePrice = getInternationalPrice(
      coveragePrice,
      country,
      team.settings.countries,
      team.settings.returns.internationalPricing as InternationalReturnPricing,
    );
  }

  return { price: coveragePrice, source: "unspecified" };
};

const getCartEligibilityInfo = (
  numValidItems: number,
  numInvalidItems: number,
  cartTotal: number,
  team: CoverageCalculatorOptions,
) => {
  if (team.settings.excludeCoverageIfAnyInvalidProduct && numInvalidItems > 0) {
    return {
      isEligible: false,
      reasonIneligible: CoverageIneligibilityReason.CART_HAS_INVALID_PRODUCT,
    };
  }

  return { isEligible: numValidItems > 0, reasonIneligible: undefined };
};

// returns a price if coverage is valid. otherwise returns undefined
const getCoverage = ({
  team,
  customerInfo,
  items,
  conversionRate,
  commentsoldIntegration,
  redoCoverageProductIds,
  coveragePausedDates,
  coverageDate,
}: GetCoverageParams): GetCoverageResult => {
  // Also covered by isProductEnabled; checked here so a pause is reported as
  // itself rather than as the merchant having coverage switched off.
  if (isCoveragePausedAt(coveragePausedDates, coverageDate)) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible: CoverageIneligibilityReason.COVERAGE_PAUSED,
      eligibleItems: [],
    };
  }

  const { enabled, payer } = isProductEnabled({
    team,
    commentsoldIntegration,
    coveragePausedDates,
    coverageDate,
  });
  if (!enabled) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible: CoverageIneligibilityReason.PRODUCT_NOT_ENABLED,
      eligibleItems: [],
    };
  }

  const shopperEligibleInfo = getShopperEligibilityInfo(customerInfo, team);
  if (!shopperEligibleInfo.isEligible) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible: shopperEligibleInfo.reasonIneligible,
      eligibleItems: [],
    };
  }

  const usePreDiscountCartValue =
    team.settings.shopifyExtension?.cartValueCalculationMethod ===
    "cart_value_pre_discount";

  let totalPrice = 0;
  let numValidItems = 0;
  let numInvalidItems = 0;
  const eligibleItems: ItemInfo[] = [];

  const ineligibleItemReasons = [];

  for (const item of items) {
    // Redo's own coverage item is in the cart, but it is neither a covered nor an invalid product.
    if (
      isCoverageFeeProduct({
        product: item,
        redoCoverageProductIds: new Set(redoCoverageProductIds ?? []),
        matchType: CoverageFeeProductMatchType.REDO_ONLY,
      })
    ) {
      continue;
    }
    const itemEligibleInfo = getItemEligibilityInfo({
      item,
      team,
      commentsoldIntegration,
      redoCoverageProductIds,
    });
    if (itemEligibleInfo.isEligible) {
      const unitPrice = usePreDiscountCartValue
        ? item.preDiscountPrice
        : item.price;
      totalPrice += unitPrice * item.quantity;
      numValidItems += item.quantity;
      eligibleItems.push(item);
    } else {
      numInvalidItems += item.quantity;
      ineligibleItemReasons.push(itemEligibleInfo.reasonIneligible);
    }
  }

  const cartEligibleInfo = getCartEligibilityInfo(
    numValidItems,
    numInvalidItems,
    totalPrice,
    team,
  );
  if (!cartEligibleInfo.isEligible) {
    return {
      eligible: false,
      payer: "shopper",
      priceResult: undefined,
      reasonIneligible:
        cartEligibleInfo.reasonIneligible || ineligibleItemReasons.join(", "),
      eligibleItems: [],
    };
  }

  const priceResult = calculateCoveragePrice({
    team,
    country: customerInfo.country,
    numProducts: numValidItems,
    amount: totalPrice,
    conversionRate,
  });

  return {
    eligible: true,
    payer,
    priceResult,
    reasonIneligible: undefined,
    eligibleItems,
  };
};

export const returnCoverageCalculator: CoverageCalculator = {
  type: "Returns",
  isProductEnabled,
  getShopperEligibilityInfo,
  getItemEligibilityInfo,
  getCartEligibilityInfo,
  // need to handle non usd here.
  calculateCoveragePrice,
  getCoverage,
};
