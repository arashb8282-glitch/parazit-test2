import { CoverageCalculatorOptions } from "./index";

import { finalSaleReturnsCoverageCalculator } from "./final-sale-returns";
import {
  CoveragePausedDates,
  CustomerInfo,
  GetCoverageResult,
  ItemInfo,
} from "./index";
import { CoverageIneligibilityReason } from "./ineligibility-reasons";
import { packageProtectionCoverageCalculator } from "./package-protection";
import { returnCoverageCalculator } from "./returns";

export interface CoverageInfo {
  returns: {
    cartEligible: boolean;
    price: number;
    isFinalSale: boolean;
    reasonIneligible?: string;
  };
  packageProtection: {
    cartEligible: boolean;
    price: number;
    reasonIneligible?: string;
  };
  both: { cartEligible: boolean; price: number; reasonIneligible?: string };
}

interface GetCoverageInfoFromCalculatorsParams {
  team: CoverageCalculatorOptions;
  customerInfo: CustomerInfo;
  items: ItemInfo[];
  redoCoverageProductIds: string[];
  onTapcart: boolean;
  cachedProtectionCoveragePrice: number | undefined;
  checkoutProbability: number | undefined;
  returnMoneyType: "cents" | "dollars";
  /**
   * Coverage already bought pre-checkout. preProtected suppresses returns
   * coverage (not final sale); prePackageProtected suppresses protection.
   */
  preProtection: { preProtected: boolean; prePackageProtected: boolean };
  /**
   * See `GetCoverageParams.coveragePausedDates`. Required so a surface that
   * offers coverage cannot omit it; `null` says a pause must not apply here.
   */
  coveragePausedDates: CoveragePausedDates | null;
}

function convertToCents({
  dollars,
  onTapcart,
}: {
  dollars: number | undefined;
  onTapcart: boolean;
}) {
  if (!dollars) {
    return 0;
  }

  // tapcart money stays in dollars.
  if (onTapcart) {
    return dollars;
  }

  // round to nearest cent
  return Math.round(dollars * 100);
}

export function getCoverageInfoFromCalculators({
  team,
  customerInfo,
  items,
  redoCoverageProductIds,
  onTapcart,
  cachedProtectionCoveragePrice,
  checkoutProbability,
  returnMoneyType,
  preProtection,
  coveragePausedDates,
}: GetCoverageInfoFromCalculatorsParams) {
  const preProtectedResult: GetCoverageResult = {
    eligible: false,
    payer: "shopper",
    priceResult: undefined,
    reasonIneligible: CoverageIneligibilityReason.PRE_PROTECTED,
    eligibleItems: [],
  };
  const returnCoverageInfo = preProtection.preProtected
    ? preProtectedResult
    : returnCoverageCalculator.getCoverage({
        team,
        customerInfo,
        items,
        commentsoldIntegration: null,
        redoCoverageProductIds,
        coveragePausedDates,
      });
  const packageProtectionCoverageInfo = preProtection.prePackageProtected
    ? preProtectedResult
    : packageProtectionCoverageCalculator.getCoverage({
        team,
        customerInfo,
        items,
        commentsoldIntegration: null,
        priceOverrideForCoverageMlModelCacheOnly:
          cachedProtectionCoveragePrice != null
            ? { price: cachedProtectionCoveragePrice }
            : undefined,
        priceCalculationContext: { checkoutProbability },
        redoCoverageProductIds,
        coveragePausedDates,
      });
  const finalSaleReturnsCoverageInfo =
    finalSaleReturnsCoverageCalculator.getCoverage({
      team,
      customerInfo,
      items,
      commentsoldIntegration: null,
      redoCoverageProductIds,
      coveragePausedDates,
    });

  const returnPrice =
    returnMoneyType === "cents"
      ? convertToCents({
          dollars: returnCoverageInfo.priceResult?.price,
          onTapcart,
        })
      : (returnCoverageInfo.priceResult?.price ?? 0);
  const packageProtectionPrice =
    returnMoneyType === "cents"
      ? convertToCents({
          dollars: packageProtectionCoverageInfo.priceResult?.price,
          onTapcart,
        })
      : (packageProtectionCoverageInfo.priceResult?.price ?? 0);
  const finalSaleReturnsPrice =
    returnMoneyType === "cents"
      ? convertToCents({
          dollars: finalSaleReturnsCoverageInfo.priceResult?.price,
          onTapcart,
        })
      : (finalSaleReturnsCoverageInfo.priceResult?.price ?? 0);

  const returnsEligible =
    returnCoverageInfo.eligible && returnCoverageInfo.payer === "shopper";
  // return coverage is included in final sale coverage. So we need to take the max of the two.
  const returnCoveragePrice = Math.max(
    returnsEligible ? returnPrice : 0,
    finalSaleReturnsPrice,
  );

  const packageProtectionMerchantPaid =
    packageProtectionCoverageInfo.eligible &&
    packageProtectionCoverageInfo.payer === "merchant";
  const packageProtectionEligible =
    packageProtectionCoverageInfo.eligible &&
    packageProtectionCoverageInfo.payer !== "merchant";
  const bothEligible =
    (returnsEligible || finalSaleReturnsCoverageInfo.eligible) &&
    (packageProtectionEligible || packageProtectionMerchantPaid);
  const bothPrice = packageProtectionMerchantPaid
    ? returnCoveragePrice
    : packageProtectionPrice + returnCoveragePrice;
  const coverageInfo: CoverageInfo = {
    returns: {
      cartEligible: returnsEligible || finalSaleReturnsCoverageInfo.eligible,
      price: returnCoveragePrice,
      isFinalSale: finalSaleReturnsCoverageInfo.eligible,
      reasonIneligible:
        returnCoverageInfo.payer === "merchant"
          ? CoverageIneligibilityReason.MERCHANT_PAID
          : returnCoverageInfo.reasonIneligible,
    },
    packageProtection: {
      cartEligible: packageProtectionEligible,
      price: packageProtectionEligible ? packageProtectionPrice : 0,
      reasonIneligible: packageProtectionCoverageInfo.reasonIneligible,
    },
    both: {
      cartEligible: bothEligible,
      price: bothEligible ? bothPrice : 0,
      reasonIneligible: bothEligible
        ? undefined
        : returnCoverageInfo.reasonIneligible ||
          packageProtectionCoverageInfo.reasonIneligible,
    },
  };

  const coveragePriceResults = {
    returns: returnCoverageInfo,
    packageProtection: packageProtectionCoverageInfo,
    finalSaleReturns: finalSaleReturnsCoverageInfo,
  };

  const eligibleItems = {
    returns: returnCoverageInfo.eligibleItems,
    packageProtection: packageProtectionCoverageInfo.eligibleItems,
    finalSaleReturns: finalSaleReturnsCoverageInfo.eligibleItems,
  };

  return { coverageInfo, coveragePriceResults, eligibleItems };
}
