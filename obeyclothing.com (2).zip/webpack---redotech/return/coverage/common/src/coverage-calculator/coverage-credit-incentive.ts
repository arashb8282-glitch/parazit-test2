import {
  CoverageCreditIncentive,
  CoverageCreditIncentiveType,
} from "../coverage-types";

/**
 * A 0 cap means no limit, like a blank one: the legacy coverage settings form
 * saved a blank cap as 0, and the settings page shows a stored 0 as blank.
 */
export function applyStoreCreditAmountCap(
  amount: number,
  cap: number | null | undefined,
): number {
  return cap ? Math.min(amount, cap) : amount;
}

export function getCoverageCreditAmount(
  coverageCreditIncentive: CoverageCreditIncentive | undefined,
  cartTotal: number,
): number {
  if (
    !coverageCreditIncentive?.enabled ||
    cartTotal < coverageCreditIncentive.minimumQualifyingPurchaseAmount
  ) {
    return 0;
  }

  if (coverageCreditIncentive.type === CoverageCreditIncentiveType.FIXED) {
    return coverageCreditIncentive.fixedAmount;
  }

  if (coverageCreditIncentive.type === CoverageCreditIncentiveType.PERCENTAGE) {
    return applyStoreCreditAmountCap(
      cartTotal * (coverageCreditIncentive.percentageSettings.percentage / 100),
      coverageCreditIncentive.percentageSettings.storeCreditAmountCap,
    );
  }

  return 0;
}
