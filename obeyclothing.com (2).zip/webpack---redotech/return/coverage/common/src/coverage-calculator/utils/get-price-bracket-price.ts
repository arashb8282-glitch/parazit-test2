import { Currency } from "@redotech/money/currencies";
import { clamp } from "@redotech/util/clamp";
import { assertNever } from "@redotech/util/type";
import { CoveragePriceResult } from "..";
import { PricingRuleSet } from "../../coverage-types";
import { coverageMlModelInferenceRegistry } from "../coverage-ml/registry";
import type { CoverageMlModelDb } from "../coverage-ml/registry-schema";
import { determineRuleSet } from "./determine-rule-set";
import { getApplicableRule } from "./get-applicable-rule";

/**
 * @param priceOverrideForCoverageMlModelCacheOnly - If the price was
 * calculated by the coverage ML model previously, use this price. This is
 * useful for (1) not showing the customer different prices for the same cart
 * and for (2) keeping those prices consistent when calculating prices
 * post-checkout e.g. to determine what to charge the merchant.
 * @param country - `undefined` means shopper country is unavailable, so pricing
 * should be treated as unspecified. `null` is an internal sentinel used by
 * cart-value dynamic pricing paths to bypass country filtering.
 */
export function getPriceBracketPrice({
  cartTotal,
  pricingRuleSets,
  country,
  minPrice,
  maxPrice,
  backupPercentage,
  fixedSubscriptionPrice,
  cartHasSubscriptionItem,
  coverageMlModel,
  priceOverrideForCoverageMlModelCacheOnly,
}: {
  cartTotal: number;
  pricingRuleSets: PricingRuleSet[] | undefined;
  country: string | undefined | null;
  minPrice: number;
  maxPrice: number;
  backupPercentage: number;
  fixedSubscriptionPrice?: number;
  cartHasSubscriptionItem?: boolean;
  coverageMlModel: CoverageMlModelInference | undefined;
  priceOverrideForCoverageMlModelCacheOnly: { price: number } | undefined;
}): CoveragePriceResult {
  if (priceOverrideForCoverageMlModelCacheOnly) {
    return {
      price: priceOverrideForCoverageMlModelCacheOnly.price,
      source: "mlModelCache",
    };
  }

  // Undefined country means the caller does not have shopper country data.
  if (
    country === undefined ||
    !maxPrice ||
    (!backupPercentage && !pricingRuleSets?.length && !coverageMlModel)
  ) {
    return { price: 0, source: "unspecified" };
  }

  if (cartHasSubscriptionItem && fixedSubscriptionPrice) {
    return { price: fixedSubscriptionPrice, source: "fixedSubscriptionPrice" };
  }

  if (coverageMlModel) {
    const prediction = (() => {
      switch (coverageMlModel.id) {
        case "random":
          return coverageMlModelInferenceRegistry[coverageMlModel.id].predict({
            modelConfig: {
              constraints: {
                minPrice: { amount: minPrice, currency: Currency.USD },
                maxPrice: { amount: maxPrice, currency: Currency.USD },
              },
              randomSeed: Math.random() * 1000,
            },
            inferenceParams: {
              fudgeFactor: { amount: 1, currency: Currency.USD },
            },
          });
        case "intent-v12_28_2025": {
          const initialPrice = getPriceBracketPrice({
            cartTotal,
            pricingRuleSets,
            country,
            minPrice,
            maxPrice,
            backupPercentage,
            fixedSubscriptionPrice,
            cartHasSubscriptionItem,
            // get the price as if there was no ML model as a baseline
            coverageMlModel: undefined,
            priceOverrideForCoverageMlModelCacheOnly: undefined,
          }).price;
          return coverageMlModelInferenceRegistry[coverageMlModel.id].predict({
            modelConfig: {
              constraints: {
                minPrice: { amount: minPrice, currency: Currency.USD },
                maxPrice: { amount: maxPrice, currency: Currency.USD },
              },
              minPriceBiasPercentOfConstraintRange:
                coverageMlModel.model.config
                  ?.minPriceBiasPercentOfConstraintRange,
              maxPriceBiasPercentOfConstraintRange:
                coverageMlModel.model.config
                  ?.maxPriceBiasPercentOfConstraintRange,
            },
            inferenceParams: {
              ...coverageMlModel.inferenceParams,
              initialPrice,
            },
          });
        }
        case "stagecoach": {
          // We use raw cartValue rather than a heuristic baseline so the model
          // can explore the full [minPrice, maxPrice] range freely. To constrain
          // early exploration, narrow these bounds for new merchants and widen
          // as the posterior tightens. If we want to be more conservative in
          // the future, we could anchor on initialPrice like intent-v12_28_2025.
          return coverageMlModelInferenceRegistry[coverageMlModel.id].predict({
            modelConfig: {
              constraints: {
                minPrice: { amount: minPrice, currency: Currency.USD },
                maxPrice: { amount: maxPrice, currency: Currency.USD },
              },
              priceVsConversionWeight:
                coverageMlModel.model.config?.priceVsConversionWeight,
              stagecoachInferenceConfig:
                coverageMlModel.model.config?.stagecoachInferenceConfig,
            },
            inferenceParams: {
              cartValue: cartTotal,
              checkoutProbability:
                coverageMlModel.inferenceParams.checkoutProbability,
            },
          });
        }
        default:
          assertNever(coverageMlModel);
      }
    })();

    return {
      price: clamp(prediction.optimalPrice.amount, minPrice, maxPrice),
      source: "mlModel",
      ...(coverageMlModel.id === "stagecoach" && {
        modelVersionId:
          coverageMlModel.model.config?.stagecoachInferenceConfig
            ?.modelVersionId,
        betaSampleIndex:
          coverageMlModel.model.config?.stagecoachInferenceConfig
            ?.betaSampleIndex,
      }),
    };
  }

  if (!pricingRuleSets?.length) {
    return {
      price: clamp(cartTotal * backupPercentage, minPrice, maxPrice),
      source: "backupPercentage",
    };
  }

  const ruleset = determineRuleSet(pricingRuleSets, country);
  if (ruleset) {
    const rule = getApplicableRule(ruleset, cartTotal);
    const price =
      // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
      ruleset.type === "percentage" ? rule.value * cartTotal : rule.value;
    return {
      price: clamp(price, minPrice, maxPrice),
      source: "pricingRuleSet",
    };
  }

  return {
    price: parseFloat(
      clamp(cartTotal * backupPercentage, minPrice, maxPrice).toFixed(2),
    ),
    source: "backupPercentage",
  };
}

type CoverageMlModelInferenceRegistry = {
  [K in keyof typeof coverageMlModelInferenceRegistry]: {
    id: K;
    model: Extract<CoverageMlModelDb, { id: K }>;
    // For most models, inferenceParams can be left as is.
    // For the intent-v12_28_2025 model, we need to exclude the initialPrice
    // field since it's easier to calculate just before calling the predict
    // function.
    inferenceParams: K extends "intent-v12_28_2025"
      ? Omit<
          Parameters<
            (typeof coverageMlModelInferenceRegistry)["intent-v12_28_2025"]["predict"]
          >[0]["inferenceParams"],
          "initialPrice"
        >
      : K extends "stagecoach"
        ? Omit<
            Parameters<
              (typeof coverageMlModelInferenceRegistry)["stagecoach"]["predict"]
            >[0]["inferenceParams"],
            "cartValue"
          >
        : Parameters<
            (typeof coverageMlModelInferenceRegistry)[K]["predict"]
          >[0]["inferenceParams"];
  };
};
export type CoverageMlModelInference =
  CoverageMlModelInferenceRegistry[keyof CoverageMlModelInferenceRegistry];

export function getCoverageMlModelInference({
  mlModel,
  sessionInferenceParams,
}: {
  mlModel: CoverageMlModelDb | undefined;
  sessionInferenceParams: { checkoutProbability: number | undefined };
}): CoverageMlModelInference | undefined {
  if (!mlModel) {
    return undefined;
  }
  switch (mlModel.id) {
    case "random":
      return {
        id: mlModel.id,
        model: mlModel,
        inferenceParams: { fudgeFactor: { amount: 1, currency: Currency.USD } },
      };
    case "intent-v12_28_2025":
      return {
        id: mlModel.id,
        model: mlModel,
        inferenceParams: {
          checkoutProbability: sessionInferenceParams.checkoutProbability,
        },
      };
    case "stagecoach": {
      const mode = mlModel.config?.inferenceMode;
      const config = mlModel.config?.stagecoachInferenceConfig;
      // Only "stub" and "active" modes with config present run inference
      if (!mode || mode === "disabled" || !config || mode === "shadow") {
        return undefined;
      }
      return {
        id: mlModel.id,
        model: mlModel,
        inferenceParams: {
          checkoutProbability: sessionInferenceParams.checkoutProbability,
        },
      };
    }
    default:
      assertNever(mlModel);
  }
}
