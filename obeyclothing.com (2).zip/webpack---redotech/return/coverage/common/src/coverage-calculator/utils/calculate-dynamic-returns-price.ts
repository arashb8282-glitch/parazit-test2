import { assertNever } from "@redotech/util/type";
import { CoveragePriceResult } from "..";
import { DynamicReturnPricing, DynamicReturnTypes } from "../../coverage-types";
import { calculatePricePerItemPrice } from "./calculate-price-per-item-price";
import { getPriceBracketPrice } from "./get-price-bracket-price";

export function calculateDynamicReturnsPrice(
  dynamicReturns: DynamicReturnPricing,
  basePrice: number,
  numItems: number,
  cartTotal: number,
): CoveragePriceResult {
  if (numItems === 0) {
    return { price: 0, source: "unspecified" };
  }

  switch (dynamicReturns.type) {
    case DynamicReturnTypes.ITEM_COUNT: {
      const price = calculatePricePerItemPrice({
        basePrice,
        pricePerAdditionalItem: dynamicReturns.pricePerAdditonalItem,
        numItems,
        maxPrice: dynamicReturns.maxPrice,
      });
      return { price, source: "unspecified" };
    }
    case DynamicReturnTypes.CART_VALUE: {
      const priceResult = getPriceBracketPrice({
        cartTotal,
        pricingRuleSets: [dynamicReturns.pricingRuleSet],
        // Intentionally pass null (not undefined): this path has no shopper
        // country context and should not be treated as unspecified.
        country: null,
        minPrice: basePrice,
        maxPrice: dynamicReturns.maxPrice,
        backupPercentage: 0,
        // As of Dec 2025, package protection pricing is the only coverage type
        // that supports ML models
        coverageMlModel: undefined,
        priceOverrideForCoverageMlModelCacheOnly: undefined,
      });
      const price = parseFloat(priceResult.price.toFixed(2));
      return { price, source: priceResult.source };
    }
    default:
      assertNever(dynamicReturns);
  }
}
