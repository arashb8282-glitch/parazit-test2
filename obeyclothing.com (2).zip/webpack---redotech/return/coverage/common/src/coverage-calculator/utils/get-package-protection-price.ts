import { CoveragePriceResult } from "..";
import {
  PackageProtectionPricePerItemPricing,
  PackageProtectionPricingStrategy,
  PricingRuleSet,
} from "../../coverage-types";
import { calculatePricePerItemPrice } from "./calculate-price-per-item-price";
import {
  CoverageMlModelInference,
  getPriceBracketPrice,
} from "./get-price-bracket-price";

/**
 * Package protection price. PRICE_PER_ITEM prices by `numItems` (summed
 * eligible quantities); otherwise delegates to cart-value bracket pricing.
 */
export function getPackageProtectionPrice({
  pricingStrategy,
  pricePerItem,
  numItems,
  cartTotal,
  pricingRuleSets,
  country,
  minPrice,
  maxPrice,
  backupPercentage,
  fixedSubscriptionPrice,
  cartHasSubscriptionItem,
  coverageMlModel,
  priceOverrideForCoverageMlModelCacheOnly,
}: {
  pricingStrategy: PackageProtectionPricingStrategy | null | undefined;
  pricePerItem: PackageProtectionPricePerItemPricing | null | undefined;
  numItems: number;
  cartTotal: number;
  pricingRuleSets: PricingRuleSet[] | undefined;
  country: string | undefined | null;
  minPrice: number;
  maxPrice: number;
  backupPercentage: number;
  fixedSubscriptionPrice?: number;
  cartHasSubscriptionItem?: boolean;
  coverageMlModel: CoverageMlModelInference | undefined;
  priceOverrideForCoverageMlModelCacheOnly: { price: number } | undefined;
}): CoveragePriceResult {
  if (
    pricingStrategy !== PackageProtectionPricingStrategy.PRICE_PER_ITEM ||
    !pricePerItem
  ) {
    return getPriceBracketPrice({
      cartTotal,
      pricingRuleSets,
      country,
      minPrice,
      maxPrice,
      backupPercentage,
      fixedSubscriptionPrice,
      cartHasSubscriptionItem,
      coverageMlModel,
      priceOverrideForCoverageMlModelCacheOnly,
    });
  }

  if (priceOverrideForCoverageMlModelCacheOnly) {
    return {
      price: priceOverrideForCoverageMlModelCacheOnly.price,
      source: "mlModelCache",
    };
  }

  if (cartHasSubscriptionItem && fixedSubscriptionPrice) {
    return { price: fixedSubscriptionPrice, source: "fixedSubscriptionPrice" };
  }

  if (numItems <= 0) {
    return { price: 0, source: "unspecified" };
  }

  // coverageMlModel and the cart-value minPrice/maxPrice are intentionally
  // ignored: per-item pricing is self-contained.
  const price = calculatePricePerItemPrice({
    basePrice: pricePerItem.basePrice,
    pricePerAdditionalItem: pricePerItem.pricePerAdditionalItem,
    numItems,
    maxPrice: pricePerItem.maxPrice,
  });
  return { price, source: "pricePerItem" };
}
