import { isDefined } from "@redotech/util/type";
import { PricingRuleSet } from "../../coverage-types";

export function determineRuleSet(
  pricingRuleSets: PricingRuleSet[],
  country: string | null,
) {
  for (const priceSet of pricingRuleSets) {
    if (
      // Blank/whitespace country = no country data (e.g. ingested orders that
      // save "" instead of undefined); treat it as the null sentinel.
      !isDefined(country) ||
      country.trim() === "" ||
      priceSet.countries.some(
        (c) => c.toLowerCase() === country.toLowerCase(),
      ) ||
      priceSet.countries.length == 0
    ) {
      return priceSet;
    }
  }
  return null;
}

/**
 * Whether `country` prices from an international rule set. The first rule set
 * is the merchant's domestic pricing; any later one is international pricing,
 * which the admin exposes as a single "international pricing" toggle.
 */
export function usesInternationalRuleSet(
  pricingRuleSets: PricingRuleSet[] | undefined,
  country: string | null | undefined,
): boolean {
  if (!pricingRuleSets || pricingRuleSets.length < 2 || !country?.trim()) {
    return false;
  }
  const ruleSet = determineRuleSet(pricingRuleSets, country);
  return ruleSet !== null && ruleSet !== pricingRuleSets[0];
}
