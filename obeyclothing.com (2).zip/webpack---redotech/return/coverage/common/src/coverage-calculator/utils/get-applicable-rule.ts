import { PricingRuleSet } from "../../coverage-types";

export function getApplicableRule(ruleSet: PricingRuleSet, cartTotal: number) {
  if (!cartTotal) {
    return ruleSet.priceBrackets[0];
  }
  for (let i = 0; i < ruleSet.priceBrackets.length; i++) {
    if (i === ruleSet.priceBrackets.length - 1) {
      return ruleSet.priceBrackets[i];
    }

    if (
      // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
      cartTotal > ruleSet.priceBrackets[i].pricePoint &&
      // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
      cartTotal <= ruleSet.priceBrackets[i + 1].pricePoint
    ) {
      return ruleSet.priceBrackets[i];
    }
  }
  return ruleSet.priceBrackets[ruleSet.priceBrackets.length - 1];
}
