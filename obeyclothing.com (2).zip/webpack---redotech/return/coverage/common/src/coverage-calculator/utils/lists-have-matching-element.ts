import { arraysHaveMatchingElement } from "@redotech/util/array";

export function listsHaveMatchingElement(list1: string[], list2: string[]) {
  return arraysHaveMatchingElement(
    list1,
    list2,
    (a, b) => a.toLowerCase() === b.toLowerCase(),
  );
}
