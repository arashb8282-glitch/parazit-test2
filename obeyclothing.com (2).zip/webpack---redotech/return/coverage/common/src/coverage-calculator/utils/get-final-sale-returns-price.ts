import { clamp } from "@redotech/util/clamp";
import { CoveragePriceResult } from "..";
import { PricingRuleSet } from "../../coverage-types";
import { determineRuleSet } from "./determine-rule-set";
import { getApplicableRule } from "./get-applicable-rule";

export function getFinalSaleReturnsPrice({
  cartTotal,
  pricingRuleSets,
  shippingLabelCoveragePrice,
  country,
  minPrice,
  maxPrice,
  backupPercentage,
}: {
  cartTotal: number;
  pricingRuleSets: PricingRuleSet[] | undefined;
  shippingLabelCoveragePrice: number | undefined | null;
  country: string | undefined | null;
  minPrice: number | undefined;
  maxPrice: number | undefined;
  backupPercentage: number;
}): CoveragePriceResult {
  if (
    cartTotal === 0 ||
    country === undefined ||
    (!backupPercentage && !pricingRuleSets?.length)
  ) {
    return { price: 0, source: "unspecified" };
  }

  const costOfItemCoverage = getCostOfItemCoverage({
    cartTotal,
    pricingRuleSets,
    country,
    maxPrice,
    minPrice,
    backupPercentage,
  });
  const costOfShippingLabelCoverage = shippingLabelCoveragePrice ?? 0;
  const totalCoveragePrice = costOfItemCoverage + costOfShippingLabelCoverage;
  return {
    price: parseFloat(totalCoveragePrice.toFixed(2)),
    source: "unspecified",
  };
}

function getCostOfItemCoverage({
  cartTotal,
  pricingRuleSets,
  country,
  maxPrice,
  minPrice,
  backupPercentage,
}: {
  cartTotal: number;
  pricingRuleSets: PricingRuleSet[] | undefined;
  country: string | null;
  maxPrice: number | undefined;
  minPrice: number | undefined;
  backupPercentage: number;
}) {
  if (!pricingRuleSets?.length) {
    const cost = cartTotal * backupPercentage;
    return clamp(cost, minPrice ?? 0, maxPrice ?? Infinity);
  }

  const ruleset = determineRuleSet(pricingRuleSets, country);
  if (ruleset) {
    const rule = getApplicableRule(ruleset, cartTotal);
    const cost =
      // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
      ruleset.type === "percentage" ? rule.value * cartTotal : rule.value;
    return clamp(cost, minPrice ?? 0, maxPrice ?? Infinity);
  }

  const cost = cartTotal * backupPercentage;
  return clamp(cost, minPrice ?? 0, maxPrice ?? Infinity);
}
