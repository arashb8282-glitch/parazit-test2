/**
 * First item costs `basePrice`, each additional item adds
 * `pricePerAdditionalItem`, capped at `maxPrice`.
 */
export function calculatePricePerItemPrice({
  basePrice,
  pricePerAdditionalItem,
  numItems,
  maxPrice,
}: {
  basePrice: number;
  pricePerAdditionalItem: number;
  numItems: number;
  maxPrice: number;
}): number {
  return parseFloat(
    Math.min(
      basePrice + pricePerAdditionalItem * (numItems - 1),
      maxPrice,
    ).toFixed(2),
  );
}
