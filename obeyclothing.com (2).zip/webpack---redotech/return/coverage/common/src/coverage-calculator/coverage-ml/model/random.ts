import { Money } from "@redotech/money";
import { SeededRandom } from "@redotech/util/random";
import { CoverageMlModel, RANDOM_COVERAGE_ML_MODEL_ID } from "../types";

export interface RandomCoverageMlModelConfig {
  constraints: { minPrice: Money; maxPrice: Money };
  randomSeed: number;
}

export const randomCoverageMlModel: CoverageMlModel<
  RandomCoverageMlModelConfig,
  RandomCoverageMlModelInferenceParams
> = { id: RANDOM_COVERAGE_ML_MODEL_ID, predict };

export interface RandomCoverageMlModelInferenceParams {
  fudgeFactor: Money;
}

/**
 * A test model that returns a random price between the min and max price and
 * adds a fudge factor to the price.
 */
function predict({
  modelConfig,
  inferenceParams,
}: {
  modelConfig: RandomCoverageMlModelConfig;
  inferenceParams: RandomCoverageMlModelInferenceParams;
}): { optimalPrice: Money } {
  const random = new SeededRandom(
    modelConfig.randomSeed + Math.random() * inferenceParams.fudgeFactor.amount,
  );
  const optimalPrice = {
    amount:
      random.float(
        modelConfig.constraints.maxPrice.amount -
          modelConfig.constraints.minPrice.amount,
      ) + modelConfig.constraints.minPrice.amount,
    currency: modelConfig.constraints.minPrice.currency,
  };
  return { optimalPrice };
}
