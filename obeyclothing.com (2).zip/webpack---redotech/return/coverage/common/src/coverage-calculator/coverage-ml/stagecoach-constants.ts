/** Prefix for Stagecoach SageMaker Multi-Model Endpoint names. */
export const STAGECOACH_MME_ENDPOINT_NAME_PREFIX = "stagecoach-mme";

/** Default Stagecoach MME endpoint name. */
export const STAGECOACH_DEFAULT_MME_ENDPOINT_NAME =
  `${STAGECOACH_MME_ENDPOINT_NAME_PREFIX}-001` as const;

/** Shared default model artifact used as cold-start fallback. */
export const STAGECOACH_DEFAULT_TARGET_MODEL =
  "stagecoach/default/v1/model.tar.gz" as const;

/** Default optimization tradeoff between price level and conversion likelihood. */
export const STAGECOACH_DEFAULT_PRICE_VS_CONVERSION_WEIGHT = 1;

/** Number of candidate prices evaluated per inference request. */
export const STAGECOACH_DEFAULT_CANDIDATE_COUNT = 100;

/** Total posterior draws from MCMC (4 chains x 1000 samples). */
export const STAGECOACH_POSTERIOR_SAMPLE_COUNT = 4000;

/** Number of posterior draws sent in each autocheck subsample. Validated empirically in PR6. */
export const STAGECOACH_POSTERIOR_SUBSAMPLE_SIZE = 50;

/** S3 bucket for model artifacts uploaded by Metaflow training pipeline. */
export const STAGECOACH_S3_BUCKET = "prod-metaflow-configs";

/** S3 key for posterior subsample JSON artifact. */
export const stagecoachS3Key = (
  teamId: string,
  mode: "dev" | "prod" = "prod",
): string =>
  mode === "dev"
    ? `stagecoach/dev/${teamId}/posterior_subsample.json`
    : `stagecoach/${teamId}/posterior_subsample.json`;
