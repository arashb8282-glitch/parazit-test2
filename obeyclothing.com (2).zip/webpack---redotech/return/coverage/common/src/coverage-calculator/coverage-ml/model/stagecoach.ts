import { Money } from "@redotech/money";
import type { CoverageMlModelDb } from "../registry-schema";
import { computeStagecoachOptimalPrice } from "../stagecoach-inference";
import { CoverageMlModel, STAGECOACH_COVERAGE_ML_MODEL_ID } from "../types";
import type { StagecoachInferenceConfig } from "./stagecoach-schema";

export interface StagecoachCoverageMlModelConfig {
  constraints: { minPrice: Money; maxPrice: Money };
  priceVsConversionWeight?: number | null;
  stagecoachInferenceConfig?: StagecoachInferenceConfig | null;
}

export interface StagecoachCoverageMlInferenceParams {
  cartValue: number;
  checkoutProbability: number | undefined;
}

export const stagecoachCoverageMlModel: CoverageMlModel<
  StagecoachCoverageMlModelConfig,
  StagecoachCoverageMlInferenceParams
> = { id: STAGECOACH_COVERAGE_ML_MODEL_ID, predict };

function predict({
  modelConfig,
  inferenceParams,
}: {
  modelConfig: StagecoachCoverageMlModelConfig;
  inferenceParams: StagecoachCoverageMlInferenceParams;
}): { optimalPrice: Money } {
  const config = modelConfig.stagecoachInferenceConfig;
  if (
    !config ||
    config.betaVector.length === 0 ||
    config.betaVector.length !== config.stagecoachFeatureOrdering.length
  ) {
    return {
      optimalPrice: {
        amount: modelConfig.constraints.minPrice.amount,
        currency: modelConfig.constraints.minPrice.currency,
      },
    };
  }

  return {
    optimalPrice: computeStagecoachOptimalPrice({
      constraints: modelConfig.constraints,
      runtimeConfig: config,
      cartValue: inferenceParams.cartValue,
      checkoutProbability: inferenceParams.checkoutProbability,
      priceVsConversionWeight: modelConfig.priceVsConversionWeight,
    }),
  };
}

/**
 * Resolves stagecoach versioning fields (modelVersionId, betaSampleIndex) from
 * either the inference result or, in shadow mode, directly from the model
 * config. Returns undefined if versioning cannot be resolved.
 *
 * This centralizes the shadow-mode fallback logic so the dependency on
 * `stagecoachInferenceConfig` being present is explicit rather than implicit.
 */
export function resolveStagecoachVersioning({
  inferenceResult,
  mlModel,
}: {
  inferenceResult: { modelVersionId?: string; betaSampleIndex?: number };
  mlModel: CoverageMlModelDb | undefined;
}): { modelVersionId: string; betaSampleIndex: number } | undefined {
  if (!mlModel || mlModel.id !== "stagecoach") {
    return undefined;
  }
  const mode = mlModel.config?.inferenceMode;
  const config = mlModel.config?.stagecoachInferenceConfig;

  // Fall back to config values when inference result doesn't include them
  // (e.g., cache hit returns price without modelVersionId).
  const modelVersionId =
    inferenceResult.modelVersionId ??
    (mode !== "disabled" ? config?.modelVersionId : undefined);
  const betaSampleIndex =
    inferenceResult.betaSampleIndex ??
    (mode !== "disabled" ? config?.betaSampleIndex : undefined);

  if (modelVersionId != null && betaSampleIndex != null) {
    return { modelVersionId, betaSampleIndex };
  }

  return undefined;
}
