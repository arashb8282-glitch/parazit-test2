import { Money } from "@redotech/money";
import { clamp } from "@redotech/util/clamp";
import {
  CoverageMlModel,
  INTENT_V12_28_2025_COVERAGE_ML_MODEL_ID,
} from "../types";

export interface IntentV12_28_2025CoverageMlModelConfig {
  constraints: { minPrice: Money; maxPrice: Money };
  minPriceBiasPercentOfConstraintRange?: number | undefined | null;
  maxPriceBiasPercentOfConstraintRange?: number | undefined | null;
}

export const intentV12_28_2025CoverageMlModel: CoverageMlModel<
  IntentV12_28_2025CoverageMlModelConfig,
  IntentV12_28_2025CoverageMlModelInferenceParams
> = { id: INTENT_V12_28_2025_COVERAGE_ML_MODEL_ID, predict };

export interface IntentV12_28_2025CoverageMlModelInferenceParams {
  checkoutProbability: number | undefined;
  initialPrice: number;
}

/**
 * A model that returns a price between the min and max price based on a
 * percentage of the cart total and the checkout probability prediction.
 * If the checkout probability prediction is undefined or 0, the price will not
 * be marked up. If the checkout probability prediction is 100, the price will
 * be marked up to the maximum.
 */
function predict({
  modelConfig,
  inferenceParams,
}: {
  modelConfig: IntentV12_28_2025CoverageMlModelConfig;
  inferenceParams: IntentV12_28_2025CoverageMlModelInferenceParams;
}): { optimalPrice: Money } {
  const minPriceBiasPercentOfConstraintRange =
    modelConfig.minPriceBiasPercentOfConstraintRange ?? 0;
  const maxPriceBiasPercentOfConstraintRange =
    modelConfig.maxPriceBiasPercentOfConstraintRange ?? 0.3;
  const normalizedIntentScore =
    clamp(inferenceParams.checkoutProbability ?? 0, 0, 100) / 100;
  const constraintRange =
    modelConfig.constraints.maxPrice.amount -
    modelConfig.constraints.minPrice.amount;
  const priceBiasRange =
    (maxPriceBiasPercentOfConstraintRange -
      minPriceBiasPercentOfConstraintRange) *
    constraintRange;
  const intentPriceBias =
    priceBiasRange * normalizedIntentScore +
    minPriceBiasPercentOfConstraintRange * constraintRange;
  const price = clamp(
    inferenceParams.initialPrice + intentPriceBias,
    modelConfig.constraints.minPrice.amount,
    modelConfig.constraints.maxPrice.amount,
  );
  return {
    optimalPrice: {
      amount: price,
      currency: modelConfig.constraints.minPrice.currency,
    },
  };
}
