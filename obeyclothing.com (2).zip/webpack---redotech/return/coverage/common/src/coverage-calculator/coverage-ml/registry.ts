import { intentV12_28_2025CoverageMlModel } from "./model/intent-v12_28_2025";
import { randomCoverageMlModel } from "./model/random";
import { stagecoachCoverageMlModel } from "./model/stagecoach";
import {
  INTENT_V12_28_2025_COVERAGE_ML_MODEL_ID,
  RANDOM_COVERAGE_ML_MODEL_ID,
  STAGECOACH_COVERAGE_ML_MODEL_ID,
} from "./types";

export const coverageMlModelInferenceRegistry = {
  [RANDOM_COVERAGE_ML_MODEL_ID]: randomCoverageMlModel,
  [INTENT_V12_28_2025_COVERAGE_ML_MODEL_ID]: intentV12_28_2025CoverageMlModel,
  [STAGECOACH_COVERAGE_ML_MODEL_ID]: stagecoachCoverageMlModel,
};
