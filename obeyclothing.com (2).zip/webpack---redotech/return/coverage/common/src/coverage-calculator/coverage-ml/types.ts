import { Money } from "@redotech/money";

export const RANDOM_COVERAGE_ML_MODEL_ID = "random" as const;
export const INTENT_V12_28_2025_COVERAGE_ML_MODEL_ID =
  "intent-v12_28_2025" as const;
export const STAGECOACH_COVERAGE_ML_MODEL_ID = "stagecoach" as const;

export const coverageMlModelIds = [
  RANDOM_COVERAGE_ML_MODEL_ID,
  INTENT_V12_28_2025_COVERAGE_ML_MODEL_ID,
  STAGECOACH_COVERAGE_ML_MODEL_ID,
] as const;
export type CoverageMlModelId = (typeof coverageMlModelIds)[number];

export interface CoverageMlModel<CONFIG, INFERENCE_PARAMS> {
  id: CoverageMlModelId;
  predict: CoverageMlModelInferenceFn<
    CoverageMlModelInferenceInput<CONFIG, INFERENCE_PARAMS>
  >;
}

interface CoverageMlModelInferenceInput<CONFIG, INFERENCE_PARAMS> {
  modelConfig: CONFIG;
  inferenceParams: INFERENCE_PARAMS;
}
interface CoverageMlModelInferenceOutput {
  optimalPrice: Money;
}
type CoverageMlModelInferenceFn<
  INPUT extends CoverageMlModelInferenceInput<any, any>,
> = (input: INPUT) => CoverageMlModelInferenceOutput;
