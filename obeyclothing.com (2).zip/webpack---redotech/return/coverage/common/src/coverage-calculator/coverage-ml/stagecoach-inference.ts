import { Money } from "@redotech/money";
import { clamp } from "@redotech/util/clamp";
import { assertNever } from "@redotech/util/type";
import {
  STAGECOACH_DEFAULT_CANDIDATE_COUNT,
  STAGECOACH_DEFAULT_PRICE_VS_CONVERSION_WEIGHT,
} from "./stagecoach-constants";

export const STAGECOACH_FEATURE_NAMES = [
  "intercept",
  "price_ratio",
  "cart_value",
  "log_cart_value",
  "intent_score",
  "price_ratio_x_cart_value",
] as const;
export type StagecoachFeatureName = (typeof STAGECOACH_FEATURE_NAMES)[number];

export interface StagecoachInferenceFeatureScaling {
  mean: number;
  std: number;
}

export interface StagecoachRuntimeInferenceConfig {
  betaVector: number[];
  stagecoachFeatureOrdering: StagecoachFeatureName[];
  featureComputationRules?: { logCartValueEpsilon?: number };
  inferenceFeatureScaling?: Record<string, StagecoachInferenceFeatureScaling>;
  conversionVsPricingTradeoffConfig?: { alpha: number };
  priceSearchConfig?: { priceCandidateTotal?: number };
  expectedClaimCostDollars?: number;
}

export function computeStagecoachOptimalPrice({
  constraints,
  runtimeConfig,
  cartValue,
  checkoutProbability,
  priceVsConversionWeight,
}: {
  constraints: { minPrice: Money; maxPrice: Money };
  runtimeConfig: StagecoachRuntimeInferenceConfig;
  cartValue: number;
  checkoutProbability: number | undefined;
  priceVsConversionWeight: number | null | undefined;
}): Money {
  const candidateCount =
    runtimeConfig.priceSearchConfig?.priceCandidateTotal ??
    STAGECOACH_DEFAULT_CANDIDATE_COUNT;
  // α controls revenue vs conversion tradeoff: α=1 revenue maximization, α→0 pure conversion
  const objectiveFuncAlpha =
    runtimeConfig.conversionVsPricingTradeoffConfig?.alpha ??
    priceVsConversionWeight ??
    STAGECOACH_DEFAULT_PRICE_VS_CONVERSION_WEIGHT;

  const expectedClaimCostDollars = runtimeConfig.expectedClaimCostDollars ?? 0;
  // Effective min price must be at least claim cost — pricing below cost is never profitable
  const effectiveMinPrice = Math.max(
    constraints.minPrice.amount,
    expectedClaimCostDollars,
  );

  const candidatePrices = generateCandidatePrices({
    minPrice: effectiveMinPrice,
    maxPrice: constraints.maxPrice.amount,
    candidateCount,
  });

  let bestPrice = candidatePrices[0] ?? effectiveMinPrice;
  let bestObjective = Number.NEGATIVE_INFINITY;

  for (const candidatePrice of candidatePrices) {
    const logit = calculateLogit({
      featureOrder: runtimeConfig.stagecoachFeatureOrdering,
      betaVector: runtimeConfig.betaVector,
      candidatePrice,
      cartValue,
      checkoutProbability,
      featureScaling: runtimeConfig.inferenceFeatureScaling,
      logCartValueEpsilon:
        runtimeConfig.featureComputationRules?.logCartValueEpsilon ?? 1e-6,
    });

    // σ(logit) — sigmoid converts logit to conversion probability
    const conversionProbability = 1 / (1 + Math.exp(-logit));
    // Subtract expected claim cost — optimizes net margin, not gross revenue
    const objective =
      Math.max(candidatePrice - expectedClaimCostDollars, 0) **
        objectiveFuncAlpha *
      conversionProbability;

    if (objective > bestObjective) {
      bestObjective = objective;
      bestPrice = candidatePrice;
    }
  }

  return {
    amount: clamp(bestPrice, effectiveMinPrice, constraints.maxPrice.amount),
    currency: constraints.minPrice.currency,
  };
}

function generateCandidatePrices({
  minPrice,
  maxPrice,
  candidateCount,
}: {
  minPrice: number;
  maxPrice: number;
  candidateCount: number;
}): number[] {
  if (candidateCount <= 1 || maxPrice <= minPrice) {
    return [minPrice];
  }

  const step = (maxPrice - minPrice) / (candidateCount - 1);
  const prices: number[] = [];
  for (let i = 0; i < candidateCount; i += 1) {
    prices.push(minPrice + step * i);
  }
  return prices;
}

function calculateLogit({
  featureOrder,
  betaVector,
  candidatePrice,
  cartValue,
  checkoutProbability,
  featureScaling,
  logCartValueEpsilon,
}: {
  featureOrder: StagecoachFeatureName[];
  betaVector: number[];
  candidatePrice: number;
  cartValue: number;
  checkoutProbability: number | undefined;
  featureScaling: Record<string, StagecoachInferenceFeatureScaling> | undefined;
  logCartValueEpsilon: number;
}): number {
  let logit = 0;

  for (const [i, featureName] of featureOrder.entries()) {
    const beta = betaVector[i] ?? 0;
    const rawValue = getFeatureValue({
      featureName,
      candidatePrice,
      cartValue,
      checkoutProbability,
      logCartValueEpsilon,
    });
    const scaledValue = applyFeatureScaling({
      featureName,
      featureScaling,
      rawValue,
    });

    logit += beta * scaledValue;
  }

  return logit;
}

function getFeatureValue({
  featureName,
  candidatePrice,
  cartValue,
  checkoutProbability,
  logCartValueEpsilon,
}: {
  featureName: StagecoachFeatureName;
  candidatePrice: number;
  cartValue: number;
  checkoutProbability: number | undefined;
  logCartValueEpsilon: number;
}): number {
  const safeCartValue = Math.max(cartValue, logCartValueEpsilon);
  const safeIntent = clamp(checkoutProbability ?? 0, 0, 100);
  const priceRatio = candidatePrice / safeCartValue;

  switch (featureName) {
    case "intercept":
      return 1;
    case "price_ratio":
      return priceRatio;
    case "cart_value":
      return cartValue;
    case "log_cart_value":
      return Math.log(safeCartValue);
    case "intent_score":
      return safeIntent;
    case "price_ratio_x_cart_value":
      return priceRatio * cartValue;
    default:
      assertNever(featureName);
  }
}

function applyFeatureScaling({
  featureName,
  featureScaling,
  rawValue,
}: {
  featureName: string;
  featureScaling: Record<string, StagecoachInferenceFeatureScaling> | undefined;
  rawValue: number;
}): number {
  const scaling = featureScaling?.[featureName];
  if (!scaling || scaling.std <= 0) {
    return rawValue;
  }

  return (rawValue - scaling.mean) / scaling.std;
}
