import {
  CoverageFeeProductMatchType,
  isCoverageFeeProduct,
  NO_COVERAGE_PRODUCT_IDS,
} from "./is-coverage-fee-product";

interface CheckIsRedoLineItem {
  sku?: string | null;
  vendor?: string | null;
  name?: string;
  title?: string;
  product_id?: string | number | null;
}

export const isRedoLineItem = (
  lineItem: CheckIsRedoLineItem | undefined,
  redoCoverageProductIds: ReadonlySet<string> | undefined,
) => {
  if (!lineItem) {
    return false;
  }
  const title = "title" in lineItem ? lineItem.title : lineItem.name;
  return isCoverageFeeProduct({
    product: {
      vendor: lineItem.vendor,
      sku: lineItem.sku,
      title,
      product_id: lineItem.product_id?.toString(),
    },
    redoCoverageProductIds: redoCoverageProductIds ?? NO_COVERAGE_PRODUCT_IDS,
    matchType: CoverageFeeProductMatchType.REDO_AND_COMPETITORS,
  });
};
