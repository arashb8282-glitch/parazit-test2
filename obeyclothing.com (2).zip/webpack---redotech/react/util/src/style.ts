import { StyleManager } from "@redotech/web-util/web-components/style";
import { ReactNode, useLayoutEffect } from "react";
import { createPortal } from "react-dom";

export function useStyleProperty(
  node: HTMLElement,
  name: string,
  value: string,
) {
  useLayoutEffect(() => {
    const oldValue = node.style.getPropertyValue(name);
    node.style.setProperty(name, value);
    return () => node.style.setProperty(name, oldValue);
  }, [node, name, value]);
}

function useStyleManager(styleManager: StyleManager, shadowRoot?: ShadowRoot) {
  useLayoutEffect(
    () => shadowRoot && styleManager.register(shadowRoot),
    [styleManager, shadowRoot],
  );
}

function useStyleRoot(
  container: Element,
  styleManager: StyleManager,
): ShadowRoot {
  const shadowRoot =
    container.shadowRoot ?? container.attachShadow({ mode: "open" });
  useStyleManager(styleManager, shadowRoot);
  return shadowRoot;
}

export function StyleRoot({
  children,
  container,
  styleManager,
}: {
  children: ReactNode | ReactNode[];
  container: Element;
  styleManager: StyleManager;
}) {
  const shadowRoot = useStyleRoot(container, styleManager);
  return createPortal(children, shadowRoot);
}

/**
 * Only styles the shadow root if it is a ShadowRoot, not an HTMLElement.
 * For flexible checkout buttons, there is no shadow root and it's not desired to put all of the redo styles into the host document.
 */
export function StyleShadowRoot({
  children,
  shadowRoot,
  styleManager,
}: {
  children: ReactNode | ReactNode[];
  shadowRoot: ShadowRoot | HTMLElement;
  styleManager: StyleManager;
}) {
  useStyleManager(
    styleManager,
    shadowRoot instanceof ShadowRoot ? shadowRoot : undefined,
  );
  return createPortal(children, shadowRoot);
}
