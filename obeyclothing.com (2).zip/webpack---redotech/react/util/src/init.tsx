import { ReactNode, useEffect, useState } from "react";

function useInitialized(value: boolean) {
  const [initialized, setInitialized] = useState(false);
  useEffect(() => {
    if (value && !initialized) {
      setInitialized(true);
    }
  }, [value, initialized]);
  return value || initialized;
}

/**
 * Create the children lazily
 */
export function Lazy({
  init,
  children,
}: {
  init: boolean;
  children: ReactNode | ReactNode[];
}) {
  const initialized = useInitialized(init);
  return initialized ? <>{children}</> : null;
}
