import { Money } from ".";
import { Currency } from "./iso4217/currencies";

export const DEFAULT_CURRENCY = Currency.USD;

let defaultDisplay: Intl.NumberFormatOptions["currencyDisplay"];
try {
  new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: DEFAULT_CURRENCY,
    currencyDisplay: "narrowSymbol",
  });
} catch {
  defaultDisplay = undefined;
}

const DEFAULT_LOCALE =
  typeof navigator !== "undefined" ? navigator.language : "en-US";
export const DEFAULT_CURRENCY_FORMATTER = getCurrencyFormatter(
  DEFAULT_CURRENCY,
  undefined,
  DEFAULT_LOCALE,
);

export function getCurrencyFormatter(
  currencyCode?: string | null,
  currencyDisplay: Intl.NumberFormatOptions["currencyDisplay"] = defaultDisplay,
  locale?: string,
  options?: Intl.NumberFormatOptions,
) {
  if (!currencyCode) {
    currencyCode = DEFAULT_CURRENCY;
  }
  const browserLocale =
    typeof navigator !== "undefined" ? navigator.language : undefined;
  return new Intl.NumberFormat(locale ?? browserLocale, {
    style: "currency",
    currency: currencyCode,
    currencyDisplay,
    ...options,
  });
}

/** Format a bare amount whose currency may be unknown (defaults USD). */
export function formatAmount(
  value: number,
  currencyCode?: string | null,
): string {
  return getCurrencyFormatter(currencyCode, undefined, "en-US").format(value);
}

export function moneyFormat(
  money: Money,
  currencyDisplay?: Intl.NumberFormatOptions["currencyDisplay"],
  locale?: string,
) {
  return getCurrencyFormatter(money.currency, currencyDisplay, locale).format(
    money.amount,
  );
}
