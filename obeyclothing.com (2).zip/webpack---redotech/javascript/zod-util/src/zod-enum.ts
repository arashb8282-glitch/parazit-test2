import * as z from "zod";

// Inline types equivalent to util.EnumLike and util.ToEnum from zod/core/util
// to avoid TS2742 (zod/core/util is not in zod's package exports)
type EnumLike = Readonly<Record<string, string | number>>;
type ToEnum<T extends string | number> = { [K in T]: K };

type EnumConstraint =
  | {
      enumName: string;
      isPartial: boolean;
      originalEnum: readonly string[] | EnumLike;
    }
  | { enumName?: undefined; isPartial?: undefined; originalEnum?: undefined };

function _createEnum<const T extends readonly string[]>(
  values: T,
  params?: z.core.$ZodEnumParams & ({ enumName?: string } | EnumConstraint),
): z.ZodEnum<ToEnum<T[number]>>;
function _createEnum<const T extends EnumLike>(
  values: T,
  params?: z.core.$ZodEnumParams & ({ enumName?: string } | EnumConstraint),
): z.ZodEnum<T>;
function _createEnum<const T extends readonly string[]>(
  values: T,
  params?: z.core.$ZodEnumParams & ({ enumName?: string } | EnumConstraint),
): z.ZodEnum<ToEnum<T[number]>> {
  const schema = z.enum(values, {
    // Don't need to print expected values, included in another part of the error message
    error: (iss) => {
      const input = iss.input === "" ? "<empty-string>" : String(iss.input);
      return `Received ${input}`;
    },
  });

  if (params) {
    const metadata: Record<string, any> = {};
    if ("isPartial" in params && params.isPartial) {
      metadata.constrainedTo = values;
      // Store the original enum values for schema extraction
      // This allows extractors to get the full set of enum values
      if (params.originalEnum) {
        metadata.originalEnumValues = Array.isArray(params.originalEnum)
          ? params.originalEnum
          : Object.values(params.originalEnum).filter(
              (v): v is string => typeof v === "string",
            );
      }
    }
    if (params.enumName) {
      metadata.enumName = params.enumName;
    }
    return schema.meta(metadata);
  }

  return schema;
}

export const createEnum = _createEnum;
