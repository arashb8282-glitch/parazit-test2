import { KeyedSet } from "./set";

/**
 * Return the element with the target value, else the element after it, else
 * the first element, else undefined.
 *
 * The array must be sorted in ascending order .
 */
// @ts-expect-error unused-export-debt
function binarySearch<T, V extends number | string>(
  items: T[],
  target: V,
  getValue: (item: T) => V,
): T | undefined {
  const values: Record<number, V> = {};
  let start = 0;
  let end = items.length - 1;
  while (start < end) {
    const mid = (start + end) >> 1;
    const midItem = items[mid];
    if (midItem === undefined) {
      return undefined;
    }
    const value = values[mid] ?? (values[mid] = getValue(midItem));
    if (value < target) {
      start = mid + 1;
    } else if (value > target) {
      end = mid - 1;
    } else {
      start = mid;
      break;
    }
  }
  return items[start];
}

/**
 * @returns [falsePartition, truePartition]
 */
export function partition<T>(
  items: T[],
  condition: (item: T) => boolean,
): [T[], T[]] {
  const truePartition: T[] = [];
  const falsePartition: T[] = [];

  for (const item of items) {
    (condition(item) ? truePartition : falsePartition).push(item);
  }
  return [falsePartition, truePartition];
}

export function unique<T>(
  items: Iterable<T>,
  uniqueKey?: (item: T) => string,
): T[] {
  if (!uniqueKey) {
    return [...new Set(items)];
  }
  const result: T[] = [];
  const seen = new KeyedSet(uniqueKey);
  for (const item of items) {
    if (!seen.has(item)) {
      seen.add(item);
      result.push(item);
    }
  }
  return result;
}

export function uniqueMerge<T>(
  items: T[],
  merge: (itemA: T, itemB: T) => T,
  uniqueKey: (item: T) => any,
): T[] {
  const map = new Map<any, T>();
  for (let item of items) {
    const key = uniqueKey(item);
    if (map.has(key)) {
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      item = merge(map.get(key)!, item);
    }
    map.set(key, item);
  }
  return [...map.values()];
}

// Array equivalent of string.join
export function interleave<T>(
  items: T[],
  separator: (item: T, index: number) => T,
): T[] {
  const result: T[] = [];
  for (const [index, item] of items.entries()) {
    if (index) {
      result.push(separator(item, index));
    }
    result.push(item);
  }
  return result;
}

/**
 * Filter on javascript's definition of truthy. Use with care as it filters out 0 and empty strings.
 */
export function filterTruthy<T>(
  items: readonly T[],
): Exclude<T, null | undefined | false | 0 | "">[] {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  return items.filter(Boolean) as Exclude<
    T,
    null | undefined | false | 0 | ""
  >[];
}

export function swap<T>(items: T[], i: number, j: number): T[] {
  if (i < 0 || i >= items.length || j < 0 || j >= items.length) {
    throw new Error(
      `Swap indices out of bounds: i=${i}, j=${j}, length=${items.length}`,
    );
  }

  const newItems = items.slice();
  const itemI = newItems[i];
  const itemJ = newItems[j];

  if (itemI === undefined || itemJ === undefined) {
    throw new Error(`Cannot swap undefined elements at indices i=${i}, j=${j}`);
  }

  newItems[i] = itemJ;
  newItems[j] = itemI;
  return newItems;
}

export function insert<T>(items: T[], index: number, item: T): T[] {
  const copy = [...items];
  copy.splice(index, 0, item);
  return copy;
}

export function replace<T>(items: T[], index: number, item: T): T[] {
  const copy = [...items];
  copy.splice(index, 1, item);
  return copy;
}

export function remove<T>(items: T[], index: number): T[] {
  const copy = [...items];
  copy.splice(index, 1);
  return copy;
}

export function repeat<T>(arr: T[], count: number): T[] {
  return Array(count).fill(arr).flat();
}

export function groupAndSum<T extends Record<string, any>>({
  items,
  groupByFields,
  sumField,
}: {
  items: T[];
  groupByFields: (keyof T)[];
  sumField?: keyof T;
}): T[] {
  const groupMap = new Map<string, any>();

  for (const item of items) {
    const key = groupByFields.map((field) => item[field]).join("|");

    if (groupMap.has(key)) {
      const existing = groupMap.get(key);
      if (sumField) {
        existing[sumField] += item[sumField];
      }
    } else {
      // Make a shallow copy so we don't mutate the original object
      groupMap.set(key, { ...item });
    }
  }

  return Array.from(groupMap.values());
}

// @ts-expect-error unused-export-debt
function coerceToArray<T>(value: T | T[]): T[] {
  if (Array.isArray(value)) {
    return value;
  }
  return [value];
}

export async function processBatches<T, R>(
  items: T[],
  batchSize: number,
  fn: (batch: T[], batchIndex: number) => Promise<R>,
): Promise<R[]> {
  const results: R[] = [];

  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const batchIndex = Math.floor(i / batchSize);
    const result = await fn(batch, batchIndex);
    results.push(result);
  }

  return results;
}

export function minMax<T>(
  items: T[],
  compare: (a: T, b: T) => number,
): { min: T | undefined; max: T | undefined } {
  if (items.length === 0) {
    return { min: undefined, max: undefined };
  }

  const first = items[0];
  if (first === undefined) {
    return { min: undefined, max: undefined };
  }

  let min: T = first;
  let max: T = first;

  for (const item of items) {
    if (compare(item, min) < 0) {
      min = item;
    }
    if (compare(item, max) > 0) {
      max = item;
    }
  }

  return { min, max };
}

export function arraysEqual<T>(a: readonly T[], b: readonly T[]): boolean {
  return (
    a.length === b.length &&
    a.every((v, i) => {
      const other = b[i];
      return v === other;
    })
  );
}

export function arraysHaveMatchingElement<T>(
  a: T[],
  b: T[],
  compare: (a: T, b: T) => boolean,
): boolean {
  return a.some((v) => b.some((v2) => compare(v, v2)));
}

/**
 * Creates a stable sort comparator that uses a tiebreaker when primary values are equal.
 * This ensures consistent ordering across different sort implementations.
 *
 * @param getValue - Function to get the primary comparison value
 * @param getTiebreaker - Function to get the tiebreaker value (typically an ID)
 * @returns A comparator function for use with Array.sort()
 */
export function stableComparator<T>(
  getValue: (item: T) => number,
  getTiebreaker: (item: T) => string,
): (a: T, b: T) => number {
  return (a: T, b: T) => {
    const primaryDiff = getValue(a) - getValue(b);
    if (primaryDiff !== 0) {
      return primaryDiff;
    }
    return getTiebreaker(a).localeCompare(getTiebreaker(b));
  };
}
