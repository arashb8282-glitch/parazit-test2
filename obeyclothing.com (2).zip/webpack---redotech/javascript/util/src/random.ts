import { hexEncoding } from "./encoding";

/**
 * Generate random hexadecimal string
 */
export function randomHexString(random: Random, length: number) {
  const bytes = random.bytes(Math.ceil(length / 2));
  return hexEncoding.write(bytes).slice(0, length);
}

/**
 * Generate random string of numbers
 */
// @ts-expect-error unused-export-debt
function randomNumberString(random: Random, length: number) {
  const string = random
    .float(1)
    .toString(36)
    .slice(2, length + 2);
  return string.slice(0, length);
}

/**
 * Generate a random string from a given alphabet. Consider checking the result
 * for obscene words depending on your use case.
 *
 * @param alphabet A string of characters to use in the random string. Defaults to "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
 */
export function randomStringFromAlphabet(
  random: Random,
  length: number,
  alphabet?: string,
) {
  alphabet ??= "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let randomString = "";
  for (let i = 0; i < length; i++) {
    const randomIndex = random.integer(alphabet.length);
    randomString += alphabet[randomIndex];
  }
  return randomString;
}

/**
 * Random generator
 */
export interface Random {
  /**
   * Generate random bytes
   */
  bytes(length: number): ArrayBuffer;
  /**
   * Generate random floating point, 0 <= result < max
   * @param max Exclusive maximum
   */
  float(max: number): number;
  /**
   * Generate random integer, 0 <= result < max
   * @param max Exclusive maximum
   */
  integer(max: number): number;
}

abstract class RandomBase implements Random {
  bytes(length: number): ArrayBuffer {
    const base = 2 ** 32;
    const buffer = new Uint32Array(
      Math.ceil(length / Uint32Array.BYTES_PER_ELEMENT),
    );
    for (let i = 0; i < buffer.length; i++) {
      buffer[i] = this.integer(base);
    }
    return buffer.buffer.slice(0, length);
  }

  abstract float(max: number): number;

  integer(max: number): number {
    return Math.floor(this.float(max));
  }
}

/**
 * Pseudo-random generator, based on Math.random.
 */
export const nativeRandom: Random = new (class extends RandomBase {
  float(max: number): number {
    return Math.random() * max;
  }
})();

/** Cryptographically secure generator, for tokens, passwords and other secrets. */
export const cryptoRandom: Random = new (class extends RandomBase {
  override bytes(length: number): ArrayBuffer {
    return crypto.getRandomValues(new Uint8Array(length)).buffer;
  }

  float(max: number): number {
    const [high = 0, low = 0] = crypto.getRandomValues(new Uint32Array(2));
    // 53 random bits, a double's full precision.
    return ((high >>> 5) * 2 ** 26 + (low >>> 6)) * 2 ** -53 * max;
  }
})();

/**
 * Seeded pseudo-random generator, for deterministic results.
 */
export class SeededRandom extends RandomBase {
  private seed: number;
  constructor(seed: number) {
    super();
    this.seed = seed;
  }
  float(max: number): number {
    const x = Math.sin(this.seed++) * 10_000;
    return (x - Math.floor(x)) * max;
  }
}

export function shuffle<T>(array: T[], random: Random): T[] {
  array = [...array];
  for (let index = array.length - 1; 0 <= index; index--) {
    const randomIndex = random.integer(index + 1);
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    [array[index], array[randomIndex]] = [array[randomIndex]!, array[index]!];
  }
  return array;
}

/**
 * Picks a random item from an array, weighted by the given function.
 *
 * @param items The array of items to choose from.
 * @param getWeight A function that takes an item and returns its weight.
 *
 * @returns A randomly chosen item from the array, weighted by the given function.
 */
export function weightedChoice<T>(
  items: T[],
  getWeight: (item: T) => number,
): T {
  if (items.length === 0) {
    throw new Error("No items to choose from");
  }
  const weightedItems = items.map((item) => ({
    item,
    weight: getWeight(item),
  }));

  const totalWeight = weightedItems.reduce(
    (sum, { weight }) => sum + weight,
    0,
  );

  const r = Math.random() * totalWeight;

  let cumulativeWeight = 0;
  for (const { item, weight } of weightedItems) {
    cumulativeWeight += weight;
    if (r < cumulativeWeight) {
      return item;
    }
  }

  // fallback: return the last item
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  return weightedItems.at(-1)!.item;
}

const BASE62_ALPHABET =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

/**
 * Generate a random base62 code (alphanumeric: A-Z, a-z, 0-9).
 * Useful for short codes like shortened links or lookup IDs.
 *
 * @param length The length of the code to generate (default: 6)
 */
export function generateRandomCode(length = 6): string {
  return randomStringFromAlphabet(nativeRandom, length, BASE62_ALPHABET);
}
