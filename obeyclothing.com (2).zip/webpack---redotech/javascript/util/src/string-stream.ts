/**
 * @param data
 * @param delimiter
 */
export async function* stringStreamSplit(
  data: AsyncIterable<string>,
  delimiter: string,
) {
  let buffer = "";
  for await (const chunk of data) {
    buffer += chunk;
    const parts = buffer.split(delimiter);
    yield* parts.slice(0, -1);
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    buffer = parts.at(-1)!;
  }
  yield buffer;
}
