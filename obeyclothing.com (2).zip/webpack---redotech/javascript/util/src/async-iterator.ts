import { abortRace, abortTimeout, awaitAbort, awaitAbortable } from "./abort";
import { asyncPipe, bufferedPipe, Condition } from "./condition";
import { promiseStreamRun, promiseStreamThrottle } from "./promise-stream";
import { sleep } from "./schedule";
import { instantMax, Timer } from "./temporal";

export interface BackpressureIterable<T> extends AsyncIterable<T> {
  pause(): void;
  resume(): void;
}

export function backpressure<T>(
  iterable: AsyncIterable<T>,
): BackpressureIterable<T> {
  let condition: Condition<void> | undefined;
  return {
    pause() {
      condition ??= new Condition<void>();
    },
    resume() {
      condition?.resolve();
      condition = undefined;
    },
    async *[Symbol.asyncIterator]() {
      await condition?.result;
      for await (const item of iterable) {
        yield item;
        await condition?.result;
      }
    },
  };
}

/** When {@link throttle} yields the first item after a quiet interval. */
export enum ThrottleStart {
  /** Yield the first item at once, then at most once per interval. */
  IMMEDIATE = "immediate",
  /** Yield an interval after the first item of each window. */
  DELAYED = "delayed",
}

/**
 * Yield at most one item per `interval`, always the latest. Items that arrive
 * while waiting or while the consumer is busy replace the pending item. When
 * the source ends, the pending item is yielded at once.
 */
export async function* throttle<T>(
  iterable: AsyncIterable<T>,
  {
    start,
    interval,
    signal,
  }: {
    start: ThrottleStart;
    interval: Temporal.Duration;
    signal?: AbortSignal;
  },
): AsyncIterableIterator<T> {
  let pending: { item: T; readyAt: Temporal.Instant } | undefined;
  let lastYieldAt: Temporal.Instant | undefined;
  let done = false;
  let wait = new AbortController();
  // Aborted when the consumer stops or `signal` aborts
  const stop = new AbortController();
  const stopSignal = signal ? abortRace([signal, stop.signal]) : stop.signal;

  const readyAt = (now: Temporal.Instant): Temporal.Instant => {
    switch (start) {
      case ThrottleStart.IMMEDIATE:
        return lastYieldAt ? instantMax(now, lastYieldAt.add(interval)) : now;
      case ThrottleStart.DELAYED:
        return now.add(interval);
    }
  };

  const iterator = iterable[Symbol.asyncIterator]();
  const ended = (async () => {
    try {
      while (!stopSignal.aborted) {
        const result = await awaitAbortable(iterator.next(), stopSignal);
        if (result.done) {
          break;
        }
        pending = {
          item: result.value,
          readyAt: pending?.readyAt ?? readyAt(Temporal.Now.instant()),
        };
        wait.abort();
      }
    } finally {
      done = true;
      wait.abort();
      if (stopSignal.aborted) {
        iterator.return?.().catch(() => {});
      }
    }
  })();
  ended.catch(() => {});

  try {
    while (!signal?.aborted) {
      if (done) {
        await ended;
        if (pending && !signal?.aborted) {
          yield pending.item;
        }
        return;
      }
      const now = Temporal.Now.instant();
      if (pending && Temporal.Instant.compare(pending.readyAt, now) <= 0) {
        const { item } = pending;
        pending = undefined;
        lastYieldAt = now;
        yield item;
        continue;
      }
      wait = new AbortController();
      await (
        pending
          ? sleep(pending.readyAt.since(now), wait.signal)
          : awaitAbort(wait.signal)
      ).catch(() => {});
    }
  } finally {
    stop.abort();
  }
}

/**
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/fromAsync Array.fromAsync}
 */
export async function asyncIterableToArray<T>(
  iterable: AsyncIterable<T>,
  max?: number,
): Promise<T[]> {
  const result: T[] = [];
  for await (const item of iterable) {
    if (max !== undefined && result.length >= max) {
      break;
    }
    result.push(item);
  }
  return result;
}

export async function* asyncChunks<T>(
  iterable: AsyncIterable<T>,
  size: number,
): AsyncIterableIterator<AsyncIterableIterator<T>> {
  if (size <= 0) {
    throw new Error("Size must be greater than 0");
  }
  const iterator = iterable[Symbol.asyncIterator]();
  try {
    for (let current = Symbol(), done = false; !done; current = Symbol()) {
      // require non-empty chunk
      const first = await iterator.next();
      if (first.done) {
        break;
      }
      const current_ = current;
      yield (async function* () {
        yield first.value;
        for (let count = 1; count < size && current_ === current; count++) {
          const next = await iterator.next();
          if (next.done) {
            done = true;
            break;
          }
          yield next.value;
        }
      })();
    }
  } finally {
    await iterator.return?.();
  }
}

export function asyncIterableFromIterable<T>(
  iterable: Iterable<T>,
): AsyncIterable<T> {
  return {
    async *[Symbol.asyncIterator]() {
      for (const item of iterable) {
        yield item;
      }
    },
  };
}

export async function* asyncPaginate<I, T>(
  fn: (iterator: I) => AsyncIterableIterator<T, I>,
  initial: I,
): AsyncIterableIterator<T> {
  for (let empty = false; !empty; ) {
    const iterator = fn(initial);
    try {
      for (empty = true; ; ) {
        const next = await iterator.next();
        if (next.done) {
          initial = next.value;
          break;
        }
        empty = false;
        yield next.value;
      }
    } finally {
      await iterator.return?.();
    }
  }
}

/**
 * Chunk the async iterable into chunks until size or timeout is reached.
 */
export async function* asyncTimeoutChunks<T>(
  iterable: AsyncIterable<T>,
  size: number,
  timeout: Temporal.Duration,
  signal?: AbortSignal,
): AsyncIterableIterator<AsyncIterableIterator<T>> {
  if (size <= 0) {
    throw new Error("Size must be greater than 0");
  }
  const iterator = iterable[Symbol.asyncIterator]();
  try {
    for (
      let done = false, previous: Promise<IteratorResult<T>> | undefined;
      !done;
    ) {
      if (signal?.aborted) {
        break;
      }
      const start = new Timer();
      // require non-empty chunk
      const first = await (previous ?? iterator.next());
      if (first.done) {
        break;
      }
      yield (async function* () {
        yield first.value;
        for (let count = 1; count < size; count++) {
          if (signal?.aborted) {
            break;
          }
          const remaining = timeout.subtract(start.elapsed());
          if (remaining.sign <= 0) {
            break;
          }
          previous = iterator.next();
          try {
            const combinedSignal = signal
              ? abortRace([signal, abortTimeout(remaining)])
              : abortTimeout(remaining);
            await awaitAbortable(previous, combinedSignal);
          } catch (e) {
            if (signal?.aborted) {
              break;
            }
            if (e instanceof DOMException && e.name === "TimeoutError") {
              break;
            }
          }
          const next = await previous;
          previous = undefined;
          if (next.done) {
            done = true;
            break;
          }
          yield next.value;
        }
      })();
    }
  } finally {
    await iterator.return?.();
  }
}

export function asyncIterableCount<T>(iterable: AsyncIterable<T>): {
  count(): number;
  iterable: AsyncIterableIterator<T>;
} {
  let count = 0;
  return {
    count: () => count,
    iterable: (async function* () {
      for await (const item of iterable) {
        count++;
        yield item;
      }
    })(),
  };
}

export async function* asyncIterableConcat<T>(
  iterables: Iterable<AsyncIterable<T>>,
) {
  for (const iterable of iterables) {
    for await (const item of iterable) {
      yield item;
    }
  }
}

// @ts-expect-error unused-export-debt
async function asyncSome<T>(
  iterable: AsyncIterable<T> | Iterable<T>,
  f: (item: T) => Promise<boolean> | boolean,
): Promise<boolean> {
  for await (const item of iterable) {
    if (await f(item)) {
      return true;
    }
  }
  return false;
}

export function asyncIterableFilter<T, F extends T>(
  iterable: AsyncIterable<T>,
  f: (item: T) => item is F,
): AsyncIterable<F> {
  return {
    async *[Symbol.asyncIterator]() {
      for await (const item of iterable) {
        if (f(item)) {
          yield item as F;
        }
      }
    },
  };
}

export function asyncIterableFlatMap<A, B>(
  iterable: AsyncIterable<A>,
  f: (a: A) => AsyncIterable<B>,
): AsyncIterable<B> {
  return {
    async *[Symbol.asyncIterator]() {
      for await (const item of iterable) {
        yield* f(item);
      }
    },
  };
}

export function asyncIterableMap<A, B>(
  iterable: AsyncIterable<A>,
  f: (a: A) => B | Promise<B>,
): AsyncIterable<B> {
  return {
    async *[Symbol.asyncIterator]() {
      for await (const item of iterable) {
        yield f(item);
      }
    },
  };
}

// @ts-expect-error unused-export-debt
async function* asyncIterableBuffer<T>(
  iterable: AsyncIterable<T>,
  limit: number,
): AsyncIterable<T> {
  const [write, read] = bufferedPipe<T>();
  let size = 0;
  let condition: Condition<void> | undefined;
  const produce = (async () => {
    try {
      for await (const item of iterable) {
        if (limit <= ++size) {
          condition = new Condition<void>();
          await condition.result;
        }
        write.next(item);
      }
    } finally {
      write.end();
    }
  })();

  try {
    for await (const item of read) {
      size--;
      condition?.resolve();
      yield item;
    }
  } finally {
    await produce;
  }
}

// @ts-expect-error unused-export-debt
function asyncIterableIgnoreAbort<T>(
  iterable: AsyncIterable<T>,
  abort: AbortSignal,
): AsyncIterable<T> {
  return {
    async *[Symbol.asyncIterator]() {
      try {
        for await (const item of iterable) {
          yield item;
        }
      } catch (e) {
        if (abort.aborted) {
          return;
        }
        throw e;
      }
    },
  };
}

export function asyncIterableMerge<T>(...iterables: AsyncIterable<T>[]) {
  if (iterables.length === 1) {
    return iterables[0];
  }
  return (async function* () {
    const abort = new AbortController();
    const [write, read] = asyncPipe<T>();
    const promise = Promise.all(
      iterables.map(async (iterable) => {
        try {
          for await (const item of iterable) {
            if (abort.signal.aborted) {
              break;
            }
            await write.next(item);
          }
        } catch (e) {
          await write.throw(e);
          abort.abort(e);
        }
      }),
    );
    try {
      for await (const item of read) {
        yield item;
      }
      await write.end();
    } finally {
      abort.abort();
      await promise;
    }
  })();
}

export function asyncIterableSlice<T>(
  iterable: AsyncIterable<T>,
  start: number,
  end?: number,
): AsyncIterable<T> {
  return {
    async *[Symbol.asyncIterator]() {
      if (end === 0) {
        return;
      }
      let index = 0;
      for await (const element of iterable) {
        if (start <= index) {
          yield element;
        }
        index++;
        if (end !== undefined && end <= index) {
          break;
        }
      }
    },
  };
}

export async function parallelForEach<T>(
  iterable: Iterable<T> | AsyncIterable<T>,
  concurrency: number,
  fn: (item: T) => Promise<void>,
) {
  for await (const _ of parallelMapUnordered(iterable, concurrency, fn)) {
    /**/
  }
}

/**
 * Process items with bounded concurrency where items sharing a key serialize.
 * Items with different keys may run concurrently up to `concurrency`.
 */
export async function parallelForEachByKey<T, K>(
  iterable: Iterable<T> | AsyncIterable<T>,
  concurrency: number,
  keyFn: (item: T) => K,
  fn: (item: T) => Promise<void>,
): Promise<void> {
  if (concurrency < 1) {
    throw new Error("concurrency must be >= 1");
  }

  const chains = new Map<K, Promise<void>>();
  const errors: unknown[] = [];
  let inFlightKeys = 0;
  let wake: Condition<void> = new Condition<void>();
  const signalWake = () => {
    const w = wake;
    wake = new Condition<void>();
    w.resolve();
  };

  for await (const item of iterable) {
    const key = keyFn(item);
    const prev = chains.get(key);
    if (!prev) {
      while (inFlightKeys >= concurrency) {
        await wake.result;
      }
      inFlightKeys++;
    }
    const next = (async () => {
      if (prev) {
        await prev;
      }
      try {
        await fn(item);
      } catch (err) {
        errors.push(err);
      }
    })();
    chains.set(key, next);
    void next.then(() => {
      if (chains.get(key) === next) {
        chains.delete(key);
        inFlightKeys--;
        signalWake();
      }
    });
  }

  await Promise.all(chains.values());

  if (errors.length > 0) {
    throw errors[0];
  }
}

export async function parallelMap<A, B>(
  iterable: Iterable<A> | AsyncIterable<A>,
  concurrency: number,
  fn: (item: A) => Promise<B>,
): Promise<B[]> {
  const result: B[] = [];
  let index = 0;
  await parallelForEach(iterable, concurrency, async (item) => {
    result[index++] = await fn(item);
  });
  return result;
}

export function parallelMapUnordered<A, B>(
  iterable: Iterable<A> | AsyncIterable<A>,
  concurrency: number,
  fn: (item: A) => Promise<B>,
): AsyncIterable<B> {
  const promises = asyncIterableMap(
    Symbol.asyncIterator in iterable
      ? iterable
      : asyncIterableFromIterable(iterable),
    (element) => () => fn(element),
  );
  return promiseStreamRun(promiseStreamThrottle(promises, concurrency));
}

export function asyncConsumeWhile<T>(
  iterator: AsyncIterable<T>,
  condition: (item: T) => boolean,
): AsyncIterable<T> {
  return {
    async *[Symbol.asyncIterator]() {
      for await (const item of iterator) {
        if (!condition(item)) {
          break;
        }
        yield item;
      }
    },
  };
}
