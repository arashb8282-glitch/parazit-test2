/** Splits a CSS selector list on its top-level commas only. */
export function splitSelectorList(selectorList: string): string[] {
  const selectors: string[] = [];
  let start = 0;
  let depth = 0;
  let quote: string | undefined;
  let inComment = false;
  for (let index = 0; index < selectorList.length; index++) {
    const char = selectorList.charAt(index);
    if (inComment) {
      if (char === "*" && selectorList[index + 1] === "/") {
        inComment = false;
        index++;
      }
      continue;
    }
    if (char === "\\") {
      index++;
      continue;
    }
    if (quote) {
      if (char === quote) {
        quote = undefined;
      }
      continue;
    }
    if (char === "/" && selectorList[index + 1] === "*") {
      inComment = true;
      index++;
    } else {
      switch (char) {
        case '"':
        case "'": {
          quote = char;

          break;
        }
        case "(":
        case "[": {
          depth++;

          break;
        }
        case ")":
        case "]": {
          depth--;

          break;
        }
        default:
          if (char === "," && depth === 0) {
            selectors.push(selectorList.slice(start, index).trim());
            start = index + 1;
          }
      }
    }
  }
  selectors.push(selectorList.slice(start).trim());
  return selectors;
}
