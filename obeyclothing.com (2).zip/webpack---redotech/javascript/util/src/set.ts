import { Key, KeyFn } from "./key";

export class KeyedSet<T> implements Set<T> {
  private readonly elements = new Map<Key, T>();

  constructor(
    private readonly keyFn: KeyFn<T>,
    entries?: Iterable<T>,
  ) {
    if (entries) {
      for (const entry of entries) {
        this.add(entry);
      }
    }
  }

  get size(): number {
    return this.elements.size;
  }

  add(value: T): this {
    this.elements.set(this.keyFn(value), value);
    return this;
  }

  clear(): void {
    this.elements.clear();
  }

  forEach(
    callbackfn: (value: T, value2: T, set: Set<T>) => void,
    thisArg?: any,
  ): void {
    // eslint-disable-next-line unicorn/no-array-for-each
    this.elements.forEach(function (this: any, value, key) {
      return callbackfn(value, value, this);
    }, thisArg);
  }

  delete(value: T): boolean {
    return this.elements.delete(this.keyFn(value));
  }

  entries(): IterableIterator<[T, T]> {
    return this.elements.entries();
  }

  has(value: T): boolean {
    return this.elements.has(this.keyFn(value));
  }

  keys(): IterableIterator<T> {
    return this.elements.values();
  }

  values(): IterableIterator<T> {
    return this.elements.values();
  }

  [Symbol.iterator](): IterableIterator<T> {
    return this.keys();
  }

  [Symbol.toStringTag] = "KeyedSet";
}

/**
 * @param setA Prospective subset
 * @param setB Prospective superset
 * @returns true if all elements of `setA` are also in `setB`
 */
export function isSubset<T>(setA: Set<T>, setB: Set<T>): boolean {
  for (const elem of setA) {
    if (!setB.has(elem)) {
      return false;
    }
  }
  return true;
}

/**
 * `Set.prototype.difference` requires Node 22, but we are using Node 20.
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Set/difference#browser_compatibility
 * @returns all elements of `setA` that are not in `setB`
 */
export function difference<T>(setA: Set<T>, setB: Set<T>): Set<T> {
  const diff = new Set(setA);
  for (const elem of setB) {
    diff.delete(elem);
  }
  return diff;
}

export function intersection<T>(setA: Set<T>, setB: Set<T>): Set<T> {
  let smallerSet;
  let largerSet;
  if (setA.size < setB.size) {
    smallerSet = setA;
    largerSet = setB;
  } else {
    smallerSet = setB;
    largerSet = setA;
  }

  const intersection = new Set<T>();
  for (const elem of smallerSet) {
    if (largerSet.has(elem)) {
      intersection.add(elem);
    }
  }

  return intersection;
}
