import { Falsy } from "./type";

// eslint-disable-next-line unicorn/prefer-native-coercion-functions
export function booleanFilter<T>(item: T): item is Exclude<T, Falsy> {
  return Boolean(item);
}
