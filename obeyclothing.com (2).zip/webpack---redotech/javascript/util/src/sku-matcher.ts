/**
 * Compiles a list of SKU exclusion patterns into a matcher.
 *
 * Patterns support a single leading and/or trailing `*` wildcard:
 *   - `foo`   exact match (case-insensitive)
 *   - `foo*`  prefix match — matches any SKU starting with `foo`
 *   - `*foo`  suffix match — matches any SKU ending with `foo`
 *   - `*foo*` contains match — matches any SKU containing `foo`
 *   - `*`     matches every SKU
 *
 * Wildcards in any other position (e.g. `f*oo`) are treated as literal characters.
 */
export interface SkuMatcher {
  readonly patternCount: number;
  /** The normalized (lowercased, non-empty) source patterns. Useful for cache keys. */
  readonly patterns: readonly string[];
  matches(sku: string | null | undefined): boolean;
}

export function createSkuMatcher(
  patterns: readonly string[] | null | undefined,
): SkuMatcher {
  const exact = new Set<string>();
  const prefixes: string[] = [];
  const suffixes: string[] = [];
  const contains: string[] = [];
  const normalizedPatterns: string[] = [];
  let matchAll = false;
  let patternCount = 0;

  for (const raw of patterns ?? []) {
    if (!raw) {
      continue;
    }
    const pattern = raw.toLowerCase();
    normalizedPatterns.push(pattern);
    patternCount++;

    const startsWithStar = pattern.startsWith("*");
    const endsWithStar = pattern.endsWith("*");

    if (startsWithStar && endsWithStar) {
      const inner = pattern.slice(1, -1);
      if (inner.length === 0) {
        matchAll = true;
      } else {
        contains.push(inner);
      }
    } else if (startsWithStar) {
      suffixes.push(pattern.slice(1));
    } else if (endsWithStar) {
      prefixes.push(pattern.slice(0, -1));
    } else {
      exact.add(pattern);
    }
  }

  return {
    patternCount,
    patterns: normalizedPatterns,
    matches(sku) {
      if (patternCount === 0 || !sku) {
        return false;
      }
      if (matchAll) {
        return true;
      }
      const lower = sku.toLowerCase();
      if (exact.has(lower)) {
        return true;
      }
      for (const prefix of prefixes) {
        if (lower.startsWith(prefix)) {
          return true;
        }
      }
      for (const suffix of suffixes) {
        if (lower.endsWith(suffix)) {
          return true;
        }
      }
      for (const sub of contains) {
        if (lower.includes(sub)) {
          return true;
        }
      }
      return false;
    },
  };
}
