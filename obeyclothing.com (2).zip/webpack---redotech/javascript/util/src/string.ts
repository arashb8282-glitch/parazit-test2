/**
 * https://stackoverflow.com/questions/7616461/generate-a-hash-from-string-in-javascript
 * @param {string} string string
 * @returns {number} 32-bit hash of string
 */
export function stringHash(string: string): number {
  let hash = 0;
  for (let i = 0; i < string.length; i++) {
    const chr = string.charCodeAt(i);
    hash = (hash << 5) - hash + chr;
    hash |= 0;
  }
  return hash;
}

export function escapeRegExp(string: string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Attempts to coerce a name into 'Jane Doe'
 * jane doe, JANE   DOE -> Jane Doe
 */
export function formatName(name: string): string {
  return name
    .split(/\s+/)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
}

export function formatSentenceCase(str: string) {
  if (!str) {
    return str;
  }
  return (
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    str[0]!.toUpperCase() +
    str
      .slice(1)
      .replace(/_/g, " ") // Convert snake_case to spaces
      .replace(/([a-z])([A-Z])/g, "$1 $2") // Convert camelCase to spaces
      .replace(/\s+/g, " ") // Clean up multiple spaces
      .toLowerCase() // Make everything lowercase except the first character
  );
}

export function camelToSnakeCase(str: string) {
  return str.replace(/[A-Z]/g, (letter) => `_${letter.toLowerCase()}`);
}

/**
 * Convert PascalCase (or camelCase) to snake_case **without** a leading
 * underscore. Unlike {@link camelToSnakeCase}, the first character is
 * lowercased in place rather than prefixed with `_`.
 *
 * Used to translate TypeScript enum members (PascalCase string values)
 * into their CRDB enum equivalents — e.g. `OutboundLabel` →
 * `outbound_label`, `Coverage` → `coverage`. The billing module had six
 * inline copies of this same regex before it was centralized here; keep
 * future enum-to-DB cases pointed at this helper to avoid the drift.
 */
export function pascalToSnakeCase(str: string): string {
  return str.replace(/[A-Z]/g, (letter, index) =>
    index === 0 ? letter.toLowerCase() : `_${letter.toLowerCase()}`,
  );
}

export type SnakeToCamelCase<S extends string> =
  S extends `${infer T}_${infer U}`
    ? `${T}${Capitalize<SnakeToCamelCase<U>>}`
    : S;

export function snakeToCamelCase(str: string) {
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  return str.replace(/(_\w)/g, (match) => match[1]!.toUpperCase());
}

export function truncateString(str: string, maxLength: number) {
  return str.length > maxLength ? str.slice(0, maxLength) + "…" : str;
}

/** Cuts at the last comma, else space, that keeps the head within `max`. */
export function splitAtBoundary(value: string, max: number): [string, string] {
  if (value.length <= max) {
    return [value, ""];
  }
  const window = value.slice(0, max + 1);
  const commaCut = window.lastIndexOf(",");
  const spaceCut = window.lastIndexOf(" ");
  const cut = commaCut > 0 ? commaCut : spaceCut > 0 ? spaceCut : max;
  return [
    value.slice(0, cut).replace(/[\s,]+$/, ""),
    value.slice(cut).replace(/^[\s,]+/, ""),
  ];
}

export async function replaceAsync(
  str: string,
  regexp: RegExp,
  replacerFunction: (match: RegExpMatchArray) => Promise<string>,
) {
  const replacements = await Promise.all(
    Array.from(str.matchAll(regexp), replacerFunction),
  );
  let i = 0;
  return str.replace(regexp, () => {
    if (i >= replacements.length) {
      throw new Error(
        `Replacement index ${i} out of bounds for replacements array of length ${replacements.length}`,
      );
    }
    const replacement = replacements[i];
    if (replacement === undefined) {
      throw new Error(`Replacement at index ${i} is undefined`);
    }
    i++;
    return replacement;
  });
}

export function isNumeric(str: string): boolean {
  return /^[0-9]+$/.test(str);
}

/**
 * Unescapes HTML-encoded quotes inside all Liquid template syntax.
 * Handles: {{ }}, {{- }}, {{ -}}, {{- -}}, {% %}, {%- %}, {% -%}, {%- -%}
 * This ensures Liquid syntax with quotes works correctly, e.g., {{ list: "ordered" }}, {% if status == "active" %}
 *
 * @param html HTML string that may contain escaped quotes in Liquid syntax
 * @returns HTML with unescaped quotes inside all Liquid blocks
 */
export function unescapeQuotesInsideLiquid(html: string): string {
  // Match all variations: {{, {{-, {% and {%-
  const liquidBlockRegex = /\{\{-?.*?-?\}\}|\{%-?.*?-?%\}/g;

  return html.replace(liquidBlockRegex, (match) => {
    return match
      .replaceAll("&quot;", '"')
      .replaceAll("&#39;", "'")
      .replaceAll("&lt;", "<")
      .replaceAll("&gt;", ">");
  });
}

export function normalizeWhitespace(str: string): string {
  return str.replace(/\s+/g, " ").trim();
}

/**
 * Normalize a user-entered search string.
 *
 * Always trims surrounding whitespace — pasted values frequently carry a stray
 * leading/trailing space, which otherwise prevents an exact match. By default
 * the result is also lowercased, which is the right choice for
 * case-insensitive search/filter comparisons.
 *
 * Pass `{ preserveCase: true }` when the normalized value is echoed back to the
 * user rather than only compared — most importantly when an unmatched search
 * may be turned into a newly created entity (e.g. creating a tag from the
 * search box), where lowercasing would silently mangle the user's casing.
 */
export function normalizeSearch(
  input?: string,
  opts?: { preserveCase?: boolean },
): string {
  if (!input) {
    return "";
  }

  const trimmed = input.trim();
  return opts?.preserveCase ? trimmed : trimmed.toLowerCase();
}

/**
 * Normalize text for comparison (lowercase, trim, remove extra spaces)
 */
export function normalizeText(text: string): string {
  return text.toLowerCase().trim().replace(/\s+/g, " ");
}

/**
 * Calculate Levenshtein distance between two strings.
 * Returns the minimum number of single-character edits (insertions, deletions, or substitutions)
 * required to change one string into the other.
 *
 * @param str1 First string
 * @param str2 Second string
 * @returns The Levenshtein distance (0 means identical strings)
 */
export function levenshteinDistance(str1: string, str2: string): number {
  const matrix: number[][] = [];

  for (let i = 0; i <= str2.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= str1.length; j++) {
    if (matrix[0]) {
      matrix[0][j] = j;
    }
  }

  for (let i = 1; i <= str2.length; i++) {
    if (!matrix[i]) {
      matrix[i] = [];
    }
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    const currentRow = matrix[i]!;

    for (let j = 1; j <= str1.length; j++) {
      if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
        currentRow[j] = matrix[i - 1]?.[j - 1] ?? 0;
      } else {
        currentRow[j] = Math.min(
          (matrix[i - 1]?.[j - 1] ?? 0) + 1, // substitution
          (currentRow[j - 1] ?? 0) + 1, // insertion
          (matrix[i - 1]?.[j] ?? 0) + 1, // deletion
        );
      }
    }
  }

  return matrix[str2.length]?.[str1.length] ?? 0;
}

/**
 * Calculate similarity score between two strings using Levenshtein distance.
 * Returns a value between 0 and 1, where 1 means identical strings.
 *
 * @param str1 First string
 * @param str2 Second string
 * @param normalize Whether to normalize strings before comparison (default: true)
 * @returns Similarity score (0-1, where 1 is identical)
 */
export function calculateStringSimilarity(
  str1: string,
  str2: string,
  normalize = true,
): number {
  const s1 = normalize ? normalizeText(str1) : str1;
  const s2 = normalize ? normalizeText(str2) : str2;

  if (s1 === s2) {
    return 1;
  }

  const longer = s1.length > s2.length ? s1 : s2;
  const shorter = s1.length > s2.length ? s2 : s1;

  if (longer.length === 0) {
    return 1;
  }

  const distance = levenshteinDistance(longer, shorter);
  return (longer.length - distance) / longer.length;
}

/**
 * Extract email addresses from text.
 * Simple extraction pattern for finding emails in free-form text.
 *
 * @param text Text to extract emails from
 * @returns Array of email addresses found in lowercase
 */
export function extractEmailsFromText(text: string): string[] {
  const emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
  const matches = text.match(emailPattern) || [];
  return matches.map((email) => email.toLowerCase());
}

/**
 * Extract phone numbers from text.
 * Matches various phone formats: (123) 456-7890, 123-456-7890, 1234567890, +1 123 456 7890
 *
 * @param text Text to extract phone numbers from
 * @returns Array of phone numbers found (raw format as found in text)
 */
export function extractPhoneNumbersFromText(text: string): string[] {
  const phonePattern =
    /(?:\+?1[-.\s]?)?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})/g;
  const matches: string[] = [];
  let match;

  while ((match = phonePattern.exec(text)) !== null) {
    matches.push(match[0]);
  }

  return matches;
}

export function stripBase64Images(text: string): string {
  let result = text.replace(
    /!\[[^\]]*\]\(data:image\/[a-z+]+;base64,[A-Za-z0-9+/=\s]+\)/g,
    "",
  );
  result = result.replace(
    /<img\s[^>]*src=["']data:image\/[a-z+]+;base64,[A-Za-z0-9+/=\s]+["'][^>]*\/?>/gi,
    "",
  );
  return result;
}

/**
 * Removes invisible characters (zero-width spaces, BOM, bidirectional formatting, etc.) and trims whitespace.
 * Useful for cleaning user input that may contain copy-pasted invisible characters.
 */
export function removeInvisibleCharacters(str: string): string {
  return str
    .replace(/[\u200B-\u200F\u202A-\u202E\uFEFF]/g, "") // Zero-width spaces, directional marks, bidirectional formatting, and BOM
    .trim();
}

/** The first `maxLength` code points of `text`. `slice` counts UTF-16 units, so it can split an emoji
 *  into a lone surrogate, which APIs reject as invalid text. */
export function truncateCodePoints(text: string, maxLength: number): string {
  return Array.from(text).slice(0, maxLength).join("");
}

/** A stretch of searched text; `matchIndex` numbers it among every match found, or is null. */
export interface FoundRun {
  text: string;
  matchIndex: number | null;
}

/**
 * Cuts each text around the case-insensitive matches of `query`, numbering the
 * matches across all the texts in order. A blank query matches nothing.
 */
export function findInTexts(
  texts: readonly string[],
  query: string,
): { runs: FoundRun[][]; total: number } {
  if (!query.trim()) {
    return {
      runs: texts.map((text) => [{ text, matchIndex: null }]),
      total: 0,
    };
  }
  const pattern = new RegExp(`(${escapeRegExp(query)})`, "gi"); // nosemgrep: detect-non-literal-regexp — input is escaped via escapeRegExp
  let total = 0;
  const runs = texts.map((text) =>
    // Split with a capturing group alternates text and match, so odd parts are matches.
    text
      .split(pattern)
      .map((part, index) => ({ part, isMatch: index % 2 === 1 }))
      .filter(({ part }) => part !== "")
      .map(({ part, isMatch }) => ({
        text: part,
        matchIndex: isMatch ? total++ : null,
      })),
  );
  return { runs, total };
}
