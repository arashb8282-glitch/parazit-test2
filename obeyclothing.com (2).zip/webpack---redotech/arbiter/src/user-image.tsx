import classNames from "classnames";
import { JSXElementConstructor, memo, useState } from "react";
import UserIcon from "./icon-old/user.svg";
import * as userImageCss from "./user-image.module.css";

const bubbleColorClassNames = [
  userImageCss.initialsColor0,
  userImageCss.initialsColor1,
  userImageCss.initialsColor2,
  userImageCss.initialsColor3,
  userImageCss.initialsColor4,
  userImageCss.initialsColor5,
  userImageCss.initialsColor6,
  userImageCss.initialsColor7,
  userImageCss.initialsColor8,
  userImageCss.initialsColor9,
  userImageCss.initialsColor10,
  userImageCss.initialsColor11,
];

const getBubbleColorClassName = (name: string) => {
  const numericValue = name
    .split("")
    .reduce((accumulator: number, letter: string) => {
      return accumulator + letter.charCodeAt(0);
    }, 0);
  const colorIndex = numericValue % bubbleColorClassNames.length;
  return bubbleColorClassNames[colorIndex] ?? "";
};

export enum UserImageSize {
  X_TINY = -1,
  TINY = 0,
  MICRO = 1,
  SMALL = 2,
  MEDIUM_SMALL = 3,
  MEDIUM_SMALL_MEDIUM = 4,
  MEDIUM = 5,
  LARGE = 6,
}

export const userImageSizeClasses: Record<UserImageSize, string> = {
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  [UserImageSize.X_TINY]: userImageCss.xTiny,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  [UserImageSize.TINY]: userImageCss.tiny,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  [UserImageSize.MICRO]: userImageCss.micro,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  [UserImageSize.SMALL]: userImageCss.small,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  [UserImageSize.MEDIUM_SMALL]: userImageCss.mediumSmall,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  [UserImageSize.MEDIUM_SMALL_MEDIUM]: userImageCss.mediumSmallMedium,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  [UserImageSize.MEDIUM]: userImageCss.medium,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  [UserImageSize.LARGE]: userImageCss.large,
};

interface UserImageProps {
  alt: string;
  imageUrl: string | null | undefined;
  name?: string;
  size?: UserImageSize;
  contrastBorder?: boolean;
  greyOut?: boolean;
  DefaultIcon?: JSXElementConstructor<any>;
  "data-arbiter"?: string;
}

/**
 * User image tries to use its main image (as given with the url), but has
 * 2 fallbacks: first to use initials of the name, and second to a generic user icon.
 *
 * @param imageUrl MUST BE TRUTHY i.e. NON-EMPTY or else double-icon bug will occur.
 */
export const UserImage = memo(function UserImage({
  alt,
  imageUrl,
  name,
  size = UserImageSize.SMALL,
  contrastBorder = false,
  greyOut = false,
  DefaultIcon = UserIcon,
  "data-arbiter": dataArbiter,
}: UserImageProps) {
  const [failedImageUrl, setFailedImageUrl] = useState<string | null>(null);
  const displayDefault = !imageUrl || failedImageUrl === imageUrl;
  const allInitials = name
    ?.split(" ")
    ?.filter((namePart) => /^[A-Za-z]/.test(namePart)) // Ensure the part starts with a letter
    // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
    ?.map((namePart) => namePart[0].toUpperCase());
  const initials =
    allInitials && allInitials.length > 0
      ? allInitials.length > 1
        ? // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
          allInitials[0] + allInitials[allInitials.length - 1]
        : allInitials[0]
      : undefined;

  return (
    <div
      className={userImageCss.container}
      data-arbiter={dataArbiter}
      data-web="UserImage"
    >
      {!displayDefault && (
        <div
          className={classNames(
            ...(contrastBorder ? [userImageCss.contrastBorder] : []),
            userImageSizeClasses[size],
            ...(greyOut ? [userImageCss.greyOut] : []),
          )}
        >
          <img
            alt={alt}
            className={classNames(
              userImageCss.bubble,
              userImageSizeClasses[size],
            )}
            onError={() => setFailedImageUrl(imageUrl ?? null)}
            src={imageUrl ?? ""}
          />
        </div>
      )}
      {displayDefault && name?.trim() && (
        <div
          className={classNames(
            userImageCss.bubble,
            userImageSizeClasses[size],
            getBubbleColorClassName(name),
            ...(greyOut ? [userImageCss.greyOut] : []),
          )}
        >
          <div className={userImageCss.initialsWrapper}>
            <p>{initials}</p>
          </div>
        </div>
      )}
      {!name?.trim() && displayDefault && (
        <DefaultIcon
          className={classNames(
            userImageSizeClasses[size],
            ...(greyOut ? [userImageCss.greyOut] : []),
          )}
        />
      )}
    </div>
  );
});
