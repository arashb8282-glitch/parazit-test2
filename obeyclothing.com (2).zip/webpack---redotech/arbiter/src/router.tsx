import { createElement, forwardRef } from "react";
import { useArbiterSettings } from "./internal/arbiter-context";
import type { LinkProps, To } from "./provider";

// Bundlers replace this expression; Arbiter doesn't depend on Node's types.
declare const process: { env: { NODE_ENV?: string } };

let warnedUnconfigured = false;

function warnUnconfiguredOnce() {
  if (warnedUnconfigured || process.env.NODE_ENV !== "development") {
    return;
  }
  warnedUnconfigured = true;
  console.warn(
    "Arbiter links are plain anchors that reload the page. Render <ArbiterProvider linkComponent={...}> from @redo/arbiter/provider around your app to route them through it.",
  );
}

function hrefOf(to: To): string {
  if (typeof to === "string") {
    return to;
  }
  return `${to.pathname ?? ""}${to.search ?? ""}${to.hash ?? ""}`;
}

export const Link = forwardRef<HTMLAnchorElement, LinkProps>(
  function Link(props, ref) {
    const { linkComponent } = useArbiterSettings();
    if (linkComponent) {
      return createElement(linkComponent, { ...props, ref });
    }
    warnUnconfiguredOnce();
    const {
      to,
      replace,
      state,
      reloadDocument,
      relative,
      preventScrollReset,
      ...anchor
    } = props;
    return <a href={hrefOf(to)} ref={ref} {...anchor} />;
  },
);
