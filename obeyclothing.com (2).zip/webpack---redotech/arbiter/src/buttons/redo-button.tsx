import classNames from "classnames";
import {
  CSSProperties,
  ForwardedRef,
  forwardRef,
  JSXElementConstructor,
  memo,
  MouseEvent,
  useState,
} from "react";
import CircleSpinner from "../circle-spinner.svg";
import { Flex } from "../flex";
import { composeWrappers } from "../internal/component";
import { Text } from "../text";
import { SpacingValue } from "../theme/box";
import { TextSizeValue, TextWeightValue } from "../theme/typography";
import { OverflowTooltip } from "../tooltip/overflow-tooltip";
import * as redoButtonThemeCss from "./redo-button-themes.module.css";
import * as redoButtonCss from "./redo-button.module.css";

export const redoButtonSize = [
  "xs",
  "sm",
  "md",
  "lg",
  "xl",
  "2xl",
  "3xl",
] as const;
export type RedoButtonSize = (typeof redoButtonSize)[number];

export const redoButtonTheme = [
  "normal",
  "destructive",
  "success",
  "action",
] as const;
export type RedoButtonTheme = (typeof redoButtonTheme)[number];

export const redoButtonHierarchy = [
  "primary",
  "secondary",
  "tertiary",
  "link",
  "link_underline",
] as const;
export type RedoButtonHierarchy = (typeof redoButtonHierarchy)[number];

/**
 * @param pending -- custom pending states can be achieved by passing spinner icon leading, new text, and disabled
 *
 * @param dangerousStyleThatShouldOnlyBeUsedInSpecificSituations -- this should only defined if we need the button to follow a merchant's branding.
 * Do not use in other situations.
 *
 * @param type -- if you are using an HTML form, you may care about setting this.
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#type}
 *
 */

export interface RedoButtonProps extends React.ComponentProps<"button"> {
  "data-dd-action-name"?: string;
  dataTarget?: string;
  onClick?(event: MouseEvent<HTMLButtonElement>): void;
  dataTestId?: string;
  dataTrackId?: string;
  size?: RedoButtonSize;
  theme?: RedoButtonTheme;
  hierarchy?: RedoButtonHierarchy;
  text?: string;
  textWeight?: TextWeightValue;
  IconLeading?: JSXElementConstructor<any> | "placeholder";
  IconTrailing?: JSXElementConstructor<any> | "placeholder";
  dontRestrainIconWidth?: boolean;
  disabled?: boolean;
  pending?: boolean;
  pressed?: boolean;
  squared?: boolean;
  buttonClassName?: string;
  buttonContentClassName?: string;
  buttonId?: string;
  buttonValue?: string;
  centerItems?: boolean;
  className?: string;
  type?: "button" | "submit" | "reset";
  form?: string;
  flexGrow?: number;
  flexBasis?: number | string;
  useOverflowTooltip?: boolean;
  dangerousStyleThatShouldOnlyBeUsedForMerchantBranding?: React.CSSProperties;
  ref?: ForwardedRef<HTMLButtonElement>;
  wrapText?: boolean;
  uiSelector?: string;
  /**
   * Renders the button's look on a non-interactive span, for a parent that is
   * already the button. A button can't contain a button. Interaction props are
   * ignored.
   */
  presentational?: boolean;
}

/**
 * Figma
 * https://www.figma.com/design/iZHj2I36zd9i8nRbWKw4ZK/%E2%9D%96-Arbiter?node-id=3287-427074&t=p984S770InFMNsms-0
 */
export const RedoButton = memo(
  forwardRef(function RedoButton(
    {
      dataTestId,
      dataTrackId,
      size = "sm",
      theme = "normal",
      hierarchy = "tertiary",
      IconLeading,
      IconTrailing,
      text,
      textWeight = "medium",
      onClick,
      disabled,
      pending,
      centerItems = true,
      buttonClassName,
      buttonContentClassName,
      buttonId,
      buttonValue,
      dontRestrainIconWidth,
      className,
      type = "button",
      form,
      pressed,
      squared,
      flexGrow,
      flexBasis,
      useOverflowTooltip = false,
      dangerousStyleThatShouldOnlyBeUsedForMerchantBranding,
      dataTarget,
      wrapText = false,
      uiSelector,
      presentational = false,
      ...rest
    }: RedoButtonProps,
    ref: ForwardedRef<HTMLButtonElement>,
  ) {
    const isIconOnly = !text;
    const [textRef, setTextRef] = useState<HTMLElement | null>(null);

    function wrappedIcon(
      Icon: JSXElementConstructor<any> | "placeholder",
      extraClasses?: string,
    ) {
      const icon = typeof Icon === "string" ? <div /> : <Icon />;

      return (
        <Flex
          align="center"
          className={classNames(
            redoButtonCss.iconContainer,
            redoButtonCss[size],
            dontRestrainIconWidth && redoButtonCss.dontRestrainIconWidth,
            extraClasses,
          )}
          justify="center"
        >
          {icon}
        </Flex>
      );
    }

    const fontSize = sizeToFontSize[size];

    const px = evaluatePx(size, isIconOnly, hierarchy);

    const style: CSSProperties = {};
    if (flexBasis !== undefined) {
      style.flexBasis = flexBasis;
    }
    if (flexGrow !== undefined) {
      style.flexGrow = flexGrow;
    }

    const buttonClasses = classNames(
      redoButtonCss.button,
      disabled || pending ? redoButtonThemeCss.disabled : undefined,
      redoButtonCss[sizeToCssClass[size]],
      themeClass[theme],
      hierarchyClass[hierarchy],
      pressed && redoButtonThemeCss.pressed,
      buttonClassName,
      squared && redoButtonCss.squared,
      wrapText && redoButtonCss.wrapText,
    );

    const content = (
      <>
        {pending && wrappedIcon(CircleSpinner, redoButtonCss.spinner)}
        <Flex
          align="center"
          className={classNames(
            redoButtonCss.buttonContent,
            pending && redoButtonCss.pending,
            buttonContentClassName,
          )}
          gap={sizeToGap[size]}
          justify={centerItems ? "center" : "flex-start"}
          px={px}
        >
          {IconLeading && wrappedIcon(IconLeading)}
          {text && (
            <Text
              fontSize={fontSize}
              fontWeight={textWeight}
              minW={wrapText ? undefined : "none"}
              overflow={wrapText ? undefined : "hidden"}
              px={px === "none" ? "none" : "xxs"}
              ref={setTextRef}
              textAlign={wrapText ? "center" : undefined}
              textOverflow={wrapText ? undefined : "ellipsis"}
              whiteSpace={wrapText ? "normal" : "nowrap"}
            >
              {text}
            </Text>
          )}
          {IconTrailing && wrappedIcon(IconTrailing)}
        </Flex>
      </>
    );

    return (
      <div
        className={className}
        data-arbiter="RedoButton"
        data-ui={uiSelector}
        style={style}
      >
        {composeWrappers((inner) =>
          useOverflowTooltip ? (
            <OverflowTooltip
              overflowRef={textRef}
              tooltipProps={{ title: text }}
              wrapperStyle={{ display: "inline-block", width: "100%" }}
            >
              {inner}
            </OverflowTooltip>
          ) : (
            inner
          ),
        )(
          presentational ? (
            <span
              className={buttonClasses}
              data-hierarchy={hierarchy}
              data-theme={theme}
            >
              {content}
            </span>
          ) : (
            <button
              className={buttonClasses}
              data-hierarchy={hierarchy}
              data-target={dataTarget}
              data-testid={dataTestId}
              data-theme={theme}
              data-track-id={dataTrackId}
              disabled={disabled || pending}
              form={form}
              id={buttonId}
              onClick={onClick}
              ref={ref}
              style={dangerousStyleThatShouldOnlyBeUsedForMerchantBranding}
              type={type}
              value={buttonValue}
              {...rest}
            >
              {content}
            </button>
          ),
        )}
      </div>
    );
  }),
);

function evaluatePx(
  size: RedoButtonSize,
  isIconOnly: boolean,
  hierarchy: RedoButtonHierarchy,
) {
  if (hierarchy === "link" || hierarchy === "link_underline") {
    return "none";
  }
  if (isIconOnly) {
    return iconOnlySizeToPaddingX[size];
  }
  return sizeToPaddingX[size];
}

const themeClass: Record<RedoButtonTheme, string> = {
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  ["normal"]: redoButtonThemeCss.themeNormal,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  ["destructive"]: redoButtonThemeCss.themeDestructive,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  ["success"]: redoButtonThemeCss.themeSuccess,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  ["action"]: redoButtonThemeCss.themeAction,
};

const hierarchyClass: Record<RedoButtonHierarchy, string> = {
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  ["primary"]: redoButtonThemeCss.hierarchyPrimary,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  ["secondary"]: redoButtonThemeCss.hierarchySecondary,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  ["tertiary"]: redoButtonThemeCss.hierarchyTertiary,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  ["link"]: redoButtonThemeCss.hierarchyLinkGray,
  // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
  ["link_underline"]: redoButtonThemeCss.hierarchyLinkUnderline,
};

const sizeToCssClass: Record<RedoButtonSize, string> = {
  ["xs"]: "xs",
  ["sm"]: "sm",
  ["md"]: "md",
  ["lg"]: "lg",
  ["xl"]: "xl",
  ["2xl"]: "xxl",
  ["3xl"]: "xxxl",
};

const sizeToPaddingX: Record<RedoButtonSize, SpacingValue> = {
  ["xs"]: "md",
  ["sm"]: "lg",
  ["md"]: "lg",
  ["lg"]: "lg",
  ["xl"]: "xl",
  ["2xl"]: "2xl",
  ["3xl"]: "2xl",
};

const iconOnlySizeToPaddingX: Record<RedoButtonSize, SpacingValue> = {
  ["xs"]: "sm",
  ["sm"]: "sm",
  ["md"]: "md",
  ["lg"]: "md",
  ["xl"]: "lg",
  ["2xl"]: "2xl",
  ["3xl"]: "2xl",
};

const sizeToFontSize: Record<RedoButtonSize, TextSizeValue> = {
  ["xs"]: "xs",
  ["sm"]: "xs",
  ["md"]: "sm",
  ["lg"]: "sm",
  ["xl"]: "md",
  ["2xl"]: "md",
  ["3xl"]: "md",
};

const sizeToGap: Record<RedoButtonSize, TextSizeValue> = {
  ["xs"]: "xs",
  ["sm"]: "xs",
  ["md"]: "xs",
  ["lg"]: "xs",
  ["xl"]: "sm",
  ["2xl"]: "sm",
  ["3xl"]: "sm",
};
