import { memo, useMemo } from "react";
import { aliasArbiterUtilityClasses } from "./theme/merchant-css";

/** A merchant's custom CSS, where selectors for Arbiter's old utility names still match. */
export const MerchantStyle = memo(function MerchantStyle({
  css,
}: {
  css: string | null | undefined;
}) {
  const aliased = useMemo(
    () => (css ? aliasArbiterUtilityClasses(css) : ""),
    [css],
  );
  return aliased ? <style>{aliased}</style> : null;
});
