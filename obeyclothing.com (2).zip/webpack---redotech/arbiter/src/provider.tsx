import {
  type AnchorHTMLAttributes,
  type ComponentType,
  type ReactNode,
  type RefAttributes,
  useContext,
  useMemo,
} from "react";
import { ArbiterContext } from "./internal/arbiter-context";

export type To = string | { pathname?: string; search?: string; hash?: string };

export interface LinkProps extends Omit<
  AnchorHTMLAttributes<HTMLAnchorElement>,
  "href"
> {
  to: To;
  replace?: boolean;
  state?: unknown;
  reloadDocument?: boolean;
  relative?: "route" | "path";
  preventScrollReset?: boolean;
}

export type LinkComponent = ComponentType<
  LinkProps & RefAttributes<HTMLAnchorElement>
>;

export type Translate = (
  key: string,
  options?: Record<string, unknown>,
) => string;

/** Connects Arbiter to the host app. A nested provider inherits what it doesn't set. */
export function ArbiterProvider({
  children,
  linkComponent,
  locale,
  translate,
}: {
  children: ReactNode;
  /** Renders Arbiter's links, such as your router's Link. Without one they're plain anchors. */
  linkComponent?: LinkComponent;
  /** The locale for Arbiter's text and formatting. Defaults to the browser's. */
  locale?: string;
  /** Translates Arbiter's English source text. Without it Arbiter renders English. */
  translate?: Translate;
}) {
  const parent = useContext(ArbiterContext);
  const value = useMemo(
    () => ({
      linkComponent: linkComponent ?? parent.linkComponent,
      locale: locale ?? parent.locale,
      translate: translate ?? parent.translate,
    }),
    [linkComponent, locale, translate, parent],
  );
  return (
    <ArbiterContext.Provider value={value}>{children}</ArbiterContext.Provider>
  );
}
