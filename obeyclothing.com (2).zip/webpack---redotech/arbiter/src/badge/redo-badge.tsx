import classNames from "classnames";
import { JSXElementConstructor, memo, ReactNode } from "react";
import { RedoButton } from "../buttons/redo-button";
import { Flag, FlagSize } from "../flag/flag";
import { Flex } from "../flex";
import { IterableMap } from "../internal/component";
import { Text } from "../text";
import { SpacingValue } from "../theme/box";
import * as darkModeCss from "../theme/component-colors-dark.module.css";
import * as lightModeCss from "../theme/component-colors-light.module.css";
import { TextSizeValue } from "../theme/typography";
import { OptionalTooltip } from "../tooltip/optional-tooltip";
import { UserImage, UserImageSize } from "../user-image";
import * as badgeColorCss from "./redo-badge-colors.module.css";
import * as badgeCss from "./redo-badge.module.css";

export const redoBadgeSize = ["xs", "sm", "md", "lg"] as const;
export type RedoBadgeSize = (typeof redoBadgeSize)[number];

export const redoBadgeColor = [
  "gray",
  "inactive",
  "brand",
  "error",
  "warning",
  "success",
  "grayBlue",
  "blueLight",
  "blue",
  "indigo",
  "purple",
  "pink",
  "orange",
  "black",
  "white",
  "whiteSuccess",
] as const;
export type RedoBadgeColor = (typeof redoBadgeColor)[number];

export const redoBadgeType = ["primary", "alternate"] as const;
export type RedoBadgeType = (typeof redoBadgeType)[number];

const redoBadgeSwatchShape = ["pill", "circle"] as const;
type RedoBadgeSwatchShape = (typeof redoBadgeSwatchShape)[number];

type BadgeSegment = ColorSwatch | BadgeIcon;
export interface BadgeIcon {
  type: "icon";
  /** If not provided, the icon's size will match its badge. */
  size?: RedoBadgeSize;
  Icon: JSXElementConstructor<any>;
  onClick?: () => void;
  /** Optional tooltip text to display on hover */
  tooltip?: string;
  /** Accessible label for the icon button (icon-only buttons need a name). */
  ariaLabel?: string;
}
interface ColorSwatch {
  type: "color";
  color: string;
}

/**
 * @param type if you are doing something other than pill color, it needs to be fleshed out in the colors module.
 */
export interface RedoBadgeProps {
  "data-dd-action-name"?: string;
  segmentLeading?: BadgeSegment;
  iconTrailing?: BadgeSegment | BadgeSegment[];
  avatar?: { alt: string; name?: string; imageUrl: string | null } | undefined;
  flag?: { countryCode: string; alt?: string; size?: FlagSize } | undefined;
  text?: string | ReactNode;
  size?: RedoBadgeSize;
  type?: RedoBadgeType;
  color?: RedoBadgeColor;
  iconColor?: RedoBadgeColor;
  setRef?: (ref: HTMLElement | null) => void;
  shadow?: boolean;
  className?: string;
  textClassName?: string;
  dataTestId?: string;
  truncateAt?: number;
  uiSelector?: string;
  monospace?: boolean;
  darkMode?: boolean;
}

function truncateText(
  text: string | ReactNode,
  truncateAt?: number,
): string | ReactNode {
  if (typeof text !== "string" || !truncateAt) {
    return text;
  }
  if (text.length <= truncateAt) {
    return text;
  }
  return text.slice(0, truncateAt - 3) + "...";
}

export const RedoBadge = memo(function RedoBadge({
  iconTrailing,
  segmentLeading,
  avatar,
  flag,
  text,
  "data-dd-action-name": actionName,
  size = "sm",
  type = "primary",
  color = "gray",
  setRef,
  iconColor,
  shadow = false,
  className,
  textClassName,
  dataTestId,
  truncateAt,
  uiSelector,
  monospace,
  darkMode = false,
}: RedoBadgeProps) {
  const truncatedText = text ? truncateText(text, truncateAt) : text;
  const px = truncatedText ? regularPaddingX[size] : iconOnlyPaddingX[size];
  const py = truncatedText ? paddingY[size] : iconOnlyPaddingY[size];
  const textSize = fontSize[size];

  const variantClassnames = [
    badgeCss[size],
    badgeColorCss[type],
    badgeColorCss[color],
  ];

  function renderSegment(badge: BadgeSegment) {
    if (badge.type === "icon") {
      const iconWrapperClassNames = classNames(
        badgeColorCss.iconWrapper,
        badgeCss.iconWrapper,
        badgeCss[badge.size ?? size],
      );
      const wrappedIcon = badge.onClick ? (
        <RedoButton
          aria-label={badge.ariaLabel}
          buttonClassName={classNames(
            badgeCss.iconButton,
            iconColor && badgeColorCss[iconColor],
          )}
          data-dd-action-name={actionName}
          hierarchy="tertiary"
          IconLeading={badge.Icon}
          onClick={(event) => {
            badge.onClick?.();
            event.stopPropagation();
          }}
          size="xs"
          theme="normal"
        />
      ) : (
        <badge.Icon />
      );

      return (
        <OptionalTooltip
          meetsCondition={!!badge.tooltip}
          tooltipProps={{ title: badge.tooltip || "" }}
        >
          <Flex className={iconWrapperClassNames}>{wrappedIcon}</Flex>
        </OptionalTooltip>
      );
    } else if (badge.type === "color") {
      const colorSwatch = badge.color;
      return (
        <div
          className={badgeCss.colorSwatch}
          style={{ backgroundColor: colorSwatch }}
        />
      );
    } else {
      throw new Error("Invalid badge type");
    }
  }

  return (
    <Flex
      align="center"
      className={classNames(
        darkMode ? darkModeCss.darkMode : lightModeCss.lightMode,
        darkMode && badgeColorCss.darkMode,
        badgeCss.arbiterBadgeContainer,
        variantClassnames,
        className,
        shadow && badgeCss.shadow,
      )}
      data-arbiter="RedoBadge"
      data-testid={dataTestId}
      data-ui={uiSelector}
      gap={itemGap[size]}
      px={px}
      py={py}
    >
      {segmentLeading && renderSegment(segmentLeading)}
      {avatar && (
        <UserImage
          alt={avatar.alt}
          imageUrl={avatar.imageUrl}
          name={avatar.name}
          size={avatarSize[size]}
        />
      )}
      {flag && (
        <Flag
          alt={flag.alt}
          countryCode={flag.countryCode}
          size={flag.size ?? badgeFlagSize[size]}
        />
      )}
      {truncatedText && (
        <Text
          className={textClassName}
          fontFamily={monospace ? "monospace" : undefined}
          fontSize={textSize}
          fontWeight="medium"
          overflow="hidden"
          ref={setRef}
          textOverflow="ellipsis"
          whiteSpace="nowrap"
        >
          {truncatedText}
        </Text>
      )}
      {iconTrailing && (
        <IterableMap items={[iconTrailing].flat()}>{renderSegment}</IterableMap>
      )}
    </Flex>
  );
});

const fontSize: Record<RedoBadgeSize, TextSizeValue> = {
  xs: "xxs",
  sm: "xs",
  md: "sm",
  lg: "sm",
};

const iconOnlyPaddingY: Record<RedoBadgeSize, SpacingValue> = {
  xs: "xs",
  sm: "xs",
  md: "sm",
  lg: "md",
};

const paddingY: Record<RedoBadgeSize, SpacingValue> = {
  xs: "xxs",
  sm: "xxs",
  md: "xxs",
  lg: "xs",
};

const iconOnlyPaddingX: Record<RedoBadgeSize, SpacingValue> = {
  xs: "xs",
  sm: "xs",
  md: "sm",
  lg: "md",
};

const regularPaddingX: Record<RedoBadgeSize, SpacingValue> = {
  xs: "xs",
  sm: "md",
  md: "md",
  lg: "lg",
};

const itemGap: Record<RedoBadgeSize, SpacingValue> = {
  xs: "xxs",
  sm: "xs",
  md: "sm",
  lg: "sm",
};

const avatarSize: Record<RedoBadgeSize, UserImageSize> = {
  xs: UserImageSize.X_TINY,
  sm: UserImageSize.TINY,
  md: UserImageSize.TINY,
  lg: UserImageSize.TINY,
};

const badgeFlagSize: Record<RedoBadgeSize, FlagSize> = {
  xs: "xxs",
  sm: "xs",
  md: "sm",
  lg: "md",
};

/** Stand-in for a full RedoBadge, tinted with the same color tokens, for when
 * a row of badges must collapse but still convey each badge's color. */
export const RedoCompactBadgeSwatch = memo(function RedoCompactBadgeSwatch({
  color = "gray",
  type = "primary",
  shape = "pill",
}: {
  color?: RedoBadgeColor;
  type?: RedoBadgeType;
  shape?: RedoBadgeSwatchShape;
}) {
  return (
    <div
      className={classNames(
        lightModeCss.lightMode,
        badgeColorCss[type],
        badgeColorCss[color],
        badgeCss.compactSwatch,
        shape === "circle" && badgeCss.circle,
      )}
      data-arbiter="RedoCompactBadgeSwatch"
    />
  );
});
