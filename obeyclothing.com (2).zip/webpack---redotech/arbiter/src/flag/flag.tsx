import { memo, useState } from "react";
import { Flex } from "../flex";
import * as css from "./flag.module.css";

/** Flag SVGs published from redo/asset/src/web/icons/flags. */
const FLAG_URL = "https://assets.getredo.com/web/icons/flags/";

const FLAG_FILE_NAME = /^[a-z0-9_-]+$/;

const FLAG_SIZE_PX = { xxs: 8, xs: 12, sm: 16, md: 20, lg: 24 } as const;

export type FlagSize = keyof typeof FLAG_SIZE_PX;

/**
 * Circular country/region flag. Pass an ISO 3166-1 alpha-2 code (e.g. "US",
 * "GB") in any casing; unsupported codes render nothing so callers can drop it
 * in next to a country label without guarding.
 */
export const Flag = memo(function Flag({
  countryCode,
  alt,
  size = "md",
  uiSelector,
}: {
  countryCode: string;
  alt?: string;
  size?: FlagSize;
  uiSelector?: string;
}) {
  const code = countryCode.toLowerCase();
  const [missingCode, setMissingCode] = useState<string>();
  if (!FLAG_FILE_NAME.test(code) || code === missingCode) {
    return null;
  }
  const px = FLAG_SIZE_PX[size];
  const label = alt ?? countryCode.toUpperCase();
  return (
    <Flex
      align="center"
      borderRadius="full"
      className={css[size]}
      data-ui={uiSelector}
      justify="center"
      overflow="hidden"
      shrink={0}
    >
      <img
        alt={label}
        height={px}
        loading="lazy"
        onError={() => setMissingCode(code)}
        src={`${FLAG_URL}${code}.svg`}
        title={label}
        width={px}
      />
    </Flex>
  );
});
