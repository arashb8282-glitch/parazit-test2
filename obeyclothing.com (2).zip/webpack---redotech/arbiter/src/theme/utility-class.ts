/** Names a global utility class from theme/base.css. The arb- prefix keeps it
 * from colliding with a host's Tailwind or other global classes. */
export function utilityClass(name: string): string {
  return `arb-u-${name}`;
}
