import { StyleProps } from "../styles";
import { utilityClass } from "./utility-class";
export const shadowPropKeys = ["shadow"] as const;

export interface ShadowProps {
  shadow?: ShadowSize;
}

const shadowSize = ["md", "lg"] as const;

export type ShadowSize = (typeof shadowSize)[number];

export function shadowClasses(props: StyleProps): string[] {
  if (props.shadow) {
    return [utilityClass(`shadow-${props.shadow}`)];
  }
  return [];
}
