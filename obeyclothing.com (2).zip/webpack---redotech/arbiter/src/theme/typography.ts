import { camelToKebab } from "./box";
import { utilityClass } from "./utility-class";

const textSizeValues = [
  "xxs",
  "xs",
  "sm",
  "md",
  "lg",
  "xl",
  "2xl",
  "3xl",
  "4xl",
  "5xl",
  "6xl",
] as const;
export type TextSizeValue = (typeof textSizeValues)[number];

/** `Header` only has `.header-*` classes up to `2xl`; larger `TextSizeValue`
 *  steps produce an undefined class and render unstyled. */
const headerSizeValues = ["xxs", "xs", "sm", "md", "lg", "xl", "2xl"] as const;
export type HeaderSizeValue = (typeof headerSizeValues)[number];

export type TextWeightValue =
  | "thin"
  | "regular"
  | "medium"
  | "semibold"
  | "bold";
export type LineHeightValue = "1" | "1.5";
export type TextColorValue =
  | "primary"
  | "secondary"
  | "tertiary"
  | "disabled"
  | "placeholder"
  | "primary-on-brand"
  | "brand-primary"
  | "brand-secondary"
  | "brand-tertiary"
  | "error"
  | "warning"
  | "success"
  | "action-primary"
  | "inherit"
  | "white"
  | "tooltip-supporting-text"
  | "tooltip-calculation-text";

export type TextAlignValue = "left" | "center" | "right";

export interface TextProps {
  fontSize?: TextSizeValue;
  fontWeight?: TextWeightValue;
  fontFamily?: "text" | "header" | "monospace" | "serif" | "inherit";
  lineHeight?: LineHeightValue;
  fontStyle?: "normal" | "italic";
  textColor?: TextColorValue;
  hoverTextColor?: TextColorValue;
  isHeader?: boolean;
  textAlign?: TextAlignValue;
  textDecoration?: "none" | "underline" | "line-through";
}

export const textPropKeys: readonly (keyof TextProps)[] = [
  "fontSize",
  "fontWeight",
  "fontFamily",
  "lineHeight",
  "textColor",
  "hoverTextColor",
  "textAlign",
  "fontStyle",
  "textDecoration",
] as const;

export function textClasses(props: TextProps) {
  const isHeader = !!props.isHeader || props.fontFamily === "header";
  const onlyTextProps = Object.entries(props).filter(
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    ([key, value]) => textPropKeys.includes(key as keyof TextProps) && value,
  );
  return onlyTextProps.reduce((acc, [key, value]) => {
    if (key === "fontSize" && value) {
      const prefix = isHeader ? "header" : "text";
      acc.push(utilityClass(prefix + "-" + value));
    } else if (key === "fontWeight" && value) {
      acc.push(utilityClass("weight-" + value));
    } else if (key === "lineHeight" && value) {
      // `.line-height-1-5` in typography.css. A dotted "1.5" never matches it.
      acc.push(
        utilityClass("line-height-" + String(value).replaceAll(".", "-")),
      );
    } else {
      acc.push(utilityClass(camelToKebab(key) + "-" + value));
    }
    return acc;
  }, [] as string[]);
}
