/** At-rules whose block holds rules, so their selectors get aliased too. */
const RULE_LIST_AT_RULES = new Set([
  "container",
  "document",
  "layer",
  "media",
  "scope",
  "starting-style",
  "supports",
]);

const CLASS_SELECTOR = /\.(-?[_a-zA-Z][\w-]*(?:\\.[\w-]*)*)/g;
const ALREADY_ALIASED =
  /:is\(\.(-?[_a-zA-Z][\w-]*(?:\\.[\w-]*)*), \.arb-u-\1\)/g;

/**
 * Turns each class selector `.x` into `:is(.x, .arb-u-x)`: same matches and
 * specificity, plus Arbiter's prefixed class, for merchant CSS on old names.
 */
export function aliasArbiterUtilityClasses(css: string): string {
  return rewriteRules(css);
}

/** Walks a run of statements, aliasing rule selectors and nested rule lists. */
function rewriteRules(text: string): string {
  let out = "";
  let index = 0;
  while (index < text.length) {
    const end = statementEnd(text, index);
    if (end.block === null) {
      out += text.slice(index, end.at) + (end.terminator ?? "");
      index = end.at + (end.terminator ? 1 : 0);
      continue;
    }
    const { prelude, body, close } = end.block;
    const atRule = /^\s*(?:\/\*[\s\S]*?\*\/\s*)*@([\w-]+)/.exec(prelude);
    if (atRule) {
      const name = (atRule[1] ?? "").toLowerCase();
      const inner = RULE_LIST_AT_RULES.has(name) ? rewriteRules(body) : body;
      out += `${prelude}{${inner}}`;
    } else {
      out += `${aliasSelector(prelude)}{${rewriteDeclarations(body)}}`;
    }
    index = close + 1;
  }
  return out;
}

/** A declaration block, which may nest rules under CSS nesting. */
function rewriteDeclarations(text: string): string {
  return stripCommentsAndStrings(text).includes("{")
    ? rewriteRules(text)
    : text;
}

/** Where the statement at `start` ends: a top-level `;`, or after its block. */
function statementEnd(
  text: string,
  start: number,
): {
  at: number;
  terminator: string | null;
  block: { prelude: string; body: string; close: number } | null;
} {
  let index = start;
  while (index < text.length) {
    const skipped = skipCommentOrString(text, index);
    if (skipped !== index) {
      index = skipped;
      continue;
    }
    const char = text[index];
    if (char === ";") {
      return { at: index, terminator: ";", block: null };
    }
    if (char === "{") {
      const close = matchingBrace(text, index);
      return {
        at: close + 1,
        terminator: null,
        block: {
          prelude: text.slice(start, index),
          body: text.slice(index + 1, close),
          close,
        },
      };
    }
    if (char === "}") {
      return { at: index + 1, terminator: null, block: null };
    }
    index++;
  }
  return { at: text.length, terminator: null, block: null };
}

function matchingBrace(text: string, open: number): number {
  let depth = 0;
  let index = open;
  while (index < text.length) {
    const skipped = skipCommentOrString(text, index);
    if (skipped !== index) {
      index = skipped;
      continue;
    }
    if (text[index] === "{") {
      depth++;
    } else if (text[index] === "}") {
      depth--;
      if (depth === 0) {
        return index;
      }
    }
    index++;
  }
  return text.length - 1;
}

/** The index after a comment or string starting at `index`, or `index` itself. */
function skipCommentOrString(text: string, index: number): number {
  if (text.startsWith("/*", index)) {
    const end = text.indexOf("*/", index + 2);
    return end === -1 ? text.length : end + 2;
  }
  const quote = text[index];
  if (quote === '"' || quote === "'") {
    let cursor = index + 1;
    while (cursor < text.length && text[cursor] !== quote) {
      cursor += text[cursor] === "\\" ? 2 : 1;
    }
    return cursor + 1;
  }
  return index;
}

function stripCommentsAndStrings(text: string): string {
  let out = "";
  let index = 0;
  while (index < text.length) {
    const skipped = skipCommentOrString(text, index);
    if (skipped !== index) {
      index = skipped;
      continue;
    }
    out += text[index];
    index++;
  }
  return out;
}

/** Aliases class selectors, leaving comments, strings and attribute selectors alone. */
function aliasSelector(selector: string): string {
  let out = "";
  let plain = "";
  let index = 0;
  const flush = () => {
    out += aliasPlainSelector(plain);
    plain = "";
  };
  while (index < selector.length) {
    const skipped = skipCommentOrString(selector, index);
    if (skipped !== index) {
      flush();
      out += selector.slice(index, skipped);
      index = skipped;
      continue;
    }
    if (selector[index] === "[") {
      flush();
      let cursor = index + 1;
      while (cursor < selector.length && selector[cursor] !== "]") {
        const after = skipCommentOrString(selector, cursor);
        cursor = after === cursor ? cursor + 1 : after;
      }
      out += selector.slice(index, cursor + 1);
      index = cursor + 1;
      continue;
    }
    plain += selector[index];
    index++;
  }
  flush();
  return out;
}

function aliasPlainSelector(selector: string): string {
  const kept: string[] = [];
  const shielded = selector.replace(ALREADY_ALIASED, (match) => {
    kept.push(match);
    return `\u0000${kept.length - 1}\u0000`;
  });
  return shielded
    .replace(CLASS_SELECTOR, (match, name: string) =>
      name.startsWith("arb-") ? match : `:is(.${name}, .arb-u-${name})`,
    )
    .replace(/\u0000(\d+)\u0000/g, (_, i: string) => kept[Number(i)] ?? "");
}
