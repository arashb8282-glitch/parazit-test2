import classNames from "classnames";
import {
  CSSProperties,
  DetailedHTMLProps,
  ElementType,
  ForwardedRef,
  ReactNode,
  forwardRef,
  memo,
} from "react";
import { StyleProps, styleClasses } from "./styles";
import * as textCss from "./text.module.css";
import { HeaderSizeValue, TextAlignValue } from "./theme/typography";

type TextElement =
  | "p"
  | "span"
  | "div"
  | "code"
  | "label"
  | "h1"
  | "h2"
  | "h3"
  | "h4"
  | "h5"
  | "h6";

export interface TextProps extends StyleProps {
  textOverflow?: CSSProperties["textOverflow"];
  whiteSpace?: CSSProperties["whiteSpace"];
  textAlign?: TextAlignValue;
  fontFamily?: "inherit" | "text" | "monospace" | "serif";
}

/** Widen to ElementType so JSX does not require a ref matching every tag. */
function textAsElement(as: TextElement | undefined): ElementType {
  return as ?? "p";
}

export const Text = memo(
  forwardRef(function Text(
    props: TextProps & {
      children: ReactNode;
      as?: TextElement;
      /** Connects the input with this id when rendered as `as="label"`. */
      htmlFor?: string;
      "data-testid"?: string;
      "data-dd-action-name"?: string;
      "data-ui"?: string;
      "data-arbiter"?: string;
      /** Merchant CSS hook. camelCase on purpose: a bare `data-target` has
       *  never rendered, so selectors handed out for it are dormant. */
      dataTarget?: string;
    } & DetailedHTMLProps<
        React.HTMLAttributes<HTMLSpanElement>,
        HTMLSpanElement
      >,
    ref: ForwardedRef<HTMLDivElement>,
  ) {
    const As = textAsElement(props.as);
    return (
      // eslint-disable-next-line react-hooks/static-components -- tag name, not a new component type
      <As
        aria-level={props["aria-level"]}
        className={classNames(
          textCss.text,
          styleClasses({ ...props, fontFamily: props.fontFamily ?? "inherit" }),
          props.className,
        )}
        data-arbiter={props["data-arbiter"] ?? "Text"}
        data-dd-action-name={props["data-dd-action-name"]}
        data-target={props.dataTarget}
        data-testid={props["data-testid"]}
        data-ui={props["data-ui"]}
        htmlFor={props.htmlFor}
        id={props.id}
        onClick={props.onClick}
        // TODO(paul): move to style
        // I am too afraid to fix this now
        // overflow={props.overflow}
        ref={ref}
        role={props.role}
        style={{
          textOverflow: props.textOverflow,
          whiteSpace: props.whiteSpace,
          color: props.color,
          ...props.style,
        }}
      >
        {props.children}
      </As>
    );
  }),
);

type HeaderElement =
  | "h1"
  | "h2"
  | "h3"
  | "h4"
  | "h5"
  | "h6"
  | "div"
  | ElementType;

export const Header = memo(function Header(
  props: Omit<TextProps, "fontFamily" | "fontSize"> & {
    children: ReactNode;
    as?: HeaderElement;
    /** Header styling only exists up to `2xl`; larger sizes are unstyled. */
    fontSize?: HeaderSizeValue;
    fontFamily?: "inherit";
    "data-testid"?: string;
    "data-arbiter"?: string;
    dataTarget?: string;
  } & DetailedHTMLProps<
      React.HTMLAttributes<HTMLHeadingElement>,
      HTMLHeadingElement
    >,
) {
  const As: ElementType = props.as ?? "h1";
  return (
    <As
      className={classNames(
        textCss.text,
        styleClasses({
          ...props,
          fontFamily: props.fontFamily ?? "header",
          textColor: props.textColor ?? "primary",
          isHeader: true,
        }),
      )}
      data-arbiter={props["data-arbiter"] ?? "Header"}
      data-target={props.dataTarget}
      data-testid={props["data-testid"]}
      style={{
        textOverflow: props.textOverflow,
        overflow: props.overflow,
        ...props.style,
      }}
    >
      {props.children}
    </As>
  );
});
