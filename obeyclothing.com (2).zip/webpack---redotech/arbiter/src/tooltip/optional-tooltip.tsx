import { memo, useState } from "react";
import { Flex } from "../flex";
import { RedoTooltipProps, Tooltip } from "./tooltip";

interface OptionalTooltipProps {
  meetsCondition: boolean;
  children: React.ReactElement;
  tooltipProps: Omit<RedoTooltipProps, "children">;
  wrapperClass?: string;
  wrapperStyle?: React.CSSProperties;
  hideOnHover?: boolean;
  "data-arbiter"?: string;
}

// Stateful component that's only used when hideOnHover is true
const HoverControlledTooltip = memo(function HoverControlledTooltip({
  tooltipProps,
  wrapperClass,
  wrapperStyle,
  children,
  "data-arbiter": dataArbiter,
}: Omit<
  OptionalTooltipProps,
  "meetsCondition" | "hideOnHover"
>): React.ReactElement {
  const [tooltipOpen, setTooltipOpen] = useState(false);

  return (
    <Tooltip {...tooltipProps} open={tooltipOpen}>
      <Flex
        as="span"
        className={wrapperClass}
        data-arbiter={dataArbiter}
        onMouseEnter={() => setTooltipOpen(true)}
        onMouseLeave={() => setTooltipOpen(false)}
        style={wrapperStyle}
      >
        {children}
      </Flex>
    </Tooltip>
  );
});

export const OptionalTooltip = memo(function OptionalTooltip({
  meetsCondition,
  children,
  tooltipProps,
  wrapperClass,
  wrapperStyle,
  hideOnHover = false,
  "data-arbiter": dataArbiter = "OptionalTooltip",
}: OptionalTooltipProps): React.ReactElement {
  if (!meetsCondition) {
    return (
      <Flex
        as="span"
        className={wrapperClass}
        data-arbiter={dataArbiter}
        style={wrapperStyle}
      >
        {children}
      </Flex>
    );
  }

  if (hideOnHover) {
    return (
      <HoverControlledTooltip
        data-arbiter={dataArbiter}
        tooltipProps={tooltipProps}
        wrapperClass={wrapperClass}
        wrapperStyle={wrapperStyle}
      >
        {children}
      </HoverControlledTooltip>
    );
  }

  return (
    <Tooltip {...tooltipProps}>
      <Flex
        as="span"
        className={wrapperClass}
        data-arbiter={dataArbiter}
        style={wrapperStyle}
      >
        {children}
      </Flex>
    </Tooltip>
  );
});
