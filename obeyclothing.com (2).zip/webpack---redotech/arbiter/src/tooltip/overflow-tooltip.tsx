import { memo } from "react";
import { OverflowDirection, useOverflow } from "../internal/overflow";
import { OptionalTooltip } from "./optional-tooltip";
import { RedoTooltipProps } from "./tooltip";

interface OverflowTooltipProps {
  children: React.ReactElement;
  overflowRef: HTMLElement | null;
  tooltipProps: Omit<RedoTooltipProps, "children">;
  wrapperClass?: string;
  wrapperStyle?: React.CSSProperties;
  direction?: OverflowDirection;
  hideOnHover?: boolean;
}

export const OverflowTooltip = memo(function OverflowTooltip({
  overflowRef,
  children,
  tooltipProps,
  wrapperClass,
  wrapperStyle,
  direction = OverflowDirection.Horizontal,
  hideOnHover = false,
}: OverflowTooltipProps): React.ReactElement {
  const isOverflowing = useOverflow(overflowRef, direction);
  return (
    <OptionalTooltip
      data-arbiter="OverflowTooltip"
      hideOnHover={hideOnHover}
      meetsCondition={isOverflowing}
      tooltipProps={{
        // This only restates text already on screen, so it should never take
        // the pointer: hovering it must reach whatever it covers.
        disableInteractive: true,
        ...tooltipProps,
        PopperProps: {
          ...tooltipProps.PopperProps,
          sx: { pointerEvents: "none", ...tooltipProps.PopperProps?.sx },
        },
      }}
      wrapperClass={wrapperClass}
      wrapperStyle={wrapperStyle}
    >
      {children}
    </OptionalTooltip>
  );
});
