import MuiToolTip, {
  TooltipProps,
  tooltipClasses,
} from "@mui/material/Tooltip";
import { styled } from "@mui/material/styles";
import classNames from "classnames";
import { ReactNode } from "react";
import * as tooltipStyles from "./tooltip.module.css";
export interface RedoTooltipProps extends TooltipProps {
  leftAlign?: boolean;
  subtitle?: ReactNode;
  darkMode?: boolean;
  paddingOverride?: string | undefined;
}

export const Tooltip: React.FunctionComponent<RedoTooltipProps> = styled(
  function Tooltip({
    className,
    darkMode,
    leftAlign,
    subtitle,
    paddingOverride,
    ...props
  }: RedoTooltipProps) {
    if (!props.title && !subtitle) {
      return props.children;
    }
    return (
      <MuiToolTip
        {...props}
        classes={{ popper: classNames(tooltipStyles.popper, className) }}
        title={
          <div data-arbiter="Tooltip">
            <div>{props.title}</div>
            {subtitle && (
              <div className={tooltipStyles.subtitle}>{subtitle}</div>
            )}
          </div>
        }
      />
    );
  },
)(({ darkMode, paddingOverride, leftAlign }) => {
  if (darkMode) {
    return {
      [`& .${tooltipClasses.tooltip}`]: {
        backgroundColor: "#FFFFFF",
        color: "var(--redo-colors-text-text-primary)",
        fontSize: "var(--redo-font-size-xs) !important",
        fontFamily: "var(--redo-font-family-body)",
        padding: paddingOverride ?? "8px 12px",
        borderRadius: "var(--border-radius-lg)",
        lineHeight: "18px",
        textAlign: leftAlign ? "left" : "center",
        whiteSpace: "normal",
        wordBreak: "break-word",
        boxShadow:
          "0px 4px 6px -2px var(--redo-shadow-color-secondary), 0px 12px 16px -4px var(--redo-shadow-color-primary)",
      },
      [`& .${tooltipClasses.arrow}`]: {
        "&::before": { backgroundColor: "#FFFFFF" },
      },
    };
  } else {
    return {
      [`& .${tooltipClasses.tooltip}`]: {
        backgroundColor: "#0F0F0F",
        color: "#FFFFFF",
        fontSize: "var(--redo-font-size-xs) !important",
        fontFamily: "var(--redo-font-family-body)",
        padding: paddingOverride ?? "8px 12px",
        borderRadius: "var(--border-radius-lg)",
        lineHeight: "18px",
        textAlign: leftAlign ? "left" : "center",
        whiteSpace: "normal",
        wordBreak: "break-word",
        boxShadow:
          "0px 4px 6px -2px var(--redo-shadow-color-secondary), 0px 12px 16px -4px var(--redo-shadow-color-primary)",
      },
      [`& .${tooltipClasses.arrow}`]: {
        "&::before": { backgroundColor: "#0F0F0F" },
      },
    };
  }
});
