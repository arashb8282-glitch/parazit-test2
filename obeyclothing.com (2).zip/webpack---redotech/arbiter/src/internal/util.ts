export type Primitive = string | number | boolean | null | undefined;

export function assertNever(value: never, errorMessage?: string): never {
  throw new Error(errorMessage ?? `Unexpected value: ${value}`);
}

export function isDef<T>(value: T | undefined | null): value is T {
  return value != null;
}

export function filterTruthy<T>(
  items: readonly T[],
): Exclude<T, null | undefined | false | 0 | "">[] {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  return items.filter(Boolean) as Exclude<
    T,
    null | undefined | false | 0 | ""
  >[];
}
