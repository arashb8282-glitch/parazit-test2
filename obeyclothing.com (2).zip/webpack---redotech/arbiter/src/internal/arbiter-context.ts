import {
  createContext,
  createElement,
  type ReactNode,
  useCallback,
  useContext,
} from "react";
import type { LinkComponent, Translate } from "../provider";

interface ArbiterSettings {
  linkComponent?: LinkComponent;
  locale?: string;
  translate?: Translate;
}

export const ArbiterContext = createContext<ArbiterSettings>({});

export function useArbiterSettings(): ArbiterSettings {
  return useContext(ArbiterContext);
}

/** Carries Arbiter's settings into a separate React root, which can't read this context. */
export function useCarryArbiterSettings(): (node: ReactNode) => ReactNode {
  const settings = useArbiterSettings();
  return useCallback(
    (node: ReactNode) =>
      createElement(ArbiterContext.Provider, { value: settings }, node),
    [settings],
  );
}
