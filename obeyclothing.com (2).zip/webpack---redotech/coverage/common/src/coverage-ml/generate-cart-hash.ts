import { isRedoLineItem } from "@redotech/redo-return-coverage-common/is-redo-line-item";
import { stringHash } from "@redotech/util/string";

/**
 * Generates a deterministic hash from cart lines to use as cache key
 * Hash includes variant IDs and quantities to detect cart composition changes
 */
export function generateCartHash(
  cartLines: HashableCartItem[],
  redoCoverageProductIds?: ReadonlySet<string>,
): string {
  // Filter out Redo products to avoid cache invalidation when Redo products are added/removed
  const nonRedoLines = cartLines.filter(
    (line) =>
      !isRedoLineItem(
        { ...line, product_id: line.productId },
        redoCoverageProductIds,
      ),
  );

  // Sort lines for deterministic hash
  const sortedLines = nonRedoLines.sort((a, b) => {
    if (a.variantId === b.variantId) {
      return a.quantity - b.quantity;
    }
    return a.variantId.localeCompare(b.variantId);
  });

  // Create hash string from variant IDs and quantities
  const hashInput = sortedLines
    .map((line) => `${line.variantId}:${line.quantity}`)
    .join("|");

  return stringHash(hashInput || "empty").toString(36);
}

interface HashableCartItem {
  variantId: string;
  /** Numeric product id, for isCoverageFeeProduct id matching. Not hashed. */
  productId?: string;
  name: string | undefined;
  sku: string | undefined;
  vendor: string | undefined;
  quantity: number;
}
