import { bijectionCompose } from "@redotech/util/bijection";
import { StringFormat } from "@redotech/util/string-format";
import { Big } from "big.js";
import { JsonFormat } from "./format";
import { Json, jsonStringFormat } from "./json";

export type Serializable =
  | null
  | undefined
  | string
  | number
  | boolean
  | bigint
  | Big
  | Date
  | Temporal.Instant
  | Temporal.PlainDate
  | Temporal.PlainTime
  | Serializable[]
  | readonly Serializable[]
  | Map<Serializable, Serializable>
  | { [key: string]: Serializable }
  | {};

export interface ObjectSerializationModule<
  T extends string = string,
  V extends object = object,
> {
  prefix: T;
  constructor: new (...args: any[]) => V;
  hydrate: (value: { [K in T]: any }, globalHydrate: (value: any) => any) => V;
  dehydrate: (
    value: V,
    globalDehydrate: (value: V) => Json,
  ) => { [K in T]: any };
}

export function createSerializationModule<
  T extends string,
  V extends object = object,
>(
  prefix: T,
  constructor: new (...args: any[]) => V,
  hydrate: (value: { [K in T]: any }, globalHydrate: (value: any) => any) => V,
  dehydrate: (
    value: V,
    globalDehydrate: (value: V) => Json,
  ) => { [K in T]: any },
): ObjectSerializationModule<T, V> {
  return { prefix, constructor, hydrate, dehydrate };
}

const bigModule = createSerializationModule(
  "$$big",
  Big,
  (value) => {
    const bigSource = value.$$big;
    if (typeof bigSource !== "string" && typeof bigSource !== "number") {
      throw new TypeError(
        `Cannot hydrate value of type { $$big: ${typeof bigSource} }`,
      );
    }
    return new Big(bigSource);
  },
  (value) => ({ $$big: value.toString() }),
);

const dateModule = createSerializationModule(
  "$$date",
  Date,
  (value) => {
    const dateSource = value.$$date;
    if (typeof dateSource !== "string" && typeof dateSource !== "number") {
      throw new TypeError(
        `Cannot hydrate value of type { $$date: ${typeof dateSource} }`,
      );
    }
    return new Date(dateSource);
  },
  (value) => ({ $$date: value.toISOString() }),
);

/**
 * Resolve a Temporal constructor from the global scope without throwing when the
 * temporal-polyfill isn't installed. Some bundles (e.g. Shopify checkout
 * extensions) import this serializer but never serialize Temporal values and so
 * don't ship the polyfill; referencing the bare `Temporal` global at module load
 * would throw a ReferenceError there. Reading it off `globalThis` is safe, and
 * the sentinel makes `instanceof` match nothing when Temporal is absent. When the
 * polyfill is present (server, web, etc.) this returns the real constructor, so
 * serialization behavior is unchanged.
 */
const TEMPORAL_ABSENT_SENTINEL = class {};
function temporalConstructor(
  name: "PlainDate",
): new (...args: any[]) => Temporal.PlainDate;
function temporalConstructor(
  name: "PlainTime",
): new (...args: any[]) => Temporal.PlainTime;
function temporalConstructor(
  name: "Instant",
): new (...args: any[]) => Temporal.Instant;
function temporalConstructor(
  name: "PlainDate" | "PlainTime" | "Instant",
): new (...args: any[]) => object {
  const temporal = (
    globalThis as {
      Temporal?: Record<typeof name, new (...args: any[]) => object>;
    }
  ).Temporal;
  return temporal ? temporal[name] : TEMPORAL_ABSENT_SENTINEL;
}

const temporalPlainDateModule = createSerializationModule(
  "$$plaindate",
  temporalConstructor("PlainDate"),
  (value) => {
    const plainDate = value.$$plaindate;
    if (typeof plainDate !== "string") {
      throw new TypeError(
        `Cannot hydrate value of type { $$plaindate: ${typeof plainDate} }`,
      );
    }
    return Temporal.PlainDate.from(plainDate);
  },
  (value) => ({ $$plaindate: value.toString() }),
);

const temporalPlainTimeModule = createSerializationModule(
  "$$plaintime",
  temporalConstructor("PlainTime"),
  (value) => {
    const plainTime = value.$$plaintime;
    if (typeof plainTime !== "string") {
      throw new TypeError(
        `Cannot hydrate value of type { $$plaintime: ${typeof plainTime} }`,
      );
    }
    return Temporal.PlainTime.from(plainTime);
  },
  (value) => ({ $$plaintime: value.toString() }),
);

const temporalInstantModule = createSerializationModule(
  "$$instant",
  temporalConstructor("Instant"),
  (value) => {
    const instantSource = value.$$instant;
    if (typeof instantSource !== "number") {
      throw new TypeError(
        `Cannot hydrate value of type { $$instant: ${typeof instantSource} }`,
      );
    }
    return Temporal.Instant.fromEpochMilliseconds(instantSource);
  },
  (value) => ({ $$instant: value.epochMilliseconds }),
);

const mapModule = createSerializationModule(
  "$$map",
  Map,
  (value, globalHydrate) => {
    const mapSource = value.$$map;
    if (!Array.isArray(mapSource)) {
      throw new TypeError(
        `Cannot hydrate value of type { $$map: ${typeof mapSource} }`,
      );
    }
    if (
      mapSource.some(
        (element) => !Array.isArray(element) || element.length !== 2,
      )
    ) {
      throw new TypeError(
        `Cannot hydrate value of type { $$map: ${mapSource} }`,
      );
    }

    return new Map(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      (mapSource as [Json, Json][]).map(([key, val]) => [
        globalHydrate(key),
        globalHydrate(val),
      ]),
    );
  },
  (value, globalDehydrate) => {
    return {
      $$map: Array.from(value.entries()).map(([key, val]) => [
        globalDehydrate(key),
        globalDehydrate(val),
      ]),
    };
  },
);

export function generateJsonFormat<
  Modules extends ObjectSerializationModule<any, any>[],
>(...modules: Modules): JsonFormat<Serializable> {
  const allModules = [
    bigModule,
    dateModule,
    temporalInstantModule,
    temporalPlainDateModule,
    temporalPlainTimeModule,
    mapModule,
    ...modules,
  ];

  const prefixToModule = new Map<string, ObjectSerializationModule<any, any>>(
    allModules.map((m) => [m.prefix, m]),
  );

  function dehydrate(value: Serializable | object): Json {
    const visited = new Set<Serializable | object>();
    return (function dehydrateInternal(value: Serializable | object): Json {
      switch (typeof value) {
        case "bigint":
          return { $$bigint: value.toString() };
        case "boolean":
        case "number":
        case "string":
          return value;
        case "object": {
          if (!value) {
            return value;
          }
          if (visited.has(value)) {
            throw new Error(`Cycle detected in ${value.constructor.name}`);
          }
          visited.add(value);
          let result: Json;
          if (Array.isArray(value)) {
            result = value.map(dehydrateInternal);
          } else {
            const module =
              allModules.find((m) => value instanceof m.constructor) ??
              // Fallback: match by constructor name when instanceof fails across
              // module boundaries (e.g. temporal-polyfill 0.3 in some environments).
              allModules.find(
                (m) => value.constructor?.name === m.constructor.name,
              );
            if (module) {
              // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
              result = module.dehydrate(value as any, dehydrateInternal);
            } else {
              // Default object serialization
              result = Object.fromEntries(
                Object.entries(value)
                  .filter(
                    ([, value]) =>
                      typeof value !== "function" && typeof value !== "symbol",
                  )
                  .map(([key, val]) => [key, dehydrateInternal(val)]),
              );
            }
          }
          visited.delete(value);
          return result;
        }
        case "function":
        case "symbol":
        case "undefined":
          return { $$undefined: true };
        default:
          throw new TypeError(`Cannot dehydrate value of type ${typeof value}`);
      }
    })(value);
  }

  function hydrate(value: Json): Serializable | object {
    switch (typeof value) {
      case "undefined":
      case "function":
      case "symbol":
        throw new TypeError(`Cannot hydrate value of type ${typeof value}`);
      case "string":
      case "number":
      case "boolean":
      case "bigint":
        return value;
      case "object": {
        if (value === null) {
          return value;
        }
        if (Array.isArray(value)) {
          return value.map(hydrate);
        }
        // Try modules first for single-key objects
        if (Object.keys(value).length === 1) {
          // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
          const [key, val] = Object.entries(value)[0];
          if (key === "$$undefined") {
            return undefined;
          }
          if (key === "$$bigint" && typeof val === "string") {
            return BigInt(val);
          }
          const module = prefixToModule.get(key);
          if (module) {
            return module.hydrate(value, hydrate);
          }
        }
        // Default object hydration
        return Object.fromEntries(
          Object.entries(value).map(([key, val]) => [key, hydrate(val)]),
        );
      }
      default:
        return value;
    }
  }

  return { read: hydrate, write: dehydrate };
}

// Default format with built-in modules
export const serializeJsonFormat: JsonFormat<Serializable> =
  generateJsonFormat();

export const serializeFormat: StringFormat<Serializable> = bijectionCompose(
  jsonStringFormat,
  serializeJsonFormat,
);

export function stableStringifyJson(serializable: Serializable): string {
  if (
    typeof serializable === "object" &&
    serializable !== null &&
    !Array.isArray(serializable)
  ) {
    // sort keys to ensure stable serialization
    const keys = Object.keys(serializable).sort();
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    return `{${keys.map((key) => `${JSON.stringify(key)}:${stableStringifyJson(serializable[key as keyof typeof serializable])}`).join(",")}}`;
  } else {
    return JSON.stringify(serializeJsonFormat.write(serializable));
  }
}
