import {
  asyncIterableFilter,
  asyncIterableMap,
} from "@redotech/util/async-iterator";
import { booleanFilter } from "@redotech/util/filter";
import { stringStreamSplit } from "@redotech/util/string-stream";
import { Json } from "./json";

export function ndjsonParse(
  stream: AsyncIterable<string>,
): AsyncIterable<Json> {
  return asyncIterableMap(
    asyncIterableFilter(stringStreamSplit(stream, "\n"), booleanFilter),
    JSON.parse,
  );
}

// @ts-expect-error unused-export-debt
function ndjsonSerialize(stream: AsyncIterable<Json>): AsyncIterable<string> {
  return asyncIterableMap(stream, (json) => JSON.stringify(json) + "\n");
}
