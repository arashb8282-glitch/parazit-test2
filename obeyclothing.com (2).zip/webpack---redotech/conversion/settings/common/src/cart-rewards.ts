export enum CartRewardsType {
  SHIPPING = "SHIPPING",
}
