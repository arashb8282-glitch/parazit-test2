import * as z from "zod";

// The storefront elements that record HSA intent. Mirrors
// `HSA_INTENT_SOURCES` in `redo/storefront/common/src/cart-attributes.ts`
// (the storefront extension's spec asserts the two lists match) and the
// `hsa_intent_source` CRDB enum.
export const HSA_INTENT_ANALYTICS_SOURCES = [
  "buy_button",
  "lmn_started",
  "lmn_completed",
  "pdp_widget",
  "cart_widget",
] as const;

// Bounds only guard the table against oversized values: the anonymous id is a
// UUID and a Shopify cart token is well under 256 characters.
export const logHsaIntentAnalyticsInput = z.object({
  source: z.enum(HSA_INTENT_ANALYTICS_SOURCES),
  exclusive: z.boolean(),
  anonymousId: z.string().min(1).max(128).optional(),
  cartToken: z.string().min(1).max(256).optional(),
});
export type LogHsaIntentAnalyticsInput = z.infer<
  typeof logHsaIntentAnalyticsInput
>;

export const logHsaIntentAnalyticsOutput = z.object({ success: z.boolean() });
