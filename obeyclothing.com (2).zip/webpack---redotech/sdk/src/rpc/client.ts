import type { ClientOptions, ModularRpcClient } from "@redotech/rpc/client";
import { createModularRpcClient } from "@redotech/rpc/client";
import { type RedoShopifyRpcDefinition } from "./definition";

export function createRedoShopifyRpcClient(
  options: ClientOptions<RedoShopifyRpcDefinition>,
): ModularRpcClient<RedoShopifyRpcDefinition> {
  return createModularRpcClient<RedoShopifyRpcDefinition>(options);
}

export type RedoShopifyRpcClient = ReturnType<
  typeof createRedoShopifyRpcClient
>;
