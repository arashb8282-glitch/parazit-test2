import type { ClientOptions, ModularRpcClient } from "@redotech/rpc/client";
import { createModularRpcClient } from "@redotech/rpc/client";
import { type RedoShopifyConversionRpcDefinition } from "./conversion-definition";

export function createRedoShopifyConversionRpcClient(
  options: ClientOptions<RedoShopifyConversionRpcDefinition>,
): ModularRpcClient<RedoShopifyConversionRpcDefinition> {
  return createModularRpcClient<RedoShopifyConversionRpcDefinition>(options);
}

export type RedoShopifyConversionRpcClient = ReturnType<
  typeof createRedoShopifyConversionRpcClient
>;
