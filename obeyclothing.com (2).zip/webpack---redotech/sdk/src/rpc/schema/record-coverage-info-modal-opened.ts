import { objectId } from "@redotech/rpc/ext";
import * as z from "zod";

export const recordCoverageInfoModalOpened = {
  name: "recordCoverageInfoModalOpened" as const,
  input: z.object({
    anonymousId: z.string(),
    treatmentId: objectId().optional(),
    eventId: z.string(),
    skipTestMetric: z.boolean().optional(),
  }),
  output: z.null(),
};
