import { CoverageWidgetRenderedPayloadSchema } from "@redotech/redo-customer-event-common/events/coverage-widget-rendered";
import * as z from "zod";

export const recordCoverageWidgetRendered = {
  name: "recordCoverageWidgetRendered" as const,
  input: CoverageWidgetRenderedPayloadSchema,
  output: z.null(),
};
