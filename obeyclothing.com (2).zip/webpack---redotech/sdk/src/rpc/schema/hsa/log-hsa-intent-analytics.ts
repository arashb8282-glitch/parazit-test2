import {
  logHsaIntentAnalyticsInput,
  logHsaIntentAnalyticsOutput,
} from "@redotech/redo-conversion-hsa-common/rpc-schemas/log-hsa-intent-analytics";

// Storefront measurement hook for HSA intent signals: called once each time a
// storefront element (buy button, questionnaire, PDP badge, cart widget) asks
// for the HSA/FSA payment method to be floated at checkout for a cart. Best
// effort on both sides; the storefront never waits on it to write the cart.
export const logHsaIntentAnalytics = {
  name: "logHsaIntentAnalytics" as const,
  input: logHsaIntentAnalyticsInput,
  output: logHsaIntentAnalyticsOutput,
};
