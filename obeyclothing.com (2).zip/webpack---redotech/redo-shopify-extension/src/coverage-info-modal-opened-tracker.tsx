import type { RedoShopifyRpcClient } from "@redotech/shopify-sdk/rpc/client";
import { recordCoverageInfoModalOpened as recordCoverageInfoModalOpenedRpc } from "@redotech/shopify-sdk/rpc/schema/record-coverage-info-modal-opened";
import { memo } from "react";
import { RedoEmittedDomEvent } from "./dom-events";
import { useStorefrontCoverageEventForwarder } from "./use-storefront-coverage-event-forwarder";
import { type CoverageInfoModalOpenedPayload } from "./utils/coverage-info-modal-opened";

export const CoverageInfoModalOpenedTracker = memo(
  function CoverageInfoModalOpenedTracker() {
    useStorefrontCoverageEventForwarder<CoverageInfoModalOpenedPayload>({
      domEvent: RedoEmittedDomEvent.CoverageInfoModalOpened,
      send: sendCoverageInfoModalOpened,
      failureMessage: "Error sending coverage info modal opened event",
    });
    return null;
  },
);

function sendCoverageInfoModalOpened(
  rpcClient: RedoShopifyRpcClient,
  payload: CoverageInfoModalOpenedPayload,
) {
  return rpcClient(recordCoverageInfoModalOpenedRpc, payload);
}
