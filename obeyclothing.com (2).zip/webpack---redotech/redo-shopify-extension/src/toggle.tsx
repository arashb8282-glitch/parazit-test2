import { RedoBadge } from "@redotech/arbiter/badge/redo-badge";
import { MerchantStyle } from "@redotech/arbiter/merchant-style";
import { Money } from "@redotech/money";
import { moneyFormat } from "@redotech/money/util";
import { useHandler } from "@redotech/react-util/hook";
import { Lazy } from "@redotech/react-util/init";
import {
  Coverage,
  PaymentModel,
} from "@redotech/redo-return-coverage-common/coverage";
import {
  fullCoverage,
  getHtml,
  getReturnType,
  texts,
} from "@redotech/redo-storefront-common/checkbox";
import { ToggleFields } from "@redotech/redo-storefront-common/toggle-fields";
import htmlReactParser from "html-react-parser";
import type { CSSProperties } from "react";
import {
  ChangeEvent,
  MouseEvent,
  ReactNode,
  Suspense,
  lazy,
  memo,
  useId,
  useMemo,
  useRef,
  useState,
} from "react";
import * as checkbox from "./checkbox.module.css";
import {
  RedoEmittedDomEvent,
  useFireEventOnRender,
  useInfoModalOpenEvents,
} from "./dom-events";
import Info from "./info.svg";
import { ClassicWidgetTheme } from "./render-elements/classic-widget-theme";
import { getAccessibilityTranslation } from "./storefront-locale";
import * as toggle from "./toggle.module.css";
import { recordCoverageInfoModalOpened } from "./utils/coverage-info-modal-opened";

const RedoModal = lazy(async () => {
  const { RedoModal } = await import("./modal");
  return { default: RedoModal };
});

const SingleToggleLabel = ({
  children,
  color,
  fontSize,
  coverage,
  price,
  onInfoClick,
  showInfoIcon,
  toggleText,
  toggleTextAfterRedo,
  labelId,
  infoButtonCustomAttributes,
}: {
  children: ReactNode;
  color: string;
  fontSize?: number;
  coverage: Coverage;
  price?: string;
  onInfoClick: () => void;
  showInfoIcon?: boolean;
  toggleText?: string | null;
  toggleTextAfterRedo?: string | null;
  labelId: string;
  infoButtonCustomAttributes?: Record<string, string>;
}) => {
  const name =
    texts[
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      `${+coverage.exchange}${+coverage.refund}${+coverage.storeCredit}` as `${0 | 1}${0 | 1}${0 | 1}`
    ];

  // toggleText may come from the singleToggleFields.titleText instead of autocheck.checkboxText
  // which means it may contain the %price% placeholder we will need to replace
  const toggleTextContainedPricePlaceholder =
    !!toggleText && toggleText.includes("%price%");
  return (
    <span
      className={toggle.label}
      data-target="toggle-label"
      id={labelId}
      style={{
        color,
        fontSize: fontSize
          ? `${fontSize.toString()}px`
          : "var(--redo-font-size-xs)",
      }}
    >
      {toggleText ? (
        htmlReactParser(
          toggleTextContainedPricePlaceholder
            ? toggleText.replace(/%price%/g, price ?? "")
            : toggleText,
        )
      ) : (
        <>
          {children} {name !== fullCoverage && <> for {name} </>}
        </>
      )}
      {price && !toggleTextContainedPricePlaceholder && ` for ${price}`}{" "}
      {showInfoIcon && (
        <>
          <span className={toggle.modalTriggerSingle} data-target="toggle-info">
            {/* design-allow: storefront widget injected into merchant pages; native button required */}
            <button
              aria-haspopup="dialog"
              aria-label="More information about coverage"
              className={checkbox.info}
              data-target="toggle-info-button"
              onClick={onInfoClick}
              type="button"
              {...(infoButtonCustomAttributes ?? {})}
            >
              <Info aria-hidden className={checkbox.infoIcon} />
            </button>
          </span>{" "}
        </>
      )}
      {toggleTextAfterRedo}
    </span>
  );
};

export const TwoLineToggleLabel = ({
  children,
  color,
  fontSize,
  coverage,
  price,
  onInfoClick,
  showInfoIcon,
  toggleTitleText,
  toggleSubtitleText,
  titleFontWeight,
  badge,
  subtlePrice,
  labelId,
  descriptionId,
  infoButtonCustomAttributes,
}: {
  children: ReactNode;
  color: string;
  fontSize?: number;
  coverage: Coverage;
  price?: string;
  onInfoClick: () => void;
  showInfoIcon?: boolean;
  toggleTitleText: string;
  toggleSubtitleText: string;
  titleFontWeight?: number;
  badge?: string;
  subtlePrice?: boolean;
  labelId?: string;
  descriptionId?: string;
  infoButtonCustomAttributes?: Record<string, string>;
}) => {
  const name =
    texts[
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      `${+coverage.exchange}${+coverage.refund}${+coverage.storeCredit}` as `${0 | 1}${0 | 1}${0 | 1}`
    ];

  const titleTextContainedPricePlaceholder =
    !!toggleTitleText && toggleTitleText.includes("%price%");
  const accessibilityTranslation = getAccessibilityTranslation();

  return (
    <div className={toggle.doubleTextContainer}>
      {/* This logic is temporarily here for Lime Ricki's A/B test, it will be removed in the near future. */}
      {toggleTitleText !== "%%HIDEME%%" && (
        <span
          className={toggle.label}
          data-target="toggle-label"
          id={labelId}
          style={{
            color,
            fontSize: fontSize
              ? `${fontSize.toString()}px`
              : "var(--redo-font-size-xs)",
            fontWeight: titleFontWeight,
          }}
        >
          {toggleTitleText ? (
            htmlReactParser(
              titleTextContainedPricePlaceholder
                ? toggleTitleText.replace(/%price%/g, price ?? "")
                : toggleTitleText,
            )
          ) : (
            <>
              {children} {name !== fullCoverage && <>for {name} </>}
            </>
          )}
          {price && !titleTextContainedPricePlaceholder ? (
            subtlePrice ? (
              <span data-target="price-value">{` ${price}`}</span>
            ) : (
              ` for ${price}`
            )
          ) : null}
          {badge && (
            <div className={toggle.badge} data-target="badge-word-container">
              <RedoBadge color="blue" text={badge} />
            </div>
          )}
          {showInfoIcon && (
            <span
              className={toggle.modalTriggerDouble}
              data-target="toggle-info"
            >
              {/* design-allow: storefront widget injected into merchant pages; native button required */}
              <button
                aria-haspopup="dialog"
                aria-label={
                  accessibilityTranslation.moreInformationAboutCoverage
                }
                className={checkbox.info}
                data-target="toggle-info-button"
                onClick={onInfoClick}
                type="button"
                {...infoButtonCustomAttributes}
              >
                <Info aria-hidden className={checkbox.infoIcon} />
              </button>
            </span>
          )}
        </span>
      )}
      <br />
      <span
        className={toggle.subtext}
        data-target="toggle-subtext"
        id={descriptionId}
        style={{ color }}
      >
        {htmlReactParser(toggleSubtitleText)}
      </span>
    </div>
  );
};

const Toggle = memo(function Toggle({
  color,
  value,
  onValue,
  toggleOnColor,
  toggleOffColor,
  toggleCircleColor,
  describedBy,
  labelledBy,
}: {
  color: string;
  value: boolean;
  onValue?: (value: boolean) => void;
  toggleOnColor?: string;
  toggleOffColor?: string;
  toggleCircleColor?: string;
  describedBy?: string;
  labelledBy?: string;
}) {
  const onChange = useMemo(
    () => (e: ChangeEvent) => {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      const isPreviewMode = (globalThis as any).redoMode === "preview";
      if (isPreviewMode) {
        alert("Clicked!");
      }
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      onValue?.((e.target as HTMLInputElement).checked);
    },
    [onValue],
  );

  const memoizedComponent = useMemo(
    () => (
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      <div style={{ "--redo-color": color } as CSSProperties}>
        <label
          className={toggle.toggleContainer}
          data-target="toggle-container"
        >
          {/* design-allow: storefront widget injected into merchant pages; native checkbox required */}
          <input
            aria-describedby={describedBy}
            aria-label={labelledBy ? undefined : "Coverage"}
            aria-labelledby={labelledBy}
            checked={value}
            className={toggle.checkbox}
            data-target="toggle-input"
            onChange={onChange}
            type="checkbox"
          />
          <div
            className={toggle.switch0}
            data-target="toggle-switch"
            style={{ backgroundColor: value ? toggleOnColor : toggleOffColor }}
          >
            <div
              className={toggle.circle}
              data-target="toggle-circle"
              style={{
                backgroundColor: toggleCircleColor,
                left: value ? "18px" : "2px",
              }}
            />
          </div>
        </label>
      </div>
    ),
    [
      color,
      describedBy,
      labelledBy,
      value,
      onChange,
      toggleOnColor,
      toggleOffColor,
      toggleCircleColor,
    ],
  );

  return memoizedComponent;
});

export const ToggleImage = memo(function ToggleImage({
  img_url,
}: {
  img_url: string;
}) {
  return (
    <img
      className={toggle.imageContainer}
      data-target="deluxe-toggle-image"
      src={img_url}
    />
  );
});

export const RedoToggle = ({
  theme,
  coverage,
  toggleText,
  toggleFields,
  value,
  onChange,
  paymentModel,
  price,
  isDeluxe,
  packageProtectionPlusEnabled,
  packageProtectionEnabled,
  returnsCoverageEnabled,
  finalSaleReturnsCoverageEnabled,
}: {
  theme: ClassicWidgetTheme;
  coverage: Coverage;
  toggleText?: string | null;
  toggleFields: ToggleFields;
  value: boolean;
  onChange?(value: boolean): void;
  paymentModel: PaymentModel;
  price: Money | undefined;
  isDeluxe: boolean;
  packageProtectionPlusEnabled?: boolean;
  packageProtectionEnabled?: boolean;
  returnsCoverageEnabled: boolean;
  finalSaleReturnsCoverageEnabled: boolean;
}) => {
  useFireEventOnRender(RedoEmittedDomEvent.ToggleRendered);
  const [modalOpen, setModalOpen] = useState(false);
  const controlId = useId();
  const labelId = `${controlId}-label`;
  const descriptionId = `${controlId}-description`;
  useInfoModalOpenEvents(setModalOpen);
  const {
    color,
    customCss,
    fontSize,
    html,
    modalVersion,
    showInfoIcon,
    toggleOffColor,
    toggleOnColor,
    toggleCircleColor,
    toggleTextAfterRedo,
    modalCustomizationsV2,
    returnPolicyUrl,
  } = theme;

  // const handleAdd = useHandler(() => {
  //   onChange && onChange(true);
  // }); // TODO(paul): would be nice to add to cart

  const infoButtonRef = useRef<HTMLElement | null>(null);
  const onInfoClick = useHandler((e?: MouseEvent<HTMLElement>) => {
    infoButtonRef.current = e?.currentTarget ?? null;
    setModalOpen(true);
    recordCoverageInfoModalOpened();
  });

  const onModalClose = useHandler(() => setModalOpen(false));
  const toggleSubtitleText = value
    ? toggleFields.positiveSubtext
    : toggleFields.negativeSubtext;
  const titleHidden = isDeluxe && toggleFields.titleText === "%%HIDEME%%";

  const label = isDeluxe ? (
    <TwoLineToggleLabel
      color={color}
      coverage={coverage}
      descriptionId={descriptionId}
      fontSize={fontSize}
      labelId={labelId}
      onInfoClick={onInfoClick}
      price={
        paymentModel === "customer_paid" && price
          ? moneyFormat(price)
          : undefined
      }
      showInfoIcon={showInfoIcon}
      toggleSubtitleText={toggleSubtitleText}
      toggleTitleText={toggleFields.titleText}
    >
      {html ? (
        htmlReactParser(getHtml(html, getReturnType(coverage)) ?? "")
      ) : (
        <strong>Free Unlimited Returns</strong>
      )}
    </TwoLineToggleLabel>
  ) : (
    <SingleToggleLabel
      color={color}
      coverage={coverage}
      fontSize={fontSize}
      labelId={labelId}
      onInfoClick={onInfoClick}
      price={
        paymentModel === "customer_paid" && price
          ? moneyFormat(price)
          : undefined
      }
      showInfoIcon={showInfoIcon}
      toggleText={toggleText}
      toggleTextAfterRedo={toggleTextAfterRedo}
    >
      {html ? (
        htmlReactParser(getHtml(html, getReturnType(coverage)) ?? "")
      ) : (
        <strong>Free Unlimited Returns</strong>
      )}
    </SingleToggleLabel>
  );

  let checkbox_: ReactNode;
  switch (paymentModel) {
    case PaymentModel.CUSTOMER_PAID:
      checkbox_ = (
        <Toggle
          color={color}
          describedBy={isDeluxe && !titleHidden ? descriptionId : undefined}
          labelledBy={
            titleHidden
              ? toggleSubtitleText
                ? descriptionId
                : undefined
              : labelId
          }
          onValue={onChange}
          toggleCircleColor={toggleCircleColor}
          toggleOffColor={toggleOffColor}
          toggleOnColor={toggleOnColor}
          value={value}
        />
      );
      break;
    case PaymentModel.MERCHANT_PAID:
      checkbox_ = <span />;
      break;
  }

  return (
    <>
      <MerchantStyle css={customCss} />
      <div
        className={toggle.container}
        data-target="toggle-root"
        style={{ color }}
      >
        {label}
        {checkbox_}
      </div>
      <Suspense>
        <Lazy init={modalOpen}>
          <RedoModal
            enableTopLayerModalApi={
              modalCustomizationsV2?.enableTopLayerModalApi
            }
            finalSaleReturnsCoverageEnabled={finalSaleReturnsCoverageEnabled}
            modalCustomizationsV2={modalCustomizationsV2}
            onClose={onModalClose}
            open={modalOpen}
            packageProtectionEnabled={packageProtectionEnabled}
            packageProtectionPlusEnabled={packageProtectionPlusEnabled}
            returnFocusRef={infoButtonRef}
            returnPolicyUrl={returnPolicyUrl}
            returnsCoverage={coverage}
            returnsCoverageEnabled={returnsCoverageEnabled}
            version={modalVersion}
          />
        </Lazy>
      </Suspense>
    </>
  );
};

export const DeluxeToggleArray = ({
  theme,
  children,
}: {
  theme: ClassicWidgetTheme;
  children: ReactNode;
}) => {
  useFireEventOnRender(RedoEmittedDomEvent.DeluxeToggleArrayRendered);
  return (
    <div className={toggle.deluxeContainerAll} data-target="deluxe-toggle-root">
      <ToggleImage img_url={theme.image_url} />
      <div
        className={toggle.deluxeContainerTextToggle}
        data-target="deluxe-toggle-container"
      >
        {children}
      </div>
    </div>
  );
};
