import { MerchantStyle } from "@redotech/arbiter/merchant-style";
import { Text } from "@redotech/arbiter/text";
import { useHandler } from "@redotech/react-util/hook";
import { generateCheckoutButtonCssFromStyle } from "@redotech/redo-storefront-web/attachment/checkout-button-styles";
import {
  CoverageButtonStyles,
  TitleSubtitle,
} from "@redotech/redo-storefront-widget-common/widget";
import { Button, ButtonTheme } from "@redotech/redo-web/button";
import { abortTimeout, awaitAbortable } from "@redotech/util/abort";
import classNames from "classnames";
import htmlReactParser from "html-react-parser";
import { memo, useId, useState } from "react";
import * as cbCss from "./checkout-buttons.module.css";
import { RedoEmittedDomEvent, useFireEventOnRender } from "./dom-events";

// Aria-label needs plain text, so strip tags and decode entities.
function stripHtml(html: string): string {
  return (
    new DOMParser().parseFromString(html, "text/html").body.textContent || ""
  );
}

const CoverageButton = memo(function CoverageButton({
  coveragePending,
  nonCoveragePending,
  onClick,
  subtitleText,
  titleText,
}: {
  coveragePending: boolean;
  nonCoveragePending: boolean;
  onClick(event: React.MouseEvent | React.TouchEvent): void;
  subtitleText: string;
  titleText: string;
}) {
  const descriptionId = useId();
  return (
    <Button
      aria-describedby={subtitleText ? descriptionId : undefined}
      aria-disabled={coveragePending || nonCoveragePending}
      aria-label={stripHtml(titleText || "Checkout with coverage")}
      bgColor={undefined}
      className={classNames(cbCss.coverageButtonContainer, cbCss.blue)}
      dataTarget="coverage-button"
      disabled={nonCoveragePending}
      onClick={onClick}
      onPointerUp={onClick}
      pending={coveragePending}
      theme={ButtonTheme.PRIMARY}
      w="full"
    >
      <>
        <div data-target="headline-text-container">
          <Text fontWeight="bold" w="full">
            {htmlReactParser(titleText)}
          </Text>
        </div>
        <div data-target="subtitle-text-container" id={descriptionId}>
          <Text data-target="subtitle-text" w="full">
            {htmlReactParser(subtitleText)}
          </Text>
        </div>
      </>
    </Button>
  );
});

const NonCoverageButton = memo(function NonCoverageButton({
  coveragePending,
  nonCoveragePending,
  onClick,
  text,
}: {
  coveragePending: boolean;
  nonCoveragePending: boolean;
  onClick(event: React.MouseEvent | React.TouchEvent): void;
  text: string;
}) {
  return (
    <button
      aria-disabled={coveragePending || nonCoveragePending}
      aria-label={stripHtml(text || "Checkout without coverage")}
      className={classNames(
        cbCss.textWrap,
        cbCss.linkButton,
        nonCoveragePending && cbCss.pending,
        coveragePending && cbCss.disabled,
      )}
      data-target="non-coverage-button"
      onClick={onClick}
      onPointerUp={onClick}
      type="button"
    >
      <Text
        className={classNames(
          cbCss.textWrap,
          coveragePending && cbCss.disabled,
          nonCoveragePending && cbCss.pending,
        )}
      >
        {text}
        {nonCoveragePending ? (
          <Button className={classNames(cbCss.loader)} pending />
        ) : null}
      </Text>
    </button>
  );
});

export const CheckoutButtons = ({
  onCoverageCheckoutClick,
  onClickNoCoverage,
  customCss,
  coverageButtonText,
  coverageButtonStyles,
  nonCoverageButtonText,
  dataTarget,
  defaultCoverageButtonTexts,
  defaultNonCoverageButtonText,
  optOutButtonFirst,
}: {
  onCoverageCheckoutClick: (
    event: React.MouseEvent | React.TouchEvent,
  ) => Promise<void>;
  onClickNoCoverage: (
    event: React.MouseEvent | React.TouchEvent,
  ) => Promise<void>;
  customCss?: string;
  coverageButtonText?: TitleSubtitle;
  nonCoverageButtonText?: string;
  coverageButtonStyles?: CoverageButtonStyles;
  dataTarget?: string;
  defaultCoverageButtonTexts: TitleSubtitle;
  defaultNonCoverageButtonText: string;
  optOutButtonFirst?: boolean;
}) => {
  const generatedCssFromStyle =
    generateCheckoutButtonCssFromStyle(coverageButtonStyles);
  const [coveragePending, setCoveragePending] = useState(false);
  const [nonCoveragePending, setNonCoveragePending] = useState(false);
  useFireEventOnRender(RedoEmittedDomEvent.CheckoutButtonsRendered);

  /** To avoid the inevitable spammers trying to checkout faster by clicking over and over, between the time the promise resolves and the new tab opens (or errors) */
  const DELAY_TO_ALLOW_CLICKING_AGAIN = 2000;
  const TIMEOUT_FOR_CHECKOUTS = Temporal.Duration.from({ seconds: 8 });

  // Stable identities so the memoized buttons aren't invalidated every render.
  const handleCoverageCheckoutClick = useHandler(
    async (event: React.MouseEvent | React.TouchEvent) => {
      if (coveragePending || nonCoveragePending) {
        return;
      }
      setCoveragePending(true);
      await awaitAbortable(
        onCoverageCheckoutClick(event),
        abortTimeout(TIMEOUT_FOR_CHECKOUTS),
      )
        .catch((e) => {
          console.error(e);
        })
        .finally(() => {
          setTimeout(() => {
            setCoveragePending(false);
          }, DELAY_TO_ALLOW_CLICKING_AGAIN);
        });
    },
  );

  const handleNonCoverageClick = useHandler(
    async (event: React.MouseEvent | React.TouchEvent) => {
      /** The link doesn't have automatic rejection with a `disabled` attribute, so we need to check manually */
      if (coveragePending || nonCoveragePending) {
        return;
      }
      setNonCoveragePending(true);
      await awaitAbortable(
        onClickNoCoverage(event),
        abortTimeout(TIMEOUT_FOR_CHECKOUTS),
      )
        .catch((e) => {
          console.error(e);
        })
        .finally(() => {
          setTimeout(() => {
            setNonCoveragePending(false);
          }, DELAY_TO_ALLOW_CLICKING_AGAIN);
        });
    },
  );

  const titleText =
    coverageButtonText?.titleText || defaultCoverageButtonTexts.titleText || "";
  const subtitleText =
    coverageButtonText?.subtitleText ||
    defaultCoverageButtonTexts.subtitleText ||
    "";
  const optOutText = nonCoverageButtonText || defaultNonCoverageButtonText;

  return (
    <>
      {generatedCssFromStyle ? <style>{generatedCssFromStyle}</style> : null}
      <MerchantStyle css={customCss} />
      <div
        className={cbCss.fullContainer}
        data-target={dataTarget || "checkout-buttons-container"}
      >
        {optOutButtonFirst ? (
          <>
            <NonCoverageButton
              coveragePending={coveragePending}
              nonCoveragePending={nonCoveragePending}
              onClick={handleNonCoverageClick}
              text={optOutText}
            />
            <CoverageButton
              coveragePending={coveragePending}
              nonCoveragePending={nonCoveragePending}
              onClick={handleCoverageCheckoutClick}
              subtitleText={subtitleText}
              titleText={titleText}
            />
          </>
        ) : (
          <>
            <CoverageButton
              coveragePending={coveragePending}
              nonCoveragePending={nonCoveragePending}
              onClick={handleCoverageCheckoutClick}
              subtitleText={subtitleText}
              titleText={titleText}
            />
            <NonCoverageButton
              coveragePending={coveragePending}
              nonCoveragePending={nonCoveragePending}
              onClick={handleNonCoverageClick}
              text={optOutText}
            />
          </>
        )}
      </div>
    </>
  );
};
