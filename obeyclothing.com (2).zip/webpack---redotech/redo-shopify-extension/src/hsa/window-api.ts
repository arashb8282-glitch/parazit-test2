// Global imperative `window.RedoHsa` surface. The theme app block placeholder
// button calls `window.RedoHsa.open()` to open the questionnaire modal; custom
// Liquid / merchant buttons / Redo's own storefront JS call `goToHsaCheckout`
// or `buyProductNowWithHsa` to send a shopper to standard checkout with the
// HSA/FSA payment method prioritized (see
// `redo/shopify/app/hsa-payment-customization/` and
// REDO_HSA_PAYMENT_PRIORITY_ATTRIBUTE_KEY).
//
// All methods are registered from the HSA island (`initializer.tsx`): `open`
// via the driver's trigger, the checkout methods via `registerHsaCheckoutApi`.
// The coverage manager island (`manager.tsx`) contributes only coverage hooks
// (`setHsaCoverageContributions`); `registerRedoHsaApi` merges partials so
// independent registrations never clobber each other.

// All methods are optional: they're contributed incrementally by separate
// registrations, so at any single registration only some are present. Callers
// (and the Liquid theme block) guard with `window.RedoHsa?.method?.()`.
// Whether the checkout methods hide the other payment options comes from the
// `showOnlyHsaPaymentMethod` merchant setting (`autocheck.hsa`, default: only
// HSA shows); the per-call option is deprecated, honored while themes migrate.
export interface RedoHsaApi {
  open?: () => void;
  goToHsaCheckout?: (opts?: {
    /** @deprecated Use the `showOnlyHsaPaymentMethod` merchant setting. */
    preventHidingOtherPaymentOptions?: boolean;
  }) => Promise<void>;
  buyProductNowWithHsa?: (opts?: {
    variantId?: string;
    quantity?: number;
    /** @deprecated Use the `showOnlyHsaPaymentMethod` merchant setting. */
    preventHidingOtherPaymentOptions?: boolean;
  }) => Promise<void>;
}

declare global {
  interface Window {
    RedoHsa?: RedoHsaApi;
  }
}

// Mutate the existing object in place rather than replacing it, so that any
// merchant/storefront code that captured `window.RedoHsa` before the second
// island registered keeps seeing later-contributed methods (the two islands
// register independently and in unspecified order).
export function registerRedoHsaApi(partial: RedoHsaApi): void {
  if (!window.RedoHsa) {
    window.RedoHsa = {};
  }
  Object.assign(window.RedoHsa, partial);
}
