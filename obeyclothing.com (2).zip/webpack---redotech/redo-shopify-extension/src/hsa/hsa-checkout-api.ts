import { HsaAutocheck } from "@redotech/redo-conversion-core-common/conversion/hsa-autocheck";
import { GidType, toGid } from "@redotech/redo-shopify-common/gid-utils";
import { buildHsaIntentCartAttributes } from "@redotech/redo-storefront-common/cart-attributes";
import { StorefrontClient } from "../client/storefront";
import { log } from "../monitoring/log";
import {
  createCartAndCheckout,
  goToHsaStandardCheckout,
} from "../utils/checkout-buttons/on-click-logic";
import { reportHsaIntentSignal } from "./intent-analytics";
import {
  getClickAnchor,
  resolveHsaProductFormData,
} from "./resolve-product-form";
import { registerRedoHsaApi } from "./window-api";

/**
 * Coverage behavior the returns-coverage manager island contributes when it
 * mounts. Absent on HSA-only stores, so checkout proceeds coverage-free.
 */
export interface HsaCoverageContributions {
  /** Redo coverage variant (plain id) to attach for a buy-now of `variantId` x
   *  `quantity`, or null when coverage doesn't apply. */
  resolveBuyNowCoverageVariantId?: (
    variantId: string | number | undefined,
    quantity: number,
  ) => string | null;
  /** Take the existing cart to HSA checkout via the Checkout+ coverage reconcile
   *  path (opt-in state owned by the manager). `exclusive` hides non-HSA methods. */
  goToHsaExistingCartCheckout?: (exclusive: boolean) => Promise<void>;
}

let coverageContributions: HsaCoverageContributions = {};

export function setHsaCoverageContributions(
  contributions: HsaCoverageContributions,
): void {
  coverageContributions = contributions;
}

export function clearHsaCoverageContributions(): void {
  coverageContributions = {};
}

/**
 * Pure builder for the `createCartAndCheckout` params of an HSA buy-now — kept
 * client/navigation-free so it can be unit-tested directly.
 */
export function buildHsaBuyNowCheckoutParams({
  variantId,
  quantity,
  coverageVariantId,
  exclusive = false,
}: {
  variantId: string | number;
  quantity: number;
  coverageVariantId: string | null;
  exclusive?: boolean;
}): {
  productLines: { merchandiseId: string; quantity: number }[];
  coverageVariantId: string | null;
  extraAttributes: { key: string; value: string }[];
  destination: "hsa-standard";
} {
  return {
    productLines: [
      { merchandiseId: toGid(GidType.PRODUCT_VARIANT, variantId), quantity },
    ],
    coverageVariantId,
    extraAttributes: buildHsaIntentCartAttributes({
      source: "buy_button",
      exclusive,
    }),
    destination: "hsa-standard",
  };
}

/** Checkout primitives, injectable so the handlers are testable without a live
 *  `location` / navigation. */
export interface HsaCheckoutApiDeps {
  createCartAndCheckout: typeof createCartAndCheckout;
  goToHsaStandardCheckout: typeof goToHsaStandardCheckout;
}

/**
 * Builds the imperative HSA checkout handlers over a client. Split from
 * registration so the handler logic is unit-testable without `window`.
 */
export function createHsaCheckoutApi(
  client: StorefrontClient,
  hsa: HsaAutocheck,
  deps: HsaCheckoutApiDeps = { createCartAndCheckout, goToHsaStandardCheckout },
): {
  goToHsaCheckout: (opts?: {
    preventHidingOtherPaymentOptions?: boolean;
  }) => Promise<void>;
  buyProductNowWithHsa: (opts?: {
    variantId?: string;
    quantity?: number;
    preventHidingOtherPaymentOptions?: boolean;
  }) => Promise<void>;
} {
  /** The option is deprecated in favor of the `showOnlyHsaPaymentMethod` team
   * setting; honor and log it while theme call sites are migrated. */
  const resolveExclusive = (preventOption: boolean | undefined): boolean => {
    if (preventOption !== undefined) {
      log("hsa: deprecated preventHidingOtherPaymentOptions option passed", {
        value: preventOption,
      });
      return !preventOption;
    }
    return hsa.enabled && hsa.buyButtons.showOnlyHsaPaymentMethod;
  };

  const goToHsaCheckout = async (opts?: {
    preventHidingOtherPaymentOptions?: boolean;
  }): Promise<void> => {
    const exclusive = resolveExclusive(opts?.preventHidingOtherPaymentOptions);
    // Reported alongside the cart write rather than before it, so measurement
    // adds no latency to the checkout entry; the write's own round trips give
    // the report time to land before the page navigates.
    const report = reportHsaIntentSignal({ source: "buy_button", exclusive });
    const existingCartCheckout =
      coverageContributions.goToHsaExistingCartCheckout;
    if (existingCartCheckout) {
      await Promise.all([report, existingCartCheckout(exclusive)]);
      return;
    }
    await Promise.all([
      report,
      deps.goToHsaStandardCheckout(client, exclusive),
    ]);
  };

  const buyProductNowWithHsa = async (opts?: {
    variantId?: string;
    quantity?: number;
    preventHidingOtherPaymentOptions?: boolean;
  }): Promise<void> => {
    const formData = opts?.variantId
      ? undefined
      : resolveHsaProductFormData(getClickAnchor());
    const variantId = opts?.variantId ?? formData?.variantId;
    const quantity = opts?.quantity ?? formData?.quantity ?? 1;
    if (!variantId || String(variantId) === "0") {
      return;
    }
    // Public API: an external caller (or a malformed PDP quantity input) can
    // hand us a non-positive or non-integer quantity. Reject it up front.
    if (!Number.isSafeInteger(quantity) || quantity < 1) {
      log("hsa buy now: invalid quantity", { quantity });
      return;
    }
    const coveragePlainId =
      coverageContributions.resolveBuyNowCoverageVariantId?.(
        variantId,
        quantity,
      ) ?? null;
    const coverageVariantId = coveragePlainId
      ? toGid(GidType.PRODUCT_VARIANT, coveragePlainId)
      : null;
    const exclusive = resolveExclusive(opts?.preventHidingOtherPaymentOptions);
    await Promise.all([
      reportHsaIntentSignal({ source: "buy_button", exclusive }),
      deps.createCartAndCheckout({
        storefrontClient: client,
        ...buildHsaBuyNowCheckoutParams({
          variantId,
          quantity,
          coverageVariantId,
          exclusive,
        }),
      }),
    ]);
  };

  return { goToHsaCheckout, buyProductNowWithHsa };
}

/**
 * Registers the imperative HSA checkout API on `window.RedoHsa`, owned by the
 * HSA island so it works even when returns-coverage is disabled.
 */
export function registerHsaCheckoutApi(
  client: StorefrontClient,
  hsa: HsaAutocheck,
): void {
  registerRedoHsaApi(createHsaCheckoutApi(client, hsa));
}
