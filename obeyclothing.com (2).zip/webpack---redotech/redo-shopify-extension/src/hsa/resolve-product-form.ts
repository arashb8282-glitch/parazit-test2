import { log } from "../monitoring/log";

/** Matches theme product forms (`{{ routes.cart_add_url }}`), including
 * locale-prefixed actions like `/en/cart/add`. */
const CART_ADD_FORM_SELECTOR = 'form[action$="/cart/add"]';

export interface HsaProductFormData {
  variantId: string | undefined;
  quantity: number;
}

/** The element whose activation invoked the current call, when we are inside a
 * DOM event dispatch (merchant buttons call `window.RedoHsa` from onclick). */
export function getClickAnchor(): Element | null {
  const target = globalThis.event?.target;
  if (typeof Element === "undefined" || !(target instanceof Element)) {
    return null;
  }
  return target;
}

/** `form.elements` also resolves `form`-attribute-associated controls outside
 * the form element and radio groups (via `RadioNodeList.value`). */
function fieldValue(form: HTMLFormElement, name: string): string {
  const control = form.elements.namedItem(name);
  const value: unknown = control ? Reflect.get(control, "value") : undefined;
  return typeof value === "string" ? value : "";
}

/** Variant + quantity for a buy-now with no explicit `variantId`: the clicked
 * button's cart-add form, else the page's first cart-add form, else `?variant=`. */
export function resolveHsaProductFormData(
  anchor?: Element | null,
): HsaProductFormData {
  const form =
    anchor?.closest<HTMLFormElement>(CART_ADD_FORM_SELECTOR) ??
    document.querySelector<HTMLFormElement>(CART_ADD_FORM_SELECTOR);

  const urlVariant = new URLSearchParams(location.search).get("variant");

  if (!form) {
    log("hsa buy now: no cart-add form found", { urlVariant });
    return { variantId: urlVariant || undefined, quantity: 1 };
  }

  const variantId = fieldValue(form, "id") || urlVariant || undefined;
  const parsedQuantity = Number.parseInt(fieldValue(form, "quantity"), 10);
  const quantity =
    Number.isSafeInteger(parsedQuantity) && parsedQuantity >= 1
      ? parsedQuantity
      : 1;
  return { variantId, quantity };
}
