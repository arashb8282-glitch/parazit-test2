import { storefrontShopperIdentity } from "@redotech/redo-marketing-browser-sdk/storefront-identity";
import { HsaIntentSource } from "@redotech/redo-storefront-common/cart-attributes";
import type { RedoShopifyRpcClient } from "@redotech/shopify-sdk/rpc/client";
import { logHsaIntentAnalytics } from "@redotech/shopify-sdk/rpc/schema/hsa/log-hsa-intent-analytics";
import { datadogLog } from "../monitoring/monitor";

let rpcClient: RedoShopifyRpcClient | undefined;

/**
 * Registered once by the HSA initializer. Until then, and on storefronts where
 * the HSA island never mounts, signals are still written to the cart but not
 * reported.
 */
export function setHsaIntentAnalyticsClient(
  client: RedoShopifyRpcClient | undefined,
): void {
  rpcClient = client;
}

export interface HsaIntentReport {
  source: HsaIntentSource;
  exclusive: boolean;
  /** The cart the attributes were written to; absent for a buy-now. */
  cartToken?: string;
}

/**
 * Reports one intent signal for measurement. Best effort: never throws and
 * never blocks the cart write it describes. Callers that are about to navigate
 * may await it so the request is not cut off by the page unloading.
 */
export async function reportHsaIntentSignal(
  report: HsaIntentReport,
): Promise<void> {
  if (!rpcClient) {
    return;
  }
  try {
    await rpcClient(logHsaIntentAnalytics, {
      source: report.source,
      exclusive: report.exclusive,
      anonymousId: readAnonymousShopperId(),
      cartToken: report.cartToken,
    });
  } catch (error) {
    datadogLog("error", "hsa: failed to report intent signal", {
      source: report.source,
      error: error instanceof Error ? error.message : String(error),
    });
  }
}

function readAnonymousShopperId(): string | undefined {
  try {
    return storefrontShopperIdentity().getShopperId();
  } catch {
    return undefined;
  }
}
