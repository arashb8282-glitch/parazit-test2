import { isCoveragePausedAt } from "@redotech/redo-return-coverage-common/coverage-calculator";
import {
  getMatchingElementFromLists,
  getReturnsCoverageExclusions,
  getVariantMetafieldIdentifiers,
  itemValidForFinalSaleReturns,
  itemValidForProtection,
  itemValidForReturnsInfo,
} from "@redotech/redo-return-coverage-common/coverage-calculator/check-product";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import {
  getLocalStorageWithExpiry,
  setLocalStorageWithExpiry,
} from "@redotech/redo-web/utils/local-storage-wrapper";
import {
  Collection,
  ExtensionShopifyClient,
  getTags,
  ShopifyProduct,
} from "@redotech/shopify-client/ajax";
import {
  getCollections,
  ShopifyExtensionClient,
} from "../client/shopify-extension-client";
import { StorefrontClient } from "../client/storefront";
import { log } from "../monitoring/log";

const STASHED_PRODUCT_INFO_KEY = "redo-product-info";

const PRODUCT_ELIGIBILITY_KEY_PREFIXES = [
  "redo-return-valid-excl-props-",
  "redo-protection-valid-",
  "redo-final-sale-valid-",
];

function getStashedProductInfoKey(productId: string) {
  return `${STASHED_PRODUCT_INFO_KEY}-${productId}`;
}

function getConfiguredVariantMetafieldExclusions(
  autocheck: WidgetAutocheck,
): string[] {
  return [
    ...(autocheck.coverageExcludedVariantMetafields ?? []),
    ...(autocheck.packageProtection.coverageExcludedVariantMetafields ?? []),
  ];
}

export function clearProductEligibilityCache(): void {
  for (const storage of [
    typeof localStorage !== "undefined" ? localStorage : null,
  ]) {
    if (!storage) {
      continue;
    }
    const keysToRemove: string[] = [];
    for (let i = 0; i < storage.length; i++) {
      const key = storage.key(i);
      if (
        key &&
        PRODUCT_ELIGIBILITY_KEY_PREFIXES.some((prefix) =>
          key.startsWith(prefix),
        )
      ) {
        keysToRemove.push(key);
      }
    }
    for (const key of keysToRemove) {
      storage.removeItem(key);
    }
  }
}

interface VariantMetafield {
  key: string;
  namespace: string;
  value: string;
}

interface productInfo {
  tags: string[];
  collections: Collection[];
  product: ShopifyProduct | undefined;
  variantMetafields: VariantMetafield[];
}

interface cartItemSubset {
  product_id: string | number;
  variant_id: string | number;
  handle: string;
  properties?: Record<string, string> | null;
  discounted_price?: number;
  line_price?: number;
  original_price?: number;
  original_line_price?: number;
  quantity?: number;
}

export function cartItemProperties(item: {
  properties?: { [key: string]: string } | null;
}): string[] {
  return item.properties
    ? Object.keys(item.properties).reduce((acc, key) => {
        const value = item.properties?.[key];
        acc.push(key);
        if (value !== null && value !== "") {
          acc.push(`${key}: ${value}`);
        }
        return acc;
      }, [] as string[])
    : [];
}

export function cartItemUnitPrices(
  item: {
    discounted_price?: number;
    line_price?: number;
    original_price?: number;
    original_line_price?: number;
    quantity?: number;
  },
  onTapcart: boolean,
): { price: number; preDiscountPrice: number } {
  let price =
    item.discounted_price ||
    (item.line_price ? item.line_price / (item.quantity ?? 1) : 0);
  price = onTapcart ? price : price / 100;

  let preDiscountPrice =
    item.original_price ||
    (item.original_line_price
      ? item.original_line_price / (item.quantity ?? 1)
      : 0);
  preDiscountPrice = onTapcart ? preDiscountPrice : preDiscountPrice / 100;

  return { price, preDiscountPrice };
}

export async function getProductInfoFromSource({
  autocheck,
  cartItem,
  product,
  shopifyClient,
  redoClient,
  storefrontGraphQLClient,
  signal,
}: {
  autocheck: WidgetAutocheck;
  cartItem: cartItemSubset;
  product?: ShopifyProduct;
  shopifyClient: ExtensionShopifyClient;
  redoClient: ShopifyExtensionClient;
  storefrontGraphQLClient?: StorefrontClient;
  signal?: AbortSignal;
}): Promise<productInfo> {
  // TODO: We don't support tags & collections for Commerce Cloud yet
  if (globalThis.redoStorefront?.type === "commercecloud") {
    return {
      tags: [],
      collections: [],
      product: undefined,
      variantMetafields: [],
    };
  }

  // return cached product info if we have it
  const productInfo: productInfo | null = getLocalStorageWithExpiry(
    getStashedProductInfoKey(cartItem.product_id.toString()),
  );
  if (productInfo) {
    return {
      tags: productInfo.tags,
      collections: productInfo.collections,
      product: productInfo.product,
      variantMetafields: await getVariantMetafields({
        variantId: cartItem.variant_id.toString(),
        autocheck,
        client: storefrontGraphQLClient,
        signal,
      }),
    };
  }

  if (globalThis.redoStorefront?.type === "miva") {
    const mivaProductInfo: productInfo = {
      tags: [],
      collections: hasCollectionExclusions(autocheck)
        ? ((await shopifyClient.getCollections(
            String(cartItem.product_id),
            signal,
          )) ?? [])
        : [],
      product: undefined,
      variantMetafields: [],
    };
    setLocalStorageWithExpiry(
      getStashedProductInfoKey(cartItem.product_id.toString()),
      mivaProductInfo,
    );
    return mivaProductInfo;
  }

  const shopifyProduct =
    product ??
    (await safeGetShopifyProduct({ cartItem, client: shopifyClient, signal }));
  if (!shopifyProduct) {
    return {
      tags: [],
      collections: [],
      product: undefined,
      variantMetafields: [],
    };
  }

  const productTags = getTags(shopifyProduct);
  const productCollections = await getProductCollections({
    cartItem,
    shopifyProduct,
    shopifyClient,
    redoClient,
    signal,
    autocheck,
  });
  const variantMetafields = await getVariantMetafields({
    variantId: cartItem.variant_id.toString(),
    autocheck,
    client: storefrontGraphQLClient,
    signal,
  });

  setLocalStorageWithExpiry(
    getStashedProductInfoKey(cartItem.product_id.toString()),
    {
      tags: productTags,
      collections: productCollections,
      product: shopifyProduct,
      // Metafields are looked up per variant and not cached. The empty array
      // keeps bundles loaded before this change from crashing on this field;
      // those bundles apply no exclusions from it until they reload.
      variantMetafields: [],
    },
  );

  return {
    tags: productTags,
    collections: productCollections,
    product: shopifyProduct,
    variantMetafields,
  };
}

export async function safeGetShopifyProduct({
  cartItem,
  client,
  signal,
}: {
  cartItem: cartItemSubset;
  client: ExtensionShopifyClient;
  signal?: AbortSignal;
}) {
  try {
    return await client.productGet(cartItem.handle, signal);
  } catch (e) {
    // For BigCommerce, if a product is set to is_visible: false (e.g. a GWP product which the merchant
    // doesn't want to be shown, but is purchaseable), we will not be able to retrieve the product via
    // storefront API. However, that means invisible products will usually always be treated as eligible.
    // If we need to support tag-filtering for invisible products, we will need to create an endpoint on
    // our Embed API to retrieve the product tags.
    if (
      globalThis.redoStorefront?.type === "bigcommerce" ||
      globalThis.redoStorefront?.type === "custom-lightopia" ||
      // Miva has no storefront product API at all, so this always throws.
      globalThis.redoStorefront?.type === "miva"
    ) {
      log(
        `Error getting product tags for ${cartItem.handle} - product is possibly not visible. Assuming no tags.`,
        e,
        cartItem.handle,
      );
      return undefined;
    } else {
      throw e;
    }
  }
}

export async function getVariantMetafields({
  variantId,
  autocheck,
  client,
  signal,
}: {
  variantId: string;
  autocheck: WidgetAutocheck;
  client?: StorefrontClient;
  signal?: AbortSignal;
}): Promise<VariantMetafield[]> {
  const variantMetafieldIdentifiers = getVariantMetafieldIdentifiers(
    getConfiguredVariantMetafieldExclusions(autocheck),
  );
  if (!variantMetafieldIdentifiers.length) {
    return [];
  }
  if (!client) {
    return [];
  }
  try {
    // Both lists can name the same metafield; the query must not repeat an
    // identifier.
    const variantMetafieldsWithoutValue = Array.from(
      new Map(
        variantMetafieldIdentifiers.map((mf) => [
          `${mf.namespace}.${mf.key}`,
          { key: mf.key, namespace: mf.namespace },
        ]),
      ).values(),
    );
    return (
      (await client.getVariantMetafields(
        variantId,
        variantMetafieldsWithoutValue,
        signal,
      )) ?? []
    );
  } catch (e) {
    log(`Error getting variant metafields for ${variantId}`, e);
    return [];
  }
}

/** Whether any setting needs a product's collections at all. */
function hasCollectionExclusions(autocheck: WidgetAutocheck): boolean {
  return !!(
    autocheck.coverageExcludeCollections.length ||
    autocheck.finalSaleReturns.coverageValidCollections.length ||
    (autocheck.packageProtection.coverageExcludedCollections ?? []).length
  );
}

export async function getProductCollections({
  cartItem,
  shopifyProduct,
  shopifyClient,
  redoClient,
  signal,
  autocheck,
}: {
  cartItem: cartItemSubset;
  shopifyProduct: ShopifyProduct;
  shopifyClient: ExtensionShopifyClient;
  redoClient: ShopifyExtensionClient;
  signal?: AbortSignal;
  autocheck: WidgetAutocheck;
}) {
  if (hasCollectionExclusions(autocheck)) {
    if (globalThis.redoStorefront?.type === "bigcommerce") {
      return (
        (await shopifyClient.getCollections(shopifyProduct?.id?.toString())) ??
        []
      );
    } else {
      return (
        (await getCollections(redoClient, {
          signal,
          productId: String(cartItem.product_id),
        })) ?? []
      );
    }
  }

  return [];
}

export async function itemValidForReturnsFrontend({
  autocheck,
  item,
  redoShopifyExtensionClient,
  shopifyClient,
  signal,
  invalidReturnProductTags,
  invalidProtectionProductTags,
  shopifyProduct,
  onTapcart,
  storefrontGraphQLClient,
}: {
  autocheck: WidgetAutocheck;
  item: cartItemSubset;
  redoShopifyExtensionClient: ShopifyExtensionClient;
  shopifyClient: ExtensionShopifyClient;
  signal?: AbortSignal;
  invalidReturnProductTags: string[];
  invalidProtectionProductTags?: string[];
  shopifyProduct?: ShopifyProduct;
  onTapcart: boolean;
  storefrontGraphQLClient?: StorefrontClient;
}): Promise<{
  returnsValid: boolean;
  protectionValid: boolean;
  finalSaleReturnsValid: boolean;
}> {
  // The product page caches per-product validity in localStorage instead of
  // running the coverage calculator, so the pause window is checked ahead of
  // that cache rather than through the calculator like every other surface.
  if (isCoveragePausedAt(autocheck.coveragePausedDates)) {
    return {
      returnsValid: false,
      protectionValid: false,
      finalSaleReturnsValid: false,
    };
  }

  const returnStorageValue = await getLocalStorageWithExpiry(
    `redo-return-valid-excl-props-${item.product_id}`,
  );
  const protectionStorageValue = await getLocalStorageWithExpiry(
    `redo-protection-valid-${item.product_id}`,
  );
  const finalSaleStorageValue = await getLocalStorageWithExpiry(
    `redo-final-sale-valid-${item.product_id}`,
  );

  const properties = cartItemProperties(item);

  const hasValidReturnProductProperties = !getMatchingElementFromLists(
    properties,
    autocheck.coverageExcludeProperties,
  );

  if (
    returnStorageValue !== null &&
    protectionStorageValue !== null &&
    finalSaleStorageValue !== null
  ) {
    return {
      returnsValid:
        returnStorageValue === "true" && hasValidReturnProductProperties,
      protectionValid: protectionStorageValue === "true",
      finalSaleReturnsValid: finalSaleStorageValue === "true",
    };
  }

  const {
    tags: productTags,
    collections,
    variantMetafields,
  } = await getProductInfoFromSource({
    autocheck,
    cartItem: item,
    product: shopifyProduct,
    shopifyClient,
    redoClient: redoShopifyExtensionClient,
    signal,
    storefrontGraphQLClient,
  });

  const coverageExclusions = getReturnsCoverageExclusions({
    returnsCoverage: {
      coverageExcludeProperties: autocheck.coverageExcludeProperties,
      coverageExcludeCollections: autocheck.coverageExcludeCollections,
      invalidProductTags: invalidReturnProductTags,
    },
    finalSaleReturnsCoverage: {
      coverageEnabled: autocheck.finalSaleReturns.coverageEnabled,
      validProductTags: autocheck.finalSaleReturns.coverageValidTags,
      validCollectionTitles:
        autocheck.finalSaleReturns.coverageValidCollectionTitles ?? [],
    },
  });

  const hasValidReturnProductIgnoringProperties =
    itemValidForReturnsInfo({
      ...coverageExclusions,
      itemInfo: {
        properties: [], // We are going to cache this result in local storage, so don't take into account the properties since they change with each item added
        productTags,
        collections: collections.map((c) => c.title),
        variantMetafields,
      },
      invalidMetafields: getVariantMetafieldIdentifiers(
        autocheck.coverageExcludedVariantMetafields ?? [],
      ),
    }).isEligible && autocheck.coverageEnabled;

  const hasValidProtectionProduct =
    itemValidForProtection({
      invalidProductTags: invalidProtectionProductTags || [],
      invalidCollections:
        autocheck.packageProtection.coverageExcludedCollections ?? [],
      itemInfo: {
        properties,
        productTags,
        collections: collections.map((c) => c.title),
      },
    }).valid && autocheck.packageProtection.coverageEnabled;

  const { price, preDiscountPrice } = cartItemUnitPrices(item, onTapcart);
  const hasValidFinalSaleProduct =
    itemValidForFinalSaleReturns({
      validProductTags: autocheck.finalSaleReturns.coverageValidTags,
      validCollections: autocheck.finalSaleReturns.coverageValidCollections,
      itemInfo: {
        price,
        preDiscountPrice,
        productTags,
        collections: collections.map((c) => c.handle),
      },
      allEligible: autocheck.finalSaleReturns.allEligible || false,
      eligibleDiscountThreshold:
        autocheck.finalSaleReturns.eligibleDiscountThreshold ?? undefined,
    }) && autocheck.finalSaleReturns.coverageEnabled;

  setLocalStorageWithExpiry(
    `redo-return-valid-excl-props-${item.product_id}`,
    String(hasValidReturnProductIgnoringProperties),
  );

  setLocalStorageWithExpiry(
    `redo-protection-valid-${item.product_id}`,
    String(hasValidProtectionProduct),
  );

  setLocalStorageWithExpiry(
    `redo-final-sale-valid-${item.product_id}`,
    String(hasValidFinalSaleProduct),
  );

  return {
    returnsValid:
      hasValidReturnProductIgnoringProperties &&
      hasValidReturnProductProperties,
    protectionValid: hasValidProtectionProduct,
    finalSaleReturnsValid: hasValidFinalSaleProduct,
  };
}
