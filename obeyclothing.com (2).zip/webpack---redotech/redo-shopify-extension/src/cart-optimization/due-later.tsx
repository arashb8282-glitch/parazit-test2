import { moneyFormat } from "@redotech/money/util";
import { useRequiredContext } from "@redotech/react-util/context";
import { useEffect } from "react";
import {
  CartOptModificationsContext,
  useShouldRefreshCartModifications,
} from "./cart-opt-modifications";
import { CartOptimizationContext } from "./cart-optimization-context";
import * as styles from "./due-later.module.css";
import { CART_TOTAL_SELECTOR } from "./selectors";

const DueLater = () => {
  const { tryFirstTotal, dueTodayTotal, currency } = useRequiredContext(
    CartOptModificationsContext,
  );
  const cartOptimizationContext = useRequiredContext(CartOptimizationContext);
  const refreshCartModifications = useShouldRefreshCartModifications();

  useEffect(() => {
    const placementSelector =
      cartOptimizationContext.autocheck.cartOptimization?.cartTotals
        ?.placementSelector || CART_TOTAL_SELECTOR;
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    const targetElement = document.querySelector(
      placementSelector,
    ) as HTMLElement;

    const shouldShowCustomTotal = tryFirstTotal > 0 && !!targetElement;

    if (shouldShowCustomTotal && !targetElement.dataset.redoDisplayReset) {
      targetElement.dataset.redoDisplayReset = targetElement.style.display;
      targetElement.style.display = "none";
    } else if (targetElement) {
      targetElement.style.display =
        targetElement.dataset.redoDisplayReset || "";
      delete targetElement.dataset.redoDisplayReset;
    }

    return () => {
      if (targetElement && targetElement.dataset.redoDisplayReset) {
        targetElement.style.display = targetElement.dataset.redoDisplayReset;
        delete targetElement.dataset.redoDisplayReset;
      }
    };
  }, [
    tryFirstTotal,
    dueTodayTotal,
    refreshCartModifications,
    cartOptimizationContext.autocheck.cartOptimization?.cartTotals
      ?.placementSelector,
  ]);

  if (tryFirstTotal === 0) {
    return null;
  }

  return (
    <div
      className={styles.dueLaterContainer}
      data-target="cart-totals-container"
    >
      <div className={styles.dueNowText} data-target="due-now-text">
        <div data-target="due-now-text-label">Total Due Now:</div>
        <div data-target="due-now-text-money">
          {moneyFormat({ amount: dueTodayTotal, currency })}
        </div>
      </div>
      <div className={styles.dueLaterText} data-target="due-later-text">
        <div data-target="due-later-text-label">Due Later:</div>
        <div data-target="due-later-text-money">
          {moneyFormat({ amount: tryFirstTotal, currency })}
        </div>
      </div>
    </div>
  );
};

export default DueLater;
