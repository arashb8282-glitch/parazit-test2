import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import { ExtensionShopifyClient } from "@redotech/shopify-client/ajax";
import { createContext, ReactNode } from "react";

interface CartOptimizationContextType {
  autocheck: WidgetAutocheck;
  extensionShopifyClient: ExtensionShopifyClient;
}

export const CartOptimizationContext = createContext<
  CartOptimizationContextType | undefined
>(undefined);

interface CartOptimizationProviderProps {
  autocheck: WidgetAutocheck;
  extensionShopifyClient: ExtensionShopifyClient;
  children: ReactNode;
}

export function CartOptimizationProvider({
  autocheck,
  extensionShopifyClient,
  children,
}: CartOptimizationProviderProps) {
  const contextValue: CartOptimizationContextType = {
    autocheck,
    extensionShopifyClient,
  };

  return (
    <CartOptimizationContext.Provider value={contextValue}>
      {children}
    </CartOptimizationContext.Provider>
  );
}
