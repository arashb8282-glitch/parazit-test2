import { RedoArbiterI18nProvider } from "@redotech/arbiter-app/arbiter-i18n-provider";
import { StyleRoot } from "@redotech/react-util/style";
import { InsertionPosition } from "@redotech/redo-storefront-common/insertion-position";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import { createRoot } from "react-dom/client";
import { StorefrontClient } from "../client/storefront";
import { log } from "../monitoring/log";
import { RedoRoot } from "../root";
import STYLE_MANAGER from "../style-manager";
import { getPlacedCustomElement } from "../utils/element-placement";
import { CartOptModificationsContainer } from "./cart-opt-modification-container";
import CartOptModifications from "./cart-opt-modifications";
import { CartOptimizationProvider } from "./cart-optimization-context";

export function isCartOptimizationEnabled(autocheck: WidgetAutocheck) {
  const cartRewardsEnabled = autocheck.cartOptimization?.cartRewards?.enabled;
  const cartTotalsEnabled = autocheck.cartOptimization?.cartTotals?.enabled;

  return cartRewardsEnabled || cartTotalsEnabled;
}

function createCartOptimizationWidget(
  element: Element,
  autocheck: WidgetAutocheck,
  extensionShopifyClient: StorefrontClient,
) {
  // Shopify applies display: none to empty divs
  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  (element as HTMLElement).style.display = "unset";

  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  const cartOptimizationContainer = document.createElement(
    CartOptModificationsContainer.TAG,
  ) as CartOptModificationsContainer;
  element.append(cartOptimizationContainer);

  const root = createRoot(cartOptimizationContainer);

  const storeUrl =
    window.redoStorefront?.storeUrl ??
    window.Shopify?.shop ??
    window.Shopify?.Checkout?.apiHost;

  root.render(
    <RedoArbiterI18nProvider>
      <StyleRoot container={element} styleManager={STYLE_MANAGER}>
        <RedoRoot
          extensionShopifyClient={extensionShopifyClient}
          storeUrl={storeUrl}
        >
          <CartOptimizationProvider
            autocheck={autocheck}
            extensionShopifyClient={extensionShopifyClient}
          >
            <CartOptModifications />
          </CartOptimizationProvider>
        </RedoRoot>
      </StyleRoot>
    </RedoArbiterI18nProvider>,
  );

  log("Cart optimization widget created");
}

export function initialize(
  autocheck: WidgetAutocheck,
  extensionShopifyClient: StorefrontClient,
) {
  if (!isCartOptimizationEnabled(autocheck)) {
    log("Cart optimization not enabled, skipping initialization");
    return;
  }

  log("Initializing cart optimization");

  const cartOptimizationRootContainer = getPlacedCustomElement(
    CartOptModificationsContainer.TAG,
    document.body,
    InsertionPosition.APPEND,
  );

  if (!cartOptimizationRootContainer) {
    const hiddenElement = document.createElement("div");
    hiddenElement.style.display = "none";
    hiddenElement.className = "redo-cart-optimization";
    document.body.append(hiddenElement);

    createCartOptimizationWidget(
      hiddenElement,
      autocheck,
      extensionShopifyClient,
    );
  }
}
