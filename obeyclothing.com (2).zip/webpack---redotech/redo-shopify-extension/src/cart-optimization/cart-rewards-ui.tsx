import { Flex } from "@redotech/arbiter/flex";
import { memo } from "react";
import * as styles from "./cart-rewards-ui.module.css";

export interface CartRewardsUiProps {
  message: string;
  progressPercentage: number;
  hasReachedThreshold: boolean;
}

export const CartRewardsUi = memo(function CartRewardsUi({
  message,
  progressPercentage,
  hasReachedThreshold,
}: CartRewardsUiProps) {
  return (
    <Flex className={styles.container} dir="column" gap="sm">
      <div
        className={hasReachedThreshold ? styles.messageReached : styles.message}
      >
        {message}
      </div>

      <div className={styles.progressBar}>
        <div
          className={`${styles.progressFill} ${
            hasReachedThreshold
              ? styles.progressFillReached
              : styles.progressFillDefault
          }`}
          style={{ width: `${progressPercentage}%` }}
        />
      </div>
    </Flex>
  );
});
