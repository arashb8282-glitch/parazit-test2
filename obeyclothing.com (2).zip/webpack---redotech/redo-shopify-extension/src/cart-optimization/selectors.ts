// GIGI PIP
export const CART_TOTAL_SELECTOR =
  "cart-drawer > div:nth-child(2) .h-stack.gap-4.justify-between";

// Cart rewards progress bar selector - this is the selector to detect and replace
export const CART_REWARDS_TARGET_SELECTOR = ".upcart-rewards";
