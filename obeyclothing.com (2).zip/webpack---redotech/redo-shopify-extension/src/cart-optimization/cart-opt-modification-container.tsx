import { StyleShadowRoot } from "@redotech/react-util/style";
import { InsertionPosition } from "@redotech/redo-storefront-common/insertion-position";
import { nativeRandom, randomHexString } from "@redotech/util/random";
import { assertNever } from "@redotech/util/type";
import { ReactNode, useEffect, useState } from "react";
import STYLE_MANAGER from "../style-manager";
import { useShouldRefreshCartModifications } from "./cart-opt-modifications";

export class CartOptModificationsContainer extends HTMLElement {
  #deregisterStyles!: () => void;
  #root!: ShadowRoot;
  private _useShadowRoot = true;

  set useShadowRoot(value: boolean) {
    this._useShadowRoot = value;
  }

  get root() {
    return this.#root ?? this;
  }

  connectedCallback() {
    if (
      this._useShadowRoot /**
       * Only mount the shadow root if it doesn't already exist (we can't unmount programmatically, e.g. if this component was already rendered and then removed)
       * https://stackoverflow.com/questions/20090059/how-to-remove-a-shadow-root-from-an-html-element-adorned-with-a-shadow-dom-from
       */ &&
      !this.#root
    ) {
      const shadowRoot = this.attachShadow({ mode: "closed" });
      this.#root = shadowRoot;
      this.#deregisterStyles = STYLE_MANAGER.register(shadowRoot);
    }
  }

  disconnectedCallback() {
    this.dispatchEvent(new Event("disconnect"));
    if (this._useShadowRoot) {
      this.#deregisterStyles();
    }
  }

  static #registered = false;

  static register() {
    if (!this.#registered) {
      customElements.define(this.TAG, this);
      this.#registered = true;
    }
  }

  static readonly TAG = "redo-try-first-cart-modification";
}

export const CartOptModification = ({
  containerSelector,
  containerPlacement,
  children,
}: {
  containerSelector: string;
  containerPlacement: InsertionPosition;
  children: ReactNode;
}) => {
  const [containerRoot, setContainerRoot] = useState<ShadowRoot | null>(null);
  const refreshCartModifications = useShouldRefreshCartModifications();

  useEffect(() => {
    CartOptModificationsContainer.register();
  }, []);

  useEffect(() => {
    const selectorElement = document.querySelector(containerSelector);

    if (!selectorElement) {
      return;
    }

    const whatWouldBeTheParentOfOurCustomElement =
      getParentOfWhereWeWouldInsert(containerPlacement, selectorElement);
    const existingElement =
      whatWouldBeTheParentOfOurCustomElement?.querySelector(
        CartOptModificationsContainer.TAG,
      );
    if (existingElement) {
      return;
    }

    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    const cartModificationElement = document.createElement(
      CartOptModificationsContainer.TAG,
    ) as CartOptModificationsContainer;

    switch (containerPlacement) {
      case InsertionPosition.BEFORE:
        selectorElement.before(cartModificationElement);
        break;
      case InsertionPosition.AFTER:
        selectorElement.after(cartModificationElement);
        break;
      case InsertionPosition.PREPEND:
        selectorElement.prepend(cartModificationElement);
        break;
      case InsertionPosition.APPEND:
        selectorElement.append(cartModificationElement);
        break;
      default:
        console.warn(`Unknown insertion position: ${containerPlacement}`);
        assertNever(containerPlacement);
        return;
    }

    setContainerRoot(cartModificationElement.root);
  }, [containerPlacement, refreshCartModifications, containerSelector]);

  return containerRoot ? (
    <StyleShadowRoot
      key={`cart-modification-${randomHexString(nativeRandom, 8)}`}
      shadowRoot={containerRoot}
      styleManager={STYLE_MANAGER}
    >
      {children}
    </StyleShadowRoot>
  ) : null;
};

const getParentOfWhereWeWouldInsert = (
  containerPlacement: InsertionPosition,
  selectorElement: Element,
): Element | null => {
  if (
    containerPlacement === InsertionPosition.BEFORE ||
    containerPlacement === InsertionPosition.AFTER
  ) {
    return selectorElement.parentElement;
  } else if (
    containerPlacement === InsertionPosition.PREPEND ||
    containerPlacement === InsertionPosition.APPEND
  ) {
    return selectorElement;
  }
  assertNever(containerPlacement);
};
