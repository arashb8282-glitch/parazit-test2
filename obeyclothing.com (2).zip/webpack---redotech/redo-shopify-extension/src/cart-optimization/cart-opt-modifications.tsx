import { MerchantStyle } from "@redotech/arbiter/merchant-style";
import { Currency } from "@redotech/money/currencies";
import { DEFAULT_CURRENCY } from "@redotech/money/util";
import { useRequiredContext } from "@redotech/react-util/context";
import { useHandler } from "@redotech/react-util/hook";
import { InsertionPosition } from "@redotech/redo-storefront-common/insertion-position";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import { ShopifyCart } from "@redotech/shopify-client/ajax";
import { createContext, useEffect, useState } from "react";
import { useCart } from "../utils/cart";
import { getRenderSafeDomObserver } from "../utils/dom";
import { CartOptModification } from "./cart-opt-modification-container";
import { CartOptimizationContext } from "./cart-optimization-context";
import { CartRewardsModification } from "./cart-rewards-modification";
import DueLater from "./due-later";
import { CART_TOTAL_SELECTOR } from "./selectors";

interface CartOptModificationsContextType {
  cart: ShopifyCart | undefined;
  tryFirstTotal: number;
  dueTodayTotal: number;
  dueTodaySubtotal: number;
  currency: Currency;
}

export const useShouldRefreshCartModifications = () => {
  const [refreshCartModifications, setRefreshCartModifications] =
    useState<symbol>(Symbol());

  const domChangeCallback = useHandler(() => {
    setRefreshCartModifications(Symbol());
  });

  useEffect(() => {
    const domObserver = getRenderSafeDomObserver();
    domObserver.registerCallback(domChangeCallback);

    return () => {
      domObserver.unregisterCallback(domChangeCallback);
    };
  }, [domChangeCallback]);

  return refreshCartModifications;
};

export const CartOptModificationsContext = createContext<
  CartOptModificationsContextType | undefined
>(undefined);

export interface TryFirstTotals {
  dueTodayTotal: number;
  dueTodaySubtotal: number; // Before taxes and shipping
  dueLaterTotal: number; // The sum of try first items before taxes. FIXME: this should probably be the amount with tax
}

export const getTryFirstTotals = ({
  cart,
  autocheck,
}: {
  cart: ShopifyCart;
  autocheck: WidgetAutocheck;
}): TryFirstTotals => {
  const cartTotalWithTaxes = Number(cart.total_price) || 0;
  const cartTotalWithoutTaxes = Number(cart.subtotal_price) || 0;

  if (!autocheck.tryFirst?.sellingPlanId) {
    return {
      dueTodayTotal: cartTotalWithTaxes,
      dueLaterTotal: 0,
      dueTodaySubtotal: cartTotalWithoutTaxes,
    };
  }

  const tryFirstTotalCents = cart.items
    .filter((item) => {
      const lineItemSellingPlanIdStr =
        item.selling_plan?.toString() ??
        item.selling_plan_allocation?.selling_plan?.id.toString();
      return (
        lineItemSellingPlanIdStr ===
        autocheck.tryFirst?.sellingPlanId?.toString()
      );
    })
    .reduce((total, item) => total + (item.line_price || 0), 0);

  const tryFirstTotal = tryFirstTotalCents / 100;

  const dueTodayTotal = cartTotalWithTaxes - tryFirstTotal;
  const dueTodaySubtotal = cartTotalWithoutTaxes - tryFirstTotal;

  return { dueTodayTotal, dueLaterTotal: tryFirstTotal, dueTodaySubtotal };
};

const CartOptModifications = () => {
  const cart = useCart();
  const cartOptimizationContext = useRequiredContext(CartOptimizationContext);

  const [dueNowAmount, setDueNowAmount] = useState<number | null>(null);
  const [dueLaterAmount, setDueLaterAmount] = useState<number | null>(null);
  const [dueTodaySubtotal, setDueTodaySubtotal] = useState<number | null>(null);

  useEffect(() => {
    if (!cart || !cart.items.length) {
      return;
    }

    // Only calculate try first totals if we have a try first selling plan
    if (cartOptimizationContext.autocheck.tryFirst?.sellingPlanId) {
      const { dueTodayTotal, dueLaterTotal, dueTodaySubtotal } =
        getTryFirstTotals({
          cart,
          autocheck: cartOptimizationContext.autocheck,
        });

      setDueNowAmount(dueTodayTotal);
      setDueLaterAmount(dueLaterTotal);
      setDueTodaySubtotal(dueTodaySubtotal);
    } else {
      // For cart optimization without try first, use full cart total
      const cartTotal = (Number(cart.total_price) || 0) * 100;
      setDueNowAmount(cartTotal);
      setDueLaterAmount(0);
      setDueTodaySubtotal((Number(cart.subtotal_price) || 0) * 100);
    }
  }, [cart, cartOptimizationContext.autocheck]);

  // Check if cart totals are enabled and get selector
  const cartTotals =
    cartOptimizationContext.autocheck.cartOptimization?.cartTotals;
  const cartTotalsEnabled =
    cartTotals?.enabled &&
    cartOptimizationContext.autocheck.tryFirst?.sellingPlanId;
  const cartTotalsSelector =
    cartTotals?.placementSelector || CART_TOTAL_SELECTOR;

  const contextValue: CartOptModificationsContextType = {
    cart,
    tryFirstTotal: dueLaterAmount ?? 0,
    dueTodayTotal: dueNowAmount ?? 0,
    dueTodaySubtotal: dueTodaySubtotal ?? 0,
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    currency: (cart?.currency as Currency | undefined) ?? DEFAULT_CURRENCY,
  };

  return (
    <CartOptModificationsContext.Provider value={contextValue}>
      <CartRewardsModification />
      {cartTotalsEnabled && (
        <CartOptModification
          containerPlacement={InsertionPosition.AFTER}
          containerSelector={cartTotalsSelector}
        >
          {cartTotals?.customCss ? (
            <MerchantStyle css={cartTotals.customCss} />
          ) : null}
          <DueLater />
        </CartOptModification>
      )}
    </CartOptModificationsContext.Provider>
  );
};

export default CartOptModifications;
