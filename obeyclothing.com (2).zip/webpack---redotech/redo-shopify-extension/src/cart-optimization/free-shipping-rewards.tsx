import { moneyFormat } from "@redotech/money/util";
import { useRequiredContext } from "@redotech/react-util/context";
import { CartRewardsType } from "@redotech/redo-conversion-settings-common/cart-rewards";
import {
  cartRewardsDefaults,
  getEvaluatedCartRewardsMessage,
} from "@redotech/redo-storefront-widget-common/cart-rewards-defaults";
import { memo } from "react";
import { CartOptModificationsContext } from "./cart-opt-modifications";
import { CartOptimizationContext } from "./cart-optimization-context";
import { CartRewardsUi } from "./cart-rewards-ui";

export const FreeShippingRewards = memo(function FreeShippingRewards() {
  const cartOptimizationContext = useRequiredContext(CartOptimizationContext);
  const cartContext = useRequiredContext(CartOptModificationsContext);

  const cartRewards =
    cartOptimizationContext.autocheck.cartOptimization?.cartRewards;

  if (!cartRewards || cartRewards.type !== CartRewardsType.SHIPPING) {
    return null;
  }

  const { threshold, approachingThresholdMessage, pastThresholdMessage } =
    cartRewards;

  const currentTotal =
    cartContext.dueTodaySubtotal ?? cartContext.dueTodayTotal;

  const remainingAmount = Math.max(0, threshold - currentTotal);
  const hasReachedThreshold = remainingAmount === 0;

  const remainingFormatted = moneyFormat({
    amount: remainingAmount,
    currency: cartContext.currency,
  });

  const message = hasReachedThreshold
    ? getEvaluatedCartRewardsMessage(
        pastThresholdMessage,
        cartRewardsDefaults.pastThresholdMessage,
      )
    : getEvaluatedCartRewardsMessage(
        approachingThresholdMessage,
        cartRewardsDefaults.approachingThresholdMessage,
        { remainingToRewardsTier: remainingFormatted },
      );

  const progressPercentage = Math.min(currentTotal / threshold, 1) * 100;

  return (
    <CartRewardsUi
      hasReachedThreshold={hasReachedThreshold}
      message={message}
      progressPercentage={progressPercentage}
    />
  );
});
