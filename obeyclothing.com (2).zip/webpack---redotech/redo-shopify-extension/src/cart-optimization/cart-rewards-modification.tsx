import { useRequiredContext } from "@redotech/react-util/context";
import { InsertionPosition } from "@redotech/redo-storefront-common/insertion-position";
import { memo, useEffect } from "react";
import { CartOptModification } from "./cart-opt-modification-container";
import { CartOptimizationContext } from "./cart-optimization-context";
import { FreeShippingRewards } from "./free-shipping-rewards";
import { CART_REWARDS_TARGET_SELECTOR } from "./selectors";

export const CartRewardsModification = memo(function CartRewardsModification() {
  const cartOptimizationContext = useRequiredContext(CartOptimizationContext);

  // Check if cart rewards are configured and enabled
  const cartRewards =
    cartOptimizationContext.autocheck.cartOptimization?.cartRewards;
  const hasCartRewards = cartRewards && cartRewards.enabled;

  // Use configurable selector or default
  const placementSelector =
    cartRewards?.placementSelector || CART_REWARDS_TARGET_SELECTOR;

  useEffect(() => {
    console.log("Checking for cart rewards");

    if (!hasCartRewards) {
      console.log("No cart rewards setup");
      return;
    }

    const existingElements = document.querySelectorAll(placementSelector);
    console.log("Found", existingElements.length, "cart rewards elements");
    for (const element of existingElements) {
      if (element instanceof HTMLElement) {
        element.style.display = "none";
      }
    }

    return () => {
      for (const element of existingElements) {
        if (element instanceof HTMLElement) {
          element.style.display = "";
        }
      }
    };
  }, [hasCartRewards, placementSelector]);

  if (!hasCartRewards) {
    return null;
  }

  return (
    <CartOptModification
      containerPlacement={InsertionPosition.BEFORE}
      containerSelector={placementSelector}
    >
      <FreeShippingRewards />
    </CartOptModification>
  );
});
