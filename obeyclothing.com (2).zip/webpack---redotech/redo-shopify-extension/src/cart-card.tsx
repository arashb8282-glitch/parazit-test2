import { MerchantStyle } from "@redotech/arbiter/merchant-style";
import { Money } from "@redotech/money";
import { moneyFormat } from "@redotech/money/util";
import { useHandler } from "@redotech/react-util/hook";
import { Lazy } from "@redotech/react-util/init";
import GiftIcon from "@redotech/redo-icons/gift-01.svg";
import LockIcon from "@redotech/redo-icons/lock-03.svg";
import PlusIcon from "@redotech/redo-icons/plus.svg";
import ShieldIcon from "@redotech/redo-icons/shield-tick.svg";
import TrashIcon from "@redotech/redo-icons/trash-01.svg";
import { Coverage } from "@redotech/redo-return-coverage-common/coverage";
import {
  getHtml,
  getReturnType,
} from "@redotech/redo-storefront-common/checkbox";
import { ToggleFields } from "@redotech/redo-storefront-common/toggle-fields";
import { DEFAULT_IMAGE_URL } from "@redotech/redo-storefront-widget-common/default-values";
import classNames from "classnames";
import htmlReactParser from "html-react-parser";
import { lazy, memo, MouseEvent, Suspense, useRef, useState } from "react";
import * as cardCss from "./cart-card.module.css";
import {
  RedoEmittedDomEvent,
  useFireEventOnRender,
  useInfoModalOpenEvents,
} from "./dom-events";
import { ClassicWidgetTheme } from "./render-elements/classic-widget-theme";
import { TwoLineToggleLabel } from "./toggle";
import { recordCoverageInfoModalOpened } from "./utils/coverage-info-modal-opened";

const RedoModal = lazy(async () => {
  const { RedoModal } = await import("./modal");
  return { default: RedoModal };
});

export const CardImage = memo(function CardImage({
  img_url,
}: {
  img_url: string;
}) {
  return (
    <img
      className={cardCss.imageContainer}
      data-target="card-image"
      src={img_url}
    />
  );
});

export const CartCard = ({
  theme,
  coverage,
  toggleFields,
  value,
  onChange,
  price,
  packageProtectionPlusEnabled,
  packageProtectionEnabled,
  returnsCoverageEnabled,
  finalSaleReturnsCoverageEnabled,
}: {
  theme: ClassicWidgetTheme;
  coverage: Coverage;
  toggleFields: ToggleFields;
  value: boolean;
  onChange(value: boolean): void;
  price: Money | undefined;
  packageProtectionPlusEnabled?: boolean;
  packageProtectionEnabled?: boolean;
  returnsCoverageEnabled: boolean;
  finalSaleReturnsCoverageEnabled: boolean;
}) => {
  useFireEventOnRender(RedoEmittedDomEvent.CartCardRendered);
  const [modalOpen, setModalOpen] = useState(false);
  useInfoModalOpenEvents(setModalOpen);
  const {
    color,
    customCss,
    fontSize,
    html,
    modalVersion,
    showInfoIcon,
    modalCustomizationsV2,
    icon,
    iconColor,
    iconBackgroundColor,
    image_url: imageUrlOrDefault,
    showIcons,
    returnPolicyUrl,
  } = theme;

  const infoButtonRef = useRef<HTMLElement | null>(null);
  const onInfoClick = (e?: MouseEvent<HTMLElement>) => {
    infoButtonRef.current = e?.currentTarget ?? null;
    setModalOpen(true);
    recordCoverageInfoModalOpened();
  };

  const onModalClose = useHandler(() => setModalOpen(false));

  const buttonText = value ? "REMOVE" : "ADD";
  const image_url = imageUrlOrDefault || DEFAULT_IMAGE_URL;

  const containerStyles: { color?: string; backgroundColor?: string } = {};
  if (iconColor) {
    containerStyles.color = iconColor;
  }
  if (iconBackgroundColor) {
    containerStyles.backgroundColor = iconBackgroundColor;
  }

  return (
    <>
      <MerchantStyle css={customCss} />

      <div className={cardCss.cardContainer} data-target="card-container">
        {image_url && (
          <div className={classNames(cardCss.imageContainer, cardCss.withIcon)}>
            <img
              className={cardCss.imageElement}
              data-target="card-image"
              src={image_url}
            />
            {icon ? (
              <div className={cardCss.iconContainer} style={containerStyles}>
                {icon === "gift" && <GiftIcon className={cardCss.icon} />}
                {icon === "lock" && <LockIcon className={cardCss.icon} />}
                {icon === "shield" && <ShieldIcon className={cardCss.icon} />}
              </div>
            ) : undefined}
          </div>
        )}

        <div
          className={cardCss.textAndButtonContainer}
          data-target="text-and-buttons-container"
        >
          <TwoLineToggleLabel
            color={color}
            coverage={coverage}
            fontSize={fontSize ?? 14}
            onInfoClick={onInfoClick}
            price={undefined}
            showInfoIcon={showInfoIcon}
            toggleSubtitleText={
              value
                ? toggleFields.positiveSubtext
                : toggleFields.negativeSubtext
            }
            toggleTitleText={toggleFields.titleText}
          >
            {html ? (
              htmlReactParser(getHtml(html, getReturnType(coverage)) ?? "")
            ) : (
              <strong>Free Unlimited Returns</strong>
            )}
          </TwoLineToggleLabel>
          <div className={cardCss.actionItems} data-target="action-items">
            <span data-target="price">{price && moneyFormat(price)}</span>
            <button
              className={cardCss.button}
              data-target="card-button"
              onClick={() => {
                onChange(!value);
              }}
              // onTouchStart={() => {
              //   onChange(!value);
              // }}
              type="button"
            >
              {showIcons ? (
                value ? (
                  <TrashIcon className={cardCss.icon} />
                ) : (
                  <PlusIcon className={cardCss.icon} />
                )
              ) : (
                buttonText
              )}
            </button>
          </div>
        </div>
      </div>
      <Suspense>
        <Lazy init={modalOpen}>
          <RedoModal
            enableTopLayerModalApi={
              modalCustomizationsV2?.enableTopLayerModalApi
            }
            finalSaleReturnsCoverageEnabled={finalSaleReturnsCoverageEnabled}
            modalCustomizationsV2={modalCustomizationsV2}
            onClose={onModalClose}
            open={modalOpen}
            packageProtectionEnabled={packageProtectionEnabled}
            packageProtectionPlusEnabled={packageProtectionPlusEnabled}
            returnFocusRef={infoButtonRef}
            returnPolicyUrl={returnPolicyUrl}
            returnsCoverage={coverage}
            returnsCoverageEnabled={returnsCoverageEnabled}
            version={modalVersion}
          />
        </Lazy>
      </Suspense>
    </>
  );
};
