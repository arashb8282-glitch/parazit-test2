import { createStyleManager } from "@redotech/web-util/web-components/style";

export default createStyleManager();
