import { WidgetElementType } from "@redotech/redo-storefront-common/widget-config";
import STYLE_MANAGER from "./style-manager";

export class StorefrontCoverageHtmlElement extends HTMLElement {
  #deregisterStyles?: () => void;
  #root?: ShadowRoot;
  #modalContainer?: HTMLElement;
  private _useShadowRoot = true;
  private _shadowRootMode: "open" | "closed" = "closed";

  toggleClass: WidgetElementType | undefined = undefined;

  setToggleClass(toggleClass?: WidgetElementType) {
    this.toggleClass = toggleClass;
  }

  set useShadowRoot(value: boolean) {
    this._useShadowRoot = value;
  }

  set shadowRootMode(value: "open" | "closed") {
    this._shadowRootMode = value;
  }

  get root(): ShadowRoot | HTMLElement {
    return this.#root ?? this;
  }

  get modalContainer() {
    return this.#modalContainer;
  }

  connectedCallback() {
    if (this._useShadowRoot) {
      /**
       * Only mount the shadow root if it doesn't already exist (we can't unmount programmatically, e.g. if this component was already rendered and then removed)
       * https://stackoverflow.com/questions/20090059/how-to-remove-a-shadow-root-from-an-html-element-adorned-with-a-shadow-dom-from
       */
      if (!this.#root) {
        const shadowRoot = this.attachShadow({ mode: this._shadowRootMode });
        this.#root = shadowRoot;
      }
      const modalRoot = this.ownerDocument.createElement("div");
      modalRoot.setAttribute("id", "redo-modal-root");
      modalRoot.style.display = "initial";
      modalRoot.style.position = "absolute";
      modalRoot.style.zIndex = "2147483647";
      document.body.append(modalRoot);
      const modalShadowRoot = modalRoot.attachShadow({ mode: "open" });
      this.#deregisterStyles = STYLE_MANAGER.register(modalShadowRoot);
      this.#modalContainer = this.ownerDocument.createElement("div");
      modalShadowRoot.append(this.#modalContainer);
    }
  }

  disconnectedCallback() {
    this.dispatchEvent(new Event("disconnect"));
    this.#deregisterStyles?.();
    this.#modalContainer?.remove();
  }

  static #registered = false;

  static register() {
    if (!this.#registered) {
      customElements.define(this.TAG, this);
      this.#registered = true;
    }
  }

  static readonly TAG = "redo-shopify-toggle";
}
