import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import sortBy from "lodash/sortBy";
import { RedoCheckboxElement } from "./checkbox-app";
import { CONCIERGE_PRODUCT_FORM_CONTAINER_ID } from "./concierge/pre-init";
import { RedoEmittedDomEvent } from "./dom-events";
import { DEFAULT_CHECKBOX_SELECTOR } from "./site-config/selectors";
import "./styles.css";
import { isElementVisible } from "./utils/is-element-visible";
import { querySelectorAllSafe } from "./utils/query-selector-safe";

void import("./styles.global.css");

const CHECKBOX_CONTAINER_ID = "redo-checkbox";

export const TAPCART_SELECTOR = "#redo_tapcart_container";

/**
 * Fallback selectors for finding product form areas when the standard
 * /cart/add form doesn't exist (e.g., when all variants are sold out).
 * These are common selectors used by Shopify themes for the product form area.
 * Listed in order of preference - more specific to more general.
 */
const SOLD_OUT_FALLBACK_SELECTORS = [
  // Common product form containers (specific)
  ".product-form",
  "#product-form",
  "[data-product-form]",
  'form[data-type="add-to-cart-form"]',
  ".product-form__buttons",
  ".shopify-payment-button",
  ".product-form__submit",
  // Broader product info sections
  ".product__info-container",
  ".product__content",
  ".product-single__meta",
  ".product-details",
  ".product-info",
  ".product",
  // Very generic - last resort
  '[class*="product"][class*="info"]',
  '[class*="product"][class*="form"]',
];

export function getPdpAddProductForm({
  onTapcart,
  autocheckSelector,
}: {
  onTapcart: boolean;
  autocheckSelector?: string;
}): Element | null {
  const selector = onTapcart
    ? TAPCART_SELECTOR
    : autocheckSelector || DEFAULT_CHECKBOX_SELECTOR;
  const forms = querySelectorAllSafe(document, selector);
  const sortedForms = sortBy(
    forms,
    (form) =>
      !form.querySelector('button[type="submit"], input:not([type="hidden"])'),
  );

  // They have an identical form that is invisible, so we need to select 2nd form
  const form = onTapcart
    ? sortedForms[0]
    : sortedForms[
        globalThis.Shopify?.shop === "palmdancewear.myshopify.com" ? 1 : 0
      ];
  return form ?? null;
}

export function getAllPdpAddProductForms({
  onTapcart,
  autocheckSelector,
}: {
  onTapcart: boolean;
  autocheckSelector?: string;
}): Element[] {
  const selector = onTapcart
    ? TAPCART_SELECTOR
    : autocheckSelector || DEFAULT_CHECKBOX_SELECTOR;
  const forms = querySelectorAllSafe(document, selector);
  const sortedForms = sortBy(
    forms,
    (form) =>
      !form.querySelector('button[type="submit"], input:not([type="hidden"])'),
  );

  const validForms = onTapcart
    ? sortedForms
    : globalThis.Shopify?.shop === "palmdancewear.myshopify.com"
      ? sortedForms.slice(1)
      : sortedForms;

  // Filter out forms that are not visible
  const visibleForms = Array.from(validForms).filter((form) =>
    isElementVisible(form),
  );

  return visibleForms;
}

/**
 * Find a fallback element to inject the Back in Stock button when the standard
 * /cart/add form doesn't exist. This happens when all variants are sold out
 * and some themes remove or hide the add-to-cart form entirely.
 *
 * Returns only the first matching element to avoid duplicate button injection.
 */
export function getSoldOutFallbackElements(): Element[] {
  for (const selector of SOLD_OUT_FALLBACK_SELECTORS) {
    const element = document.querySelector(selector);
    if (element && isElementVisible(element)) {
      return [element];
    }
  }

  return [];
}

/**
 * Configured selector, then the default cart form, then a sold-out container.
 * Shared by the Back in Stock widget and the spotlight embed launcher.
 */
export function getBackInStockAttachPoints({
  onTapcart,
  autocheckSelector,
}: {
  onTapcart: boolean;
  autocheckSelector?: string;
}): { elements: Element[]; usedSoldOutFallback: boolean } {
  let elements = getAllPdpAddProductForms({ onTapcart, autocheckSelector });

  if (elements.length === 0 && autocheckSelector) {
    elements = getAllPdpAddProductForms({ onTapcart });
  }

  if (elements.length > 0) {
    return { elements, usedSoldOutFallback: false };
  }

  return { elements: getSoldOutFallbackElements(), usedSoldOutFallback: true };
}

function addContainer(
  widgetId: string,
  autocheck: WidgetAutocheck,
  onTapcart: boolean,
  containerId: string,
) {
  if (!autocheck.enabled) {
    return;
  }
  // Should use getPdpAddProductForm at some point, but that
  // feels like a risky refactor for not enough benefit.
  const selector = onTapcart
    ? TAPCART_SELECTOR
    : autocheck.selector || DEFAULT_CHECKBOX_SELECTOR;
  const forms = querySelectorAllSafe(document, selector);
  const sortedForms = sortBy(
    forms,
    (form) =>
      !form.querySelector('button[type="submit"], input:not([type="hidden"])'),
  );
  // They have an identical form that is invisible, so we need to select 2nd form
  const form = onTapcart
    ? sortedForms[0]
    : sortedForms[
        globalThis.Shopify?.shop === "palmdancewear.myshopify.com" ? 1 : 0
      ];
  if (!form) {
    return;
  }

  const container = document.createElement("div");
  container.id = containerId;
  form.append(container);
  return container;
}

export function addCheckbox(
  autocheck: WidgetAutocheck,
  onTapcart: boolean,
): RedoCheckboxElement | null {
  const container =
    document.getElementById(CHECKBOX_CONTAINER_ID) ||
    addContainer(
      globalThis.redoWidgetId,
      autocheck,
      onTapcart,
      CHECKBOX_CONTAINER_ID,
    );
  if (!container) {
    return null;
  }

  RedoCheckboxElement.register();

  const existingCheckbox = container.querySelector(RedoCheckboxElement.TAG);
  if (existingCheckbox && existingCheckbox instanceof RedoCheckboxElement) {
    return existingCheckbox;
  }

  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  const checkbox = document.createElement(
    RedoCheckboxElement.TAG,
  ) as RedoCheckboxElement;

  container.append(checkbox);

  const onRemoveRedo = () => {
    document.body.removeEventListener(
      RedoEmittedDomEvent.RemoveAllElements,
      onRemoveRedo,
    );
    container.remove();
  };
  document.body.addEventListener(
    RedoEmittedDomEvent.RemoveAllElements,
    onRemoveRedo,
  );

  return checkbox;
}

export function addConciergeProductForm(
  autocheck: WidgetAutocheck,
  onTapcart: boolean,
) {
  const container =
    document.getElementById(CONCIERGE_PRODUCT_FORM_CONTAINER_ID) ||
    addContainer(
      globalThis.redoWidgetId,
      autocheck,
      onTapcart,
      CONCIERGE_PRODUCT_FORM_CONTAINER_ID,
    );

  if (!container) {
    return null;
  }

  return container;
}
