import { makePostRequest } from "@redotech/redo-shopify-utils/request-helper";
import {
  COVERAGE_PLACEMENT_STALE_MINUTES,
  type CoverageLoadedEvent,
  type CoveragePlacement,
  coveragePlacementKey,
  coverageTreatmentKey,
} from "@redotech/redo-storefront-common/coverage-placement-metrics";
import { WidgetElementType } from "@redotech/redo-storefront-common/widget-config";
import type {
  ResolvedWidgetPlacement,
  WidgetAutocheck,
} from "@redotech/redo-storefront-widget-common/widget";
import { LRUCache } from "@redotech/util/cache";
import { localStore } from "@redotech/web-util/storage";
import { inCoverageBuilderMode } from "./coverage-builder/coverage-builder-init";
import { log } from "./monitoring/log";
import { PreviewModeState } from "./preview-mode/preview-state";
import { renderedWidgetSelectors } from "./utils/rendered-widget-selectors";

const MINUTE_MS = 60_000;
const STORAGE_PREFIX = "redo_coverage_observation:";
const inFlight = new Set<string>();
const localReports = new LRUCache<
  string,
  { attemptedAt: number; reportedAt?: number }
>(1000);

interface ReportingContext {
  autocheck: Pick<WidgetAutocheck, "widgetSlug" | "coveragePlacementMetrics">;
  treatmentId: string | null;
}

interface PlacedCoverageWidget {
  redoHtmlElements: readonly { isConnected: boolean; root: ParentNode }[];
  matchedSelectors: readonly (string | undefined)[];
  widgetConfig?: { _id?: string; elementType: WidgetElementType };
  placement: ResolvedWidgetPlacement;
  placementIndex: number;
}

function isRenderedWidgetElement(
  element: { isConnected: boolean; root: ParentNode },
  elementType: WidgetElementType,
): boolean {
  return (
    element.isConnected &&
    element.root.querySelector(renderedWidgetSelectors[elementType]) !== null
  );
}

/** Widget elements that are connected and have mounted their inner content. */
export function getRenderedWidgetElements<
  TElement extends { isConnected: boolean; root: ParentNode },
>(
  widgets: readonly {
    redoHtmlElements: readonly TElement[];
    widgetConfig?: { elementType: WidgetElementType };
  }[],
  standardElementType: WidgetElementType,
): TElement[] {
  return widgets.flatMap((widget) => {
    const elementType = widget.widgetConfig?.elementType ?? standardElementType;
    return widget.redoHtmlElements.filter((element) =>
      isRenderedWidgetElement(element, elementType),
    );
  });
}

export function getObservedCoveragePlacements(
  widgets: readonly PlacedCoverageWidget[],
  standardElementType: WidgetElementType,
): CoveragePlacement[] {
  const observed: CoveragePlacement[] = [];
  for (const widget of widgets) {
    const elementType = widget.widgetConfig?.elementType ?? standardElementType;
    const selectors = [
      ...new Set(
        widget.redoHtmlElements.flatMap((element, index) => {
          if (!isRenderedWidgetElement(element, elementType)) {
            return [];
          }
          const selector = widget.matchedSelectors[index]?.trim();
          return selector ? [selector] : [];
        }),
      ),
    ];
    if (selectors.length === 0) {
      continue;
    }
    observed.push({
      placementId: widget.widgetConfig?._id ?? null,
      placementIndex: widget.placementIndex,
      elementType,
      selector: selectors.sort().join(", "),
      insertionPosition: widget.placement.insertionPosition,
      ...(widget.placement.shadowRootSelector
        ? { shadowRootSelector: widget.placement.shadowRootSelector }
        : {}),
    });
  }
  return observed;
}

export function shouldReport(minutesSinceLastSeen: number): boolean {
  if (minutesSinceLastSeen < 1) {
    return false;
  }
  if (
    minutesSinceLastSeen >= COVERAGE_PLACEMENT_STALE_MINUTES ||
    Number.isNaN(minutesSinceLastSeen)
  ) {
    return true;
  }
  return (
    Math.random() <
    0.01 +
      (0.99 * (minutesSinceLastSeen - 1)) /
        (COVERAGE_PLACEMENT_STALE_MINUTES - 1)
  );
}

function reportingData({ autocheck, treatmentId }: ReportingContext) {
  const theme = globalThis.Shopify?.theme;
  if (
    globalThis.__redoCoverageQa ||
    !autocheck.widgetSlug ||
    !theme?.id ||
    theme.role !== "main" ||
    globalThis.Shopify?.designMode ||
    inCoverageBuilderMode() ||
    PreviewModeState.isActive()
  ) {
    return undefined;
  }
  const base =
    globalThis.redoStorefront?.env?.REDO_API_URL ?? process.env.REDO_API_URL;
  if (!base) {
    return undefined;
  }
  const themeId = String(theme.id);
  const path = location.pathname;
  const pageType: CoverageLoadedEvent["pageType"] = /\/products(?:\/|$)/.test(
    path,
  )
    ? "pdp"
    : /\/collections(?:\/|$)/.test(path)
      ? "collection"
      : /\/cart(?:\/|$)/.test(path)
        ? "cart"
        : "unknown";
  return {
    url: `${base.replace(/\/$/, "")}/widgets/${encodeURIComponent(autocheck.widgetSlug)}`,
    key: [autocheck.widgetSlug, themeId, treatmentId],
    history:
      autocheck.coveragePlacementMetrics?.[themeId]?.[
        coverageTreatmentKey(treatmentId)
      ],
    event: { themeId, treatmentId, url: location.href, path, pageType },
  };
}

function startReport(key: string, serverLastSeen: string | undefined): boolean {
  if (inFlight.has(key)) {
    return false;
  }
  const now = Date.now();
  const local = localReports.get(key);
  if (local && now - local.attemptedAt < MINUTE_MS) {
    return false;
  }
  const stored = Number(localStore(STORAGE_PREFIX + key).get());
  const serverSeen = serverLastSeen ? Date.parse(serverLastSeen) : 0;
  const lastSeen = Math.max(
    Number.isFinite(serverSeen) ? serverSeen : 0,
    Number.isFinite(stored) ? stored : 0,
    local?.reportedAt ?? 0,
  );
  localReports.set(key, { attemptedAt: now, reportedAt: local?.reportedAt });
  if (!shouldReport(lastSeen ? (now - lastSeen) / MINUTE_MS : Infinity)) {
    return false;
  }
  inFlight.add(key);
  return true;
}

async function sendReport(
  url: string,
  body: object,
  keys: string[],
): Promise<void> {
  try {
    const response = await makePostRequest(url, body);
    if (!response.ok) {
      throw new Error(`Coverage observation returned ${response.status}`);
    }
    const now = Date.now();
    for (const key of keys) {
      localReports.set(key, { attemptedAt: now, reportedAt: now });
      localStore(STORAGE_PREFIX + key).set(String(now));
    }
  } catch (error) {
    log("Failed to report coverage observation", error);
  } finally {
    for (const key of keys) {
      inFlight.delete(key);
    }
  }
}

export async function reportCoverageLoaded(
  context: ReportingContext,
): Promise<void> {
  try {
    const data = reportingData(context);
    if (!data) {
      return;
    }
    const key = JSON.stringify([...data.key, "loaded"]);
    if (startReport(key, data.history?.lastLoadedAt)) {
      await sendReport(`${data.url}/coverage-loaded-event`, data.event, [key]);
    }
  } catch (error) {
    log("Failed to prepare coverage loaded observation", error);
  }
}

export async function reportCoveragePlacementMetrics(
  context: ReportingContext,
  placements: CoveragePlacement[],
): Promise<void> {
  try {
    const data = reportingData(context);
    if (!data) {
      return;
    }
    const unique = [
      ...new Map(placements.map((p) => [coveragePlacementKey(p), p])).values(),
    ];
    const due = unique.filter((placement) => {
      const key = coveragePlacementKey(placement);
      return startReport(
        JSON.stringify([...data.key, key]),
        data.history?.placements[key]?.lastSeenAt,
      );
    });
    for (let i = 0; i < due.length; i += 50) {
      const batch = due.slice(i, i + 50);
      await sendReport(
        `${data.url}/coverage-placement-event`,
        { ...data.event, placements: batch },
        batch.map((p) =>
          JSON.stringify([...data.key, coveragePlacementKey(p)]),
        ),
      );
    }
  } catch (error) {
    log("Failed to prepare coverage placement observation", error);
  }
}
