import {
  CartRefreshAction,
  CartRefreshActionType,
} from "@redotech/redo-storefront-common/cart-refresh-action";
import { REDO_CART_STORAGE_KEY } from "@redotech/redo-storefront-web/cache/keys";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import { setSessionStorageWithExpiry } from "@redotech/redo-web/utils/session-storage-wrapper";
import { ExtensionShopifyClient } from "@redotech/shopify-client/ajax";
import { assertNever } from "@redotech/util/type";
import { isBigcommerceCheckout } from "../client/bigcommerce-checkout-refresh";
import { BigcommerceStorefrontClient } from "../client/bigcommerce-storefront";
import { RedoEmittedDomEvent } from "../dom-events";

/** Runs the team's configured refresh actions instead of the built-in hooks. */
function runCartRefreshActions(actions: CartRefreshAction[]) {
  for (const action of actions) {
    try {
      switch (action.type) {
        case CartRefreshActionType.EMIT_EVENT:
          if (action.value) {
            document.body.dispatchEvent(
              new CustomEvent(action.value, { bubbles: true }),
            );
          }
          break;
        case CartRefreshActionType.CALL_FUNCTION: {
          const fn = action.value
            ? (globalThis as Record<string, unknown>)[action.value]
            : undefined;
          if (typeof fn === "function") {
            fn();
          }
          break;
        }
        case CartRefreshActionType.REFRESH_PAGE:
          location.reload();
          break;
        default:
          assertNever(action.type);
      }
    } catch (e) {
      console.error("Cart refresh action failed:", action.type, e);
    }
  }
}

/**
 * Oftentimes when we add Redo to the cart using the toggle, it happens after some side cart has rendered.
 * Many themes rely on the position of the line item in the cart to be current, and items are added to the top, changing the line number
 * for anything already in there. So we have to do our best to re-render the cart whenever we add/remove redo.
 *
 * This function is called after we add/remove redo from the cart, and contains all of the known methods for reloading the cart in various themes.
 */
export async function renderCart(
  autocheck?: Pick<
    WidgetAutocheck,
    "cartRefreshActions" | "preventPageRefreshAfterCartAdd"
  >,
  storefrontClient?: ExtensionShopifyClient,
) {
  setSessionStorageWithExpiry(REDO_CART_STORAGE_KEY, undefined, 0.35);

  /* Add a small delay to ensure cart operations are processed,
   * without this timeout bugs occur on a variety of stores using cartAddToEnd.
   */
  await new Promise((resolve) => setTimeout(resolve, 100));

  try {
    document.body.dispatchEvent(
      new CustomEvent(RedoEmittedDomEvent.RenderCart, { bubbles: true }),
    );

    if (autocheck?.cartRefreshActions?.length) {
      runCartRefreshActions(autocheck.cartRefreshActions);
      return;
    }

    if (
      storefrontClient instanceof BigcommerceStorefrontClient &&
      isBigcommerceCheckout() &&
      !autocheck?.preventPageRefreshAfterCartAdd
    ) {
      await storefrontClient.refreshCheckout();
      return;
    }

    if (globalThis.Shopify?.shop === "augustine-boutique.myshopify.com") {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      await (globalThis as any).theme.cart.updateAllHtml();
    }

    if (globalThis.Shopify?.shop === "hatch-insane-deal.myshopify.com") {
      /**
       * async function refreshCart(delay = 2000)
       * Refreshes the cart content and state. Pass input delay in milliseconds. Default is 2000.
       */
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      await (globalThis as any).MiraCart?.refreshCart(0);
    }

    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    if ((globalThis as any)?.SideCart?.updateSideCart) {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      (globalThis as any).SideCart.updateSideCart();
    }

    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    if (typeof (globalThis as any).updateCartDrawer === "function") {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      (globalThis as any).updateCartDrawer();
    }

    if (
      globalThis.Shopify?.shop === "undiesforever.myshopify.com" ||
      globalThis.Shopify?.shop === "baltic-born.myshopify.com" ||
      globalThis.Shopify?.shop === "lyons-group.myshopify.com"
    ) {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      (globalThis as any).publish("cart-update", {});
    }

    if (
      globalThis.Shopify?.shop === "thevaultproscooters.myshopify.com" &&
      globalThis.customElements.get("cart-items") !== undefined
    ) {
      const cartItems: any = document.querySelector("cart-items");
      if (cartItems) {
        await cartItems.refresh();
      }
    }

    if (
      globalThis.Shopify?.shop === "rooney.myshopify.com" ||
      globalThis.Shopify?.shop === "bigshoes-store.myshopify.com" ||
      globalThis.Shopify?.shop === "charming-and-main.myshopify.com" ||
      globalThis.Shopify?.shop === "49274c.myshopify.com" || // Shevibe
      globalThis.Shopify?.shop === "kindred-bravely.myshopify.com" ||
      globalThis.Shopify?.shop === "comradsocks.myshopify.com" ||
      globalThis.Shopify?.shop === "baloo-living.myshopify.com"
    ) {
      location.reload();
    }

    if (
      globalThis.redoStorefront?.storeUrl === "www.cariloha.com" &&
      window.location.pathname.includes("/cart")
    ) {
      location.reload();
    }

    if (globalThis.Shopify?.shop === "rebelstork-us.myshopify.com") {
      document.dispatchEvent(
        new CustomEvent("cart-changed", { bubbles: true }),
      );
    }

    if (typeof SLIDECART_UPDATE === "function") {
      SLIDECART_UPDATE();
    }
    if (typeof globalThis.ajaxCart?.load === "function") {
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      ajaxCart!.load();
    }
    if (typeof reloadCart === "function") {
      reloadCart();
    }
    if (typeof globalThis.redoBasketUpdate === "function") {
      globalThis.redoBasketUpdate(); // Custom function City Beach gave us to update the cart. Does a GET https://dev.citybeach.com/on/demandware.store/Sites-CityBeachAustralia-Site/en_AU/Redo-Update and then fires page events to refresh cart numbers.
    }
    if (typeof globalThis.upcartRefreshCart === "function") {
      void globalThis.upcartRefreshCart();
    }
    if (typeof globalThis.Rebuy?.Cart?.fetchCart === "function") {
      void globalThis.Rebuy.Cart.fetchCart();
    }
  } catch (e) {
    console.error("Failed to re-render cart:", e);
  }
}
