import { storefrontShopperIdentity } from "@redotech/redo-marketing-browser-sdk/storefront-identity";
import { inCoverageBuilderMode } from "../coverage-builder/coverage-builder-init";
import type { RedoEmittedDomEvent } from "../dom-events";
import { PreviewModeState } from "../preview-mode/preview-state";

/** The shopper to attribute a storefront coverage event to; none in preview or builder mode. */
export function readEligibleAnonymousId(): string | undefined {
  if (
    globalThis.__redoCoverageQa ||
    PreviewModeState.isActive() ||
    inCoverageBuilderMode()
  ) {
    return undefined;
  }
  return storefrontShopperIdentity().getShopperId();
}

export function dispatchStorefrontCoverageEvent<TDetail>(
  eventName: RedoEmittedDomEvent,
  detail: TDetail,
): void {
  window.dispatchEvent(new CustomEvent<TDetail>(eventName, { detail }));
}
