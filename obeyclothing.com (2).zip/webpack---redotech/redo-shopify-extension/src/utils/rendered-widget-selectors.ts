import { WidgetElementType } from "@redotech/redo-storefront-common/widget-config";

export const renderedWidgetSelectors: Record<WidgetElementType, string> = {
  [WidgetElementType.COVERAGE_CHECKOUT_BUTTON]:
    '[data-target="coverage-button"]',
  [WidgetElementType.NON_COVERAGE_CHECKOUT_BUTTON]:
    '[data-target="non-coverage-button"]',
  [WidgetElementType.BOTH_CHECKOUT_BUTTONS]:
    '[data-target="coverage-button"], [data-target="non-coverage-button"]',
  [WidgetElementType.INFO_CARD]: '[data-target="info-card-container"]',
  [WidgetElementType.SINGLE_TOGGLE]: '[data-target="toggle-root"]',
  [WidgetElementType.DOUBLE_TOGGLE]: '[data-target="toggle-root"]',
  [WidgetElementType.CART_CARD]: '[data-target="card-container"]',
  [WidgetElementType.CART_CHECKBOX]: '[data-target="cart-checkbox-root"]',
  [WidgetElementType.CHECKOUT_BUTTON]:
    '[data-target="coverage-button"], [data-target="non-coverage-button"]',
};
