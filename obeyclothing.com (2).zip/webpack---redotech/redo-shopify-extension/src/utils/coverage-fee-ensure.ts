import { CartProductType } from "@redotech/redo-storefront-widget-common/cart-product-types";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import { CoverageFeeCapability } from "@redotech/shopify-client/ajax";
import { log } from "../monitoring/log";
import { RedoProductToSell } from "../utils";
import { EnsurePromiseAction } from "./signals";

/** Serializes fee mutations; navigationOwningCalls blocks a background
 *  reload while a click-driven (reloadOnChange:false) call is in flight. */
let mutationChain: Promise<void> = Promise.resolve();
let navigationOwningCalls = 0;

/** Holds the background-reload suppression open across a whole caller
 *  (e.g. the click handler), not just one ensureCoverageFee call. */
export function holdBackgroundReload(): () => void {
  navigationOwningCalls++;
  let released = false;
  return () => {
    if (released) {
      return;
    }
    released = true;
    navigationOwningCalls--;
  };
}

/** Fee line-item display text; independent of the widget's configurable toggle copy. */
export function coverageFeeLabel(productType: CartProductType): string {
  // tslint-disable-next-line @typescript-eslint/switch-exhaustiveness-check -- TODO: grandfather FIXME
  switch (productType) {
    case CartProductType.PackageProtection:
      return "Package Protection";
    case CartProductType.Both:
      return "Return & Package Protection";
    default:
      return "Return Protection";
  }
}

/** Shared ADD/REMOVE/reload body for both the BigCommerce and Commerce Cloud custom-fee call sites. */
export async function ensureCoverageFee({
  coverageFee,
  action,
  autocheck,
  redoProductToSell,
  reloadOnChange = true,
  refresh,
}: {
  coverageFee: CoverageFeeCapability;
  action: EnsurePromiseAction;
  autocheck: WidgetAutocheck;
  redoProductToSell: RedoProductToSell | undefined;
  /** Set false to skip the reload after a successful attach/remove. */
  reloadOnChange?: boolean;
  /** Overrides the capability's own refreshAfterChange, else a full reload. */
  refresh?: () => void | Promise<void>;
}): Promise<void> {
  const refreshPage =
    refresh ??
    coverageFee.refreshAfterChange?.bind(coverageFee) ??
    (() => location.reload());
  if (!(await coverageFee.isAvailable())) {
    log(
      `Custom fee not available on this page, skipping. Location: ${globalThis.location?.pathname}`,
    );
    return;
  }

  if (!reloadOnChange) {
    navigationOwningCalls++;
  }
  const previous = mutationChain;
  let release!: () => void;
  mutationChain = new Promise<void>((resolve) => {
    release = resolve;
  });
  try {
    await previous;
    if (
      action === EnsurePromiseAction.ADD &&
      redoProductToSell &&
      redoProductToSell.rawCalculatedCoveragePrice
    ) {
      log(
        `Adding Redo custom fee of price ${redoProductToSell.rawCalculatedCoveragePrice}`,
      );
      const { changed } = await coverageFee.attach({
        productType: redoProductToSell.productType,
        feeAmount: redoProductToSell.rawCalculatedCoveragePrice,
        label: coverageFeeLabel(redoProductToSell.productType),
        widgetSlug: autocheck.widgetSlug,
      });
      if (changed) {
        const willReload =
          reloadOnChange &&
          navigationOwningCalls === 0 &&
          !autocheck.preventPageRefreshAfterCartAdd;
        log(
          willReload
            ? "Attached custom fee to cart, refreshing page"
            : "Attached custom fee to cart",
        );
        if (willReload) {
          await refreshPage();
        }
      }
    } else if (action === EnsurePromiseAction.REMOVE) {
      log("Removing Redo custom fee");
      const { changed } = await coverageFee.remove({
        widgetSlug: autocheck.widgetSlug,
      });
      if (changed) {
        const willReload =
          reloadOnChange &&
          navigationOwningCalls === 0 &&
          !autocheck.preventPageRefreshAfterCartAdd;
        log(
          willReload
            ? "Deleted custom fee from cart, refreshing page"
            : "Deleted custom fee from cart",
        );
        if (willReload) {
          await refreshPage();
        }
      }
    }
  } finally {
    if (!reloadOnChange) {
      navigationOwningCalls--;
    }
    release();
  }
}
