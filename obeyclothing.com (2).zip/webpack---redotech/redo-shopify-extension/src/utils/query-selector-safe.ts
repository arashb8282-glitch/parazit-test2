import { log } from "../monitoring/log";

export function querySelectorAllSafe(
  root: ParentNode,
  selector: string,
): Element[] {
  try {
    return Array.from(root.querySelectorAll(selector));
  } catch (error) {
    log(error, "Invalid CSS selector", selector);
    return [];
  }
}

export function querySelectorSafe(
  root: ParentNode,
  selector: string,
): Element | null {
  try {
    return root.querySelector(selector);
  } catch (error) {
    log(error, "Invalid CSS selector", selector);
    return null;
  }
}
