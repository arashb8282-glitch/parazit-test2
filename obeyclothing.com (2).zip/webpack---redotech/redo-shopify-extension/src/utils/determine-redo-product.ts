import { CoverageInfo } from "@redotech/redo-return-coverage-common/coverage-calculator/coverage-info-from-calculators";
import {
  binarySearch,
  getThreshold,
} from "@redotech/redo-shopify-utils/binary-search";
import { AttachmentStrategy } from "@redotech/redo-storefront-common/attachment-strategy";
import { CartProductType } from "@redotech/redo-storefront-widget-common/cart-product-types";
import {
  WidgetAutocheck,
  WidgetFees,
} from "@redotech/redo-storefront-widget-common/widget";
import {
  ShopifyProductJS,
  ShopifyVariantJS,
} from "@redotech/shopify-client/ajax";
import { assertNever } from "@redotech/util/type";
import { log } from "../monitoring/log";

export function getCorrectlyPricedVariant({
  product,
  productType,
  coverageInfo,
  country,
}: {
  product: ShopifyProductJS;
  productType: string | undefined;
  coverageInfo: CoverageInfo;
  country: string | undefined;
}): ShopifyVariantJS {
  if (product.variants.length === 1 && product.variants[0] !== undefined) {
    return product.variants[0];
  }

  let variants: ShopifyVariantJS[] = [];
  let calculatedCoveragePrice = 0;
  // tslint-disable-next-line @typescript-eslint/switch-exhaustiveness-check -- TODO: grandfather FIXME
  switch (productType) {
    case CartProductType.Return: {
      variants = product.variants;
      calculatedCoveragePrice = coverageInfo.returns.price;

      break;
    }
    case CartProductType.Both: {
      variants = product.variants.slice(1);
      calculatedCoveragePrice = coverageInfo.both.price;
      break;
    }
    case CartProductType.PackageProtection: {
      variants = product.variants;
      calculatedCoveragePrice = coverageInfo.packageProtection.price;
      break;
    }
    // No default
  }
  log("product calculatedCoveragePrice", calculatedCoveragePrice);

  const threshold = getThreshold({
    country: country ?? undefined,
    unit: "cents",
    targetPrice: calculatedCoveragePrice,
  });

  // Binary search for the variant with the price closest to the newCalculatedCoveragePrice.
  return binarySearch(
    variants,
    calculatedCoveragePrice,
    (v) => v.price,
    threshold,
  );
}

export function determineRedoProductType({
  fees,
  autocheck,
  coverageInfo,
  toggleStates,
}: {
  fees: WidgetFees;
  autocheck: WidgetAutocheck;
  coverageInfo: CoverageInfo;
  toggleStates: { returnToggleState: boolean; protectionToggleState: boolean };
}): CartProductType | null {
  let mainProductType: CartProductType | null = null;

  const hasTwoOptions =
    autocheck.attachmentStrategy === AttachmentStrategy.DOUBLE_TOGGLE ||
    autocheck.attachmentStrategy === AttachmentStrategy.DROP_DOWN;
  if (
    fees.splitProducts &&
    (autocheck.coverageEnabled ||
      autocheck.finalSaleReturns?.coverageEnabled) &&
    autocheck.packageProtection.coverageEnabled
  ) {
    if (
      coverageInfo.returns.cartEligible &&
      coverageInfo.packageProtection.cartEligible
    ) {
      mainProductType = CartProductType.Both;
      if (hasTwoOptions) {
        if (
          toggleStates.returnToggleState &&
          !toggleStates.protectionToggleState
        ) {
          mainProductType = CartProductType.Return;
        } else if (
          !toggleStates.returnToggleState &&
          toggleStates.protectionToggleState
        ) {
          mainProductType = CartProductType.PackageProtection;
        }
      }
    } else if (coverageInfo.packageProtection.cartEligible) {
      mainProductType = CartProductType.PackageProtection;
    } else {
      mainProductType = CartProductType.Return;
    }
  }

  return mainProductType ?? fees.mainType;
}

export function determineRedoProduct({
  mainRedoProduct,
  returnRedoProduct,
  packageRedoProduct,
  bothRedoProduct,
  fees,
  autocheck,
  coverageInfo,
  toggleStates,
}: {
  mainRedoProduct: ShopifyProductJS;
  returnRedoProduct: ShopifyProductJS | null | undefined;
  packageRedoProduct: ShopifyProductJS | null | undefined;
  bothRedoProduct: ShopifyProductJS | null | undefined;
  fees: WidgetFees;
  autocheck: WidgetAutocheck;
  coverageInfo: CoverageInfo;
  toggleStates: { returnToggleState: boolean; protectionToggleState: boolean };
}) {
  if (returnRedoProduct && packageRedoProduct && bothRedoProduct) {
    const mainProductType: CartProductType | null = determineRedoProductType({
      fees,
      autocheck,
      coverageInfo,
      toggleStates,
    });

    switch (mainProductType) {
      case CartProductType.Return:
        return returnRedoProduct;
      case CartProductType.PackageProtection:
        return packageRedoProduct;
      case CartProductType.Both:
        return bothRedoProduct;
      case CartProductType.ExtendedWarranty:
        log("Unsupported product type");
        return mainRedoProduct;
      case null:
        return mainRedoProduct;
      default:
        assertNever(mainProductType);
    }
  }

  return mainRedoProduct;
}

export function getVariantAndProduct({
  coverageInfo,
  mainRedoProduct,
  returnRedoProduct,
  packageRedoProduct,
  bothRedoProduct,
  fees,
  autocheck,
  productTypeMap,
  toggleStates,
  country,
}: {
  coverageInfo: CoverageInfo;
  mainRedoProduct: ShopifyProductJS;
  returnRedoProduct: ShopifyProductJS | null | undefined;
  packageRedoProduct: ShopifyProductJS | null | undefined;
  bothRedoProduct: ShopifyProductJS | null | undefined;
  fees: WidgetFees;
  autocheck: WidgetAutocheck;
  productTypeMap: Map<number | string, string>;
  toggleStates: { returnToggleState: boolean; protectionToggleState: boolean };
  country: string | undefined;
}): { variant: ShopifyVariantJS; product: ShopifyProductJS } {
  const product = determineRedoProduct({
    mainRedoProduct,
    returnRedoProduct,
    packageRedoProduct,
    bothRedoProduct,
    fees,
    autocheck,
    coverageInfo,
    toggleStates,
  });

  const variant = getCorrectlyPricedVariant({
    product,
    productType: productTypeMap.get(product.id),
    coverageInfo,
    country,
  });

  return { product, variant };
}
