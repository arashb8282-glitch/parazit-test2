import { CustomerInfo, ItemInfo } from "@redotech/redo-coverage-common";
import { generateCartHash } from "@redotech/redo-coverage-common/coverage-ml/generate-cart-hash";
import { resolveStagecoachVersioning } from "@redotech/redo-coverage-common/coverage-ml/model/stagecoach";
import {
  CoverageInfo,
  getCoverageInfoFromCalculators,
} from "@redotech/redo-return-coverage-common/coverage-calculator/coverage-info-from-calculators";
import {
  CoverageFeeProductMatchType,
  isCoverageFeeProduct,
} from "@redotech/redo-return-coverage-common/is-coverage-fee-product";
import { autocheckToCoverageSettings } from "@redotech/redo-storefront-widget-common/autocheck-conversion";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import {
  ExtensionShopifyClient,
  ShopifyCart,
  ShopifyCartItem,
} from "@redotech/shopify-client/ajax";
import { parseNumericIdFromShopifyId } from "@redotech/shopify-util/id";
import { isDef } from "@redotech/util/checks";
import { ShopifyExtensionClient } from "../client/shopify-extension-client";
import { StorefrontClient } from "../client/storefront";
import {
  cartItemProperties,
  cartItemUnitPrices,
  getProductInfoFromSource,
} from "../eligibility/returns-coverage-eligibility";
import { log } from "../monitoring/log";
import { datadogLog } from "../monitoring/monitor";
import { coveragePriceCache } from "./checkout-buttons/coverage-price-cache";
import { loadCheckoutProbabilityFromSessionStorage } from "./checkout-probability";
import { selectBetaDraw } from "./select-beta-draw";

async function cartItemToItemInfo({
  cartItem,
  autocheck,
  shopifyClient,
  redoClient,
  onTapcart,
  storefrontGraphQLClient,
  bundleComponentProperties,
}: {
  cartItem: ShopifyCartItem;
  autocheck: WidgetAutocheck;
  shopifyClient: ExtensionShopifyClient;
  redoClient: ShopifyExtensionClient;
  onTapcart: boolean;
  storefrontGraphQLClient?: StorefrontClient;
  bundleComponentProperties: string[];
}): Promise<ItemInfo> {
  const { tags, collections, variantMetafields } =
    await getProductInfoFromSource({
      cartItem,
      autocheck,
      shopifyClient,
      redoClient,
      storefrontGraphQLClient,
    });

  const properties = cartItemProperties(cartItem);
  const { price, preDiscountPrice } = cartItemUnitPrices(cartItem, onTapcart);

  return {
    lineItemId: cartItem.id?.toString() ?? "",
    productId: cartItem.product_id?.toString(),
    price,
    preDiscountPrice,
    quantity: cartItem.quantity,
    collections: collections.map((c) => c.title),
    productTags: tags,
    properties: [...properties, ...bundleComponentProperties],
    vendor: cartItem.vendor || "",
    sku: cartItem.sku,
    discounts: cartItem.discounts?.map((d) => ({ name: d.title })) || [],
    isFinalSale: false,
    hasSubscription: !!cartItem.selling_plan_allocation?.selling_plan?.id,
    deliveryProfileId: null,
    requiresShipping: cartItem.requires_shipping ?? true,
    variantMetafields,
  };
}

/** Pairs `/cart.js` lines with Storefront API lines by position; both list the cart in the same order. */
export async function getBundleComponentProperties({
  cartItems,
  storefrontGraphQLClient,
}: {
  cartItems: ShopifyCartItem[];
  storefrontGraphQLClient?: StorefrontClient;
}): Promise<Map<ShopifyCartItem, { [key: string]: string }[]>> {
  const bundleItems = cartItems.filter((item) => item.has_components);
  if (!storefrontGraphQLClient || bundleItems.length === 0) {
    return new Map();
  }
  const lines = await storefrontGraphQLClient
    .cartLineComponentProperties()
    .catch((error: unknown) => {
      log("Failed to fetch bundle component properties", { error });
      return undefined;
    });
  if (!lines) {
    return new Map();
  }
  const aligned =
    lines.length === cartItems.length &&
    lines.every(
      (line, index) => line.variantId === Number(cartItems[index]?.variant_id),
    );
  if (aligned) {
    return new Map(
      cartItems.map((item, index) => [
        item,
        item.has_components ? (lines[index]?.components ?? []) : [],
      ]),
    );
  }

  // Can't tell same-variant bundles apart, so each gets all of their properties.
  log("Bundle lines didn't line up with the Storefront API cart");
  return new Map(
    bundleItems.map((item) => [
      item,
      lines
        .filter((line) => line.variantId === Number(item.variant_id))
        .flatMap((line) => line.components),
    ]),
  );
}

export async function getCoverageInfoFromCoverageCalculators({
  autocheck,
  customerInfo,
  cart,
  shopifyClient,
  redoClient,
  onTapcart,
  storefrontGraphQLClient,
}: {
  autocheck: WidgetAutocheck;
  customerInfo: CustomerInfo;
  cart: ShopifyCart;
  shopifyClient: ExtensionShopifyClient;
  redoClient: ShopifyExtensionClient;
  onTapcart: boolean;
  storefrontGraphQLClient?: StorefrontClient;
}) {
  // Select a per-shopper beta draw from the posterior subsample (if stagecoach is active)
  const mlModel = autocheck?.packageProtection?.coverageMlModel;
  if (mlModel?.id === "stagecoach") {
    const stagecoachConfig = mlModel.config?.stagecoachInferenceConfig;
    if (stagecoachConfig?.posteriorSubsample) {
      const draw = selectBetaDraw({
        posteriorSubsample: stagecoachConfig.posteriorSubsample,
        modelVersionId: stagecoachConfig.modelVersionId,
      });
      // Mutates stagecoachConfig in-place on the cached autocheck object.
      // This is safe because selectBetaDraw is idempotent (persisted in localStorage),
      // and no other code reads betaVector/betaSampleIndex from the autocheck cache.
      if (draw) {
        stagecoachConfig.betaSampleIndex = draw.betaSampleIndex;
        stagecoachConfig.betaVector = draw.betaVector;
      }
    }
  }

  const teamSettings = autocheckToCoverageSettings(autocheck);

  const nonRedoItems = cart.items.filter(
    (item) =>
      !isCoverageFeeProduct({
        product: {
          vendor: item.vendor,
          sku: item.sku,
          title: item.title,
          product_id: item.product_id?.toString(),
        },
        redoCoverageProductIds: new Set(autocheck.coverageProductIds ?? []),
        matchType: CoverageFeeProductMatchType.REDO_ONLY,
      }),
  );
  const bundleComponentPropertiesByItem = await getBundleComponentProperties({
    cartItems: cart.items,
    storefrontGraphQLClient,
  });
  const items = await Promise.all(
    nonRedoItems.map((item) =>
      cartItemToItemInfo({
        cartItem: item,
        autocheck,
        shopifyClient,
        redoClient,
        onTapcart,
        storefrontGraphQLClient,
        bundleComponentProperties: (
          bundleComponentPropertiesByItem.get(item) ?? []
        ).flatMap((properties) => cartItemProperties({ properties })),
      }),
    ),
  );

  const cachedCoveragePrices = coveragePriceCache.getCachedCoveragePrices({
    cartItems: cart.items,
    coverageProductIds: autocheck.coverageProductIds,
  });

  const checkoutProbability = (() => {
    const stored = loadCheckoutProbabilityFromSessionStorage();
    if (isDef(stored?.cumulativeConversionProbability)) {
      // Convert from 0-1 scale to 0-100 scale
      return stored.cumulativeConversionProbability * 100;
    }
    return undefined;
  })();

  const { coverageInfo, coveragePriceResults, eligibleItems } =
    getCoverageInfoFromCalculators({
      team: teamSettings,
      customerInfo,
      items,
      redoCoverageProductIds: autocheck.coverageProductIds ?? [],
      onTapcart,
      cachedProtectionCoveragePrice:
        cachedCoveragePrices?.packageProtection?.price ?? undefined,
      checkoutProbability: checkoutProbability ?? 0,
      returnMoneyType: "cents",
      // The storefront widget does not fetch pre-protected state.
      preProtection: { preProtected: false, prePackageProtected: false },
      coveragePausedDates: autocheck.coveragePausedDates ?? null,
    });

  coveragePriceCache.maybeCacheCoveragePrices({
    cartItems: cart.items,
    coveragePrices: {
      returns: coveragePriceResults.returns.priceResult,
      packageProtection: coveragePriceResults.packageProtection.priceResult,
      finalSaleReturns: coveragePriceResults.finalSaleReturns.priceResult,
    },
    coverageProductIds: autocheck.coverageProductIds,
  });

  // Map ShopifyCartItem (variant_id) to HashableCartItem (variantId)
  // to match the format generateCartHash expects
  const cartHash = generateCartHash(
    cart.items
      .map((item) => ({
        variantId: parseNumericIdFromShopifyId(item.variant_id.toString()),
        productId: item.product_id?.toString(),
        sku: undefined,
        vendor: item.vendor ?? undefined,
        name: item.title ?? undefined,
        quantity: item.quantity,
      }))
      .filter((v) => v.variantId && v.quantity > 0),
    new Set(autocheck.coverageProductIds ?? []),
  );

  const isStagecoachModelActive = mlModel?.id === "stagecoach";
  const ppPriceResult = coveragePriceResults.packageProtection.priceResult;
  const cachedPP = cachedCoveragePrices?.packageProtection;
  // Resolve versioning: inference result → cache → shadow-mode config fallback
  const resolvedVersioning = resolveStagecoachVersioning({
    inferenceResult: {
      modelVersionId: ppPriceResult?.modelVersionId ?? cachedPP?.modelVersionId,
      betaSampleIndex:
        ppPriceResult?.betaSampleIndex ?? cachedPP?.betaSampleIndex,
    },
    mlModel,
  });
  const stagecoachModelMetadata =
    isStagecoachModelActive && resolvedVersioning
      ? {
          modelVersionId: resolvedVersioning.modelVersionId,
          betaSampleIndex: resolvedVersioning.betaSampleIndex,
        }
      : undefined;

  const validCartItems = cart.items.filter(
    (item) =>
      eligibleItems.returns.some(
        (eligibleItem) => eligibleItem.lineItemId === item.id?.toString(),
      ) ||
      eligibleItems.packageProtection.some(
        (eligibleItem) => eligibleItem.lineItemId === item.id?.toString(),
      ) ||
      eligibleItems.finalSaleReturns.some(
        (eligibleItem) => eligibleItem.lineItemId === item.id?.toString(),
      ),
  );

  return {
    coverageInfo,
    stagecoachModelMetadata,
    cartHash,
    validCartItems,
    /** What package protection would insure, in major units; the cart modal splits its price against it. */
    packageProtectionInsuredValue:
      coveragePriceResults.packageProtection.insuredValue ?? 0,
  };
}

export function compareCoverageInfos({
  oldCoverageInfo,
  newCoverageInfo,
  autocheck,
  cart,
  onTapcart,
}: {
  oldCoverageInfo: CoverageInfo;
  newCoverageInfo: CoverageInfo;
  autocheck: WidgetAutocheck;
  cart: ShopifyCart;
  onTapcart: boolean;
}) {
  const ineligibleReasons = {
    returns: newCoverageInfo.returns.reasonIneligible,
    packageProtection: newCoverageInfo.packageProtection.reasonIneligible,
    both: newCoverageInfo.both.reasonIneligible,
  };

  // remove reasonIneligible from newCoverageInfo to avoid comparing the reasonIneligible strings
  newCoverageInfo.returns.reasonIneligible = undefined;
  newCoverageInfo.packageProtection.reasonIneligible = undefined;
  newCoverageInfo.both.reasonIneligible = undefined;

  // Tapcart prices are in dollars; non-Tapcart prices are in cents
  const priceThreshold = onTapcart ? 0.02 : 2;
  const pricesDifferSignificantly =
    Math.abs(oldCoverageInfo.returns.price - newCoverageInfo.returns.price) >
      priceThreshold ||
    Math.abs(
      oldCoverageInfo.packageProtection.price -
        newCoverageInfo.packageProtection.price,
    ) > priceThreshold ||
    Math.abs(oldCoverageInfo.both.price - newCoverageInfo.both.price) >
      priceThreshold;

  const eligibilityDiffers =
    oldCoverageInfo.returns.cartEligible !==
      newCoverageInfo.returns.cartEligible ||
    oldCoverageInfo.returns.isFinalSale !==
      newCoverageInfo.returns.isFinalSale ||
    oldCoverageInfo.packageProtection.cartEligible !==
      newCoverageInfo.packageProtection.cartEligible ||
    oldCoverageInfo.both.cartEligible !== newCoverageInfo.both.cartEligible;

  if (pricesDifferSignificantly || eligibilityDiffers) {
    log("Coverage infos are different", {
      oldCoverageInfo,
      newCoverageInfo,
      ineligibleReasons,
    });
    datadogLog("info", "Coverage infos are different", {
      oldCoverageInfo,
      newCoverageInfo,
      lineItems: cart?.items ?? [],
      ineligibleReasons,
      isTapcart: onTapcart,
    });
    return false;
  }

  log("Coverage infos are the same");
  return true;
}
