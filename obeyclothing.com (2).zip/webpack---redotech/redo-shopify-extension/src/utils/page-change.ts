import { useEffect, useState } from "react";

export function usePageChange() {
  const [pageChange, setPageChange] = useState<symbol | undefined>(undefined);
  useEffect(() => {
    // Handle navigation using Temporal.InstantClick which doesn't actually reload the page.
    if (globalThis.InstantClick) {
      globalThis.InstantClick.on("change", () => {
        setPageChange(Symbol());
      });
    }
    addEventListener("pushstate", () => {
      setPageChange(Symbol());
    });
    addEventListener("popstate", () => {
      setPageChange(Symbol());
    });
  }, []);
  return pageChange;
}
