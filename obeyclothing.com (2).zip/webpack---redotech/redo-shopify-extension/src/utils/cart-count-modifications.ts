import { Currency, isCurrency } from "@redotech/money/currencies";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import { ShopifyCart } from "@redotech/shopify-client/ajax";
import { log } from "../monitoring/log";
import { DEFAULT_CART_COUNT_SELECTOR } from "../site-config/selectors";
import {
  isPackageProtection,
  isRedoItem,
  queryDocumentAndShadowRoot,
} from "../utils";

const DEFAULT_CART_COUNT_MODIFICATION = {
  selector: DEFAULT_CART_COUNT_SELECTOR,
  search: "\\d+",
  replace: "%count%",
};

const getFormatter = (currency: Currency, removeCents: boolean) => {
  return new Intl.NumberFormat("en-US", {
    currency,
    minimumFractionDigits: removeCents ? 0 : 2,
    maximumFractionDigits: removeCents ? 0 : 2,
  });
};

type CartModificationVariables =
  | "cart-subtotal"
  | "cart-total"
  | "valuePlusRedo";

export const applyCartCountModifications = ({
  autocheck,
  cart,
  redoProductPrice,
  redoShouldBeInCart,
}: {
  autocheck: WidgetAutocheck;
  redoProductPrice: number;
  cart: ShopifyCart;
  redoShouldBeInCart: boolean;
}) => {
  const cartCurrency = isCurrency(cart.currency) ? cart.currency : Currency.USD;
  const count = cart.items.reduce((acc, item) => {
    if (
      isRedoItem(item, autocheck.coverageProductIds) ||
      isPackageProtection(item, autocheck.coverageProductIds)
    ) {
      return acc;
    }
    return acc + item.quantity;
  }, 0);

  const line_item_count = cart.items.reduce((acc, item) => {
    if (
      isRedoItem(item, autocheck.coverageProductIds) ||
      isPackageProtection(item, autocheck.coverageProductIds)
    ) {
      return acc;
    }
    return acc + 1;
  }, 0);

  const cartCountModifications =
    (autocheck.hideRedoProduct?.cartCountModifications?.length ?? 0) > 0
      ? autocheck.hideRedoProduct?.cartCountModifications || [
          DEFAULT_CART_COUNT_MODIFICATION,
        ]
      : [DEFAULT_CART_COUNT_MODIFICATION];

  for (const mod of cartCountModifications) {
    const search = new RegExp(mod.search, "g");
    const replace = mod.replace
      .replaceAll("%count%", count.toString())
      .replaceAll("%line_item_count%", line_item_count.toString());
    const elements = queryDocumentAndShadowRoot(mod.selector, autocheck);
    for (const element of elements) {
      element.innerHTML = element.innerHTML.replace(search, replace);
      // Jack's Surf Shop
      if (element.hasAttribute("data-header-cart-count")) {
        element.setAttribute("data-header-cart-count", count.toString());
      }
    }
  }

  const cart_subtotal =
    cart.items.reduce((acc, item) => {
      if (
        isRedoItem(item, autocheck.coverageProductIds) ||
        isPackageProtection(item, autocheck.coverageProductIds)
      ) {
        return acc;
      }
      return acc + (item.line_price || 0);
    }, 0) / 100;
  const redo_cart_subtotal =
    cart.items.reduce((acc, item) => {
      if (isRedoItem(item, autocheck.coverageProductIds)) {
        return acc + (item.line_price || 0);
      }
      return acc;
    }, 0) / 100;
  const redo_subtotal =
    redo_cart_subtotal || (redoShouldBeInCart ? redoProductPrice : 0);

  const cartPriceModifications =
    (autocheck.hideRedoProduct?.cartPriceModifications?.length ?? 0) > 0
      ? autocheck.hideRedoProduct?.cartPriceModifications || []
      : [];

  for (const mod of cartPriceModifications) {
    const search = new RegExp(mod.search, "g");
    const removeCents = mod.replace.includes("round");
    const includeRedo = mod.replace.includes("withRedo");
    const alwaysIncludeRedo = mod.replace.includes("alwaysIncludeRedo");
    const currencyFormatter = getFormatter(cartCurrency, removeCents);

    const removeRedoFromTotal = mod.replace.includes("withoutRedo");

    if (mod.replace.includes("%cart-total%") && cart?.total_price == null) {
      continue;
    }

    const elements = queryDocumentAndShadowRoot(mod.selector, autocheck);
    for (const element of elements) {
      const storedOriginalValue = parseFloat(
        element.getAttribute("data-redo-original-value") || "0",
      );
      const storedWithRedoValue = parseFloat(
        element.getAttribute("data-redo-with-redo-value") || "0",
      );
      const elementValue = element.innerHTML;
      let elementNumber = parseFloat(elementValue.replace(/[^\d.]/g, ""));

      if (
        mod.replace.includes("%valuePlusRedo%") &&
        !redo_subtotal &&
        elementNumber !== storedWithRedoValue &&
        elementNumber !== storedOriginalValue
      ) {
        continue;
      }

      if (!elementNumber || isNaN(elementNumber)) {
        elementNumber = 0;
      }

      // If the element was previously replaced by us but the value has changed, we need to recalculate the value. Otherwise, we can leave it as is and use the existing value.
      let valuePlusRedo = storedWithRedoValue;
      let baselineValue = storedOriginalValue;
      let resetValues = false;
      let displayValue = storedWithRedoValue;
      if (
        elementNumber !== storedWithRedoValue &&
        elementNumber !== storedOriginalValue &&
        redo_subtotal
      ) {
        log(
          "Element with relative cart adjustment has changed since we last modified it. Resetting values",
          {
            prevStoredOriginalValue: storedOriginalValue,
            prevStoredWithRedoValue: storedWithRedoValue,
            newBaselineValue: elementNumber,
            newDisplayValue: valuePlusRedo, // Note: this is not yet formatted
          },
        );
        valuePlusRedo = elementNumber + redo_subtotal;
        baselineValue = elementNumber;
        displayValue = valuePlusRedo;
        resetValues = true;
      } else if (!redo_subtotal) {
        displayValue = baselineValue;
      }

      const variables: Record<CartModificationVariables, string> = {
        "cart-subtotal": currencyFormatter.format(
          cart_subtotal +
            (includeRedo
              ? redo_subtotal
              : alwaysIncludeRedo && redoProductPrice
                ? redoProductPrice
                : 0),
        ),
        "cart-total": currencyFormatter.format(
          removeRedoFromTotal
            ? (cart?.total_price ?? 0) - redo_cart_subtotal
            : (cart?.total_price ?? 0),
        ),
        valuePlusRedo: currencyFormatter.format(displayValue),
      };

      const replace = mod.replace
        .replaceAll(/%cart-subtotal.*%/g, variables["cart-subtotal"])
        .replaceAll(/%cart-total.*%/g, variables["cart-total"])
        .replaceAll(/%valuePlusRedo.*%/g, variables.valuePlusRedo);

      element.innerHTML = element.innerHTML.replace(search, replace);
      if (mod.replace.includes("%valuePlusRedo%") && resetValues) {
        element.setAttribute("data-redo-original-value", String(baselineValue));
        element.setAttribute(
          "data-redo-with-redo-value",
          variables.valuePlusRedo,
        );
      }
    }
  }

  const cart_discount =
    cart.items.reduce((acc, item) => {
      if (
        isRedoItem(item, autocheck.coverageProductIds) ||
        isPackageProtection(item, autocheck.coverageProductIds)
      ) {
        return acc;
      }
      return (
        acc +
        (item.discounts?.reduce((acc2, discount) => {
          return acc2 + discount?.amount || 0;
        }, 0) || 0)
      );
    }, 0) / 100;

  const cartDiscountModifications =
    (autocheck.hideRedoProduct?.cartDiscountModifications?.length ?? 0) > 0
      ? autocheck.hideRedoProduct?.cartDiscountModifications || []
      : [];

  for (const mod of cartDiscountModifications) {
    const search = new RegExp(mod.search, "g");
    const removeCents = mod.replace.includes("round");
    const replace = mod.replace.replaceAll(
      /%cart-discount.*%/g,
      getFormatter(cartCurrency, removeCents).format(cart_discount),
    );
    const elements = queryDocumentAndShadowRoot(mod.selector, autocheck);
    for (const element of elements) {
      element.innerHTML = element.innerHTML.replace(search, replace);
    }
  }
};

export const applyCartCountModificationsWithRetries = async ({
  autocheck,
  cart,
  redoProductPrice,
  redoShouldBeInCart,
  signal,
}: {
  autocheck: WidgetAutocheck;
  redoProductPrice: number;
  cart: ShopifyCart;
  redoShouldBeInCart: boolean;
  signal?: AbortSignal;
}) => {
  if (signal?.aborted) {
    return;
  }

  for (let i = 0; i < 5; i++) {
    try {
      if (signal?.aborted) {
        return;
      }
      applyCartCountModifications({
        autocheck,
        cart,
        redoProductPrice,
        redoShouldBeInCart,
      });
      await new Promise((resolve) => setTimeout(resolve, (i + 1) * 150));
    } catch (error) {
      console.error("error applying cart count modifications", error);
    }
  }
};
