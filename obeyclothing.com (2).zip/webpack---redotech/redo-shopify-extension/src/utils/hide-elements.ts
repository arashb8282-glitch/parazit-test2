import { parseGid } from "@redotech/redo-shopify-common/gid-utils";
import { isAttachmentStrategyUsingCheckoutButtons } from "@redotech/redo-storefront-common/attachment-strategy";
import {
  feeProduct,
  ResolvedWidgetPlacement,
  WidgetAutocheck,
  WidgetConfig,
  WidgetFees,
} from "@redotech/redo-storefront-widget-common/widget";
import { ShopifyCart } from "@redotech/shopify-client/ajax";
import { useEffect, useState } from "react";
import { StorefrontCoverageHtmlElement } from "../cart-app";
import { log } from "../monitoring/log";
import {
  DEFAULT_CHECKOUT_BUTTONS_SELECTOR,
  DEFAULT_PRODUCT_SELECTORS,
} from "../site-config/selectors";
import { getCartShadowRoot } from "../utils";
import {
  getPlacedTogglesKey,
  hasValidButtonSelectors,
} from "./checkout-button-utils";

export const useHideRedoProductAndCheckoutButtons = (
  autocheck: WidgetAutocheck,
  fees: WidgetFees,
  toggles: {
    redoHtmlElements: StorefrontCoverageHtmlElement[];
    widgetConfig?: WidgetConfig;
  }[],
  cart: ShopifyCart | undefined,
) => {
  const [foundValidButtonSelectors, setFoundValidButtonSelectors] = useState<
    boolean | undefined
  >(undefined);
  const togglesKey = getPlacedTogglesKey(toggles);
  const redoIndex = cart?.items.findIndex((item) =>
    [
      Number(fees.packageProduct?.productId),
      Number(fees.returnProduct?.productId),
      Number(fees.bothProduct?.productId),
    ].includes(Number(item.product_id)),
  );

  useEffect(() => {
    if (!autocheck.attachmentStrategy) {
      return;
    }

    if (
      !isAttachmentStrategyUsingCheckoutButtons[autocheck.attachmentStrategy]
    ) {
      return;
    }

    const valid = hasValidButtonSelectors(toggles);
    if (foundValidButtonSelectors !== valid) {
      setFoundValidButtonSelectors(valid);
    }
  }, [toggles, autocheck.attachmentStrategy, foundValidButtonSelectors]);

  useEffect(() => {
    if (
      !fees ||
      !autocheck.hideRedoProduct?.enabled ||
      autocheck.disableRedoForCustomer
    ) {
      return;
    }

    if (
      redoStorefront?.type !== "commercecloud" &&
      isAttachmentStrategyUsingCheckoutButtons[autocheck.attachmentStrategy] &&
      foundValidButtonSelectors === false
    ) {
      return;
    }

    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    const products = [
      fees.packageProduct,
      fees.returnProduct,
      fees.bothProduct,
    ].filter(Boolean) as feeProduct[];

    const productSelectorTemplates = autocheck.hideRedoProduct.productSelector
      ? [autocheck.hideRedoProduct.productSelector]
      : DEFAULT_PRODUCT_SELECTORS;

    const productAndCheckoutButtonSelectorTemplates = [
      ...productSelectorTemplates,
      ...getCheckoutButtonSelectorTemplatesIfReady({
        autocheck,
        foundValidButtonSelectors: foundValidButtonSelectors ?? false,
      }),
    ];

    const selector = expandProductSelector({
      selectorTemplates: productAndCheckoutButtonSelectorTemplates,
      vars: {
        products,
        redoIndex: redoIndex ? String(redoIndex + 1) : "1000000",
      },
    });
    if (!selector) {
      return;
    }
    const hideElementsCss = `${selector} {
      display: none !important;
      max-width: 0 !important;
      max-height: 0 !important;
      overflow: hidden !important;
      padding: 0 !important;
      margin: 0 !important;
      border: 0 !important;
      visibility: hidden !important;
    }`.replaceAll("\n", "");
    const style = document.createElement("style");
    style.innerText = hideElementsCss;
    document.head.append(style);

    // If the cart is inside a shadow root, append the styles there
    const shadowRoot = getCartShadowRoot(autocheck);

    let shadowStyle: HTMLStyleElement | undefined = undefined;
    if (shadowRoot) {
      shadowStyle = document.createElement("style");
      shadowStyle.innerText = hideElementsCss;
      shadowRoot.append(shadowStyle);
    }

    return () => {
      style.remove();
      shadowStyle?.remove();
    };
  }, [
    fees,
    autocheck,
    autocheck.hideRedoProduct?.enabled,
    foundValidButtonSelectors,
    cart,
    redoIndex,
    togglesKey,
  ]);
};

const isValidCssSelector = (selector: string): boolean => {
  if (!selector) {
    return false;
  }
  try {
    // Some selector templates like .%handle% can generate an invalid selector like .163 if the handle is a number
    document.createDocumentFragment().querySelector(selector);
    return true;
  } catch (error) {
    return false;
  }
};

const cssSelectorMatchesElement = (
  autocheck: WidgetAutocheck,
  placement: ResolvedWidgetPlacement,
  widgetConfig: WidgetConfig,
): boolean => {
  try {
    if (placement.shadowRootSelector || widgetConfig.shadowRootSelector) {
      const shadowRoot = getCartShadowRoot(
        autocheck,
        placement.shadowRootSelector || widgetConfig.shadowRootSelector,
      );
      if (shadowRoot) {
        const element = shadowRoot.querySelector(
          placement.cssSelector || DEFAULT_CHECKOUT_BUTTONS_SELECTOR,
        );
        if (element) {
          return true;
        }
        if (!widgetConfig.placeInsideAndOutsideShadowRoot) {
          return !!element;
        }
      }
    }
    const element = document.querySelector(
      placement.cssSelector || DEFAULT_CHECKOUT_BUTTONS_SELECTOR,
    );
    return !!element;
  } catch (error) {
    return false;
  }
};

interface ProductSelectorVars {
  products: feeProduct[];
  redoIndex: string;
}
const expandProductSelector = ({
  selectorTemplates,
  vars,
}: {
  selectorTemplates: string[];
  vars: ProductSelectorVars;
}): string => {
  const { products, redoIndex } = vars;

  const selectors = new Set<string>();

  for (const selectorTemplate of selectorTemplates) {
    for (const product of products) {
      if (!product) {
        continue;
      }
      const variants =
        product.variants.length >= 1 ? product.variants : [{ variant_id: "" }];
      for (const variant of variants) {
        selectors.add(
          selectorTemplate
            .replaceAll("%handle%", product.handle || "")
            ?.replaceAll("%product_id%", String(product.productId) || "")
            ?.replaceAll(
              "%variant_id%",
              product.variants?.length >= 1
                ? parseGid(String(variant.variant_id))
                : "",
            )
            ?.replaceAll("%index%", redoIndex),
        );
      }
    }
  }
  const selector = Array.from(selectors).filter(isValidCssSelector).join(", ");
  return selector;
};

const getCheckoutButtonSelectorTemplatesIfReady = ({
  autocheck,
  foundValidButtonSelectors,
}: {
  autocheck: WidgetAutocheck;
  foundValidButtonSelectors: boolean;
}): string[] => {
  const widgetHidingElementSelectorsSet = new Set<string>();

  for (const config of autocheck.widgetConfigs ?? []) {
    for (const placement of config.placement?.list ?? []) {
      if (
        placement.hidingElementSelector &&
        cssSelectorMatchesElement(autocheck, placement, config)
      ) {
        widgetHidingElementSelectorsSet.add(placement.hidingElementSelector);
      }
    }
  }

  const widgetHidingElementSelectors = Array.from(
    widgetHidingElementSelectorsSet,
  );

  const hidingSelector =
    widgetHidingElementSelectors.length > 0
      ? widgetHidingElementSelectors.join(", ")
      : autocheck.hideRedoProduct?.checkoutButtonSelector;
  if (
    hidingSelector &&
    !isValidCssSelector(hidingSelector) &&
    !hidingSelector.includes("%")
  ) {
    log(
      `Invalid hide checkout buttons selector configured: ${hidingSelector} - this may result in double checkout buttons.`,
    );
  }

  if (
    isAttachmentStrategyUsingCheckoutButtons[autocheck.attachmentStrategy] &&
    foundValidButtonSelectors !== false
  ) {
    return [hidingSelector || DEFAULT_CHECKOUT_BUTTONS_SELECTOR];
  }
  return [];
};
