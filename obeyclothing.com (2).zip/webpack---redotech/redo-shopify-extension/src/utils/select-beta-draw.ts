import type { StagecoachPosteriorSubsampleEntry } from "@redotech/redo-coverage-common/coverage-ml/model/stagecoach-schema";

// localStorage keys for persisting the per-shopper beta draw across visits.
// Duplicated from @redotech/web-utils/shared-conf because the extension bundle
// does not depend on that package.
const STAGECOACH_MODEL_VERSION_ID_KEY = "redo.stagecoach_model_version_id";
const STAGECOACH_BETA_SAMPLE_INDEX_KEY = "redo.stagecoach_beta_sample_index";
const STAGECOACH_BETA_VECTOR_KEY = "redo.stagecoach_beta_vector";

export interface SelectedBetaDraw {
  betaSampleIndex: number;
  betaVector: number[];
}

export function selectBetaDraw({
  posteriorSubsample,
  modelVersionId,
}: {
  posteriorSubsample: StagecoachPosteriorSubsampleEntry[];
  modelVersionId: string;
}): SelectedBetaDraw | undefined {
  if (posteriorSubsample.length === 0) {
    console.warn(
      "Stagecoach: empty posteriorSubsample, skipping beta draw selection",
    );
    return undefined;
  }

  // Return visit with same model version — use saved draw.
  try {
    const savedModelVersionId = localStorage.getItem(
      STAGECOACH_MODEL_VERSION_ID_KEY,
    );
    if (savedModelVersionId === modelVersionId) {
      const savedIndex = localStorage.getItem(STAGECOACH_BETA_SAMPLE_INDEX_KEY);
      const savedVector = localStorage.getItem(STAGECOACH_BETA_VECTOR_KEY);
      if (savedIndex !== null && savedVector !== null) {
        try {
          const parsedIndex = Number(savedIndex);
          const parsedVector: number[] = JSON.parse(savedVector);
          if (
            Number.isInteger(parsedIndex) &&
            Array.isArray(parsedVector) &&
            parsedVector.length > 0
          ) {
            return { betaSampleIndex: parsedIndex, betaVector: parsedVector };
          }
        } catch {
          // JSON.parse failed on betaVector — fall through to re-randomize
        }
      }
    }
  } catch {
    // fall through to random draw without persistence
  }

  // First visit or model retrain — pick random draw from subsample
  const selectedBetaSample =
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    posteriorSubsample[Math.floor(Math.random() * posteriorSubsample.length)]!;

  try {
    localStorage.setItem(STAGECOACH_MODEL_VERSION_ID_KEY, modelVersionId);
    localStorage.setItem(
      STAGECOACH_BETA_SAMPLE_INDEX_KEY,
      String(selectedBetaSample.betaSampleIndex),
    );
    localStorage.setItem(
      STAGECOACH_BETA_VECTOR_KEY,
      JSON.stringify(selectedBetaSample.betaVector),
    );
  } catch {
    // localStorage unavailable — draw won't persist across renders.
  }

  return {
    betaSampleIndex: selectedBetaSample.betaSampleIndex,
    betaVector: selectedBetaSample.betaVector,
  };
}
