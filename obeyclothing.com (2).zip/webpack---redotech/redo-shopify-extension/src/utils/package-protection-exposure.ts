import {
  getSessionStorageWithExpiry,
  setSessionStorageWithExpiry,
} from "@redotech/redo-web/utils/session-storage-wrapper";

const PP_EXPOSURE_SESSION_CACHE_KEY = "redo.packageProtectionExposureFired";
const PP_EXPOSURE_SESSION_CACHE_TTL_HOURS = 24;

export interface PackageProtectionExposurePayload {
  anonymousId: string;
  treatmentId?: string;
  isStagecoachArm: boolean;
  modelVersionId?: string;
  betaSampleIndex?: number;
  packageProtectionPriceDollars?: number;
  returnsCoveragePriceDollars?: number;
  cartValue: number;
  cartItemCount: number;
  cartHash: string;
  checkoutProbability: number | undefined;
}

export interface PackageProtectionExposureKey {
  cartHash: string;
  treatmentId?: string;
  modelVersionId?: string;
  betaSampleIndex?: number;
}

export function buildExposureCacheKey(
  key: PackageProtectionExposureKey,
): string {
  return `${key.cartHash}_${key.treatmentId ?? "none"}_${key.modelVersionId ?? "none"}_${key.betaSampleIndex ?? "none"}`;
}

export function shouldFireExposure(key: PackageProtectionExposureKey): boolean {
  const firedKeys: string[] =
    getSessionStorageWithExpiry(PP_EXPOSURE_SESSION_CACHE_KEY) ?? [];
  return !firedKeys.includes(buildExposureCacheKey(key));
}

export function markExposureFired(key: PackageProtectionExposureKey): void {
  const firedKeys: string[] =
    getSessionStorageWithExpiry(PP_EXPOSURE_SESSION_CACHE_KEY) ?? [];
  firedKeys.push(buildExposureCacheKey(key));
  setSessionStorageWithExpiry(
    PP_EXPOSURE_SESSION_CACHE_KEY,
    firedKeys,
    PP_EXPOSURE_SESSION_CACHE_TTL_HOURS,
  );
}
