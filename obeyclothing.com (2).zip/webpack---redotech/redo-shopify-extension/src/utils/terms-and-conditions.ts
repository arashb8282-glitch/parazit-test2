import { querySelectorSafe } from "./query-selector-safe";

export function shouldBlockCheckout(termsCheckboxSelector?: string): boolean {
  if (!termsCheckboxSelector) {
    return false;
  }

  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  const checkboxElement = querySelectorSafe(
    document,
    termsCheckboxSelector,
  ) as HTMLInputElement | null;

  if (!checkboxElement) {
    return false;
  }

  if (checkboxElement.checked == null) {
    return false;
  }

  return !checkboxElement.checked;
}
