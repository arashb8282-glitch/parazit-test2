import { ShopifyCart, ShopifyCartItem } from "@redotech/shopify-client/ajax";

/** Line item properties Purple Dot sets on pre-order lines it checks out itself. */
const PURPLE_DOT_RELEASE_ID_PROPERTY = "__releaseId";
const PURPLE_DOT_CHECKOUT_REQUIRED_PROPERTY = "__pdCheckoutRequired";

function isPurpleDotPreorderItem(item: ShopifyCartItem): boolean {
  return (
    !!item.properties?.[PURPLE_DOT_RELEASE_ID_PROPERTY] &&
    item.properties[PURPLE_DOT_CHECKOUT_REQUIRED_PROPERTY] === "yes"
  );
}

/** Purple Dot owns checkout navigation (from the cart page) when the cart holds a pre-order. */
export function isPurpleDotPreorderCart(
  cart: Pick<ShopifyCart, "items"> | undefined,
): boolean {
  return !!cart?.items.some(isPurpleDotPreorderItem);
}
