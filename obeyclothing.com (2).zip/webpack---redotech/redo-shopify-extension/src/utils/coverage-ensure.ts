import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import type { ShopifyCart } from "@redotech/shopify-client/ajax";
import { isRedoItem } from "../utils";

function coveragePricingSignature(
  cart: ShopifyCart,
  coverageProductIds: string[] | undefined,
) {
  const items = cart.items
    .filter((item) => !isRedoItem(item, coverageProductIds))
    .map((item) =>
      JSON.stringify([
        item.product_id,
        item.quantity,
        item.line_price,
        item.original_line_price,
        item.requires_shipping,
        item.sku,
        item.vendor,
      ]),
    )
    .sort();

  return JSON.stringify({ currency: cart.currency, items });
}

export function coveragePricingInputsChanged(
  pricedCart: ShopifyCart,
  freshCart: ShopifyCart,
  coverageProductIds: string[] | undefined,
): boolean {
  return (
    coveragePricingSignature(freshCart, coverageProductIds) !==
    coveragePricingSignature(pricedCart, coverageProductIds)
  );
}

/** True if the customer forcibly removed coverage after this ensure cycle started. */
export function redoForciblyRemovedDuringEnsurePromise(
  autocheck: Pick<WidgetAutocheck, "respectForcedRemovalDuringEnsure">,
  currentForcedRemovalAt: number,
  removalSnapshot: number,
): boolean {
  return (
    autocheck.respectForcedRemovalDuringEnsure !== false &&
    currentForcedRemovalAt !== removalSnapshot
  );
}
