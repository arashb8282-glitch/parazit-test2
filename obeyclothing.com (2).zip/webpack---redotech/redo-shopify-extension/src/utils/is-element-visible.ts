/**
 * Check if an element is visible in the DOM (not hidden via CSS).
 * Use checkVisibility if available, fall back to offsetParent for older browsers.
 */
export function isElementVisible(element: Element): boolean {
  if (typeof element.checkVisibility === "function") {
    return element.checkVisibility({
      checkVisibilityCSS: true,
      visibilityProperty: true,
    });
  }

  const view = element.ownerDocument?.defaultView;
  if (!view) {
    return false;
  }
  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  const htmlElement = element as HTMLElement;
  const style = view.getComputedStyle(htmlElement);

  if (
    style.position !== "fixed" &&
    style.display !== "contents" &&
    // Accessing offsetParent forces a reflow, so we avoid it if we can.
    !htmlElement.offsetParent
  ) {
    // Element is hidden via display:none or parent is hidden
    return false;
  }

  if (style.display === "none" || style.visibility === "hidden") {
    return false;
  }

  return true;
}
