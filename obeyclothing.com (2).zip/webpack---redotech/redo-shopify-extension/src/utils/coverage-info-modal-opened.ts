import { isMongoCoverageTreatmentId } from "@redotech/redo-ab-testing-common/coverage-treatment-id";
import { RedoEmittedDomEvent } from "../dom-events";
import { getStoredTreatmentId } from "../utils";
import {
  dispatchStorefrontCoverageEvent,
  readEligibleAnonymousId,
} from "./storefront-coverage-event";

const INFO_MODAL_METRIC_SESSION_KEY = "redo_info_modal_metric_at";
const INFO_MODAL_METRIC_CHECKPOINT_MS = 2 * 60 * 60 * 1000;

export interface CoverageInfoModalOpenedPayload {
  anonymousId: string;
  treatmentId?: string;
  eventId: string;
  skipTestMetric: boolean;
}

function shouldSendTestMetric(hasTreatment: boolean): boolean {
  if (!hasTreatment) {
    return false;
  }
  try {
    const lastSentAt = Number(
      sessionStorage.getItem(INFO_MODAL_METRIC_SESSION_KEY),
    );
    const now = Date.now();
    if (
      Number.isFinite(lastSentAt) &&
      now - lastSentAt < INFO_MODAL_METRIC_CHECKPOINT_MS
    ) {
      return false;
    }
    sessionStorage.setItem(INFO_MODAL_METRIC_SESSION_KEY, String(now));
  } catch {
    return false;
  }
  return true;
}

export function recordCoverageInfoModalOpened(): void {
  const anonymousId = readEligibleAnonymousId();
  if (!anonymousId) {
    return;
  }

  const treatmentId = getStoredTreatmentId();
  // The legacy test metric is keyed by Mongo treatment; storefront A/B arms use customer events.
  const sendTestMetric = shouldSendTestMetric(
    isMongoCoverageTreatmentId(treatmentId),
  );
  dispatchStorefrontCoverageEvent<CoverageInfoModalOpenedPayload>(
    RedoEmittedDomEvent.CoverageInfoModalOpened,
    {
      anonymousId,
      treatmentId,
      eventId: crypto.randomUUID(),
      skipTestMetric: !sendTestMetric,
    },
  );
}
