/** The Bundler app owns checkout navigation (kit assembly) when it is installed. */
export function isSiteUsingBundlerApp(): boolean {
  return (
    typeof globalThis.bndlr !== "undefined" && !!globalThis.bndlr?.goToCheckout
  );
}
