import { useEffect, useRef, useState } from "react";
import { LeakyDebounce } from "./leaky-debounce";

export interface UseLeakyDebounceOpts {
  outputHz: number;
}

export function useLeakyDebounce<T>(
  value: T,
  { outputHz }: UseLeakyDebounceOpts,
): T {
  const [output, setOutput] = useState(value);
  const bucketRef = useRef<LeakyDebounce<T> | null>(null);
  const mountedRef = useRef(false);

  if (bucketRef.current === null) {
    bucketRef.current = new LeakyDebounce(value, outputHz, setOutput);
  }

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    const bucket = bucketRef.current!;
    bucket.start();
    return () => bucket.stop();
  }, []);

  useEffect(() => {
    if (!mountedRef.current) {
      mountedRef.current = true;
      return;
    }
    bucketRef.current?.trigger(value);
  }, [value]);

  return output;
}
