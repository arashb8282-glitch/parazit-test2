import { InsertionPosition } from "@redotech/redo-storefront-common/insertion-position";
import { WidgetElementType } from "@redotech/redo-storefront-common/widget-config";
import {
  ResolvedWidgetPlacement,
  WidgetAutocheck,
  WidgetConfig,
} from "@redotech/redo-storefront-widget-common/widget";
import { assertNever } from "@redotech/util/type";
import { StorefrontCoverageHtmlElement } from "../cart-app";
import { log } from "../monitoring/log";
import { TAPCART_SELECTOR } from "../product-page";
import { getCartShadowRoot } from "../utils";
import { resolveStandardTogglePlacement } from "./resolve-widget-placements";

// The resolver lives in its own DOM-free module so unit tests can import it
// without dragging in `cart-app` (which extends `HTMLElement` at module load).
// eslint-disable-next-line @redotech/no-re-exports -- TODO: remove re-export, update all import sites
export type { ResolvedWidgetPlacement } from "@redotech/redo-storefront-widget-common/widget";
// eslint-disable-next-line @redotech/no-re-exports -- TODO: remove re-export, update all import sites
export {
  resolveStandardTogglePlacement,
  resolveWidgetPlacements,
} from "./resolve-widget-placements";

type DocOrShadow = ShadowRoot | Document;

/**
 * Find the DOM elements a (widget, placement) pair should anchor to. The
 * placement is expected to be fully resolved (see `resolveWidgetPlacements`)
 * — `cssSelector` is read directly with no fallback.
 */
export function getReactElementFromPlacement({
  widgetConfig,
  placement,
  autocheck,
}: {
  widgetConfig: WidgetConfig;
  placement: ResolvedWidgetPlacement;
  autocheck: WidgetAutocheck;
}): Element[] {
  try {
    const shadowRoot = getCartShadowRoot(
      autocheck,
      placement?.shadowRootSelector ?? widgetConfig.shadowRootSelector,
    );

    const docElements: DocOrShadow[] = [];

    if (shadowRoot) {
      docElements.push(shadowRoot);

      if (widgetConfig.placeInsideAndOutsideShadowRoot) {
        docElements.push(document);
      }
    } else {
      docElements.push(document);
    }

    const foundElements: Element[] = [];

    for (const ele of docElements) {
      foundElements.push(
        ...Array.from(ele.querySelectorAll(placement.cssSelector)),
      );
    }

    return foundElements;
  } catch (error) {
    log(error, "Error getting React element from placement");
    return [];
  }
}

export function getPlacedRedoToggle({
  container,
  widgetConfig,
  anyRedoToggle,
}: {
  container: HTMLElement | Element | null;
  widgetConfig?: WidgetConfig;
  anyRedoToggle: boolean;
}): StorefrontCoverageHtmlElement | undefined {
  if (!container) {
    return undefined;
  }

  try {
    if (anyRedoToggle) {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      return container?.querySelector(
        StorefrontCoverageHtmlElement.TAG,
      ) as StorefrontCoverageHtmlElement;
    }

    const toggles = container.querySelectorAll(
      StorefrontCoverageHtmlElement.TAG,
    ) as NodeListOf<StorefrontCoverageHtmlElement> | undefined;

    if (toggles) {
      for (const toggleElement of toggles) {
        if (toggleElement.toggleClass === widgetConfig?.elementType) {
          return toggleElement;
        }
      }
    }
  } catch (error) {
    log(error, "Error getting placed Redo toggle");
    return undefined;
  }
  return undefined;
}

export function getPlacedCustomElement(
  customElementTag: string,
  container: Element,
  placementType: InsertionPosition,
): Element | null {
  const checkDirectChildren = (parent: Element): Element | null => {
    for (const child of parent.children) {
      if (child.tagName.toLowerCase() === customElementTag.toLowerCase()) {
        return child;
      }
    }
    return null;
  };

  switch (placementType) {
    case InsertionPosition.BEFORE:
    case InsertionPosition.AFTER:
      return container.parentElement
        ? checkDirectChildren(container.parentElement)
        : null;

    case InsertionPosition.PREPEND:
    case InsertionPosition.APPEND:
      return checkDirectChildren(container);

    default:
      assertNever(placementType);
      return null;
  }
}

export function hasCustomElementPlaced(
  customElementTag: string,
  selector: string,
  placementType: InsertionPosition,
): boolean {
  const elements = document.querySelectorAll(selector);
  for (const element of elements) {
    if (getPlacedCustomElement(customElementTag, element, placementType)) {
      return true;
    }
  }
  return false;
}

export function widgetSortOrder({
  widget,
  placement,
}: {
  widget?: WidgetConfig;
  placement: ResolvedWidgetPlacement;
}): number {
  const widgetType: WidgetElementType | undefined = widget?.elementType;
  if (!widgetType) {
    return 0;
  }

  const sign =
    placement.insertionPosition === InsertionPosition.APPEND ? -1 : 1;
  switch (widgetType) {
    case WidgetElementType.BOTH_CHECKOUT_BUTTONS:
      return 1 * sign;
    case WidgetElementType.INFO_CARD:
      return 2 * sign;
    case WidgetElementType.NON_COVERAGE_CHECKOUT_BUTTON:
      return 3 * sign;
    case WidgetElementType.COVERAGE_CHECKOUT_BUTTON:
      return 4 * sign;
    case WidgetElementType.SINGLE_TOGGLE:
      return 5 * sign;
    case WidgetElementType.DOUBLE_TOGGLE:
      return 6 * sign;
    case WidgetElementType.CART_CARD:
      return 7 * sign;
    case WidgetElementType.CHECKOUT_BUTTON:
      return 8 * sign;
    case WidgetElementType.CART_CHECKBOX:
      return 9 * sign;
    default:
      assertNever(widgetType);
      return 0;
  }
}

/**
 * WidgetMatchingSelectorTargets
 *
 * Before Redo's custom elements have been created, but after having found all
 * of the matching elements that Redo should be placed by. `placement` is the
 * fully-resolved (no nullish fields) placement that produced these elements;
 * `widgetConfig` is the original widget config it came from, and is absent
 * for the standard cart-toggle path which has no widget config.
 */
export interface WidgetMatchingSelectorTargets {
  elements: Element[];
  placementIndex: number;
  widgetConfig?: WidgetConfig;
  placement: ResolvedWidgetPlacement;
}

/**
 * PlacedWidgetHtmlElements
 *
 * After Redo's custom elements are placed for each widget type. Carries the
 * same `widgetConfig` + `placement` pair that produced them.
 */
export interface PlacedWidgetHtmlElements {
  redoHtmlElements: StorefrontCoverageHtmlElement[];
  placementIndex: number;
  matchedSelectors: (string | undefined)[];
  widgetConfig?: WidgetConfig;
  placement: ResolvedWidgetPlacement;
}

export const getPlacementLocationsForStandardToggles = ({
  autocheck,
  onTapcart,
}: {
  autocheck: WidgetAutocheck;
  onTapcart: boolean;
}): WidgetMatchingSelectorTargets[] => {
  const placement = resolveStandardTogglePlacement(autocheck);
  try {
    const shadowRoot = getCartShadowRoot(autocheck);
    const shadowRootSelector = shadowRoot
      ? autocheck.cartToggle.cartShadowRootSelector
      : undefined;
    const shadowToggleSelector =
      autocheck.cartToggle.cartToggleShadowRootSelector;
    if (shadowToggleSelector) {
      return [
        {
          placementIndex: 0,
          elements: Array.from(
            document.querySelectorAll(
              onTapcart ? TAPCART_SELECTOR : placement.cssSelector,
            ),
          ),
          placement,
        },
        {
          placementIndex: 1,
          elements: shadowRoot
            ? Array.from(
                shadowRoot.querySelectorAll(
                  onTapcart ? TAPCART_SELECTOR : shadowToggleSelector,
                ),
              )
            : [],
          placement: {
            ...placement,
            cssSelector: shadowToggleSelector,
            shadowRootSelector,
          },
        },
      ];
    }
    return [
      {
        placementIndex: 0,
        elements: Array.from(
          (shadowRoot ?? document).querySelectorAll(
            onTapcart ? TAPCART_SELECTOR : placement.cssSelector,
          ),
        ),
        placement: {
          ...placement,
          ...(shadowRootSelector ? { shadowRootSelector } : {}),
        },
      },
    ];
  } catch (error) {
    log(error, "Error getting placement locations for standard toggles");
    return [{ elements: [], placement, placementIndex: 0 }];
  }
};
