import { WidgetElementType } from "@redotech/redo-storefront-common/widget-config";
import { WidgetConfig } from "@redotech/redo-storefront-widget-common/widget";
import type { ShopifyCart } from "@redotech/shopify-client/ajax";
import { StorefrontCoverageHtmlElement } from "../cart-app";

// Stable useEffect dep for toggles: the array gets a new identity every
// renderElementsHandler call, but reused toggle elements keep their ids.
export function getPlacedTogglesKey(
  toggles: {
    redoHtmlElements: StorefrontCoverageHtmlElement[];
    widgetConfig?: WidgetConfig;
  }[],
): string {
  return toggles
    .map(
      ({ redoHtmlElements, widgetConfig }) =>
        `${widgetConfig?.elementType ?? ""}:${redoHtmlElements
          .map((element) => element.id)
          .join(",")}`,
    )
    .join(";");
}

export function hasValidButtonSelectors(
  toggles: {
    redoHtmlElements: StorefrontCoverageHtmlElement[];
    widgetConfig?: WidgetConfig;
  }[],
): boolean {
  const usingWidgetConfigs = toggles.some(
    ({ redoHtmlElements, widgetConfig }) => !!widgetConfig,
  );

  if (!usingWidgetConfigs) {
    return false;
  }

  const checkoutButtonElements = toggles.filter(
    ({ redoHtmlElements, widgetConfig }) => {
      return (
        widgetConfig?.elementType === WidgetElementType.BOTH_CHECKOUT_BUTTONS ||
        widgetConfig?.elementType ===
          WidgetElementType.COVERAGE_CHECKOUT_BUTTON ||
        widgetConfig?.elementType ===
          WidgetElementType.NON_COVERAGE_CHECKOUT_BUTTON
      );
    },
  );

  // bail only if EVERY checkout button is hidden — a hidden copy in a closed cart shouldn't block the visible one
  if (
    checkoutButtonElements.every(({ redoHtmlElements }) =>
      redoHtmlElements.every((element) => {
        return window.getComputedStyle(element).display === "none";
      }),
    )
  ) {
    return false;
  }

  if (
    checkoutButtonElements.every(
      ({ redoHtmlElements, widgetConfig }) => redoHtmlElements.length === 0,
    )
  ) {
    return false;
  }

  return true;
}

// Grand total minus the Redo product line (product mode) and minus the attached
// coverage fee (custom-fee mode), so the copy's `coveragePrice + cartTotal`
// counts coverage once. Product-mode carts never carry `coverage_fee`.
export function commerceCloudMerchandiseTotal(
  cart: Pick<ShopifyCart, "total_price" | "coverage_fee"> | undefined,
  redoInCartSubtotal: number,
): number {
  return (
    (cart?.total_price ?? 0) - redoInCartSubtotal - (cart?.coverage_fee ?? 0)
  );
}
