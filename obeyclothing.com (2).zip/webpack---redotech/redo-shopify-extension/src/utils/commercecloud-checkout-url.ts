/** `us`, `en`, `us-en`, `en_US` — one or two 2-letter tokens. */
const LOCALE_LIKE = /^[a-z]{2}(?:[-_][a-z]{2})?$/i;

const tokens = (value: string) =>
  value.toLowerCase().split(/[-_]/).filter(Boolean);

/**
 * Checkout URL for a Commerce Cloud storefront: the cartridge-provided one, or
 * a locale-prefixed guess like `https://shop.com/us-en/cart` -> `.../checkout`.
 */
export function resolveCommerceCloudCheckoutUrl({
  configuredUrl,
  origin,
  pathname,
  knownLocale,
}: {
  configuredUrl?: string;
  origin: string;
  pathname: string;
  knownLocale?: string;
}): string | undefined {
  if (configuredUrl?.trim()) {
    return configuredUrl.trim();
  }
  const segment = pathname.split("/").find(Boolean);
  if (!segment || !LOCALE_LIKE.test(segment)) {
    return undefined;
  }
  // Formats differ freely (`en_US` vs `us-en` vs `us`), so compare token sets.
  // `default` is SFCC's placeholder locale and tells us nothing.
  const known = knownLocale ? tokens(knownLocale) : [];
  const consistent =
    !known.length ||
    known.includes("default") ||
    tokens(segment).every((token) => known.includes(token));
  return consistent
    ? `${origin.replace(/\/$/, "")}/${segment}/checkout`
    : undefined;
}
