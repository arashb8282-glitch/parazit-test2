/**
 * Leaky-bucket debounce. Allows a burst of up to `outputHz` immediate emits,
 * then rate-limits further triggers to at most `outputHz` emits per second.
 * Idle time refills the bucket so future bursts are permitted again.
 */
export class LeakyDebounce<T> {
  private requiresUpdate = false;
  private bucketFill: number;
  private latestValue: T;
  private intervalId: ReturnType<typeof setInterval> | null = null;

  constructor(
    initialValue: T,
    readonly outputHz: number,
    private readonly emit: (value: T) => void,
  ) {
    this.bucketFill = outputHz;
    this.latestValue = initialValue;
  }

  start(): void {
    if (this.intervalId !== null) {
      return;
    }
    this.intervalId = setInterval(() => this.tick(), 1000 / this.outputHz);
  }

  stop(): void {
    if (this.intervalId === null) {
      return;
    }
    clearInterval(this.intervalId);
    this.intervalId = null;
  }

  trigger(value: T): void {
    this.latestValue = value;
    this.requiresUpdate = true;

    if (this.bucketFill > 0) {
      this.requiresUpdate = false;
      this.emit(value);
    }

    this.bucketFill = Math.max(0, this.bucketFill - 1);
  }

  private tick(): void {
    if (this.requiresUpdate) {
      this.requiresUpdate = false;
      this.emit(this.latestValue);
    } else {
      this.bucketFill = Math.min(this.outputHz, this.bucketFill + 1);
    }
  }
}
