import debounce from "lodash/debounce";

type DomChangeCallback = () => void;

interface DomObserverInstance {
  registerCallback: (callback: DomChangeCallback) => void;
  unregisterCallback: (callback: DomChangeCallback) => void;
  destroy: () => void;
}

const DEBOUNCE_CHANGES_MS = 100;
const MAX_DEBOUNCE_MS = 300;

let globalDomObserver: DomObserverInstance | null = null;

/**
 * Registered callbacks are run by way of a debounced requestAnimationFrame
 * call to avoid blocking rendering.
 */
export const createRenderSafeDomObserver = (): DomObserverInstance => {
  if (globalDomObserver) {
    return globalDomObserver;
  }

  const callbacks = new Set<DomChangeCallback>();
  let observer: MutationObserver | null = null;
  let pendingFrame: number | null = null;

  const runCallbacks = () => {
    pendingFrame = null;
    for (const callback of callbacks) {
      callback();
    }
  };

  const scheduleCallbacks = () => {
    if (pendingFrame === null) {
      pendingFrame = requestAnimationFrame(runCallbacks);
    }
  };

  const debouncedNotifyCallbacks = debounce(
    scheduleCallbacks,
    DEBOUNCE_CHANGES_MS,
    { maxWait: MAX_DEBOUNCE_MS, leading: true, trailing: false },
  );

  const startObserver = () => {
    if (observer) {
      return;
    }

    observer = new MutationObserver(() => {
      debouncedNotifyCallbacks();
    });

    observer.observe(document.body, { childList: true, subtree: true });
  };

  const stopObserver = () => {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    debouncedNotifyCallbacks.cancel();
    if (pendingFrame !== null) {
      cancelAnimationFrame(pendingFrame);
      pendingFrame = null;
    }
  };

  const registerCallback = (callback: DomChangeCallback) => {
    callbacks.add(callback);
    if (callbacks.size === 1) {
      startObserver();
    }
  };

  const unregisterCallback = (callback: DomChangeCallback) => {
    callbacks.delete(callback);
    if (callbacks.size === 0) {
      stopObserver();
    }
  };

  const destroy = () => {
    stopObserver();
    callbacks.clear();
    globalDomObserver = null;
  };

  globalDomObserver = { registerCallback, unregisterCallback, destroy };

  return globalDomObserver;
};

export const getRenderSafeDomObserver = (): DomObserverInstance => {
  return createRenderSafeDomObserver();
};

type AncestorMatchFunction = (element: Element) => boolean;
interface IsDescendantOfProps {
  element: Element;
  ancestor: Element | AncestorMatchFunction;
  maxDepth?: number;
}

export const isDescendantOf = ({
  element,
  ancestor,
  maxDepth = 20,
}: IsDescendantOfProps) => {
  let currentElement: Element | null = element;
  let curDepth = 0;
  while (currentElement) {
    if (curDepth > maxDepth) {
      return false;
    } else if (typeof ancestor === "function" && ancestor(currentElement)) {
      return true;
    } else if (typeof ancestor !== "function" && currentElement === ancestor) {
      return true;
    }
    currentElement = currentElement.parentElement;
    curDepth++;
  }
  return false;
};
