import type { CoverageTreatmentAttribution } from "@redotech/redo-ab-testing-common/coverage-treatment-id";
import { coverageAttributionFromTreatmentId } from "@redotech/redo-ab-testing-common/coverage-treatment-id";
import type { CoverageWidgetRenderedPayload } from "@redotech/redo-customer-event-common/events/coverage-widget-rendered";
import { storefrontShopperIdentity } from "@redotech/redo-marketing-browser-sdk/storefront-identity";
import { fnv1a32Hex } from "@redotech/redo-storefront-common/cart-hash";
import {
  CART_PLACEMENT_CONTAINER_TYPES,
  type CartPlacementContainerType,
} from "@redotech/redo-storefront-common/widget-config";
import {
  getLocalStorageWithExpiry,
  setLocalStorageWithExpiry,
} from "@redotech/redo-web/utils/local-storage-wrapper";
import { checkoutPlacementContainerTypeForElement } from "../coverage-builder/checkout-cart-surface";
import { RedoEmittedDomEvent } from "../dom-events";
import { log } from "../monitoring/log";
import { getStoredTreatmentId } from "../utils";
import { isElementVisible } from "./is-element-visible";
import {
  dispatchStorefrontCoverageEvent,
  readEligibleAnonymousId,
} from "./storefront-coverage-event";

const RENDERED_FLAG_KEY_PREFIX = "redo_cart_widget_rendered:";
const RENDERED_FLAG_EXPIRY_HOURS = 24;
const VISIBILITY_ATTRIBUTES = [
  "class",
  "style",
  "open",
  "hidden",
  "aria-hidden",
];
const VISIBILITY_END_EVENTS = ["transitionend", "animationend"] as const;

/** Cart widgets that rendered hidden (e.g. inside a closed drawer), waiting to become visible. */
const hiddenWidgets = new Set<Element>();
/** The pending widgets and their ancestors across shadow roots: only their changes trigger a recheck. */
let watchedAncestors = new Set<Element>();
let visibilityObserver: MutationObserver | undefined;
let recheckScheduled = false;

const WIDGET_RENDERED_STOREFRONT_TYPES: readonly (string | undefined)[] = [
  "shopify",
  "bigcommerce",
  "commercecloud",
];

function isWidgetRenderedStorefront(): boolean {
  return WIDGET_RENDERED_STOREFRONT_TYPES.includes(
    globalThis.redoStorefront?.type,
  );
}

function cartSurfaceOf(
  element: Element,
): CartPlacementContainerType | undefined {
  const surface = checkoutPlacementContainerTypeForElement(element);
  return CART_PLACEMENT_CONTAINER_TYPES.find(
    (cartSurface) => cartSurface === surface,
  );
}

function renderedFlagKey(dedupKey: string): string {
  return `${RENDERED_FLAG_KEY_PREFIX}${dedupKey}`;
}

function isRenderedFlagSet(dedupKey: string): boolean {
  return !!getLocalStorageWithExpiry(renderedFlagKey(dedupKey));
}

/** True the first time this session sees the key; sets the flag before the caller sends. */
function claimRenderedFlag(dedupKey: string): boolean {
  if (isRenderedFlagSet(dedupKey)) {
    return false;
  }
  setLocalStorageWithExpiry(
    renderedFlagKey(dedupKey),
    true,
    RENDERED_FLAG_EXPIRY_HOURS,
  );
  return true;
}

interface SessionContext {
  anonymousId: string;
  sessionId: string;
  attribution: CoverageTreatmentAttribution;
}

/** Everything that is the same for all widgets of a render; undefined when nothing can be sent. */
function readSessionContext(): SessionContext | undefined {
  if (!isWidgetRenderedStorefront()) {
    return undefined;
  }
  const attribution = coverageAttributionFromTreatmentId(
    getStoredTreatmentId(),
  );
  if (!attribution) {
    return undefined;
  }
  const sessionId = storefrontShopperIdentity().getSessionId();
  const anonymousId = sessionId ? readEligibleAnonymousId() : undefined;
  return sessionId && anonymousId
    ? { anonymousId, sessionId, attribution }
    : undefined;
}

function dedupKeyOf(
  { sessionId, attribution }: SessionContext,
  cartSurface: CartPlacementContainerType,
): string {
  return `${sessionId}:${attribution.coverageTreatmentId}:${cartSurface}`;
}

function sendOnce(
  context: SessionContext,
  cartSurface: CartPlacementContainerType,
): void {
  const { anonymousId, sessionId, attribution } = context;
  const dedupKey = dedupKeyOf(context, cartSurface);
  if (!claimRenderedFlag(dedupKey)) {
    return;
  }
  dispatchStorefrontCoverageEvent<CoverageWidgetRenderedPayload>(
    RedoEmittedDomEvent.CoverageWidgetRendered,
    {
      anonymousId,
      sessionId,
      cartSurface,
      ...attribution,
      eventId: fnv1a32Hex(dedupKey),
    },
  );
}

function composedAncestorsOf(element: Element): Element[] {
  const ancestors: Element[] = [];
  let current: Element | null = element;
  while (current) {
    ancestors.push(current);
    const root: Node | undefined = current.parentElement
      ? undefined
      : current.getRootNode();
    current =
      current.parentElement ??
      (root instanceof window.ShadowRoot ? root.host : null);
  }
  return ancestors;
}

function onVisibilityEnd(event: Event): void {
  if (
    event.target instanceof window.Element &&
    watchedAncestors.has(event.target)
  ) {
    scheduleHiddenWidgetsRecheck();
  }
}

/** Observes exactly the ancestors of the pending widgets; observes nothing once none are pending. */
function syncWatchedAncestors(): void {
  visibilityObserver?.disconnect();
  watchedAncestors = new Set([...hiddenWidgets].flatMap(composedAncestorsOf));
  if (watchedAncestors.size === 0) {
    visibilityObserver = undefined;
    for (const eventName of VISIBILITY_END_EVENTS) {
      document.removeEventListener(eventName, onVisibilityEnd, true);
    }
    return;
  }
  visibilityObserver ??= new window.MutationObserver(
    scheduleHiddenWidgetsRecheck,
  );
  for (const ancestor of watchedAncestors) {
    visibilityObserver.observe(ancestor, {
      attributes: true,
      attributeFilter: VISIBILITY_ATTRIBUTES,
    });
  }
  for (const eventName of VISIBILITY_END_EVENTS) {
    document.addEventListener(eventName, onVisibilityEnd, true);
  }
}

function recheckHiddenWidgets(): void {
  recheckScheduled = false;
  try {
    const context = readSessionContext();
    for (const element of hiddenWidgets) {
      const cartSurface = cartSurfaceOf(element);
      if (
        !context ||
        !cartSurface ||
        !element.isConnected ||
        isRenderedFlagSet(dedupKeyOf(context, cartSurface))
      ) {
        hiddenWidgets.delete(element);
      } else if (isElementVisible(element)) {
        hiddenWidgets.delete(element);
        sendOnce(context, cartSurface);
      }
    }
  } catch (error) {
    hiddenWidgets.clear();
    log("Error rechecking hidden coverage widgets", error);
  }
  syncWatchedAncestors();
}

function scheduleHiddenWidgetsRecheck(): void {
  if (!recheckScheduled) {
    recheckScheduled = true;
    window.requestAnimationFrame(recheckHiddenWidgets);
  }
}

/**
 * Drawers usually open by changing an attribute on an ancestor of the widget
 * or finishing a transition there, without a manager render, so the hidden
 * widget is rechecked on those.
 */
function watchHiddenWidget(element: Element): void {
  hiddenWidgets.add(element);
  syncWatchedAncestors();
}

function reportElement(element: Element, context: SessionContext): void {
  const cartSurface = cartSurfaceOf(element);
  if (
    !cartSurface ||
    !element.isConnected ||
    isRenderedFlagSet(dedupKeyOf(context, cartSurface))
  ) {
    return;
  }
  if (isElementVisible(element)) {
    sendOnce(context, cartSurface);
  } else {
    watchHiddenWidget(element);
  }
}

/**
 * Reports the visibly rendered coverage widgets of one render that sit on a
 * cart surface, once per session, treatment and surface. A hidden widget is
 * reported when it later becomes visible. The per-session checks run first so
 * merchants without a treatment pay almost nothing. Runs in the render path,
 * so it never throws.
 */
export function recordCoverageWidgetsRendered(
  elements: readonly Element[],
): void {
  try {
    const context = elements.length > 0 ? readSessionContext() : undefined;
    if (context) {
      for (const element of elements) {
        reportElement(element, context);
      }
    }
  } catch (error) {
    log("Error recording coverage widget rendered", error);
  }
}
