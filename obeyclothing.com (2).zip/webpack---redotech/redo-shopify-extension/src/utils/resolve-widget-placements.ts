import { InsertionPosition } from "@redotech/redo-storefront-common/insertion-position";
import {
  ResolvedWidgetPlacement,
  WidgetAutocheck,
  WidgetConfig,
} from "@redotech/redo-storefront-widget-common/widget";
import {
  DEFAULT_RIC_PLACEMENT_SELECTOR,
  DEFAULT_TOGGLE_PLACEMENT,
  DEFAULT_TOGGLE_SELECTOR,
} from "../site-config/selectors";

interface PlacementAutocheck {
  cartToggle: Pick<
    WidgetAutocheck["cartToggle"],
    "cartToggleSelector" | "cartTogglePlacement"
  >;
}

/**
 * Resolve the DOM placements a widget config should render into, with every
 * field fully populated. Callers can read `placement.cssSelector` and
 * `placement.insertionPosition` directly without further fallback chains.
 *
 * Resolution cascade (first defined wins, then fixed defaults):
 *  - cssSelector:        placement.cssSelector → widget.placementSelector →
 *                        DEFAULT_RIC_PLACEMENT_SELECTOR
 *  - insertionPosition:  placement.insertionPosition →
 *                        widget.insertionPosition → DEFAULT_TOGGLE_PLACEMENT
 *
 * When `widgetConfig.placement.list` is non-empty, returns one entry per
 * `PlacementDescriptor`; otherwise returns a single entry built from the
 * legacy `placementSelector` / `insertionPosition` fields. The widget config
 * is never copied or mutated — callers carry it through alongside the
 * resolved placement.
 */
export function resolveWidgetPlacements({
  widgetConfig,
}: {
  widgetConfig: WidgetConfig;
}): ResolvedWidgetPlacement[] {
  const list = widgetConfig.placement?.list;
  if (list && list.length > 0) {
    return list.map((p) =>
      resolveWidgetPlacementDefaults({
        cssSelector: p.cssSelector,
        insertionPosition: p.insertionPosition,
        shadowRootSelector: p.shadowRootSelector,
      }),
    );
  }
  return [
    resolveWidgetPlacementDefaults({
      cssSelector: widgetConfig.placementSelector,
      insertionPosition: widgetConfig.insertionPosition,
      shadowRootSelector: widgetConfig.shadowRootSelector,
    }),
  ];
}

/**
 * Resolve the placement for the standard cart-toggle path, which has no
 * widget config — only the autocheck-level cart-toggle defaults and the
 * fixed toggle defaults.
 */
export function resolveStandardTogglePlacement(
  autocheck: PlacementAutocheck,
): ResolvedWidgetPlacement {
  return {
    cssSelector:
      autocheck.cartToggle.cartToggleSelector || DEFAULT_TOGGLE_SELECTOR,
    insertionPosition:
      autocheck.cartToggle.cartTogglePlacement || DEFAULT_TOGGLE_PLACEMENT,
  };
}

function resolveWidgetPlacementDefaults({
  cssSelector,
  insertionPosition,
  shadowRootSelector,
}: {
  cssSelector: string | undefined;
  insertionPosition: InsertionPosition | undefined;
  shadowRootSelector: string | undefined;
}): ResolvedWidgetPlacement {
  return {
    cssSelector: cssSelector || DEFAULT_RIC_PLACEMENT_SELECTOR,
    insertionPosition: insertionPosition || DEFAULT_TOGGLE_PLACEMENT,
    shadowRootSelector: shadowRootSelector || undefined,
  };
}
