export enum EnsurePromiseAction {
  ADD = "add",
  REMOVE = "remove",
  IGNORE = "ignore",
}

export const RETURN_TOGGLE_STATE_KEY = "return-toggle-state";
export const PROTECTION_TOGGLE_STATE_KEY = "protection-toggle-state";
export const SINGLE_TOGGLE_STATE_KEY = "single-toggle-state";
export const SELLING_PLANS_ID = "redo-selling-plans";
export const REDO_REMOVED_REDO = "redo-remove-redo";
