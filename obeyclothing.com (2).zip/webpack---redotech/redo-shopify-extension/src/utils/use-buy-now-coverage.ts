import { GidType, toGid } from "@redotech/redo-shopify-common/gid-utils";
import { getLocalStorageWithExpiry } from "@redotech/redo-web/utils/local-storage-wrapper";
import {
  getSessionStorageWithExpiry,
  setSessionStorageWithExpiry,
} from "@redotech/redo-web/utils/session-storage-wrapper";
import {
  BUY_NOW_COVERAGE_VARIANT_KEY_PREFIX,
  PRICING_TEST_TREATMENT_ID_LOCAL_STORAGE_KEY,
} from "@redotech/redo-web/utils/shared-conf";
import { useCallback, useEffect, useRef } from "react";
import { StorefrontClient } from "../client/storefront";
import { log } from "../monitoring/log";
import { getShopPayProductOnClickEvent } from "./checkout-buttons/on-click-logic";

// Selectors for various wallet payment buttons
const WALLET_SELECTORS = [
  "shop-pay-wallet-button", // Shopify Shop Pay
  "shopify-amazon-pay-button", // Shopify Amazon Pay
  "shopify-paypal-button", // Shopify PayPal
  "shopify-google-pay-button", // Shopify Google Pay
  "button.rebuy-cart__shop-pay-button", // Rebuy Parent Container that holds all Rebuy Buy Now Buttons
];

type AsyncEventHandler = (
  event: React.MouseEvent | React.TouchEvent,
) => Promise<void>;

interface UseBuyNowCoverageProps {
  shouldInterceptBuyNow?: boolean;
  /** Read at click time, so a handler that was since cleared is never run. */
  getBuyNowCoverageHandler: () => AsyncEventHandler | null;
  storefrontClient?: StorefrontClient;
  getBuyNowCoverageVariantId: () => string | null;
  buyNowCustomCss?: string;
}

/**
 * Extracts variant ID and quantity from the product form
 */
export const extractProductFormData = (element?: HTMLElement) => {
  let elementToUse = element;

  if (!elementToUse) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    elementToUse = document.querySelector(
      WALLET_SELECTORS.join(","),
    ) as HTMLElement;
  }

  if (!elementToUse) {
    log("no wallet button found");
    return { variantId: 0, quantity: 1 };
  }

  const form = elementToUse.closest('form[action="/cart/add"]');
  if (!form) {
    log("Form with action='/cart/add' not found");
    return { variantId: 0, quantity: 1 };
  }

  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  const variantInput = form.querySelector('[name="id"]') as HTMLInputElement;
  // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
  const quantityInput = form.querySelector(
    'input[name="quantity"]',
  ) as HTMLInputElement;
  const urlParams = new URLSearchParams(window.location.search);
  const variantUrlParam = urlParams.get("variant");

  const variantId = variantInput?.value
    ? variantInput.value
    : variantUrlParam || "0";
  const quantity = quantityInput ? parseInt(quantityInput.value, 10) : 1;

  return { variantId, quantity };
};

function buyNowCoverageVariantKey(
  variantId: string | number | undefined,
): string | undefined {
  return variantId
    ? `${BUY_NOW_COVERAGE_VARIANT_KEY_PREFIX}${variantId}`
    : undefined;
}

export function cacheBuyNowCoverageVariantId(
  variantId: string | number | undefined,
  coverageVariantId: string,
): void {
  const key = buyNowCoverageVariantKey(variantId);
  if (key) {
    setSessionStorageWithExpiry(key, coverageVariantId);
  }
}

export function getCachedBuyNowCoverageVariantId(
  variantId: string | number | undefined,
): string | null {
  const key = buyNowCoverageVariantKey(variantId);
  return key ? getSessionStorageWithExpiry(key) : null;
}

/**
 * Buys the product now through Shop Pay with coverage for its variant.
 */
async function runShopPayProductBuyNow({
  clickedElement,
  event,
  storefrontClient,
  coverageVariantId,
}: {
  clickedElement: HTMLElement;
  event: React.MouseEvent | React.TouchEvent;
  storefrontClient: StorefrontClient;
  coverageVariantId: string;
}) {
  const { variantId, quantity } = extractProductFormData(clickedElement);

  if (!variantId && !quantity) {
    return;
  }

  event.stopPropagation();

  const pricingTestTreatmentId = getLocalStorageWithExpiry(
    PRICING_TEST_TREATMENT_ID_LOCAL_STORAGE_KEY,
  );

  const shopPayHandler = getShopPayProductOnClickEvent({
    storefrontClient,
    productVariantId: toGid(GidType.PRODUCT_VARIANT, variantId),
    productVariantQuantity: quantity,
    redoProductVariantId: toGid(GidType.PRODUCT_VARIANT, coverageVariantId),
    pricingTestTreatmentId: pricingTestTreatmentId ?? undefined,
  });

  await shopPayHandler();
}

export const useBuyNowCoverage = ({
  shouldInterceptBuyNow = false,
  getBuyNowCoverageHandler,
  storefrontClient,
  getBuyNowCoverageVariantId,
  buyNowCustomCss,
}: UseBuyNowCoverageProps) => {
  const storefrontClientRef = useRef(storefrontClient);
  useEffect(() => {
    storefrontClientRef.current = storefrontClient;
  }, [storefrontClient]);

  /**
   * Handles click events on wallet buttons
   */
  const handleWalletClick = useCallback(
    async (e: Event) => {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      const clickedElement = e.target as HTMLElement;
      const relevantButton = clickedElement.closest(
        WALLET_SELECTORS.join(","),
      ) as HTMLElement | null;

      if (!relevantButton) {
        return;
      }

      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      const eventToPass = e as unknown as React.MouseEvent | React.TouchEvent;

      // Check if this is a Shop Pay button on a product page
      const isShopPayButton =
        relevantButton.tagName === "SHOP-PAY-WALLET-BUTTON";
      const pageType = relevantButton.getAttribute("page-type");
      const isShopPayProductButton = isShopPayButton && pageType === "product";

      // Handle Shop Pay product page buttons specially
      if (isShopPayProductButton) {
        const buyNowCoverageVariantId = getBuyNowCoverageVariantId();
        if (storefrontClientRef.current && buyNowCoverageVariantId) {
          await runShopPayProductBuyNow({
            clickedElement,
            event: eventToPass,
            storefrontClient: storefrontClientRef.current,
            coverageVariantId: buyNowCoverageVariantId,
          });
        }
        return;
      }

      // Handle other wallet buttons with the provided coverage handler
      const buyNowCoverageHandler = getBuyNowCoverageHandler();
      if (buyNowCoverageHandler) {
        await buyNowCoverageHandler(eventToPass);
      }
    },
    [getBuyNowCoverageHandler, getBuyNowCoverageVariantId],
  );

  useEffect(() => {
    if (shouldInterceptBuyNow) {
      document.body.addEventListener("click", handleWalletClick, {
        capture: true,
      });
    }

    return () => {
      document.body.removeEventListener("click", handleWalletClick, {
        capture: true,
      });
    };
  }, [shouldInterceptBuyNow, handleWalletClick]);

  // Inject custom CSS for Buy Now coverage
  useEffect(() => {
    if (shouldInterceptBuyNow && buyNowCustomCss) {
      const styleId = "redo-buy-now-custom-css";

      // Check if style element already exists
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      let styleElement = document.getElementById(styleId) as HTMLStyleElement;

      if (!styleElement) {
        // Create new style element
        styleElement = document.createElement("style");
        styleElement.id = styleId;
        styleElement.type = "text/css";
        document.body.append(styleElement);
      }

      // Update the CSS content
      styleElement.textContent = buyNowCustomCss;

      // Cleanup function
      return () => {
        const element = document.getElementById(styleId);
        if (element) {
          element.remove();
        }
      };
    }

    return () => {};
  }, [shouldInterceptBuyNow, buyNowCustomCss]);
};
