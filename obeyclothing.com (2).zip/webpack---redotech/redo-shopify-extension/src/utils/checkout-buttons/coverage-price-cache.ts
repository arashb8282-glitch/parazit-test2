import { CoveragePriceResult } from "@redotech/redo-coverage-common";
import { generateCartHash } from "@redotech/redo-coverage-common/coverage-ml/generate-cart-hash";
import {
  CoveragePriceCacheValue,
  REDO_METADATA_ATTRIBUTE_KEY,
  RedoMetadata,
  StagecoachInferenceConfigForCheckout,
  parseCoveragePriceCache,
  parseRedoMetadata,
} from "@redotech/redo-storefront-common/cart-attributes";
import { ShopifyCart, ShopifyCartItem } from "@redotech/shopify-client/ajax";
import { parseNumericIdFromShopifyId } from "@redotech/shopify-util/id";
import { log } from "../../monitoring/log";

const COVERAGE_PRICE_CACHE_KEY = "redo.coverage_price_cache";

function getCache(): RedoMetadata["coveragePriceCache"] | undefined {
  try {
    const rawCoveragePriceCache = localStorage.getItem(
      COVERAGE_PRICE_CACHE_KEY,
    );
    return rawCoveragePriceCache
      ? parseCoveragePriceCache(rawCoveragePriceCache)
      : undefined;
  } catch (error) {
    log("Error getting coverage price cache", { error });
    return undefined;
  }
}

function setCache({ cache }: { cache: RedoMetadata["coveragePriceCache"] }) {
  try {
    if (cache) {
      localStorage.setItem(COVERAGE_PRICE_CACHE_KEY, JSON.stringify(cache));
    }
  } catch (error) {
    log("Error setting coverage price cache", { error });
  }
}

function getItem({
  key,
}: {
  key: string;
}): CoveragePriceCacheValue | undefined {
  const coveragePriceCache = getCache();
  return coveragePriceCache?.cache?.[key];
}

// Bounds the ids stamped onto the redo_metadata cart attribute so a team with
// a long history of recreated coverage products can't bloat the attribute.
const MAX_STAMPED_COVERAGE_PRODUCT_IDS = 25;

function boundedCoverageProductIds(
  coverageProductIds: string[] | undefined,
): string[] | undefined {
  if (!coverageProductIds) {
    return undefined;
  }
  if (coverageProductIds.length > MAX_STAMPED_COVERAGE_PRODUCT_IDS) {
    log("Truncating coverage product ids stamped on cart attribute", {
      total: coverageProductIds.length,
      kept: MAX_STAMPED_COVERAGE_PRODUCT_IDS,
    });
    return coverageProductIds.slice(0, MAX_STAMPED_COVERAGE_PRODUCT_IDS);
  }
  return coverageProductIds;
}

function setItem({
  key,
  value,
  coverageProductIds,
}: {
  key: string;
  value: CoveragePriceCacheValue;
  coverageProductIds: string[] | undefined;
}) {
  try {
    const currentCoveragePriceCache = getCache();
    const existingValue = currentCoveragePriceCache?.cache?.[key];
    const alreadyCached =
      currentCoveragePriceCache?.latestCartHash === key &&
      existingValue?.packageProtection?.price ===
        value.packageProtection?.price &&
      existingValue?.packageProtection?.modelVersionId ===
        value.packageProtection?.modelVersionId &&
      existingValue?.packageProtection?.betaSampleIndex ===
        value.packageProtection?.betaSampleIndex &&
      existingValue?.returns?.price === value.returns?.price &&
      existingValue?.finalSaleReturns?.price === value.finalSaleReturns?.price;

    if (alreadyCached) {
      return;
    }

    const updatedCoveragePriceCache = {
      ...currentCoveragePriceCache,
      cache: { ...currentCoveragePriceCache?.cache, [key]: value },
      lastUpdatedTimestamp: Date.now(),
      latestCartHash: key,
      coverageProductIds:
        boundedCoverageProductIds(coverageProductIds) ??
        currentCoveragePriceCache?.coverageProductIds,
    };

    setCache({ cache: updatedCoveragePriceCache });
  } catch (error) {
    log("Error setting coverage price cache", { error });
  }
}

function getCachedCoveragePrices({
  cartItems,
  coverageProductIds,
}: {
  cartItems: ShopifyCartItem[];
  coverageProductIds: string[] | undefined;
}): CoveragePriceCacheValue | undefined {
  const cartHash = generateCartHash(
    cartItems
      .map((item) => ({
        variantId: parseNumericIdFromShopifyId(item.variant_id.toString()),
        productId: item.product_id?.toString(),
        sku: undefined,
        vendor: item.vendor ?? undefined,
        name: item.title ?? undefined,
        quantity: item.quantity,
      }))
      .filter((v) => v.variantId && v.quantity > 0),
    new Set(coverageProductIds ?? []),
  );

  return getItem({ key: cartHash });
}

function maybeCacheCoveragePrices({
  cartItems,
  coveragePrices,
  coverageProductIds,
}: {
  cartItems: ShopifyCartItem[];
  coveragePrices: {
    returns: CoveragePriceResult | undefined;
    packageProtection: CoveragePriceResult | undefined;
    finalSaleReturns: CoveragePriceResult | undefined;
  };
  coverageProductIds: string[] | undefined;
}) {
  // Update even if it comes from the coverage ML model cache so we always
  // have the latest cart hash saved.
  if (
    coveragePrices.packageProtection?.source === "mlModel" ||
    coveragePrices.packageProtection?.source === "mlModelCache"
  ) {
    const cartHash = generateCartHash(
      cartItems
        .map((item) => ({
          variantId: parseNumericIdFromShopifyId(item.variant_id.toString()),
          productId: item.product_id?.toString(),
          vendor: item.vendor ?? undefined,
          name: item.title ?? undefined,
          sku: undefined,
          quantity: item.quantity,
        }))
        .filter((v) => v.variantId && v.quantity > 0),
      new Set(coverageProductIds ?? []),
    );
    setItem({
      key: cartHash,
      coverageProductIds,
      value: {
        ...(coveragePrices.returns
          ? { returns: { price: coveragePrices.returns.price } }
          : {}),
        ...(coveragePrices.packageProtection
          ? {
              packageProtection: {
                price: coveragePrices.packageProtection.price,
                modelVersionId: coveragePrices.packageProtection.modelVersionId,
                betaSampleIndex:
                  coveragePrices.packageProtection.betaSampleIndex,
              },
            }
          : {}),
        ...(coveragePrices.finalSaleReturns
          ? {
              finalSaleReturns: {
                price: coveragePrices.finalSaleReturns.price,
              },
            }
          : {}),
      } satisfies CoveragePriceCacheValue,
    });
  }
}

/**
 * If the cart coverage price cache is ahead of the localStorage coverage price
 * cache, update the localStorage coverage price cache to the latest value.
 */
function syncCartCoveragePriceCacheWithLocalStorage({
  cart,
}: {
  cart: ShopifyCart;
}) {
  try {
    const rawRedoMetadata = cart.attributes?.[REDO_METADATA_ATTRIBUTE_KEY];
    if (!rawRedoMetadata) {
      return;
    }
    const redoMetadata = parseRedoMetadata(rawRedoMetadata);
    if (!redoMetadata.coveragePriceCache) {
      return;
    }

    const cartCoveragePriceCache = redoMetadata.coveragePriceCache;
    const localStorageCoveragePriceCache = getCache();

    const localStorageCacheIsOutdated =
      localStorageCoveragePriceCache &&
      cartCoveragePriceCache.lastUpdatedTimestamp >
        localStorageCoveragePriceCache.lastUpdatedTimestamp;
    if (localStorageCacheIsOutdated) {
      setCache({ cache: cartCoveragePriceCache });
    }
  } catch (error) {
    log("Error syncing cart coverage price cache with localStorage", { error });
  }
}

/**
 * Sets the cache-wide stagecoach inference config. Called by the coverage
 * calculator after resolving the beta draw. Persists in localStorage and
 * flows to checkout via redo_metadata for recomputing on cache miss.
 */
function setStagecoachConfigInCache(
  config: StagecoachInferenceConfigForCheckout | undefined,
) {
  try {
    const currentCache = getCache();
    if (!currentCache) {
      return;
    }
    setCache({ cache: { ...currentCache, stagecoachInferenceConfig: config } });
  } catch (error) {
    log("Error setting stagecoach config on cache", { error });
  }
}

export const coveragePriceCache = {
  getCache,
  getCachedCoveragePrices,
  maybeCacheCoveragePrices,
  setStagecoachConfigInCache,
  syncCartCoveragePriceCacheWithLocalStorage,
};
