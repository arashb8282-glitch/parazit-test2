import { PRICING_TEST_TREATMENT_KEY } from "@redotech/redo-shopify-common/cart";
import {
  AttachmentStrategy,
  doesAttachmentStrategyUseCustomFee,
} from "@redotech/redo-storefront-common/attachment-strategy";
import {
  buildHsaIntentCartAttributes,
  MERCHANDISE_OUT_OF_STOCK_CODE,
  REDO_METADATA_ATTRIBUTE_KEY,
  REDO_OPTED_IN_FROM_CART_ATTRIBUTE_KEY,
  RedoMetadata,
  StagecoachDecisionMetadata,
} from "@redotech/redo-storefront-common/cart-attributes";
import { REDO_CART_TOKEN_STORAGE_KEY } from "@redotech/redo-storefront-web/cache/keys";
import {
  defaultTermsAndConditionsBlockedMessage,
  WidgetAutocheck,
} from "@redotech/redo-storefront-widget-common/widget";
import { getSessionStorageWithExpiry } from "@redotech/redo-web/utils/session-storage-wrapper";
import {
  ExtensionShopifyClient,
  ShopifyAjaxClient,
  ShopifyCart,
  ShopifyCartItem,
} from "@redotech/shopify-client/ajax";
import { StorefrontClient } from "../../client/storefront";
import { getInternalAppStatusEmitter } from "../../config";
import { log } from "../../monitoring/log";
import { snapshotVisitorBeforeCheckout } from "../../monitoring/visitor-observation";
import { renderCart } from "../../site-config/render-cart";
import { STANDARD_CHECKOUT_BUTTON } from "../../site-config/selectors";
import { isRedoItem, RedoProductToSell } from "../../utils";
import { isSiteUsingBundlerApp } from "../bundler-app";
import { safeCartAdd, safeUpdateCartAttribute } from "../cart";
import { resolveCommerceCloudCheckoutUrl } from "../commercecloud-checkout-url";
import {
  ensureCoverageFee,
  holdBackgroundReload,
} from "../coverage-fee-ensure";
import type { RedoCheckoutButtonClickedEvent } from "../internal-app-events";
import { isPurpleDotPreorderCart } from "../purple-dot";
import { querySelectorSafe } from "../query-selector-safe";
import { EnsurePromiseAction } from "../signals";
import { appendSkipShopPay, applySkipShopPay } from "../skip-shop-pay";
import { shouldBlockCheckout } from "../terms-and-conditions";
import {
  shouldUseCartPermalink,
  tryCartPermalinkCheckout,
} from "./cart-permalink-checkout";
import { coveragePriceCache } from "./coverage-price-cache";
import { appendDiscountCode } from "./discount-codes";
import { syncMysteryGift } from "./mystery-gift";

interface ShopPayEventParams {
  storefrontClient: StorefrontClient;
  productVariantId: string;
  productVariantQuantity: number;
  redoProductVariantId: string;
  pricingTestTreatmentId?: string;
}

interface CheckoutButtonItemsToAdd {
  items: (Partial<ShopifyCartItem> & {
    product_id: string | number;
    variant_id: string | number;
  })[];
}

const FALLBACK_CHECKOUT_TIMEOUT_MS = 6500;

/** Where a freshly-created buy-now cart is sent. */
export type CheckoutDestination = "shop-pay" | "hsa-standard";

interface CreateCartAndCheckoutParams {
  storefrontClient: StorefrontClient;
  /** The product line(s) to buy now. The coverage line is appended by this
   *  function when `coverageVariantId` is set. */
  productLines: { merchandiseId: string; quantity: number }[];
  /** Redo coverage variant gid to attach, or null to attach no coverage. */
  coverageVariantId: string | null;
  /** Extra cart attributes (e.g. the HSA payment-priority flag). */
  extraAttributes?: { key: string; value: string }[];
  destination: CheckoutDestination;
  pricingTestTreatmentId?: string;
}

/**
 * Creates a new cart with the given product line(s) — plus the Redo coverage
 * line when `coverageVariantId` is set — and navigates to checkout. The
 * `shop-pay` destination targets Shop Pay's accelerated checkout (the Shop Pay
 * buy-now flow); `hsa-standard` unconditionally skips Shop Pay so the HSA/FSA
 * payment method is reachable on the standard checkout.
 */
export async function createCartAndCheckout({
  storefrontClient,
  productLines,
  coverageVariantId,
  extraAttributes = [],
  destination,
  pricingTestTreatmentId,
}: CreateCartAndCheckoutParams): Promise<void> {
  const fallbackUrl = () =>
    destination === "shop-pay"
      ? applySkipShopPay(`${location.origin}/checkout`)
      : appendSkipShopPay(`${location.origin}/checkout`);

  try {
    const addCoverage = !!coverageVariantId;
    const lines = productLines.map((line) => ({ ...line, attributes: [] }));
    if (coverageVariantId) {
      lines.push({
        merchandiseId: coverageVariantId,
        quantity: 1,
        attributes: [],
      });
    }

    const attributes = getCoverageCartAttributes({
      cart: undefined,
      addCoverage,
    });

    if (pricingTestTreatmentId) {
      attributes.push({
        key: PRICING_TEST_TREATMENT_KEY,
        value: pricingTestTreatmentId,
      });
    }
    attributes.push(...extraAttributes);

    const cart = await storefrontClient.createCart({
      lines,
      attributes,
      discountCodes: [],
    });

    if (cart?.checkoutUrl) {
      location.href =
        destination === "shop-pay"
          ? `${cart.checkoutUrl}&payment=shop_pay&redirect_source=direct_checkout_product`
          : appendSkipShopPay(cart.checkoutUrl);
    } else {
      location.href = fallbackUrl();
    }
  } catch (error) {
    console.error("Error creating cart for checkout:", error);
    location.href = fallbackUrl();
  }
}

/**
 * Creates an event handler for Shop Pay button clicks on product pages.
 * When triggered, it creates a cart with both the selected product and the Redo offering,
 * then redirects to Shop Pay checkout.
 */
export function getShopPayProductOnClickEvent({
  storefrontClient,
  productVariantId,
  productVariantQuantity,
  redoProductVariantId,
  pricingTestTreatmentId,
}: ShopPayEventParams) {
  return async () =>
    createCartAndCheckout({
      storefrontClient,
      productLines: [
        { merchandiseId: productVariantId, quantity: productVariantQuantity },
      ],
      coverageVariantId: redoProductVariantId,
      destination: "shop-pay",
      pricingTestTreatmentId,
    });
}

export interface onClickProps {
  autocheck: WidgetAutocheck;
  client: ExtensionShopifyClient;
  cart: ShopifyCart | undefined;
  itemsToAdd: CheckoutButtonItemsToAdd;
  cartParams: any;
  anyCheckoutButtonClicked: boolean;
  allowingBubblingRef: React.MutableRefObject<boolean>;
  triggerCartRefresh: () => void;
  redoProductToSell: RedoProductToSell | undefined;
  /** Applied on top of the cart's own codes when this click proceeds to checkout. */
  discountCode?: string;
}

const pendingCheckouts = new WeakSet<onClickProps["allowingBubblingRef"]>();

function getRemovalClient(
  client: ExtensionShopifyClient,
): ExtensionShopifyClient {
  if (
    !globalThis.redoStorefront?.type ||
    globalThis.redoStorefront.type === "shopify"
  ) {
    return ShopifyAjaxClient.fromEnv();
  }
  return client;
}

export async function checkAndRemoveRedoFromCart(
  client: ExtensionShopifyClient,
  cart: ShopifyCart | undefined,
  coverageProductIds: string[] | undefined,
) {
  if (!cart) {
    return;
  }
  const removalClient = getRemovalClient(client);
  for (const item of cart.items) {
    if (isRedoItem(item, coverageProductIds)) {
      try {
        log("checkAndRemoveRedoFromCart: removing redo item", {
          itemId: item.id,
          variantId: item.variant_id,
          quantity: item.quantity,
          clientType: removalClient.type,
        });
        await removalClient.removeItemFromCart(item, item.quantity);
        log("checkAndRemoveRedoFromCart: removal succeeded");
      } catch (error) {
        log("checkAndRemoveRedoFromCart: removal failed", { error });
        console.warn("Error removing Redo item from cart:", error);
      }
    }
  }
}

/**
 * Whether the Redo coverage product should be added to the cart as a line item
 * on this opt-in click. Only the `*_PRODUCT` attachment strategies attach the
 * line at click time (the toggle/checkbox strategies add it live when the
 * shopper opts in); the merchant can also disable click-time attach via
 * `addProductOnOptInClick`.
 */
export function shouldAttachCoverageProductOnClick(
  attachmentStrategy: AttachmentStrategy | undefined,
  addProductOnOptInClick: boolean | undefined,
  addCoverage: boolean,
): boolean {
  return (
    (attachmentStrategy === AttachmentStrategy.CHECKOUT_BUTTON_PRODUCT ||
      attachmentStrategy === AttachmentStrategy.ANY_WIDGET_PRODUCT) &&
    addCoverage &&
    addProductOnOptInClick !== false
  );
}

/**
 * Reconciles the cart with the shopper's coverage opt-in before checkout:
 * writes the opt-in attributes, attaches the coverage line item when the
 * attachment strategy adds it at click time (with dedupe + out-of-stock
 * handling), and removes any Redo items on opt-out. Shared by the Checkout+
 * button (`getCheckoutOnClickEvent`) and the HSA existing-cart checkout
 * (`runHsaExistingCartCheckout`) so the coverage-attach logic has one
 * definition. For custom-fee strategies it also awaits the fee attach (or
 * removal) before the caller navigates, without the in-page reload.
 */
export async function attachCoverageToCart(
  addCoverage: boolean,
  {
    autocheck,
    client,
    cart,
    itemsToAdd,
    cartParams,
    anyCheckoutButtonClicked,
    triggerCartRefresh,
    redoProductToSell,
  }: onClickProps,
): Promise<void> {
  const ownsNavigation =
    !anyCheckoutButtonClicked &&
    !!client.coverageFee &&
    !!doesAttachmentStrategyUseCustomFee[autocheck.attachmentStrategy];
  const release = ownsNavigation ? holdBackgroundReload() : undefined;
  try {
    // set opted in cart attribute
    await safeUpdateCoverageCartAttribute({ client, cart, addCoverage });

    const shouldAddProduct = shouldAttachCoverageProductOnClick(
      autocheck.attachmentStrategy,
      autocheck.addProductOnOptInClick,
      addCoverage,
    );

    if (!anyCheckoutButtonClicked) {
      // this blocks ensureProduct from removing the redo variant we're adding, also signals to checkout op and toggle if on the "any widget" attachment strategy
      const internalEmitter = getInternalAppStatusEmitter();
      const clickEvent: RedoCheckoutButtonClickedEvent = {
        type: "RedoCheckoutButtonClickedEvent",
        timestamp: Date.now(),
        addCoverage,
      };
      internalEmitter.emit(clickEvent);
    }

    // if a checkout button was already clicked don't add the redo product again.
    if (shouldAddProduct && !anyCheckoutButtonClicked) {
      const { isDesiredRedoAlreadyInCart } =
        await checkAndRemoveAnyUndesiredRedoItemsFromCart({
          client,
          cart,
          itemsToAdd,
          coverageProductIds: autocheck.coverageProductIds,
        });
      if (!isDesiredRedoAlreadyInCart) {
        const { error } = await safeCartAdd({
          client,
          items: itemsToAdd,
          params: cartParams,
          retries: 2,
        });
        // if there's an issue with the redo product mark it, but otherwise continue to checkout.
        if (error && error.message.includes(MERCHANDISE_OUT_OF_STOCK_CODE)) {
          // set metadata saying we Received a merchandise out of stock error so Checkout Toggle won't attempt to add redo.
          await safeUpdateCoverageCartAttribute({
            client,
            cart,
            addCoverage,
            merchandiseOutOfStockError: true,
          });
        }
      }
    }

    if (
      !anyCheckoutButtonClicked &&
      client.coverageFee &&
      doesAttachmentStrategyUseCustomFee[autocheck.attachmentStrategy]
    ) {
      // Fail open like the out-of-stock branch above: a Redo fee failure must never block checkout.
      // An order without the fee is neither covered nor charged (order-sync and ingestion key on the real fee).
      try {
        await ensureCoverageFee({
          coverageFee: client.coverageFee,
          action: addCoverage
            ? EnsurePromiseAction.ADD
            : EnsurePromiseAction.REMOVE,
          autocheck,
          redoProductToSell,
          reloadOnChange: false,
        });
      } catch (error) {
        log(
          "checkout button: custom fee attach failed, continuing to checkout",
          { error },
        );
        console.warn("Error attaching Redo custom fee before checkout:", error);
      }
    }

    if (!addCoverage) {
      log("opt-out: removing redo from cart", {
        cartExists: !!cart,
        cartItemCount: cart?.items?.length,
        redoItemsInCart: cart?.items?.filter((item) =>
          isRedoItem(item, autocheck.coverageProductIds),
        ),
      });
      await checkAndRemoveRedoFromCart(
        client,
        cart,
        autocheck.coverageProductIds,
      );
    }

    if (
      globalThis.redoStorefront?.type === "bigcommerce" ||
      globalThis.redoStorefront?.type === "commercecloud" ||
      globalThis.redoStorefront?.type === "custom-lightopia"
    ) {
      // Omit the client to avoid refreshing BigCommerce checkout before navigation.
      await renderCart(autocheck);
      triggerCartRefresh();
    }
  } finally {
    release?.();
  }
}

/**
 * Writes the buy-button HSA intent cart attributes (priority, plus exclusivity
 * when `exclusive`) and navigates to standard checkout with Shop Pay skipped so
 * HSA/FSA is reachable.
 */
export async function goToHsaStandardCheckout(
  client: ExtensionShopifyClient,
  exclusive = false,
): Promise<void> {
  await safeUpdateCartAttribute({
    client,
    attributes: {
      attributes: buildHsaIntentCartAttributes({
        source: "buy_button",
        exclusive,
      }),
    },
    retries: 1,
  });
  location.href = appendSkipShopPay(`${location.origin}/checkout`);
}

/**
 * Reconciles coverage like the Checkout+ button, then flags HSA priority (and
 * exclusivity when `exclusive`) and navigates to standard checkout.
 */
export async function runHsaExistingCartCheckout(
  addCoverage: boolean,
  props: onClickProps,
  exclusive = false,
): Promise<void> {
  await attachCoverageToCart(addCoverage, props);
  await goToHsaStandardCheckout(props.client, exclusive);
}

async function applyClickDiscountCode({
  client,
  discountCode,
}: Pick<onClickProps, "client" | "discountCode">) {
  if (!discountCode || !client.applyDiscountCode) {
    return;
  }
  try {
    await appendDiscountCode({
      client,
      cart: await client.cartGet(),
      code: discountCode,
    });
  } catch (error) {
    log("Discount code apply failed", { error });
  }
}

export function getCheckoutOnClickEvent(
  addCoverage: boolean,
  isBuyNowHandler: boolean,
  props: onClickProps,
) {
  const { autocheck, allowingBubblingRef, triggerCartRefresh } = props;
  return async (
    event: Pick<
      React.MouseEvent,
      "target" | "preventDefault" | "stopPropagation"
    >,
  ) => {
    if (allowingBubblingRef.current) {
      return;
    } else {
      // prevent default logic if we're inside a form
      if (isBuyNowHandler) {
        event.stopPropagation();
      }
      event.preventDefault();
    }

    // handle Terms and condition
    if (
      autocheck.termsAndConditions?.blockCheckoutIfNotAccepted &&
      autocheck.termsAndConditions.termsCheckboxSelector &&
      shouldBlockCheckout(autocheck.termsAndConditions.termsCheckboxSelector)
    ) {
      alert(
        autocheck.termsAndConditions.blockedMessageText ||
          defaultTermsAndConditionsBlockedMessage,
      );
      return;
    }

    if (pendingCheckouts.has(allowingBubblingRef)) {
      return;
    }
    pendingCheckouts.add(allowingBubblingRef);
    try {
      if (
        shouldUseCartPermalink({
          autocheck,
          client: props.client,
          cart: props.cart,
          isBuyNowHandler,
        }) &&
        tryCartPermalinkCheckout({
          addCoverage,
          autocheck,
          cart: props.cart,
          attachCoverageLine: shouldAttachCoverageProductOnClick(
            autocheck.attachmentStrategy,
            autocheck.addProductOnOptInClick,
            addCoverage,
          ),
          coverageItem: props.itemsToAdd.items[0],
          attributes: getCoverageCartAttributes({
            cart: props.cart,
            addCoverage,
          }),
          discountCode: props.discountCode,
        })
      ) {
        return;
      }

      await attachCoverageToCart(addCoverage, props);
      if (!isBuyNowHandler) {
        await syncMysteryGift(addCoverage, props);
      }
      await applyClickDiscountCode(props);

      if (isBuyNowHandler) {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        const currTarget = event.target as HTMLElement;
        allowingBubblingRef.current = true;
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        if ((currTarget as any)?.button) {
          // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
          (currTarget as any)?.button?.dispatchEvent(new Event("click"));
        } else if (currTarget?.click) {
          currTarget?.click();
        } else {
          currTarget?.dispatchEvent(new Event("click"));
        }
        return;
      }

      // Purple Dot integration: pre-order carts check out from the cart page
      if (isPurpleDotPreorderCart(props.cart)) {
        location.href = `${location.origin}/cart`;
        return;
      }

      // click merchants standard checkout button
      if (autocheck.clickStandardCheckoutButton?.enabled) {
        const selector =
          autocheck.clickStandardCheckoutButton.checkoutButtonSelector ||
          STANDARD_CHECKOUT_BUTTON;
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        const checkoutButton = querySelectorSafe(
          document,
          selector,
        ) as HTMLButtonElement | null;

        if (checkoutButton?.click) {
          checkoutButton.click();

          if (
            globalThis.redoStorefront?.type === "commercecloud" &&
            typeof globalThis.redoBasketUpdate === "function"
          ) {
            globalThis.redoBasketUpdate(); // Custom function City Beach gave us to update the cart. Does a GET https://dev.citybeach.com/on/demandware.store/Sites-CityBeachAustralia-Site/en_AU/Redo-Update and then fires page events to refresh cart numbers.
            triggerCartRefresh();
          }

          if (autocheck.autoNavigateToCheckoutAfterTimeout ?? true) {
            return await goToCheckoutAfterTimeout();
          }
          return;
        }
      }

      // Bundler app integration
      if (isSiteUsingBundlerApp()) {
        try {
          // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
          (globalThis.bndlr as Bundler).goToCheckout();
          return await goToCheckoutAfterTimeout();
        } catch (error) {
          console.warn("Error calling bndlr.goToCheckout:", error);
        }
      }

      // send shopper directly to checkout
      goToCheckout();
    } finally {
      pendingCheckouts.delete(allowingBubblingRef);
    }
  };
}

/**
 * Set opted in cart attribute and metadata
 */
async function safeUpdateCoverageCartAttribute({
  client,
  cart,
  addCoverage,
  merchandiseOutOfStockError,
}: {
  client: ExtensionShopifyClient;
  cart: ShopifyCart | undefined;
  addCoverage: boolean;
  merchandiseOutOfStockError?: boolean;
}) {
  const attributes = getCoverageCartAttributes({
    cart,
    addCoverage,
    merchandiseOutOfStockError,
  });
  await safeUpdateCartAttribute({
    client,
    attributes: { attributes },
    retries: 1,
  });
}

export function getCoverageCartAttributes({
  cart,
  addCoverage,
  merchandiseOutOfStockError,
}: {
  cart: ShopifyCart | undefined;
  addCoverage: boolean;
  merchandiseOutOfStockError?: boolean;
}): { key: string; value: string }[] {
  snapshotVisitorBeforeCheckout();
  const cartToken =
    cart?.token ||
    getSessionStorageWithExpiry(REDO_CART_TOKEN_STORAGE_KEY) ||
    undefined;
  const currency = globalThis.Shopify?.currency;
  const country = globalThis.Shopify?.country;
  const rate = Number(currency?.rate);
  const metadata: RedoMetadata = {
    currencyConversion:
      currency?.active && country && Number.isFinite(rate) && rate > 0
        ? { currency: currency.active, country, rate }
        : undefined,
    optedTimestamp: Date.now(),
    coveragePriceCache: coveragePriceCache.getCache(),
    stagecoachDecision: getStagecoachDecisionMetadata(),
    merchandiseOutOfStockError: merchandiseOutOfStockError ?? false,
    cartToken,
  };
  return [
    {
      key: REDO_OPTED_IN_FROM_CART_ATTRIBUTE_KEY,
      value: addCoverage ? "true" : "false",
    },
    { key: REDO_METADATA_ATTRIBUTE_KEY, value: JSON.stringify(metadata) },
  ];
}

const goToCheckoutAfterTimeout = async () => {
  await new Promise((resolve) =>
    setTimeout(resolve, FALLBACK_CHECKOUT_TIMEOUT_MS),
  );
  goToCheckout();
};

export const goToCheckout = () => {
  if (globalThis.redoStorefront?.type === "commercecloud") {
    const sfccCheckoutUrl = resolveCommerceCloudCheckoutUrl({
      configuredUrl: globalThis.redoStorefront.sfcc?.checkoutUrl,
      origin: location.origin,
      pathname: location.pathname,
      knownLocale: globalThis.redoStorefront.sfcc?.locale,
    });
    if (!sfccCheckoutUrl) {
      throw new Error(
        "Merchant checkout buttons were not clicked, and no alternate checkout functionality has been tested",
      );
    }
    log("sfcc: navigating to checkout", { sfccCheckoutUrl });
    location.href = sfccCheckoutUrl;
    return;
  }
  location.href = applySkipShopPay(location.origin + "/checkout");
};

export const getCheckoutButtonItemsToAdd = ({
  singleProductVariantId,
  singleProductId,
  hasFinalSaleCoverage,
  sellingPlanId,
}: {
  singleProductVariantId: string | number;
  singleProductId: string | number;
  hasFinalSaleCoverage: boolean;
  sellingPlanId: number | null;
}): CheckoutButtonItemsToAdd => {
  return {
    items: [
      {
        id: singleProductVariantId, // I hate this. This is `id` prop is supposed to be a cart line id based on the type, but it's used everywhere as variant id.
        product_id: singleProductId,
        variant_id: singleProductVariantId,
        quantity: 1,
        properties: hasFinalSaleCoverage
          ? { __final_sale_coverage: "true" }
          : {},
        selling_plan: sellingPlanId ?? undefined,
      },
    ],
  };
};

function getStagecoachDecisionMetadata():
  | StagecoachDecisionMetadata
  | undefined {
  const cache = coveragePriceCache.getCache();
  const latestCartHash = cache?.latestCartHash;
  if (!cache || !latestCartHash) {
    return undefined;
  }

  const packageProtection = cache.cache[latestCartHash]?.packageProtection;
  if (!packageProtection?.modelVersionId) {
    return undefined;
  }

  return {
    cartHash: latestCartHash,
    packageProtectionPrice: packageProtection.price,
    modelVersionId: packageProtection.modelVersionId,
    betaSampleIndex: packageProtection.betaSampleIndex,
    validationMode: "detect_only",
  };
}

interface RemoveUndesiredRedoProductsResult {
  isDesiredRedoAlreadyInCart: boolean;
}
export const checkAndRemoveAnyUndesiredRedoItemsFromCart = async ({
  client,
  cart,
  itemsToAdd,
  coverageProductIds,
}: {
  client: ExtensionShopifyClient;
  cart: ShopifyCart | undefined;
  itemsToAdd: CheckoutButtonItemsToAdd;
  coverageProductIds: string[] | undefined;
}): Promise<RemoveUndesiredRedoProductsResult> => {
  let isDesiredRedoAlreadyInCart = false;
  if (!cart) {
    return { isDesiredRedoAlreadyInCart };
  }
  const removalClient = getRemovalClient(client);
  const redoLineItems = cart.items.filter((item) =>
    isRedoItem(item, coverageProductIds),
  );
  const numberOfRedoItems = redoLineItems.reduce(
    (acc, item) => acc + item.quantity,
    0,
  );
  if (numberOfRedoItems > 0) {
    // Check if the desired variant is already in the cart.
    const desiredVariantId = itemsToAdd.items[0]?.variant_id;
    const desiredProduct = redoLineItems.find(
      (item) =>
        String(item.variant_id) === String(desiredVariantId) ||
        item.id === itemsToAdd.items[0]?.id,
    );
    if (desiredProduct && desiredProduct.quantity > 0) {
      log(
        `Desired product ${desiredProduct.id} found in cart with quantity ${desiredProduct.quantity}.`,
      );
      isDesiredRedoAlreadyInCart = true;
      if (desiredProduct.quantity > 1) {
        await removalClient.removeItemFromCart(
          desiredProduct,
          desiredProduct.quantity - 1,
          undefined,
          true,
        );
        log(`Removed extra quantity of desired product ${desiredProduct.id}.`);
      }
    }
    const remainingItems = redoLineItems.filter(
      (item) => item !== desiredProduct,
    );
    for (const item of remainingItems) {
      await removalClient.removeItemFromCart(
        item,
        item.quantity,
        undefined,
        true,
      );
      log(
        `Removed undesired Redo products from cart: Item ID ${item.id} of quantity ${item.quantity}.`,
      );
    }
  }

  log(
    `Verified no undesired redo products in cart after checkout buttons clicked. Desired Redo product already in the cart? ${isDesiredRedoAlreadyInCart}`,
  );
  return { isDesiredRedoAlreadyInCart };
};
