import type {
  ExtensionShopifyClient,
  ShopifyCart,
} from "@redotech/shopify-client/ajax";

export const isSameDiscountCode = (a: string, b: string) =>
  a.toUpperCase() === b.toUpperCase();

/** Adds `code` unless it is already present, keeping the existing codes. */
export const withDiscountCode = (codes: string[], code: string) =>
  codes.some((existing) => isSameDiscountCode(existing, code))
    ? codes
    : [...codes, code];

/** Applies `code` on top of the cart's current codes, which the client would otherwise replace. */
export async function appendDiscountCode({
  client,
  cart,
  code,
}: {
  client: Pick<ExtensionShopifyClient, "applyDiscountCode">;
  cart: Pick<ShopifyCart, "discount_codes">;
  code: string;
}): Promise<void> {
  const codes = cart.discount_codes?.map(({ code }) => code) ?? [];
  const next = withDiscountCode(codes, code);
  if (next !== codes) {
    await client.applyDiscountCode?.(next.join(","));
  }
}
