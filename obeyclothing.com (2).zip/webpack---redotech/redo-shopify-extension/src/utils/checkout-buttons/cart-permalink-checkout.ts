import { CheckoutMethod } from "@redotech/redo-storefront-common/checkout-method";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import {
  ExtensionShopifyClient,
  getShopifyRouteRoot,
  ShopifyCart,
  ShopifyCartItem,
  ShopifyClientType,
} from "@redotech/shopify-client/ajax";
import { log } from "../../monitoring/log";
import { isRedoItem } from "../../utils";
import { isSiteUsingBundlerApp } from "../bundler-app";
import { isPurpleDotPreorderCart } from "../purple-dot";
import { applySkipShopPay } from "../skip-shop-pay";
import {
  buildCartPermalink,
  cartHasPermalinkUnsupportedLines,
} from "./cart-permalink";
import { needsMysteryGiftSync } from "./mystery-gift";

export interface ShouldUseCartPermalinkParams {
  autocheck: WidgetAutocheck;
  client: ExtensionShopifyClient;
  cart: ShopifyCart | undefined;
  /** Buy-now buttons hand off to the theme's product form, so a permalink can't own that navigation. */
  isBuyNowHandler: boolean;
}

export function shouldUseCartPermalink({
  autocheck,
  client,
  cart,
  isBuyNowHandler,
}: ShouldUseCartPermalinkParams): boolean {
  if (
    autocheck.checkoutMethod !== CheckoutMethod.CART_PERMALINK ||
    needsMysteryGiftSync(autocheck.mysteryGiftVariantId, cart)
  ) {
    log("not permalink");
    return false;
  }
  if (isBuyNowHandler) {
    return false;
  }
  if (autocheck.clickStandardCheckoutButton?.enabled) {
    log("click standard enabled.");
    return false;
  }
  if (isSiteUsingBundlerApp()) {
    log("cart permalink unsupported", { reason: "bundler_app" });
    return false;
  }
  if (isPurpleDotPreorderCart(cart)) {
    log("cart permalink unsupported", { reason: "purple_dot_preorder" });
    return false;
  }
  const storefrontType = globalThis.redoStorefront?.type;
  if (storefrontType && storefrontType !== "shopify") {
    return false;
  }
  if (
    client.type !== ShopifyClientType.AJAX &&
    client.type !== ShopifyClientType.SHOPIFYGRAPHQL
  ) {
    return false;
  }
  if (!cart) {
    log("cart permalink unsupported", { reason: "no_cart_in_memory" });
    return false;
  }
  if (cartHasPermalinkUnsupportedLines(cart)) {
    log("cart permalink unsupported", { reason: "selling_plan_or_bundle" });
    return false;
  }
  return true;
}

export interface CartPermalinkCheckoutParams {
  addCoverage: boolean;
  autocheck: WidgetAutocheck;
  /** The cart already in memory; absent until `useCart` has loaded it. */
  cart: ShopifyCart | undefined;
  /** Whether the attachment strategy adds the coverage line on this click. */
  attachCoverageLine: boolean;
  /** The coverage variant the Checkout+ button would add to the cart. */
  coverageItem:
    | Pick<
        Partial<ShopifyCartItem>,
        "variant_id" | "quantity" | "properties" | "selling_plan"
      >
    | undefined;
  /** Redo opt-in and metadata attributes to write onto the checkout. */
  attributes: { key: string; value: string }[];
  /** Discount code carried to checkout next to the cart's own codes. */
  discountCode?: string;
}

/**
 * Sends the shopper to checkout through a cart permalink that carries their
 * current cart, the coverage line (when the attachment strategy adds it at
 * click time), and the opt-in attributes. Makes no network requests: it uses
 * the cart already in memory (kept current by `useCart`) so the only cost
 * before navigation is building the URL. Returns false without navigating when
 * the cart can't be represented as a permalink.
 */
export function tryCartPermalinkCheckout({
  addCoverage,
  autocheck,
  cart,
  attachCoverageLine,
  coverageItem,
  attributes,
  discountCode,
}: CartPermalinkCheckoutParams): boolean {
  if (!cart) {
    return false;
  }
  if (attachCoverageLine && coverageItem?.selling_plan) {
    log("cart permalink unsupported", { reason: "coverage_selling_plan" });
    return false;
  }

  const dropExistingCoverageLines = attachCoverageLine || !addCoverage;
  const result = buildCartPermalink({
    origin: location.origin,
    routeRoot: getShopifyRouteRoot(),
    cart,
    isExcludedItem: (item) =>
      dropExistingCoverageLines &&
      isRedoItem(item, autocheck.coverageProductIds),
    coverageLine:
      attachCoverageLine && coverageItem?.variant_id !== undefined
        ? {
            variantId: String(coverageItem.variant_id),
            quantity: coverageItem.quantity ?? 1,
            properties: coverageItem.properties,
          }
        : null,
    attributes,
    discountCode,
  });
  if (!result.ok) {
    log("cart permalink unsupported", { reason: result.reason });
    return false;
  }

  log("cart permalink: navigating to checkout", { addCoverage });
  location.href = applySkipShopPay(result.url);
  return true;
}
