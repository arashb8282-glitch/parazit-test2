import { isAnyWidgetAttachmentStrategy } from "@redotech/redo-storefront-common/attachment-strategy";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import { useEffect, useState } from "react";
import { getInternalAppStatusEmitter } from "../../config";
import { RedoCheckoutButtonClickedEvent } from "../internal-app-events";

const CHECKOUT_BUTTONS_BLOCKING_TIME = 2000;

export function useCheckoutButtonClicked(autocheck: WidgetAutocheck) {
  const [anyCheckoutButtonClicked, setAnyCheckoutButtonClicked] =
    useState<boolean>(false);

  useEffect(() => {
    const internalEmitter = getInternalAppStatusEmitter();
    const listener = (_event: RedoCheckoutButtonClickedEvent) => {
      setAnyCheckoutButtonClicked(true);

      // if we're on any widget, we only want to disable ensure product temporarily to avoid race conditions.
      // also we want to be able to click the button again later if the buttons don't navigate anywhere
      if (isAnyWidgetAttachmentStrategy[autocheck.attachmentStrategy]) {
        setTimeout(() => {
          setAnyCheckoutButtonClicked(false);
        }, CHECKOUT_BUTTONS_BLOCKING_TIME);
      }
    };

    internalEmitter.on("RedoCheckoutButtonClickedEvent", listener);

    return () => {
      internalEmitter.off("RedoCheckoutButtonClickedEvent", listener);
    };
  }, [autocheck.attachmentStrategy]);

  return { anyCheckoutButtonClicked, setAnyCheckoutButtonClicked };
}
