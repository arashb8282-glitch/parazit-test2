import { AttachmentStrategy } from "@redotech/redo-storefront-common/attachment-strategy";
import type { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import {
  type ExtensionShopifyClient,
  type ShopifyCart,
  ShopifyClientType,
} from "@redotech/shopify-client/ajax";
import { log } from "../../monitoring/log";
import { isRedoItem } from "../../utils";
import { appendDiscountCode, isSameDiscountCode } from "./discount-codes";

const GIFT_PROPERTY = "__redo_mystery_gift";
const GIFT_DISCOUNT_CODE = "REDO-COVERAGE-GIFT";
const isGift = (item: ShopifyCart["items"][number]) =>
  item.properties?.[GIFT_PROPERTY] === "true";
const isGiftCode = (code: string) =>
  isSameDiscountCode(code, GIFT_DISCOUNT_CODE);

export const needsMysteryGiftSync = (
  variantId: string | undefined,
  cart: ShopifyCart | undefined,
) =>
  Boolean(
    variantId ||
    cart?.items.some(isGift) ||
    cart?.discount_codes?.some(({ code }) => isGiftCode(code)),
  );

export async function syncMysteryGift(
  addCoverage: boolean,
  {
    client,
    cart,
    autocheck,
  }: {
    client: ExtensionShopifyClient;
    cart?: ShopifyCart;
    autocheck: Pick<
      WidgetAutocheck,
      "mysteryGiftVariantId" | "attachmentStrategy" | "coverageProductIds"
    >;
  },
): Promise<void> {
  const variantId = autocheck.mysteryGiftVariantId;
  if (
    (client.type !== ShopifyClientType.AJAX &&
      client.type !== ShopifyClientType.SHOPIFYGRAPHQL) ||
    !client.applyDiscountCode ||
    !needsMysteryGiftSync(variantId, cart)
  ) {
    return;
  }
  let keepGift = false;
  try {
    const currentCart = await client.cartGet();
    const eligible =
      addCoverage &&
      variantId &&
      autocheck.attachmentStrategy ===
        AttachmentStrategy.CHECKOUT_BUTTON_PRODUCT &&
      currentCart.items.some((item) =>
        isRedoItem(item, autocheck.coverageProductIds),
      );
    if (eligible) {
      await appendDiscountCode({
        client,
        cart: currentCart,
        code: GIFT_DISCOUNT_CODE,
      });
      if (!currentCart.items.some(isGift)) {
        await client.cartAdd(
          {
            items: [
              {
                id: variantId,
                quantity: 1,
                properties: { [GIFT_PROPERTY]: "true" },
              },
            ],
          },
          undefined,
          true,
        );
      }
      const gifts = (await client.cartGet()).items.filter(isGift);
      keepGift =
        gifts.length === 1 &&
        gifts.every(
          (gift) => gift.quantity === 1 && gift.final_line_price === 0,
        );
    }
  } catch (error) {
    log("Mystery gift update failed", { error });
  }
  // Cleanup failures must stop checkout rather than leave an unexpected paid gift.
  if (!keepGift) {
    const currentCart = await client.cartGet();
    for (const gift of currentCart.items.filter(isGift)) {
      const lineId = gift.line_id ?? gift.key;
      if (!lineId) {
        throw new Error("Missing mystery gift cart line ID");
      }
      await client.removeItemFromCart({ ...gift, id: lineId }, gift.quantity);
    }
    const codes = currentCart.discount_codes?.map(({ code }) => code) ?? [];
    if (codes.some(isGiftCode)) {
      await client.applyDiscountCode(
        codes.filter((code) => !isGiftCode(code)).join(","),
      );
    }
  }
}
