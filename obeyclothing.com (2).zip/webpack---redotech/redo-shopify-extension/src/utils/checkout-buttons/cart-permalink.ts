import type {
  ShopifyCart,
  ShopifyCartItem,
} from "@redotech/shopify-client/ajax";
import { withDiscountCode } from "./discount-codes";

/**
 * Shopify caps request lines well below browser limits; stay under a
 * conservative bound so a permalink never turns into a 414 for the shopper.
 */
export const MAX_CART_PERMALINK_LENGTH = 7500;

export interface CartPermalinkLine {
  variantId: string;
  quantity: number;
  properties?: { [key: string]: string } | null;
}

export type CartPermalinkUnsupportedReason =
  | "empty_cart"
  | "selling_plan"
  | "bundle"
  | "multiple_lines_with_properties"
  | "url_too_long";

export type CartPermalinkResult =
  | { ok: true; url: string }
  | { ok: false; reason: CartPermalinkUnsupportedReason };

export interface BuildCartPermalinkParams {
  origin: string;
  /** `Shopify.routes.root`, e.g. `/` or `/fr/`, so the checkout stays localized. */
  routeRoot: string;
  cart: ShopifyCart;
  /** Existing cart lines to leave out of the permalink (stale coverage lines). */
  isExcludedItem: (item: ShopifyCartItem) => boolean;
  /** Coverage line to append, or null when none should be attached. */
  coverageLine: CartPermalinkLine | null;
  /** Attributes written on top of the cart's current attributes. */
  attributes: { key: string; value: string }[];
  /** Discount code added next to the cart's applicable codes. */
  discountCode?: string;
}

function hasProperties(properties: CartPermalinkLine["properties"]): boolean {
  return !!properties && Object.keys(properties).length > 0;
}

/**
 * Why a single cart line can never appear in a permalink: Shopify documents
 * that selling plans don't work with permalinks, and bundle parents or
 * components can't be expressed as `variant:qty`.
 */
export function permalinkUnsupportedLineReason(
  item: ShopifyCartItem,
): Extract<CartPermalinkUnsupportedReason, "selling_plan" | "bundle"> | null {
  if (item.selling_plan || item.selling_plan_allocation) {
    return "selling_plan";
  }
  if (item.parent_relationship || item.has_components) {
    return "bundle";
  }
  return null;
}

/** True when any line in the cart rules out a permalink checkout. */
export function cartHasPermalinkUnsupportedLines(cart: ShopifyCart): boolean {
  return cart.items.some((item) => permalinkUnsupportedLineReason(item));
}

function base64UrlEncode(value: string): string {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function collectLines({
  cart,
  isExcludedItem,
  coverageLine,
}: Pick<BuildCartPermalinkParams, "cart" | "isExcludedItem" | "coverageLine">):
  | CartPermalinkLine[]
  | { reason: CartPermalinkUnsupportedReason } {
  const quantityByVariant = new Map<string, number>();
  const linesWithProperties: CartPermalinkLine[] = [];

  for (const item of cart.items) {
    if (isExcludedItem(item)) {
      continue;
    }
    const unsupportedReason = permalinkUnsupportedLineReason(item);
    if (unsupportedReason) {
      return { reason: unsupportedReason };
    }
    if (item.quantity <= 0) {
      continue;
    }
    const variantId = String(item.variant_id);
    if (hasProperties(item.properties)) {
      linesWithProperties.push({
        variantId,
        quantity: item.quantity,
        properties: item.properties,
      });
    } else {
      quantityByVariant.set(
        variantId,
        (quantityByVariant.get(variantId) ?? 0) + item.quantity,
      );
    }
  }

  const plainLines: CartPermalinkLine[] = [...quantityByVariant].map(
    ([variantId, quantity]) => ({ variantId, quantity }),
  );

  // Shopify adds permalink lines in order and shows the newest line at the top,
  // so the coverage line goes first to render at the bottom of the checkout.
  if (coverageLine) {
    if (hasProperties(coverageLine.properties)) {
      linesWithProperties.push(coverageLine);
    } else {
      plainLines.unshift(coverageLine);
    }
  }

  // Shopify only accepts line item properties on the first permalink line, so
  // a cart line carrying properties has to go ahead of the coverage line.
  if (linesWithProperties.length > 1) {
    return { reason: "multiple_lines_with_properties" };
  }

  const lines = [...linesWithProperties, ...plainLines];
  if (lines.length === 0) {
    return { reason: "empty_cart" };
  }
  return lines;
}

/**
 * Builds a Shopify cart permalink (`/cart/{variant}:{qty},...`) that recreates
 * the shopper's cart plus the Redo coverage line and attributes in a single
 * navigation. Returns the reason instead of a URL for carts a permalink can't
 * faithfully represent, so the caller can fall back to mutating the cart.
 *
 * @see https://shopify.dev/docs/apps/build/checkout/create-cart-permalinks
 */
export function buildCartPermalink({
  origin,
  routeRoot,
  cart,
  isExcludedItem,
  coverageLine,
  attributes,
  discountCode,
}: BuildCartPermalinkParams): CartPermalinkResult {
  const lines = collectLines({ cart, isExcludedItem, coverageLine });
  if (!Array.isArray(lines)) {
    return { ok: false, reason: lines.reason };
  }

  const root = routeRoot.endsWith("/") ? routeRoot : `${routeRoot}/`;
  const path = `${root}cart/${lines
    .map((line) => `${line.variantId}:${line.quantity}`)
    .join(",")}`;
  const url = new URL(path, origin);

  const firstLine = lines[0];
  if (firstLine && hasProperties(firstLine.properties)) {
    url.searchParams.set(
      "properties",
      base64UrlEncode(JSON.stringify(firstLine.properties)),
    );
  }

  const mergedAttributes: { [key: string]: string } = { ...cart.attributes };
  for (const { key, value } of attributes) {
    mergedAttributes[key] = value;
  }
  for (const [key, value] of Object.entries(mergedAttributes)) {
    if (value !== "") {
      url.searchParams.append(`attributes[${key}]`, value);
    }
  }

  if (cart.note) {
    url.searchParams.set("note", cart.note);
  }

  const cartDiscountCodes = (cart.discount_codes ?? [])
    .filter((code) => code.applicable && !code.code.includes(","))
    .map((code) => code.code);
  const discountCodes =
    discountCode && !discountCode.includes(",")
      ? withDiscountCode(cartDiscountCodes, discountCode)
      : cartDiscountCodes;
  if (discountCodes.length > 0) {
    url.searchParams.set("discount", discountCodes.join(","));
  }

  const href = url.toString();
  if (href.length > MAX_CART_PERMALINK_LENGTH) {
    return { ok: false, reason: "url_too_long" };
  }
  return { ok: true, url: href };
}
