import { splitSelectorList } from "@redotech/util/css-selector-list";
import { log } from "../monitoring/log";

export function getMatchingSelectors(
  elements: readonly Element[],
  selectorList: string,
): (string | undefined)[] {
  const selectors = splitSelectorList(selectorList);
  const matchesByRoot = new Map<
    Document | ShadowRoot,
    Map<string, Set<Element>>
  >();
  return elements.map((element) => {
    const root = element.getRootNode();
    if (!(root instanceof Document || root instanceof ShadowRoot)) {
      return undefined;
    }
    // Elements already matched the full selector list before widget insertion.
    if (selectors.length === 1) {
      return selectors[0];
    }
    return selectors.find((selector) => {
      try {
        // Escapes can spell :scope, which must be matched against the root.
        if (!/:scope|\\/i.test(selector)) {
          return element.matches(selector);
        }
        const matches =
          matchesByRoot.get(root) ?? new Map<string, Set<Element>>();
        matchesByRoot.set(root, matches);
        const matchingElements =
          matches.get(selector) ?? new Set(root.querySelectorAll(selector));
        matches.set(selector, matchingElements);
        return matchingElements.has(element);
      } catch (error) {
        log(error, "Error identifying matched placement selector");
        return false;
      }
    });
  });
}
