import { DeliveryType, ShopifyCart } from "@redotech/shopify-client/ajax";
import { useEffect, useState } from "react";
import { CommercecloudStorefrontClient } from "../client/commercecloud-storefront";

/** Zapiet records the shopper's fulfillment choice as a cart attribute. */
function isZapietPickup(cart: ShopifyCart | undefined): boolean {
  return cart?.attributes?.["Checkout-Method"] === "pickup";
}

function isSfccCheckout(): boolean {
  return (
    globalThis.redoStorefront?.type === "commercecloud" &&
    CommercecloudStorefrontClient.isOnCheckoutPage()
  );
}

function isSfccPickupSelected(): boolean {
  return (
    isSfccCheckout() &&
    CommercecloudStorefrontClient.getCheckoutDeliveryType() ===
      DeliveryType.IN_STORE_PICKUP
  );
}

/**
 * Whether the shopper chose in-store pickup (click and collect), read from the
 * Zapiet cart attribute or the observed SFCC checkout DOM, not a cart fetch.
 */
export function useInStorePickup(cart: ShopifyCart | undefined): boolean {
  const [sfccPickup, setSfccPickup] = useState(isSfccPickupSelected);

  useEffect(() => {
    if (!isSfccCheckout()) {
      return;
    }
    const update = () => setSfccPickup(isSfccPickupSelected());
    update();
    // Toggling an input changes the `checked` property, not the attribute,
    // so input events are needed alongside DOM mutations.
    const observer = new MutationObserver(update);
    observer.observe(document.body, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["class", "checked"],
    });
    document.addEventListener("change", update, true);
    document.addEventListener("click", update, true);
    return () => {
      observer.disconnect();
      document.removeEventListener("change", update, true);
      document.removeEventListener("click", update, true);
    };
  }, []);

  // Re-read on each cart refresh, the previous sole read, as a fallback.
  useEffect(() => {
    if (isSfccCheckout()) {
      setSfccPickup(isSfccPickupSelected());
    }
  }, [cart]);

  return isZapietPickup(cart) || sfccPickup;
}
