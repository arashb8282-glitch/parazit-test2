import * as z from "zod";

const SESSION_STORAGE_KEY = "redo-checkout-probability-state";

const checkoutProbabilityStorageSchema = z.object({
  cumulativeConversionProbability: z.number().nullable(),
  instantaneousHazardProbability: z.number().nullable(),
});
type CheckoutProbabilityStorage = z.infer<
  typeof checkoutProbabilityStorageSchema
>;

export function loadCheckoutProbabilityFromSessionStorage(): CheckoutProbabilityStorage | null {
  try {
    const stored = sessionStorage.getItem(SESSION_STORAGE_KEY);
    if (!stored) {
      return null;
    }

    const parsed = JSON.parse(stored);
    const result = checkoutProbabilityStorageSchema.safeParse(parsed);

    if (result.success) {
      return result.data;
    } else {
      console.warn(
        "Invalid checkout probability data in SessionStorage:",
        result.error,
      );
      // Clear invalid data
      sessionStorage.removeItem(SESSION_STORAGE_KEY);
      return null;
    }
  } catch (error) {
    console.warn(
      "Failed to load checkout probability from SessionStorage:",
      error,
    );
    return null;
  }
}

export function saveCheckoutProbabilityToSessionStorage(
  storage: CheckoutProbabilityStorage,
) {
  try {
    // Validate before saving
    const validated = checkoutProbabilityStorageSchema.parse(storage);
    sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(validated));
  } catch (error) {
    console.warn(
      "Failed to save checkout probability to SessionStorage:",
      error,
    );
  }
}
