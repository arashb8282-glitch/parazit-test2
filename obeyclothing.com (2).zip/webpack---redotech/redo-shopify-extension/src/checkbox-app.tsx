import STYLE_MANAGER from "./style-manager";

export class RedoCheckboxElement extends HTMLElement {
  #deregisterStyles!: () => void;
  #modalContainer!: HTMLElement;
  #root!: ShadowRoot;

  get root() {
    return this.#root;
  }

  get modalContainer() {
    return this.#modalContainer;
  }

  connectedCallback() {
    const shadowRoot = this.attachShadow({ mode: "open" });
    this.#root = shadowRoot;

    const modalRoot = this.ownerDocument.createElement("div");
    modalRoot.setAttribute("id", "redo-modal-root");
    modalRoot.style.display = "initial";
    modalRoot.style.position = "absolute";
    modalRoot.style.zIndex = "50000";
    document.body.append(modalRoot);
    const modalShadowRoot = modalRoot.attachShadow({ mode: "open" });
    this.#deregisterStyles = STYLE_MANAGER.register(modalShadowRoot);
    this.#modalContainer = this.ownerDocument.createElement("div");
    modalShadowRoot.append(this.#modalContainer);
  }

  disconnectedCallback() {
    this.#deregisterStyles();
    this.#modalContainer?.remove();
  }

  static #registered = false;

  static register() {
    if (!this.#registered) {
      customElements.define(this.TAG, this);
      this.#registered = true;
    }
  }

  static readonly TAG = "redo-shopify-checkbox";
}
