import { isAttachmentStrategyUsingCheckoutButtons } from "@redotech/redo-storefront-common/attachment-strategy";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";

/**
 * A coverage A/B arm with rescue on shows the CHOP rescue panel. Teams that
 * already run the CHOP panel keep it, so the two never stack.
 */
export function shouldShowCoverageRescuePanel(
  autocheck: WidgetAutocheck,
): boolean {
  const chopRescuePanelEnabled =
    autocheck.conversion.enabled &&
    autocheck.conversion.predictiveConversion.enabled;
  return (
    !chopRescuePanelEnabled &&
    !!autocheck.rescueCheckoutButtonsEnabled &&
    isAttachmentStrategyUsingCheckoutButtons[autocheck.attachmentStrategy]
  );
}
