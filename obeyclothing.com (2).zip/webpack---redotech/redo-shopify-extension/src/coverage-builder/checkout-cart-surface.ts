import { PlacementContainerType } from "@redotech/redo-storefront-common/widget-config";
import type { CheckoutCartSurface } from "@redotech/web-iframe-rpc/rpc-definitions";

const DRAWER_HINT =
  /cart.?drawer|side.?cart|mini.?cart|minicart|flyout|upcart|rebuy/i;
const POPUP_HINT = /popup|pop.?up|popover|modal|floating|notification/i;

export function checkoutElementHint(element: Element): string {
  return [
    element.tagName,
    element.id,
    element.className,
    element.getAttribute("aria-label"),
    element.getAttribute("data-cart-drawer"),
    element.getAttribute("data-drawer"),
    element.getAttribute("role"),
  ]
    .filter((value): value is string => typeof value === "string")
    .join(" ");
}

function placementContainerTypeFromHint(
  hint: string,
): PlacementContainerType | null {
  if (DRAWER_HINT.test(hint)) {
    return PlacementContainerType.SIDE_CART;
  }
  return POPUP_HINT.test(hint) ? PlacementContainerType.POPUP_CART : null;
}

export function checkoutComposedParentElement(
  element: Element,
): Element | null {
  if (element.parentElement) {
    return element.parentElement;
  }
  const root = element.getRootNode();
  const ShadowRootClass = element.ownerDocument.defaultView?.ShadowRoot;
  return ShadowRootClass && root instanceof ShadowRootClass ? root.host : null;
}

function trimTrailingSlash(pathname: string): string {
  return pathname.replace(/\/$/, "");
}

/** Shopify /cart, BigCommerce /cart.php, or the SFCC Cart-Show URL the cartridge publishes. */
function isCartPagePath(location: Location | null): boolean {
  if (!location) {
    return false;
  }
  if (/\/cart(\.php)?\/?$/.test(location.pathname)) {
    return true;
  }
  const cartUrl = globalThis.redoStorefront?.sfcc?.cartUrl;
  if (!cartUrl) {
    return false;
  }
  try {
    return (
      trimTrailingSlash(new URL(cartUrl, location.origin).pathname) ===
      trimTrailingSlash(location.pathname)
    );
  } catch {
    return false;
  }
}

export function checkoutPlacementContainerTypeForElement(
  element: Element,
): PlacementContainerType {
  if (isCartPagePath(element.ownerDocument.location)) {
    return PlacementContainerType.CART_PAGE;
  }
  let current: Element | null = element;
  while (current && current !== element.ownerDocument.documentElement) {
    const containerType = placementContainerTypeFromHint(
      checkoutElementHint(current),
    );
    if (containerType) {
      return containerType;
    }
    current = checkoutComposedParentElement(current);
  }
  return PlacementContainerType.OTHER;
}

export function checkoutCartSurfaceForElement(
  element: Element,
): CheckoutCartSurface | null {
  switch (checkoutPlacementContainerTypeForElement(element)) {
    case PlacementContainerType.SIDE_CART:
      return "cart-drawer";
    case PlacementContainerType.POPUP_CART:
      return "popup-cart";
    case PlacementContainerType.CART_PAGE:
    case PlacementContainerType.OTHER:
      return null;
  }
}

export function checkoutCartSurfaceAncestors(
  element: Element,
  cartSurface: CheckoutCartSurface,
): Element[] {
  const placementContainerType =
    cartSurface === "cart-drawer"
      ? PlacementContainerType.SIDE_CART
      : PlacementContainerType.POPUP_CART;
  const ancestors: Element[] = [];
  let current: Element | null = element;
  while (current && current !== element.ownerDocument.documentElement) {
    if (
      placementContainerTypeFromHint(checkoutElementHint(current)) ===
      placementContainerType
    ) {
      ancestors.push(current);
    }
    current = checkoutComposedParentElement(current);
  }
  return ancestors;
}
