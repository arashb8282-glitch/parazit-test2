import { Currency } from "@redotech/money/currencies";
import { useHandler } from "@redotech/react-util/hook";
import { StyleShadowRoot } from "@redotech/react-util/style";
import { CoverageInfo } from "@redotech/redo-return-coverage-common/coverage-calculator/coverage-info-from-calculators";
import {
  AttachmentStrategy,
  doesAttachmentStrategyUseCustomFee,
} from "@redotech/redo-storefront-common/attachment-strategy";
import { CartProductType } from "@redotech/redo-storefront-widget-common/cart-product-types";
import { applyLocalizationTextOverrides } from "@redotech/redo-storefront-widget-common/use-localization-text-override";
import {
  WidgetAutocheck,
  WidgetFees,
} from "@redotech/redo-storefront-widget-common/widget";
import { ModalRootContext } from "@redotech/redo-web/modal-root";
import { setLocalStorageWithExpiry } from "@redotech/redo-web/utils/local-storage-wrapper";
import { ShopifyProductJS } from "@redotech/shopify-client/ajax";
import { memo, ReactNode, useMemo } from "react";
import { log } from "../monitoring/log";
import { getClassicWidgetTheme } from "../render-elements/classic-widget-theme";
import STYLE_MANAGER from "../style-manager";
import { DeluxeToggleArray, RedoToggle } from "../toggle";
import { getCorrectlyPricedVariant } from "../utils/determine-redo-product";
import { PlacedWidgetHtmlElements } from "../utils/element-placement";
import {
  PROTECTION_TOGGLE_STATE_KEY,
  RETURN_TOGGLE_STATE_KEY,
} from "../utils/signals";
import { getToggleTextOptions } from "./helpers";

export const DoubleToggleManager = memo(function DoubleToggleManager({
  autocheck,
  fees,
  placedWidgetHtmlElements,
  coverageInfo,
  cartCurrency,
  country,
  language,
  returnToggleState,
  protectionToggleState,
  returnRedoProduct,
  packageRedoProduct,
  setReturnToggleVal,
  setProtectionToggleVal,
  onTapcart,
}: {
  autocheck: WidgetAutocheck;
  fees: WidgetFees;
  placedWidgetHtmlElements: PlacedWidgetHtmlElements[];
  coverageInfo: CoverageInfo;
  cartCurrency: Currency;
  country: string;
  language: string | undefined;
  returnToggleState: boolean;
  protectionToggleState: boolean;
  returnRedoProduct: ShopifyProductJS | undefined;
  packageRedoProduct: ShopifyProductJS | undefined;
  setReturnToggleVal: (state: boolean) => void;
  setProtectionToggleVal: (state: boolean) => void;
  onTapcart: boolean;
}) {
  let cartReactElement: ReactNode = null;
  const cartReactElements: JSX.Element[] = [];
  const classicWidgetTheme = getClassicWidgetTheme({ autocheck });

  const onReturnToggleChange = useHandler((value: boolean, manual = true) => {
    log("return toggle changed", { value, manual });
    setReturnToggleVal(value);
    const state = value ? "enabled" : "disabled";
    setLocalStorageWithExpiry(RETURN_TOGGLE_STATE_KEY, state);
  });

  const onProtectionToggleChange = useHandler(
    (value: boolean, manual = true) => {
      log("package protection toggle changed", { value, manual });
      setProtectionToggleVal(value);
      const state = value ? "enabled" : "disabled";
      setLocalStorageWithExpiry(PROTECTION_TOGGLE_STATE_KEY, state);
    },
  );

  const hasProtectionReturnsAndSplit =
    autocheck.packageProtection.coverageEnabled &&
    (autocheck.coverageEnabled ||
      autocheck.finalSaleReturns?.coverageEnabled) &&
    autocheck.packageProtection.splitProducts;

  const localizedAutocheck = useMemo(
    () =>
      applyLocalizationTextOverrides({
        obj: autocheck,
        country: country ?? undefined,
        language: language ?? undefined,
        localizationGroups: autocheck.localizationGroups ?? [],
        localizationObjectId: autocheck.localizationObjectId,
        localizationTextOverrides: autocheck.localizationTextOverrides ?? [],
      }),
    [autocheck, country, language],
  );
  const allToggleOptions = getToggleTextOptions(localizedAutocheck);

  const priceDivisor = onTapcart ? 1 : 100;

  if (
    autocheck.attachmentStrategy == AttachmentStrategy.DOUBLE_TOGGLE &&
    hasProtectionReturnsAndSplit
  ) {
    let returnToggle: ReactNode = null;
    let packageProtectionToggle: ReactNode = null;

    if (coverageInfo.returns.cartEligible && returnRedoProduct) {
      const price = doesAttachmentStrategyUseCustomFee[
        autocheck.attachmentStrategy
      ]
        ? coverageInfo.returns.price / priceDivisor
        : getCorrectlyPricedVariant({
            product: returnRedoProduct,
            productType: CartProductType.Return,
            coverageInfo,
            country: country ?? undefined,
          }).price / priceDivisor;
      returnToggle = (
        <RedoToggle
          coverage={autocheck.coverage}
          finalSaleReturnsCoverageEnabled={coverageInfo.returns.isFinalSale}
          isDeluxe
          onChange={onReturnToggleChange}
          packageProtectionEnabled={coverageInfo.packageProtection.cartEligible}
          packageProtectionPlusEnabled={
            autocheck.packageProtection.packageProtectionPlusEnabled
          }
          paymentModel={autocheck.paidModel}
          price={{ amount: price || +fees.price, currency: cartCurrency }}
          returnsCoverageEnabled={coverageInfo.returns.cartEligible}
          theme={classicWidgetTheme}
          toggleFields={allToggleOptions.returnToggle}
          toggleText="returns"
          value={returnToggleState}
        />
      );
    }

    if (coverageInfo.packageProtection.cartEligible && packageRedoProduct) {
      const price = doesAttachmentStrategyUseCustomFee[
        autocheck.attachmentStrategy
      ]
        ? coverageInfo.packageProtection.price / priceDivisor
        : getCorrectlyPricedVariant({
            product: packageRedoProduct,
            productType: CartProductType.PackageProtection,
            coverageInfo,
            country: country ?? undefined,
          }).price / priceDivisor;
      packageProtectionToggle = (
        <RedoToggle
          coverage={autocheck.coverage}
          finalSaleReturnsCoverageEnabled={coverageInfo.returns.isFinalSale}
          isDeluxe
          onChange={onProtectionToggleChange}
          packageProtectionEnabled={coverageInfo.packageProtection.cartEligible}
          packageProtectionPlusEnabled={
            autocheck.packageProtection.packageProtectionPlusEnabled
          }
          paymentModel={autocheck.paidModel}
          price={{ amount: price || +fees.price, currency: cartCurrency }}
          returnsCoverageEnabled={coverageInfo.returns.cartEligible}
          theme={classicWidgetTheme}
          toggleFields={allToggleOptions.packageProtectionToggle}
          toggleText="Package Protection"
          value={protectionToggleState}
        />
      );
    }

    cartReactElement = (
      <DeluxeToggleArray theme={classicWidgetTheme}>
        {returnToggle}
        {packageProtectionToggle}
      </DeluxeToggleArray>
    );
  }

  for (const toggle of placedWidgetHtmlElements) {
    cartReactElements.push(
      ...toggle.redoHtmlElements.map((toggle, i) => (
        <StyleShadowRoot
          key={`${toggle.id}-${cartReactElements.length + i}`}
          shadowRoot={toggle.root}
          styleManager={STYLE_MANAGER}
        >
          {/* eslint-disable-next-line @typescript-eslint/no-non-null-assertion */}
          <ModalRootContext.Provider value={toggle.modalContainer!}>
            <meta found-selector={toggle.getAttribute("found-selector")} />
            {cartReactElement}
          </ModalRootContext.Provider>
        </StyleShadowRoot>
      )),
    );
  }

  return <>{cartReactElements}</>;
});
