import { Currency } from "@redotech/money/currencies";
import { useHandler } from "@redotech/react-util/hook";
import { StyleShadowRoot } from "@redotech/react-util/style";
import {
  AttachmentStrategy,
  doesAttachmentStrategyUseCustomFee,
} from "@redotech/redo-storefront-common/attachment-strategy";
import { ToggleFields } from "@redotech/redo-storefront-common/toggle-fields";
import { WidgetElementType } from "@redotech/redo-storefront-common/widget-config";
import { CartProductType } from "@redotech/redo-storefront-widget-common/cart-product-types";
import { defaultToggleTextOptions } from "@redotech/redo-storefront-widget-common/default-values";

import { CoverageInfo } from "@redotech/redo-return-coverage-common/coverage-calculator/coverage-info-from-calculators";
import {
  WidgetAutocheck,
  WidgetFees,
} from "@redotech/redo-storefront-widget-common/widget";

import { applyLocalizationTextOverrides } from "@redotech/redo-storefront-widget-common/use-localization-text-override";
import { ModalRootContext } from "@redotech/redo-web/modal-root";
import { setLocalStorageWithExpiry } from "@redotech/redo-web/utils/local-storage-wrapper";
import { memo, ReactNode, useEffect, useMemo } from "react";
import { CartCard } from "../cart-card";
import { CartCheckbox } from "../cart-checkbox";
import { getInternalAppStatusEmitter } from "../config";
import { log } from "../monitoring/log";
import { getClassicWidgetTheme } from "../render-elements/classic-widget-theme";
import STYLE_MANAGER from "../style-manager";
import { DeluxeToggleArray, RedoToggle } from "../toggle";
import { RedoProductToSell } from "../utils";
import { PlacedWidgetHtmlElements } from "../utils/element-placement";
import { RedoCheckoutButtonClickedEvent } from "../utils/internal-app-events";
import { SINGLE_TOGGLE_STATE_KEY } from "../utils/signals";
import { getToggleTextOptions } from "./helpers";

function getToggleText(
  autocheck: WidgetAutocheck,
  fees: WidgetFees,
  coverageInfo: CoverageInfo,
) {
  let toggleText = autocheck.checkboxText;

  const defaults = defaultToggleTextOptions(autocheck.coverage);
  const hasProtectionReturnsAndSplit =
    autocheck.packageProtection.coverageEnabled &&
    (autocheck.coverageEnabled ||
      autocheck.finalSaleReturns?.coverageEnabled) &&
    autocheck.packageProtection.splitProducts;

  const allToggleOptions = getToggleTextOptions(autocheck);

  let singleToggleFields: ToggleFields | undefined =
    allToggleOptions.returnToggle;
  switch (fees.mainType) {
    case CartProductType.Return: {
      singleToggleFields = allToggleOptions.returnToggle;

      break;
    }
    case CartProductType.Both: {
      singleToggleFields = allToggleOptions.bothProductToggle;

      break;
    }
    case CartProductType.PackageProtection: {
      singleToggleFields = allToggleOptions.packageProtectionToggle;

      break;
    }
    // No default
  }

  if (hasProtectionReturnsAndSplit) {
    if (
      coverageInfo?.returns.cartEligible &&
      coverageInfo?.packageProtection.cartEligible
    ) {
      singleToggleFields = allToggleOptions.bothProductToggle;
    } else if (coverageInfo?.packageProtection.cartEligible) {
      singleToggleFields = allToggleOptions.packageProtectionToggle;
    } else {
      singleToggleFields = allToggleOptions.packageProtectionToggle;
    }
  }

  if (
    !autocheck.checkboxText &&
    !(
      singleToggleFields.titleText === defaults.bothProductToggle.titleText ||
      singleToggleFields.titleText === defaults.returnToggle.titleText ||
      singleToggleFields.titleText ===
        defaults.packageProtectionToggle.titleText
    )
  ) {
    toggleText = singleToggleFields.titleText;
  }

  if (fees.splitProducts || autocheck.packageProtection.coverageEnabled) {
    toggleText = singleToggleFields.titleText;
  }

  return { toggleText, singleToggleFields };
}

export const SingleToggleManager = memo(function SingleToggleManager({
  autocheck,
  fees,
  placedWidgetHtmlElements,
  redoProductToSell,
  coverageInfo,
  cartCurrency,
  setSingleToggleVal,
  singleToggleState,
  country,
  language,
}: {
  autocheck: WidgetAutocheck;
  fees: WidgetFees;
  placedWidgetHtmlElements: PlacedWidgetHtmlElements[];
  redoProductToSell: RedoProductToSell;
  coverageInfo: CoverageInfo;
  cartCurrency: Currency;
  setSingleToggleVal: (value: boolean) => void;
  singleToggleState: boolean;
  country: string | undefined;
  language: string | undefined;
}) {
  const onToggleChange = useHandler((value: boolean, manual = true) => {
    log("toggle changed", { value, manual });
    setSingleToggleVal(value);
    const state = value ? "enabled" : "disabled";
    setLocalStorageWithExpiry(SINGLE_TOGGLE_STATE_KEY, state);
  });

  // Listen for internal RedoCheckoutButtonClickedEvent for ANY_WIDGET_* attachment strategies
  useEffect(() => {
    if (
      autocheck.attachmentStrategy === AttachmentStrategy.ANY_WIDGET_PRODUCT ||
      autocheck.attachmentStrategy === AttachmentStrategy.ANY_WIDGET_CUSTOM_FEE
    ) {
      const internalEmitter = getInternalAppStatusEmitter();
      const listener = (event: RedoCheckoutButtonClickedEvent) => {
        log(
          "Checkout button click event received and single toggles are active, updating toggle state",
          { event, attachmentStrategy: autocheck.attachmentStrategy },
        );
        // Update toggle state and localStorage based on the event
        onToggleChange(event.addCoverage, true);
      };

      internalEmitter.on("RedoCheckoutButtonClickedEvent", listener);

      return () => {
        internalEmitter.off("RedoCheckoutButtonClickedEvent", listener);
      };
    }
    return undefined;
  }, [autocheck.attachmentStrategy, onToggleChange]);

  const singleProductPrice = doesAttachmentStrategyUseCustomFee[
    autocheck.attachmentStrategy
  ]
    ? (redoProductToSell.rawCalculatedCoveragePrice ?? 0)
    : redoProductToSell.price;

  const localizedAutocheck = useMemo(
    () =>
      applyLocalizationTextOverrides({
        obj: autocheck,
        country: country ?? undefined,
        language: language ?? undefined,
        localizationGroups: autocheck.localizationGroups ?? [],
        localizationObjectId: autocheck.localizationObjectId,
        localizationTextOverrides: autocheck.localizationTextOverrides ?? [],
      }),
    [autocheck, country, language],
  );
  const classicWidgetTheme = getClassicWidgetTheme({
    autocheck: localizedAutocheck,
  });

  const { toggleText, singleToggleFields } = getToggleText(
    localizedAutocheck,
    fees,
    coverageInfo,
  );

  let cartReactElement: ReactNode | null = null;
  const cartReactElements: ReactNode[] = [];
  if (
    autocheck.attachmentStrategy === AttachmentStrategy.SINGLE_TOGGLE ||
    autocheck.attachmentStrategy ===
      AttachmentStrategy.TOGGLE_CUSTOM_CHECKOUT_FEE ||
    autocheck.attachmentStrategy === AttachmentStrategy.ANY_WIDGET_PRODUCT ||
    autocheck.attachmentStrategy === AttachmentStrategy.ANY_WIDGET_CUSTOM_FEE ||
    (!autocheck.attachmentStrategy && autocheck.cartToggle.enabled === true)
  ) {
    const deluxeVar = autocheck.toggleSubtextEnabled ?? false;
    const toggle = (
      <RedoToggle
        coverage={autocheck.coverage}
        finalSaleReturnsCoverageEnabled={coverageInfo.returns.isFinalSale}
        isDeluxe={deluxeVar}
        onChange={onToggleChange}
        packageProtectionEnabled={coverageInfo.packageProtection.cartEligible}
        packageProtectionPlusEnabled={
          autocheck.packageProtection.packageProtectionPlusEnabled
        }
        paymentModel={autocheck.paidModel}
        price={{
          amount: singleProductPrice || +fees.price,
          currency: cartCurrency,
        }}
        returnsCoverageEnabled={coverageInfo.returns.cartEligible}
        theme={classicWidgetTheme}
        toggleFields={singleToggleFields}
        toggleText={toggleText}
        value={singleToggleState}
      />
    );

    if (deluxeVar) {
      cartReactElement = (
        <DeluxeToggleArray theme={classicWidgetTheme}>
          {toggle}
        </DeluxeToggleArray>
      );
    } else {
      cartReactElement = toggle;
    }
  } else if (autocheck.attachmentStrategy === AttachmentStrategy.CART_CARD) {
    cartReactElement = (
      <CartCard
        coverage={autocheck.coverage}
        finalSaleReturnsCoverageEnabled={coverageInfo.returns.isFinalSale}
        onChange={onToggleChange}
        packageProtectionEnabled={coverageInfo.packageProtection.cartEligible}
        packageProtectionPlusEnabled={
          autocheck.packageProtection.packageProtectionPlusEnabled
        }
        price={{
          amount: singleProductPrice || +fees.price,
          currency: cartCurrency,
        }}
        returnsCoverageEnabled={coverageInfo.returns.cartEligible}
        theme={classicWidgetTheme}
        toggleFields={singleToggleFields}
        value={singleToggleState}
      />
    );
  }

  const cartCheckboxElement = (
    <CartCheckbox
      coverage={autocheck.coverage}
      finalSaleReturnsCoverageEnabled={coverageInfo.returns.isFinalSale}
      onChange={onToggleChange}
      packageProtectionEnabled={coverageInfo.packageProtection.cartEligible}
      packageProtectionPlusEnabled={
        autocheck.packageProtection.packageProtectionPlusEnabled
      }
      paymentModel={autocheck.paidModel}
      price={{
        amount: singleProductPrice || +fees.price,
        currency: cartCurrency,
      }}
      returnsCoverageEnabled={coverageInfo.returns.cartEligible}
      theme={classicWidgetTheme}
      toggleFields={singleToggleFields}
      value={singleToggleState}
    />
  );

  for (const toggle of placedWidgetHtmlElements) {
    const widgetElement =
      toggle.widgetConfig?.elementType === WidgetElementType.CART_CHECKBOX
        ? cartCheckboxElement
        : cartReactElement;
    cartReactElements.push(
      ...toggle.redoHtmlElements.map((toggle, i) => (
        <StyleShadowRoot
          key={`${toggle.id}-${cartReactElements.length + i}`}
          // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
          shadowRoot={toggle.root as ShadowRoot}
          styleManager={STYLE_MANAGER}
        >
          <ModalRootContext.Provider
            // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
            value={toggle.modalContainer as HTMLElement}
          >
            <meta found-selector={toggle.getAttribute("found-selector")} />
            {widgetElement}
          </ModalRootContext.Provider>
        </StyleShadowRoot>
      )),
    );
  }
  return <>{cartReactElements}</>;
});
