import { Currency } from "@redotech/money/currencies";
import { useLoad } from "@redotech/react-util/load";
import { StyleShadowRoot } from "@redotech/react-util/style";
import { getCoverageCreditAmount } from "@redotech/redo-return-coverage-common/coverage-calculator/coverage-credit-incentive";
import { CoverageInfo } from "@redotech/redo-return-coverage-common/coverage-calculator/coverage-info-from-calculators";
import {
  doesAttachmentStrategyUseCustomFee,
  isAttachmentStrategyUsingCheckoutButtons,
} from "@redotech/redo-storefront-common/attachment-strategy";
import { WidgetElementType } from "@redotech/redo-storefront-common/widget-config";
import { StorefrontCheckoutTextUtils } from "@redotech/redo-storefront-widget-common/storefront-checkout-text-utils";
import { applyLocalizationTextOverrides } from "@redotech/redo-storefront-widget-common/use-localization-text-override";
import {
  WidgetAutocheck,
  WidgetFees,
} from "@redotech/redo-storefront-widget-common/widget";
import { ModalRootContext } from "@redotech/redo-web/modal-root";
import {
  ExtensionShopifyClient,
  ShopifyCart,
} from "@redotech/shopify-client/ajax";
import { isDefined } from "@redotech/util/type";
import {
  lazy,
  memo,
  MouseEvent,
  Suspense,
  useEffect,
  useRef,
  useState,
} from "react";
import { getTryFirstTotals } from "../cart-optimization/cart-opt-modifications";
import { CheckoutButtons } from "../checkout-buttons";
import { ShopifyExtensionClient } from "../client/shopify-extension-client";
import { StorefrontClient } from "../client/storefront";
import { getProductInfoFromSource } from "../eligibility/returns-coverage-eligibility";
import { reportTiming } from "../monitoring/timing";
import { shouldShowCoverageRescuePanel } from "../redo-storefront/checkout-probability/should-show-coverage-rescue-panel";
import { FlexibleCheckoutButtons } from "../render-elements/flexible-coverage-checkout-buttons";
import { getInfoCardTheme, InfoCard } from "../render-elements/info-card";
import { getStorefrontMoneyLocale } from "../storefront-locale";
import STYLE_MANAGER from "../style-manager";
import { isPackageProtection, isRedoItem, RedoProductToSell } from "../utils";
import { commerceCloudMerchandiseTotal } from "../utils/checkout-button-utils";
import {
  getCheckoutButtonItemsToAdd,
  getCheckoutOnClickEvent,
  runHsaExistingCartCheckout,
} from "../utils/checkout-buttons/on-click-logic";
import { PlacedWidgetHtmlElements } from "../utils/element-placement";

const CoverageRescuePanelHost = lazy(async () => ({
  default: (await import("../redo-storefront/coverage-rescue-panel-host"))
    .CoverageRescuePanelHost,
}));

export const CheckoutButtonInfoCardManager = memo(
  function CheckoutButtonInfoCardManager({
    autocheck,
    fees,
    placedWidgetHtmlElements,
    setOnBuyNowCoverage,
    setOnHsaExistingCartCheckout,
    coverageInfo,
    redoProductToSell,
    productIdToSellingPlanId,
    cartCurrency,
    cart,
    shopifyClient,
    storefrontGraphqlClient,
    redoClient,
    anyCheckoutButtonClicked,
    triggerCartRefresh,
    country,
    language,
  }: {
    autocheck: WidgetAutocheck;
    fees: WidgetFees;
    placedWidgetHtmlElements: PlacedWidgetHtmlElements[];
    setOnBuyNowCoverage: (onClickCoverage: any) => void;
    setOnHsaExistingCartCheckout: (
      handler:
        | ((addCoverage: boolean, exclusive: boolean) => Promise<void>)
        | null,
    ) => void;
    coverageInfo: CoverageInfo;
    redoProductToSell: RedoProductToSell;
    productIdToSellingPlanId: Record<string, number>;
    cartCurrency: Currency;
    cart: ShopifyCart | undefined;
    shopifyClient: ExtensionShopifyClient;
    storefrontGraphqlClient: StorefrontClient | undefined;
    redoClient: ShopifyExtensionClient;
    anyCheckoutButtonClicked: boolean;
    triggerCartRefresh: () => void;
    country: string | undefined;
    language: string | undefined;
  }) {
    const allowingBubblingRef = useRef<boolean>(false);
    const [bundlerDiscountedCartValue, setBundlerDiscountedCartValue] =
      useState<number | null>(null);
    useEffect(() => {
      document.addEventListener("bundler:total_cart_values", function (e) {
        setBundlerDiscountedCartValue(
          // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
          (e as any)?.detail?.total_amount_discounted / 100,
        );
      });
    }, []);

    const hasProtectionReturnsAndSplit =
      autocheck.packageProtection.coverageEnabled &&
      (autocheck.coverageEnabled ||
        autocheck.finalSaleReturns?.coverageEnabled) &&
      autocheck.packageProtection.splitProducts;

    const sellingPlanId =
      productIdToSellingPlanId?.[String(redoProductToSell.productId)];

    const comparePriceOrHighestPriceLoad = useLoad(async () => {
      let compareAtPrice = 0;
      for (const item of cart?.items || []) {
        if (
          isRedoItem(item, autocheck.coverageProductIds) ||
          isPackageProtection(item, autocheck.coverageProductIds)
        ) {
          continue;
        }
        const { product } = await getProductInfoFromSource({
          autocheck,
          cartItem: item,
          shopifyClient,
          redoClient,
        });
        const variant = product?.variants.find(
          (v) => String(v.id) === String(item.variant_id),
        );
        const preDiscountPriceCents = item.original_line_price || 0;
        const preDiscountPriceDollars = preDiscountPriceCents / 100;
        const linePriceCents = item.line_price || 0;
        const linePriceDollars = linePriceCents / 100;
        // compare at price is already in dollars
        const comparePrice = variant?.compare_at_price
          ? parseFloat(variant.compare_at_price.toString()) * item.quantity
          : 0;

        // not all products have a compare at price, so we'll fallback to a pre-discount price or line price
        // that way this variable always represents the highest price of the product that we have.
        compareAtPrice +=
          comparePrice || preDiscountPriceDollars || linePriceDollars;
      }
      return compareAtPrice;
    }, [cart?.items]);

    const cartItems = cart?.items;
    const cart_subtotal = isDefined(bundlerDiscountedCartValue)
      ? bundlerDiscountedCartValue
      : (cartItems?.reduce((acc, item) => {
          if (
            isRedoItem(item, autocheck.coverageProductIds) ||
            isPackageProtection(item, autocheck.coverageProductIds)
          ) {
            return acc;
          }
          return acc + (item.line_price || 0);
        }, 0) || 0) / 100;

    const pre_discount_cart_subtotal =
      (cartItems?.reduce((acc, item) => {
        if (
          isRedoItem(item, autocheck.coverageProductIds) ||
          isPackageProtection(item, autocheck.coverageProductIds)
        ) {
          return acc;
        }
        return acc + (item.original_line_price || 0);
      }, 0) || 0) / 100;

    const tryFirstTotalDueLater = cart
      ? getTryFirstTotals({ cart, autocheck }).dueLaterTotal
      : 0;

    const redoInCartSubtotal =
      (cartItems?.reduce((acc, item) => {
        if (
          isRedoItem(item, autocheck.coverageProductIds) ||
          isPackageProtection(item, autocheck.coverageProductIds)
        ) {
          return acc + (item.line_price || 0);
        }
        return acc;
      }, 0) || 0) / 100;

    const coveragePrice = doesAttachmentStrategyUseCustomFee[
      autocheck.attachmentStrategy
    ]
      ? (redoProductToSell.rawCalculatedCoveragePrice ?? 0)
      : redoProductToSell.price;

    const cartTotal =
      globalThis.redoStorefront?.type === "commercecloud"
        ? commerceCloudMerchandiseTotal(cart, redoInCartSubtotal)
        : cart_subtotal;

    const moneyLocale = getStorefrontMoneyLocale();
    const textInfo = {
      mainProductType: fees.mainType,
      hasProtectionReturnsAndSplit,
      coverageInfo,
      currency: cartCurrency,
      locale: moneyLocale,
      coveragePrice,
      cartTotal,
      cartTotalPreDiscount: pre_discount_cart_subtotal,
      dueLaterTotal: tryFirstTotalDueLater,
      coverageCreditAmount: getCoverageCreditAmount(
        autocheck.coverageCreditIncentive,
        cart_subtotal,
      ),
      compareAtPrice: comparePriceOrHighestPriceLoad.value || 0,
    };

    const defaultCoverageButtonTexts =
      StorefrontCheckoutTextUtils.getCoverageTextAndSubtext(
        StorefrontCheckoutTextUtils.defaultCheckoutTexts.coverageButtonText,
        textInfo,
      );

    const defaultTextsForInfoCard =
      StorefrontCheckoutTextUtils.getCoverageTextAndSubtext(
        StorefrontCheckoutTextUtils.defaultCheckoutTexts.cardText,
        textInfo,
      );

    const defaultTextsForNonCoverageButton =
      StorefrontCheckoutTextUtils.getTextByProduct(
        StorefrontCheckoutTextUtils.defaultCheckoutTexts.nonCoverageButtonText,
        textInfo,
      );

    const hasFinalSaleCoverage =
      coverageInfo.returns.cartEligible && coverageInfo.returns.isFinalSale;

    const cartParams = new URLSearchParams();
    const itemsToAdd = getCheckoutButtonItemsToAdd({
      singleProductVariantId: redoProductToSell.variantId,
      singleProductId: redoProductToSell.productId,
      hasFinalSaleCoverage,
      sellingPlanId: sellingPlanId ?? null,
    });

    const onClickProps = {
      autocheck,
      client: shopifyClient,
      cart,
      itemsToAdd,
      cartParams,
      anyCheckoutButtonClicked,
      allowingBubblingRef,
      triggerCartRefresh,
      redoProductToSell,
    };

    const buyNowCoverageHandler = getCheckoutOnClickEvent(
      true,
      true,
      onClickProps,
    );
    const hsaExistingCartCheckoutHandler = (
      addCoverage: boolean,
      exclusive: boolean,
    ) => runHsaExistingCartCheckout(addCoverage, onClickProps, exclusive);

    // Re-registered after every render so the handlers carry the latest cart,
    // and cleared on unmount so a cart that stops being eligible (or a page
    // that stops showing coverage) cannot be checked out with a stale handler.
    useEffect(() => {
      setOnBuyNowCoverage(buyNowCoverageHandler);
      setOnHsaExistingCartCheckout(hsaExistingCartCheckoutHandler);
      return () => {
        setOnBuyNowCoverage(null);
        setOnHsaExistingCartCheckout(null);
      };
    });

    const onClickCoverage = getCheckoutOnClickEvent(true, false, onClickProps);
    const onClickRescuePanel = (
      event: MouseEvent<HTMLButtonElement>,
      discountCode: string | undefined,
    ) =>
      getCheckoutOnClickEvent(true, false, { ...onClickProps, discountCode })(
        event,
      );
    const onClickNoCoverage = getCheckoutOnClickEvent(
      false,
      false,
      onClickProps,
    );

    let cartReactElement = null;
    const cartReactElements: JSX.Element[] = [];

    if (
      isAttachmentStrategyUsingCheckoutButtons[autocheck.attachmentStrategy]
    ) {
      cartReactElement = (
        <CheckoutButtons
          customCss={autocheck.customToggleCss}
          defaultCoverageButtonTexts={defaultCoverageButtonTexts}
          defaultNonCoverageButtonText={defaultTextsForNonCoverageButton ?? ""}
          onClickNoCoverage={onClickNoCoverage}
          onCoverageCheckoutClick={onClickCoverage}
        />
      );
    }

    for (const { redoHtmlElements, widgetConfig } of placedWidgetHtmlElements) {
      let element = cartReactElement;
      if (
        isAttachmentStrategyUsingCheckoutButtons[
          autocheck.attachmentStrategy
        ] &&
        (widgetConfig?.elementType ===
          WidgetElementType.COVERAGE_CHECKOUT_BUTTON ||
          widgetConfig?.elementType ===
            WidgetElementType.NON_COVERAGE_CHECKOUT_BUTTON)
      ) {
        element = (
          <FlexibleCheckoutButtons
            cartTotal={Number(cart_subtotal)}
            cartTotalPreDiscount={pre_discount_cart_subtotal}
            compareAtPrice={comparePriceOrHighestPriceLoad.value ?? 0}
            coverageCreditAmount={getCoverageCreditAmount(
              autocheck.coverageCreditIncentive,
              cart_subtotal,
            )}
            coveragePrice={Number(coveragePrice)}
            currency={cartCurrency}
            customCss={autocheck.customToggleCss}
            dueLaterTotal={tryFirstTotalDueLater}
            html={widgetConfig.content}
            isCoverage={
              widgetConfig.elementType ===
              WidgetElementType.COVERAGE_CHECKOUT_BUTTON
            }
            locale={moneyLocale}
            onClickCoverage={onClickCoverage}
            onClickNoCoverage={onClickNoCoverage}
          />
        );
      } else if (
        isAttachmentStrategyUsingCheckoutButtons[
          autocheck.attachmentStrategy
        ] &&
        widgetConfig?.elementType === WidgetElementType.BOTH_CHECKOUT_BUTTONS
      ) {
        const localizedWidgetConfig = applyLocalizationTextOverrides({
          obj: widgetConfig,
          country: country ?? undefined,
          language: language ?? undefined,
          localizationGroups: autocheck.localizationGroups ?? [],
          localizationObjectId: widgetConfig?.localizationId ?? "",
          localizationTextOverrides: autocheck.localizationTextOverrides ?? [],
        });
        const coverageButtonText =
          StorefrontCheckoutTextUtils.getCoverageTextAndSubtext(
            localizedWidgetConfig?.coverageButtonText ??
              widgetConfig.coverageButtonText,
            textInfo,
          );
        const nonCoverageButtonText =
          StorefrontCheckoutTextUtils.getTextByProduct(
            localizedWidgetConfig?.nonCoverageButtonText ??
              widgetConfig.nonCoverageButtonText,
            textInfo,
          );
        const coverageButtonStyles = widgetConfig.coverageButtonStyles;

        element = cartReactElement = (
          <CheckoutButtons
            coverageButtonStyles={coverageButtonStyles}
            coverageButtonText={coverageButtonText}
            customCss={autocheck.customToggleCss}
            defaultCoverageButtonTexts={defaultCoverageButtonTexts}
            defaultNonCoverageButtonText={
              defaultTextsForNonCoverageButton ?? ""
            }
            nonCoverageButtonText={nonCoverageButtonText}
            onClickNoCoverage={onClickNoCoverage}
            onCoverageCheckoutClick={onClickCoverage}
            optOutButtonFirst={widgetConfig.optOutButtonFirst}
          />
        );
      } else if (widgetConfig?.elementType === WidgetElementType.INFO_CARD) {
        const localizedWidgetConfig = applyLocalizationTextOverrides({
          obj: widgetConfig,
          country: country ?? undefined,
          language: language ?? undefined,
          localizationGroups: autocheck.localizationGroups ?? [],
          localizationObjectId: widgetConfig?.localizationId ?? "",
          localizationTextOverrides: autocheck.localizationTextOverrides ?? [],
        });
        const localizedAutocheck = applyLocalizationTextOverrides({
          obj: autocheck,
          country: country ?? undefined,
          language: language ?? undefined,
          localizationGroups: autocheck.localizationGroups ?? [],
          localizationObjectId: autocheck.localizationObjectId,
          localizationTextOverrides: autocheck.localizationTextOverrides ?? [],
        });
        const titleAndSubtitle =
          StorefrontCheckoutTextUtils.getCoverageTextAndSubtext(
            localizedWidgetConfig?.cardText ?? widgetConfig.cardText,
            textInfo,
          );
        element = cartReactElement = (
          <InfoCard
            coverage={autocheck.coverage}
            defaultTexts={defaultTextsForInfoCard}
            finalSaleReturnsCoverageEnabled={coverageInfo.returns.isFinalSale}
            locale={moneyLocale}
            packageProtectionEnabled={
              coverageInfo.packageProtection.cartEligible
            }
            packageProtectionPlusEnabled={
              autocheck.packageProtection.packageProtectionPlusEnabled
            }
            price={{
              amount: coveragePrice || +fees.price,
              currency: cartCurrency,
            }}
            returnsCoverage={autocheck.coverage}
            returnsCoverageEnabled={coverageInfo.returns.cartEligible}
            subtitleText={titleAndSubtitle.subtitleText || ""}
            theme={getInfoCardTheme({
              autocheck: localizedAutocheck,
              widgetConfig,
            })}
            titleText={titleAndSubtitle.titleText || ""}
          />
        );
      }

      cartReactElements.push(
        ...redoHtmlElements.map((toggle, i) => (
          <StyleShadowRoot
            key={`${toggle.id}-${cartReactElements.length + i}`}
            shadowRoot={toggle.root}
            styleManager={STYLE_MANAGER}
          >
            {toggle.modalContainer ? (
              <ModalRootContext.Provider value={toggle.modalContainer}>
                <meta found-selector={toggle.getAttribute("found-selector")} />
                {element}
              </ModalRootContext.Provider>
            ) : (
              <>{element}</>
            )}
          </StyleShadowRoot>
        )),
      );
    }

    // Report timing for coverage button rendering
    if (cartReactElements.length > 0) {
      reportTiming("coverage.buttonRendered", {
        sendDatadogMetric: true,
        completeTiming: true,
      });
    }

    return (
      <>
        {cartReactElements}
        {shouldShowCoverageRescuePanel(autocheck) && (
          <Suspense fallback={null}>
            <CoverageRescuePanelHost
              autocheck={autocheck}
              cartClient={shopifyClient}
              cartToken={cart?.token}
              onCheckoutClick={onClickRescuePanel}
              storefrontClient={storefrontGraphqlClient}
            />
          </Suspense>
        )}
      </>
    );
  },
);
