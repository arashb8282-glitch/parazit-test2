import {
  defaultToggleTextOptions,
  fillEmptyFieldsWithDefault,
  makeEmptyToggleTexts,
} from "@redotech/redo-storefront-widget-common/default-values";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";

export function getToggleTextOptions(autocheck: WidgetAutocheck) {
  const allToggleOptions = makeEmptyToggleTexts();
  const defaults = defaultToggleTextOptions(autocheck.coverage);

  if (autocheck.toggleTextOptions) {
    allToggleOptions.returnToggle = fillEmptyFieldsWithDefault(
      autocheck.toggleTextOptions.returnToggle,
      defaults.returnToggle,
    );
    allToggleOptions.packageProtectionToggle = fillEmptyFieldsWithDefault(
      autocheck.toggleTextOptions.packageProtectionToggle,
      defaults.packageProtectionToggle,
    );
    allToggleOptions.bothProductToggle = fillEmptyFieldsWithDefault(
      autocheck.toggleTextOptions.bothProductToggle,
      defaults.bothProductToggle,
    );
  }

  return allToggleOptions;
}
