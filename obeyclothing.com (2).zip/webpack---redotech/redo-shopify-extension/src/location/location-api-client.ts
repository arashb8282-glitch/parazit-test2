import {
  getSessionStorageWithExpiry,
  setSessionStorageWithExpiry,
} from "@redotech/redo-web/utils/session-storage-wrapper";

export interface CountryLocation {
  country: string;
  region: string;
  timezone: string;
}

export interface CountryCityLocation extends CountryLocation {
  postalCode: string;
  city: string;
}

export interface LocationApiClient {
  /**
   * Get the country code for the current user's location.
   * @param signal AbortSignal for request cancellation
   * @returns Promise resolving to a 2-letter country code
   */
  getCountry(signal: AbortSignal): Promise<string>;

  /**
   * Get detailed location information for the current user.
   * @param signal AbortSignal for request cancellation
   * @returns Promise resolving to detailed location data
   */
  getDetailedLocation(signal: AbortSignal): Promise<CountryCityLocation>;
}

const COUNTRY_CODE_CACHE_KEY = "redo.country_code";
const DETAILED_LOCATION_CACHE_KEY = "redo.detailed_location";
const LOCATION_CACHE_HOURS = 10 / 60;

export abstract class CachedLocationApiClient implements LocationApiClient {
  protected abstract getCountryUncached(signal: AbortSignal): Promise<string>;
  protected abstract getDetailedLocationUncached(
    signal: AbortSignal,
  ): Promise<CountryCityLocation>;

  async getCountry(signal: AbortSignal): Promise<string> {
    const cachedCountry = getSessionStorageWithExpiry(COUNTRY_CODE_CACHE_KEY);
    if (cachedCountry) {
      return cachedCountry;
    }

    const countryCodeForUser = await this.getCountryUncached(signal);

    setSessionStorageWithExpiry(
      COUNTRY_CODE_CACHE_KEY,
      countryCodeForUser,
      LOCATION_CACHE_HOURS,
    );

    return countryCodeForUser;
  }

  async getDetailedLocation(signal: AbortSignal): Promise<CountryCityLocation> {
    const cachedLocation = getSessionStorageWithExpiry(
      DETAILED_LOCATION_CACHE_KEY,
    );
    if (cachedLocation) {
      return cachedLocation;
    }

    const locationForUser = await this.getDetailedLocationUncached(signal);

    setSessionStorageWithExpiry(
      DETAILED_LOCATION_CACHE_KEY,
      locationForUser,
      LOCATION_CACHE_HOURS,
    );

    return locationForUser;
  }
}
