import { log } from "../monitoring/log";
import {
  CachedLocationApiClient,
  CountryCityLocation,
} from "./location-api-client";

/**
 * Location client that uses the backend /widgets/location endpoint
 * to get location data based on the request IP address.
 */
export class StorefrontEmbedServerLocationClient extends CachedLocationApiClient {
  constructor(private readonly baseUrl: string) {
    super();
  }

  protected async getCountryUncached(signal: AbortSignal): Promise<string> {
    const location = await this.getDetailedLocationUncached(signal);
    return location.country;
  }

  protected async getDetailedLocationUncached(
    signal: AbortSignal,
  ): Promise<CountryCityLocation> {
    const response = await fetch(`${this.baseUrl}/unauthed/location`, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
      signal,
    });

    if (!response.ok) {
      log(
        `Failed to fetch location from IP geolocation backend ${response.status} ${response.statusText}`,
      );
      throw new Error(
        `Failed to fetch location: ${response.status} ${response.statusText}`,
      );
    }

    const locationData: CountryCityLocation = await response.json();

    return locationData;
  }
}
