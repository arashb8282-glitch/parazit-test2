import { createContext, memo } from "react";
import { LocationApiClient } from "./location-api-client";
import { StorefrontEmbedServerLocationClient } from "./storefront-embed-server-location-client";

export const LocationClientContext = createContext<
  LocationApiClient | undefined
>(undefined);

export interface LocationClientProviderProps {
  children: React.ReactNode;
}

export const LocationClientProvider = memo(function LocationClientProvider({
  children,
}: LocationClientProviderProps) {
  const client = getLocationApiClientFromEnv();

  return (
    <LocationClientContext.Provider value={client}>
      {children}
    </LocationClientContext.Provider>
  );
});

export const getLocationApiClientFromEnv = (): LocationApiClient => {
  return new StorefrontEmbedServerLocationClient(
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    globalThis.redoStorefront?.env?.REDO_API_URL ?? process.env.REDO_API_URL!,
  );
};
