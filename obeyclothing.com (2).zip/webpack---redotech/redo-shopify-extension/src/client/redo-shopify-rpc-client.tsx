import type { RedoShopifyRpcClient } from "@redotech/shopify-sdk/rpc/client";
import { createRedoShopifyRpcClient } from "@redotech/shopify-sdk/rpc/client";
import type { RedoShopifyConversionRpcClient } from "@redotech/shopify-sdk/rpc/conversion-client";
import { createRedoShopifyConversionRpcClient } from "@redotech/shopify-sdk/rpc/conversion-client";
import {
  STORE_URL_HEADER,
  WIDGET_ID_HEADER,
} from "@redotech/shopify-sdk/rpc/custom-http-headers";
import { Context, createContext, memo, ReactNode, useMemo } from "react";

export const RedoShopifyRpcClientContext: Context<
  RedoShopifyRpcClient | undefined
> = createContext<RedoShopifyRpcClient | undefined>(undefined);

/**
 * Context for the narrow conversion-pool RPC client. Its type exposes only
 * the three endpoints routed to the conversion-dedicated ECS pool
 * (`getSessionHazardProbabilities`, `watchFailedDiscountAttempt`,
 * `recordCheckoutConversionMetric`); any other RPC name is a compile error.
 * Requests target `/rpc/conversion/<name>` and match the
 * ALB rule for paths under `/rpc/conversion/`. See redo/shopify/infra/src/index.ts.
 */
export const RedoShopifyConversionRpcClientContext: Context<
  RedoShopifyConversionRpcClient | undefined
> = createContext<RedoShopifyConversionRpcClient | undefined>(undefined);

export const RedoShopifyRpcClientContextProvider = memo(
  function RedoShopifyRpcClientContextProvider({
    children,
    baseUrl,
    authToken,
    widgetId,
    storeUrl,
  }: {
    children: ReactNode | ReactNode[];
    baseUrl?: string | undefined;
    authToken?: string | undefined;
    widgetId?: string | undefined;
    storeUrl?: string | undefined;
  }) {
    const { client, conversionClient } = useMemo(() => {
      if (!baseUrl) {
        return { client: undefined, conversionClient: undefined };
      }

      const authHeaders: Record<string, string> = authToken
        ? { Authorization: `Bearer ${authToken}` }
        : {};
      const widgetHeaders: Record<string, string> = widgetId
        ? { [WIDGET_ID_HEADER]: widgetId }
        : {};
      const storeUrlHeaders: Record<string, string> = storeUrl
        ? { [STORE_URL_HEADER]: storeUrl }
        : {};
      const headers = { ...widgetHeaders, ...storeUrlHeaders, ...authHeaders };
      return {
        client: createRedoShopifyRpcClient({
          baseURL: new URL(`${baseUrl}/rpc`),
          headers,
        }),
        conversionClient: createRedoShopifyConversionRpcClient({
          baseURL: new URL(`${baseUrl}/rpc/conversion`),
          headers,
        }),
      };
      // FIXME
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [baseUrl, authToken]);

    return client && conversionClient ? (
      <RedoShopifyRpcClientContext.Provider value={client}>
        <RedoShopifyConversionRpcClientContext.Provider
          value={conversionClient}
        >
          {children}
        </RedoShopifyConversionRpcClientContext.Provider>
      </RedoShopifyRpcClientContext.Provider>
    ) : null;
  },
);
