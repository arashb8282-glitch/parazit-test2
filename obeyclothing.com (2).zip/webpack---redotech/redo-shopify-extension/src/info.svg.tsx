import * as React from "react";
const SvgInfo = props => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" {...props}><defs /><g id="Redo_Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><circle className="cls-1" cx={50} cy={50} r={46.5} fill="none" stroke="currentColor" style={{
        strokeMiterlimit: 10,
        strokeWidth: 7
      }} /><path d="M50,25a4.49,4.49,0,0,1,4.51,4.5A4.43,4.43,0,0,1,50,33.92a4.36,4.36,0,0,1-4.43-4.43A4.42,4.42,0,0,1,50,25ZM46.61,41.43h6.78V75H46.61Z" fill="currentColor" /></g></g></svg>;
export default SvgInfo;