import type { RedoShopifyRpcClient } from "@redotech/shopify-sdk/rpc/client";
import { useContext, useEffect } from "react";
import { RedoShopifyRpcClientContext } from "./client/redo-shopify-rpc-client";
import type { RedoEmittedDomEvent } from "./dom-events";
import { log } from "./monitoring/log";

/**
 * Forwards a dispatched storefront coverage DOM event to its RPC; failures are
 * logged and never retried.
 */
export function useStorefrontCoverageEventForwarder<
  TPayload extends { eventId: string },
>({
  domEvent,
  send,
  failureMessage,
}: {
  domEvent: RedoEmittedDomEvent;
  send: (
    rpcClient: RedoShopifyRpcClient,
    payload: TPayload,
  ) => Promise<unknown>;
  failureMessage: string;
}): void {
  const rpcClient = useContext(RedoShopifyRpcClientContext);

  useEffect(() => {
    if (!rpcClient) {
      return;
    }

    const handler = (event: Event) => {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      const payload = (event as CustomEvent<TPayload>).detail;
      send(rpcClient, payload).catch((error) => {
        log(failureMessage, error, { eventId: payload.eventId });
      });
    };

    window.addEventListener(domEvent, handler);
    return () => {
      window.removeEventListener(domEvent, handler);
    };
  }, [rpcClient, domEvent, send, failureMessage]);
}
