import { MerchantStyle } from "@redotech/arbiter/merchant-style";
import { Money } from "@redotech/money";
import { moneyFormat } from "@redotech/money/util";
import { useHandler } from "@redotech/react-util/hook";
import { Lazy } from "@redotech/react-util/init";
import GiftIcon from "@redotech/redo-icons/gift-01.svg";
import LockIcon from "@redotech/redo-icons/lock-03.svg";
import ShieldIcon from "@redotech/redo-icons/shield-tick.svg";
import {
  Coverage,
  PaymentModel,
} from "@redotech/redo-return-coverage-common/coverage";
import {
  fullCoverage,
  getHtml,
  getReturnType,
  texts,
} from "@redotech/redo-storefront-common/checkbox";
import { DEFAULT_CHECKBOX_ICON_POSITION } from "@redotech/redo-storefront-common/checkbox-icon-position";
import { ToggleFields } from "@redotech/redo-storefront-common/toggle-fields";
import htmlReactParser from "html-react-parser";
import type { CSSProperties } from "react";
import {
  ChangeEvent,
  lazy,
  MouseEvent,
  Suspense,
  useId,
  useMemo,
  useRef,
  useState,
} from "react";
import * as cartCheckbox from "./cart-checkbox.module.css";
import {
  RedoEmittedDomEvent,
  useFireEventOnRender,
  useInfoModalOpenEvents,
} from "./dom-events";
import Info from "./info.svg";
import { ClassicWidgetTheme } from "./render-elements/classic-widget-theme";
import { getAccessibilityTranslation } from "./storefront-locale";
import { recordCoverageInfoModalOpened } from "./utils/coverage-info-modal-opened";

const RedoModal = lazy(async () => {
  const { RedoModal } = await import("./modal");
  return { default: RedoModal };
});

const ICONS = { gift: GiftIcon, lock: LockIcon, shield: ShieldIcon };

function fillPrice(text: string, price: string | undefined) {
  return text.replace(/%price%/g, price ?? "");
}

/**
 * Cart coverage opt-in rendered as a checkbox row rather than a switch. Same
 * opt-in state, text fields, and info modal as {@link RedoToggle}.
 */
export const CartCheckbox = ({
  theme,
  coverage,
  toggleFields,
  value,
  onChange,
  paymentModel,
  price,
  packageProtectionPlusEnabled,
  packageProtectionEnabled,
  returnsCoverageEnabled,
  finalSaleReturnsCoverageEnabled,
}: {
  theme: ClassicWidgetTheme;
  coverage: Coverage;
  toggleFields: ToggleFields;
  value: boolean;
  onChange?(value: boolean): void;
  paymentModel: PaymentModel;
  price: Money | undefined;
  packageProtectionPlusEnabled?: boolean;
  packageProtectionEnabled?: boolean;
  returnsCoverageEnabled: boolean;
  finalSaleReturnsCoverageEnabled: boolean;
}) => {
  useFireEventOnRender(RedoEmittedDomEvent.CartCheckboxRendered);
  const [modalOpen, setModalOpen] = useState(false);
  const checkboxId = useId();
  const descriptionId = `${checkboxId}-description`;
  useInfoModalOpenEvents(setModalOpen);
  const {
    checkboxIconPosition,
    color,
    customCss,
    fontSize,
    html,
    icon,
    modalCustomizationsV2,
    modalVersion,
    returnPolicyUrl,
    showInfoIcon,
    toggleOnColor,
  } = theme;

  const infoButtonRef = useRef<HTMLElement | null>(null);
  const onInfoClick = useHandler((e?: MouseEvent<HTMLElement>) => {
    infoButtonRef.current = e?.currentTarget ?? null;
    setModalOpen(true);
    recordCoverageInfoModalOpened();
  });
  const onModalClose = useHandler(() => setModalOpen(false));

  const onCheckboxChange = useMemo(
    () => (e: ChangeEvent) => {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      if ((globalThis as any).redoMode === "preview") {
        alert("Clicked!");
        return;
      }
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      onChange?.((e.target as HTMLInputElement).checked);
    },
    [onChange],
  );

  const formattedPrice =
    paymentModel === PaymentModel.CUSTOMER_PAID && price
      ? moneyFormat(price)
      : undefined;
  const isCustomerPaid = paymentModel === PaymentModel.CUSTOMER_PAID;
  const CheckboxLabel = isCustomerPaid ? "label" : "span";

  const titleText = toggleFields.titleText;
  /** Text that places the price itself suppresses the standalone price column. */
  const titleContainsPrice = titleText.includes("%price%");
  const subtext = value
    ? toggleFields.positiveSubtext
    : toggleFields.negativeSubtext;

  const coverageName =
    texts[
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      `${+coverage.exchange}${+coverage.refund}${+coverage.storeCredit}` as `${0 | 1}${0 | 1}${0 | 1}`
    ];

  const Icon = icon ? ICONS[icon] : undefined;
  const infoIconPosition =
    checkboxIconPosition ?? DEFAULT_CHECKBOX_ICON_POSITION;
  const accessibilityTranslation = getAccessibilityTranslation();
  const infoIconElement = showInfoIcon && (
    <span
      className={cartCheckbox.modalTrigger}
      data-target="cart-checkbox-info"
    >
      {/* design-allow: storefront widget renders raw elements in the shadow root, matching the rest of this file */}
      <button
        aria-haspopup="dialog"
        aria-label={accessibilityTranslation.moreInformationAboutCoverage}
        className={cartCheckbox.info}
        data-target="cart-checkbox-info-button"
        onClick={onInfoClick}
        type="button"
      >
        <Info aria-hidden className={cartCheckbox.infoIcon} />
      </button>
    </span>
  );

  return (
    <>
      <MerchantStyle css={customCss} />
      <div
        className={cartCheckbox.container}
        data-target="cart-checkbox-root"
        style={
          {
            color,
            fontSize: fontSize
              ? `${fontSize.toString()}px`
              : "var(--redo-font-size-sm)",
            "--redo-checkbox-color": toggleOnColor || color,
          } as CSSProperties
        }
      >
        <span className={cartCheckbox.titleRow} data-target="cart-checkbox-row">
          <CheckboxLabel
            className={cartCheckbox.checkboxLabel}
            htmlFor={isCustomerPaid ? checkboxId : undefined}
          >
            {isCustomerPaid && (
              // design-allow: storefront widget injected into merchant pages; native checkbox required
              <input
                aria-describedby={subtext ? descriptionId : undefined}
                checked={value}
                className={cartCheckbox.checkbox}
                data-target="cart-checkbox-input"
                id={checkboxId}
                onChange={onCheckboxChange}
                type="checkbox"
              />
            )}
            {Icon && (
              <span
                className={cartCheckbox.iconContainer}
                data-target="cart-checkbox-icon"
              >
                <Icon aria-hidden className={cartCheckbox.icon} />
              </span>
            )}
            <span
              className={cartCheckbox.title}
              data-target="cart-checkbox-title"
            >
              {titleText ? (
                htmlReactParser(fillPrice(titleText, formattedPrice))
              ) : (
                <>
                  {html ? (
                    htmlReactParser(
                      getHtml(html, getReturnType(coverage)) ?? "",
                    )
                  ) : (
                    <strong>Free Unlimited Returns</strong>
                  )}
                  {coverageName !== fullCoverage && <> for {coverageName}</>}
                </>
              )}
            </span>
            {formattedPrice && !titleContainsPrice && (
              <span
                className={cartCheckbox.price}
                data-target="cart-checkbox-price"
              >
                {formattedPrice}
              </span>
            )}
          </CheckboxLabel>
          {infoIconPosition === "title_right" && infoIconElement}
        </span>
        {(subtext ||
          (showInfoIcon && infoIconPosition === "description_right")) && (
          <span
            className={cartCheckbox.subtext}
            data-target="cart-checkbox-subtext"
            id={descriptionId}
          >
            {subtext
              ? htmlReactParser(fillPrice(subtext, formattedPrice))
              : null}
            {infoIconPosition === "description_right" && infoIconElement}
          </span>
        )}
      </div>
      <Suspense>
        <Lazy init={modalOpen}>
          <RedoModal
            enableTopLayerModalApi={
              modalCustomizationsV2?.enableTopLayerModalApi
            }
            finalSaleReturnsCoverageEnabled={finalSaleReturnsCoverageEnabled}
            modalCustomizationsV2={modalCustomizationsV2}
            onClose={onModalClose}
            open={modalOpen}
            packageProtectionEnabled={packageProtectionEnabled}
            packageProtectionPlusEnabled={packageProtectionPlusEnabled}
            returnFocusRef={infoButtonRef}
            returnPolicyUrl={returnPolicyUrl}
            returnsCoverage={coverage}
            returnsCoverageEnabled={returnsCoverageEnabled}
            version={modalVersion}
          />
        </Lazy>
      </Suspense>
    </>
  );
};
