import { type CoverageWidgetRenderedPayload } from "@redotech/redo-customer-event-common/events/coverage-widget-rendered";
import type { RedoShopifyRpcClient } from "@redotech/shopify-sdk/rpc/client";
import { recordCoverageWidgetRendered as recordCoverageWidgetRenderedRpc } from "@redotech/shopify-sdk/rpc/schema/record-coverage-widget-rendered";
import { memo } from "react";
import { RedoEmittedDomEvent } from "./dom-events";
import { useStorefrontCoverageEventForwarder } from "./use-storefront-coverage-event-forwarder";

export const CoverageWidgetRenderedTracker = memo(
  function CoverageWidgetRenderedTracker() {
    useStorefrontCoverageEventForwarder<CoverageWidgetRenderedPayload>({
      domEvent: RedoEmittedDomEvent.CoverageWidgetRendered,
      send: sendCoverageWidgetRendered,
      failureMessage: "Error sending coverage widget rendered event",
    });
    return null;
  },
);

function sendCoverageWidgetRendered(
  rpcClient: RedoShopifyRpcClient,
  payload: CoverageWidgetRenderedPayload,
) {
  return rpcClient(recordCoverageWidgetRenderedRpc, payload);
}
