import {
  Theme as MuiTheme,
  ThemeProvider as MuiThemeProvider,
} from "@mui/material/styles";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import { RedoClientProvider } from "@redotech/redo-web/client";
import { ExtensionShopifyClient } from "@redotech/shopify-client/ajax";
import { ReactNode } from "react";
import { ShopifyExtensionClientProvider } from "./client/client-context";
import { LocationClientProvider } from "./location/location-client-context";
import { ErrorBoundaryMonitor } from "./monitoring/error-boundary-monitor";
import { ExtensionShopifyClientContext } from "./shopify";

export const RedoRoot = ({
  autocheck,
  children,
  extensionShopifyClient,
  widgetId,
  storeUrl,
  muiTheme,
}: {
  children: ReactNode;
  autocheck?: WidgetAutocheck;
  extensionShopifyClient: ExtensionShopifyClient | undefined;
  widgetId?: string;
  storeUrl?: string;
  muiTheme?: MuiTheme;
}) => {
  if (extensionShopifyClient) {
    children = (
      <ExtensionShopifyClientContext.Provider value={extensionShopifyClient}>
        {children}
      </ExtensionShopifyClientContext.Provider>
    );
  }
  if (muiTheme) {
    children = <MuiThemeProvider theme={muiTheme}>{children}</MuiThemeProvider>;
  }

  return (
    <LocationClientProvider>
      <RedoClientProvider
        url={
          globalThis.redoStorefront?.env?.REDO_API_URL ??
          // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
          process.env.REDO_API_URL!
        }
      >
        <ShopifyExtensionClientProvider storeUrl={storeUrl} widgetId={widgetId}>
          <ErrorBoundaryMonitor>{children}</ErrorBoundaryMonitor>
        </ShopifyExtensionClientProvider>
      </RedoClientProvider>
    </LocationClientProvider>
  );
};
