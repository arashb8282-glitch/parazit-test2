import { MerchantStyle } from "@redotech/arbiter/merchant-style";
import { Money } from "@redotech/money";
import { moneyFormat } from "@redotech/money/util";
import { useHandler } from "@redotech/react-util/hook";
import { Lazy } from "@redotech/react-util/init";
import GiftIcon from "@redotech/redo-icons/gift-01.svg";
import LockIcon from "@redotech/redo-icons/lock-03.svg";
import ShieldIcon from "@redotech/redo-icons/shield-tick.svg";
import { Coverage } from "@redotech/redo-return-coverage-common/coverage";
import { Icons } from "@redotech/redo-storefront-common/checkout-ui-customization";
import { InfoModal } from "@redotech/redo-storefront-common/info-modal";
import { InfoModalVersion } from "@redotech/redo-storefront-common/info-modal-version";
import {
  ImageElementType,
  PriceLocation,
} from "@redotech/redo-storefront-common/widget-config";
import { createCssLine } from "@redotech/redo-storefront-web/utils/generate-css-from-model-style";
import { DEFAULT_IMAGE_URL } from "@redotech/redo-storefront-widget-common/default-values";
import {
  InfoCardStyles,
  InfoCard as InfoCardWidgetConfig,
  TitleSubtitle,
  WidgetAutocheck,
} from "@redotech/redo-storefront-widget-common/widget";
import classNames from "classnames";
import { lazy, memo, MouseEvent, Suspense, useRef, useState } from "react";
import * as cardCss from "../cart-card.module.css";
import {
  RedoEmittedDomEvent,
  useFireEventOnRender,
  useInfoModalOpenEvents,
} from "../dom-events";
import { TwoLineToggleLabel } from "../toggle";
import { recordCoverageInfoModalOpened } from "../utils/coverage-info-modal-opened";
import * as infoCardCss from "./info-card.module.css";

const RedoModal = lazy(async () => {
  const { RedoModal } = await import("../modal");
  return { default: RedoModal };
});

export const CardImage = memo(function CardImage({
  img_url,
}: {
  img_url: string;
}) {
  return (
    <img
      className={cardCss.imageContainer}
      data-target="card-image"
      src={img_url}
    />
  );
});

export interface InfoCardTheme {
  color: string;
  fontSize?: number;
  customCss?: string;
  image_url: string;
  infoCardStyles?: InfoCardStyles;
  showInfoIcon?: boolean;
  modalTextAdjustments?: {
    text1: string;
    title1: string;
    text2: string;
    title2: string;
    text3: string;
    title3: string;
  };
  modalV1Logo?: string;
  imageElement?: ImageElementType;
  showBackground?: boolean;
  modalCustomizationsV2?: InfoModal;
  priceLocation?: PriceLocation;
  dataTarget?: string;
  badgeWord?: string;
  infoButtonCustomAttributes?: Record<string, string>;
  returnPolicyUrl?: string;
}

export const getInfoCardTheme = ({
  autocheck,
  widgetConfig,
}: {
  autocheck: WidgetAutocheck;
  widgetConfig: InfoCardWidgetConfig;
}): InfoCardTheme => {
  return {
    color: autocheck.textColor,
    badgeWord: widgetConfig.badgeWord,
    customCss: autocheck.customToggleCss,
    dataTarget: widgetConfig.dataTarget,
    fontSize: autocheck.toggleFontSize,
    image_url: (autocheck.logo && autocheck.logo.trim()) || DEFAULT_IMAGE_URL,
    imageElement: widgetConfig.imageElement,
    infoCardStyles: widgetConfig.infoCardStyles,
    modalCustomizationsV2: autocheck.infoModal,
    modalTextAdjustments: autocheck.modalTextAdjustments,
    modalV1Logo: autocheck.modalLogo,
    priceLocation: widgetConfig.priceLocation,
    showBackground: widgetConfig.showBackground,
    showInfoIcon:
      widgetConfig.showInfoIcon ?? autocheck.infoModal?.cartIconEnabled,
    infoButtonCustomAttributes: widgetConfig.infoButtonCustomAttributes,
    returnPolicyUrl: autocheck.returnPolicyUrl,
  };
};

export const InfoCard = ({
  theme,
  coverage,
  price,
  locale,
  returnsCoverage,
  packageProtectionPlusEnabled,
  packageProtectionEnabled,
  subtitleText,
  titleText,
  defaultTexts,
  returnsCoverageEnabled,
  finalSaleReturnsCoverageEnabled,
}: {
  theme: InfoCardTheme;
  coverage: Coverage;
  price: Money | undefined;
  locale?: string;
  returnsCoverage?: Coverage;
  packageProtectionPlusEnabled?: boolean;
  packageProtectionEnabled?: boolean;
  subtitleText: string;
  titleText: string;
  defaultTexts: TitleSubtitle;
  returnsCoverageEnabled: boolean;
  finalSaleReturnsCoverageEnabled: boolean;
}) => {
  useFireEventOnRender(RedoEmittedDomEvent.InfoCardRendered);
  const [modalOpen, setModalOpen] = useState(false);
  const {
    color,
    badgeWord,
    customCss,
    dataTarget,
    fontSize,
    image_url,
    imageElement,
    infoCardStyles,
    modalCustomizationsV2,
    modalTextAdjustments,
    modalV1Logo,
    priceLocation,
    showBackground,
    showInfoIcon,
    infoButtonCustomAttributes,
    returnPolicyUrl,
  } = theme;

  const infoButtonRef = useRef<HTMLElement | null>(null);
  const onInfoClick = (e?: MouseEvent<HTMLElement>) => {
    infoButtonRef.current = e?.currentTarget ?? null;
    setModalOpen(true);
    recordCoverageInfoModalOpened();
  };

  const onModalClose = useHandler(() => {
    setModalOpen(false);
  });

  useInfoModalOpenEvents(setModalOpen);

  const cardClasses = [infoCardCss.cardContainer];

  // should show card background if undefined or true
  const shouldShowBackground = showBackground !== false;

  if (shouldShowBackground) {
    cardClasses.push(infoCardCss.backgroundColor);
  }

  const generatedCssFromStyle = generateInfoCardCssFromModelStyle(
    shouldShowBackground,
    infoCardStyles,
  );

  return (
    <>
      {generatedCssFromStyle ? <style>{generatedCssFromStyle}</style> : null}
      <MerchantStyle css={customCss} />

      <div
        className={classNames(cardClasses)}
        data-target={dataTarget || "info-card-container"}
      >
        <ImageElement
          image_url={image_url}
          imageElement={imageElement}
          imageIconInfo={{}}
        />

        <div
          className={infoCardCss.textContainer}
          data-target="text-and-buttons-container"
        >
          <TwoLineToggleLabel
            badge={badgeWord}
            color={color}
            coverage={coverage}
            fontSize={fontSize ?? 14}
            infoButtonCustomAttributes={infoButtonCustomAttributes}
            onInfoClick={onInfoClick}
            price={
              priceLocation === PriceLocation.TITLE && price
                ? moneyFormat(price, undefined, locale)
                : undefined
            }
            showInfoIcon={showInfoIcon}
            subtlePrice
            titleFontWeight={600}
            toggleSubtitleText={subtitleText || defaultTexts.subtitleText || ""}
            toggleTitleText={titleText || defaultTexts.titleText || ""}
          >
            {null}
          </TwoLineToggleLabel>
        </div>
        {(!priceLocation || priceLocation === PriceLocation.RIGHT) && (
          <div className={infoCardCss.priceContainer}>
            <span data-target="price">
              {price && moneyFormat(price, undefined, locale)}
            </span>
          </div>
        )}
      </div>
      <Suspense>
        <Lazy init={modalOpen}>
          <RedoModal
            enableTopLayerModalApi={
              modalCustomizationsV2?.enableTopLayerModalApi
            }
            finalSaleReturnsCoverageEnabled={finalSaleReturnsCoverageEnabled}
            modalCustomizationsV2={modalCustomizationsV2}
            modalLogo={modalV1Logo}
            modalTextAdjustments={modalTextAdjustments}
            onClose={onModalClose}
            open={modalOpen}
            packageProtectionEnabled={packageProtectionEnabled}
            packageProtectionPlusEnabled={packageProtectionPlusEnabled}
            returnFocusRef={infoButtonRef}
            returnPolicyUrl={returnPolicyUrl}
            returnsCoverage={returnsCoverage}
            returnsCoverageEnabled={returnsCoverageEnabled}
            version={modalCustomizationsV2?.version || InfoModalVersion.V1}
          />
        </Lazy>
      </Suspense>
    </>
  );
};

const ImageElement = ({
  imageElement,
  image_url,
  imageIconInfo,
}: {
  imageElement?: ImageElementType;
  image_url: string;
  imageIconInfo: { type?: Icons; color?: string; backgroundColor?: string };
}) => {
  if (image_url === "") {
    image_url = DEFAULT_IMAGE_URL;
  }

  const containerStyles: { color?: string; backgroundColor?: string } = {};
  if (imageIconInfo.color) {
    containerStyles.color = imageIconInfo.color;
  }
  if (imageIconInfo.backgroundColor) {
    containerStyles.backgroundColor = imageIconInfo.backgroundColor;
  }
  return (
    <>
      {(imageElement === ImageElementType.CUSTOM_IMAGE || !imageElement) &&
        image_url && (
          <div className={classNames(infoCardCss.imageContainer)}>
            <img
              alt="Brand Logo"
              className={infoCardCss.imageElement}
              data-target="info-card-image"
              src={image_url}
            />
            {imageIconInfo.type ? (
              <div className={cardCss.iconContainer} style={containerStyles}>
                {imageIconInfo.type === "gift" && (
                  <GiftIcon className={cardCss.icon} />
                )}
                {imageIconInfo.type === "lock" && (
                  <LockIcon className={cardCss.icon} />
                )}
                {imageIconInfo.type === "shield" && (
                  <ShieldIcon className={cardCss.icon} />
                )}
              </div>
            ) : undefined}
          </div>
        )}
      {imageElement === ImageElementType.GIFT && (
        <GiftIcon className={infoCardCss.icon} />
      )}
      {imageElement === ImageElementType.LOCK && (
        <LockIcon className={infoCardCss.icon} />
      )}
      {imageElement === ImageElementType.SHIELD && (
        <ShieldIcon className={infoCardCss.icon} />
      )}
    </>
  );
};

function generateInfoCardCssFromModelStyle(
  shouldShowBackground: boolean,
  style?: InfoCardStyles,
) {
  if (!style) {
    return "";
  }
  let generatedCssFromStyle = "";
  if (shouldShowBackground && style.color) {
    generatedCssFromStyle += createCssLine(
      "info-card-container",
      "background-color",
      style.color,
    );
  }

  if (style.titleFontSize) {
    generatedCssFromStyle += createCssLine(
      "toggle-label",
      "font-size",
      style.titleFontSize.toString(),
      "px",
    );
  }

  if (style.titleFontColor) {
    generatedCssFromStyle += createCssLine(
      "toggle-label",
      "color",
      style.titleFontColor,
    );
  }

  if (style.subtitleFontColor) {
    generatedCssFromStyle += createCssLine(
      "toggle-subtext",
      "color",
      style.subtitleFontColor,
    );
  }

  if (style.subtitleFontSize) {
    generatedCssFromStyle += createCssLine(
      "toggle-subtext",
      "font-size",
      style.subtitleFontSize.toString(),
      "px",
    );
  }
  return generatedCssFromStyle;
}
