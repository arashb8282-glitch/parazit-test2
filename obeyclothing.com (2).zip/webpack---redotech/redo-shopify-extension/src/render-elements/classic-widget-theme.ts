import type { CheckboxIconPosition } from "@redotech/redo-storefront-common/checkbox-icon-position";
import { Icons } from "@redotech/redo-storefront-common/checkout-ui-customization";
import { InfoModal } from "@redotech/redo-storefront-common/info-modal";
import { InfoModalVersion } from "@redotech/redo-storefront-common/info-modal-version";
import {
  DEFAULT_ICON_BACKGROUND_COLOR,
  DEFAULT_ICON_COLOR,
  DEFAULT_IMAGE_URL,
} from "@redotech/redo-storefront-widget-common/default-values";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";

export const getClassicWidgetTheme = ({
  autocheck,
}: {
  autocheck: WidgetAutocheck;
}): ClassicWidgetTheme => {
  return {
    color: autocheck.textColor,
    customCss: autocheck.customToggleCss,
    customPdpCss: autocheck.customPdpCss,
    fontSize: autocheck.toggleFontSize,
    html: autocheck.html,
    modalCustomizationsV2: autocheck.infoModal,
    modalVersion: autocheck.infoModal?.version,
    showInfoIcon: autocheck.infoModal?.cartIconEnabled,
    toggleCircleColor: autocheck.cartToggle.toggleCircleColor,
    toggleOffColor: autocheck.cartToggle.toggleOffColor,
    toggleOnColor: autocheck.cartToggle.toggleOnColor,
    toggleTextAfterRedo: autocheck.checkboxTextAfterRedo,
    icon: autocheck.displayIcon ? autocheck.icon : undefined,
    checkboxIconPosition: autocheck.checkboxIconPosition,
    iconColor: autocheck.iconColor || DEFAULT_ICON_COLOR,
    iconBackgroundColor:
      autocheck.iconBackgroundColor || DEFAULT_ICON_BACKGROUND_COLOR,
    image_url: (autocheck.logo && autocheck.logo.trim()) || DEFAULT_IMAGE_URL,
    showIcons: autocheck.showIcons,
    returnPolicyUrl: autocheck.returnPolicyUrl,
  };
};

export interface ClassicWidgetTheme {
  color: string;
  customCss?: string;
  customPdpCss?: string; // This field exists because PDP CSS was implemented before the concept of a widget system was fully established.
  fontSize?: number;
  html?: string | null;
  modalVersion?: InfoModalVersion;
  showInfoIcon?: boolean;
  toggleOffColor?: string;
  toggleOnColor?: string;
  toggleCircleColor?: string;
  toggleTextAfterRedo?: string | null;
  modalCustomizationsV2?: InfoModal;
  icon?: Icons;
  checkboxIconPosition?: CheckboxIconPosition;
  iconColor?: string;
  iconBackgroundColor?: string;
  image_url: string;
  showIcons?: boolean;
  returnPolicyUrl?: string;
}

export type CardWidgetTheme = ClassicWidgetTheme & {};
