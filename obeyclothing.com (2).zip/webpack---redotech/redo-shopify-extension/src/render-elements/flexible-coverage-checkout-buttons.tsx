import { MerchantStyle } from "@redotech/arbiter/merchant-style";
import { Currency } from "@redotech/money/currencies";
import { StorefrontCheckoutTextUtils } from "@redotech/redo-storefront-widget-common/storefront-checkout-text-utils";
import * as React from "react";

export const FlexibleCheckoutButtons = ({
  onClickCoverage,
  onClickNoCoverage,
  isCoverage,
  dataTarget,
  coveragePrice,
  cartTotal,
  cartTotalPreDiscount,
  compareAtPrice,
  html,
  customCss,
  currency,
  locale,
  dueLaterTotal,
  coverageCreditAmount,
}: {
  onClickCoverage: (event: React.MouseEvent) => void;
  onClickNoCoverage: (event: React.MouseEvent) => void;
  isCoverage: boolean;
  dataTarget?: string;
  coveragePrice: number;
  cartTotal: number;
  cartTotalPreDiscount: number;
  compareAtPrice: number;
  html: string;
  customCss?: string;
  currency: Currency;
  locale?: string;
  dueLaterTotal: number;
  coverageCreditAmount: number;
}) => {
  // replace html here then place.
  html = StorefrontCheckoutTextUtils.fillTemplateVariables({
    text: html,
    currency,
    locale,
    coveragePrice,
    cartTotal,
    cartTotalPreDiscount,
    dueLaterTotal,
    coverageCreditAmount,
    compareAtPrice,
  });

  return (
    <>
      <MerchantStyle css={customCss} />
      <div
        dangerouslySetInnerHTML={{ __html: html }}
        data-target={`${dataTarget || (isCoverage ? "coverage-button" : "non-coverage-button")}`}
        onClick={isCoverage ? onClickCoverage : onClickNoCoverage}
      />
    </>
  );
};
