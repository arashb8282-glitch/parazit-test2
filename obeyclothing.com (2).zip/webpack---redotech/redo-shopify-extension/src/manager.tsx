import { RedoArbiterI18nProvider } from "@redotech/arbiter-app/arbiter-i18n-provider";
import { storefrontShopperIdentity } from "@redotech/redo-marketing-browser-sdk/storefront-identity";
import { isBigcommerceCheckout } from "./client/bigcommerce-checkout-refresh";
// cspell:ignore pcheebum

import { Currency, isCurrency } from "@redotech/money/currencies";

import { useRequiredContext } from "@redotech/react-util/context";
import { useEventListener } from "@redotech/react-util/event";
import { useHandler } from "@redotech/react-util/hook";
import { useLoad, useTriggerLoad } from "@redotech/react-util/load";
import { StyleShadowRoot } from "@redotech/react-util/style";
import {
  getAllReturnEligibleCountries,
  isCountryCoverageExcluded,
} from "@redotech/redo-return-coverage-common/coverage-calculator/country-check";
import {
  doesAttachmentStrategyUseCustomFee,
  isAnyWidgetAttachmentStrategy,
  isAttachmentStrategyUsingCheckoutButtons,
} from "@redotech/redo-storefront-common/attachment-strategy";
import { CartProductType } from "@redotech/redo-storefront-widget-common/cart-product-types";

import {
  AttachmentStrategy,
  isAttachmentStrategyCheckoutExtensionEnabled,
  singleCartToggleAttachmentStrategies,
} from "@redotech/redo-storefront-common/attachment-strategy";

import { CheckoutButtonsFeeProductBehavior } from "@redotech/redo-conversion-settings-common/checkout-buttons-fee-product-behavior";
import { CoverageInfo } from "@redotech/redo-return-coverage-common/coverage-calculator/coverage-info-from-calculators";
import { InsertionPosition } from "@redotech/redo-storefront-common/insertion-position";
import {
  PlacementType,
  WidgetElementType,
} from "@redotech/redo-storefront-common/widget-config";
import {
  WidgetAutocheck,
  WidgetFees,
  isCheckoutButtonsOrInfoCards,
} from "@redotech/redo-storefront-widget-common/widget";

import { getCalculatedCoveragePrice } from "@redotech/redo-shopify-utils/price-calculations";
import { getMatchingRedoSellingPlanId } from "@redotech/redo-shopify-utils/selling-plan-utils";
import { ModalRootContext } from "@redotech/redo-web/modal-root";

import {
  getLocalStorageWithExpiry,
  setLocalStorageWithExpiry,
} from "@redotech/redo-web/utils/local-storage-wrapper";

import type {
  ShopifyCart,
  ShopifyProduct,
  ShopifyProducts,
} from "@redotech/shopify-client/ajax";

import {
  ExtensionShopifyClient,
  ShopifyAjaxClient,
  ShopifyCartItem,
  ShopifyClientType,
} from "@redotech/shopify-client/ajax";

import { partition } from "@redotech/util/array";
import { nativeRandom, randomHexString } from "@redotech/util/random";
import { assertNever } from "@redotech/util/type";
import { memo, useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { StorefrontCoverageHtmlElement } from "./cart-app";
import { RedoCheckbox } from "./checkbox";
import type { RedoCheckboxElement } from "./checkbox-app";
import { ShopifyExtensionClientContext } from "./client/client-context";
import { CommercecloudStorefrontClient } from "./client/commercecloud-storefront";
import { RedoShopifyRpcClientContextProvider } from "./client/redo-shopify-rpc-client";
import { getSellingPlan } from "./client/shopify-extension-client";
import { StorefrontClient } from "./client/storefront";
import { CoverageInfoModalOpenedTracker } from "./coverage-info-modal-opened-tracker";
import { CoverageWidgetRenderedTracker } from "./coverage-widget-rendered-tracker";
import { ExternalListenedDomEvent, RedoListenedDomEvent } from "./dom-events";
import { itemValidForReturnsFrontend } from "./eligibility/returns-coverage-eligibility";
import {
  InsurerDisclosureContext,
  cartInsurerDisclosure,
} from "./insurer-disclosure";
import { useLocationManager } from "./location";
import { log } from "./monitoring/log";
import { datadogLog } from "./monitoring/monitor";
import { reportTiming } from "./monitoring/timing";
import { TAPCART_SELECTOR, addCheckbox } from "./product-page";
import { getClassicWidgetTheme } from "./render-elements/classic-widget-theme";
import { RedoRoot } from "./root";
import { renderCart } from "./site-config/render-cart";
import {
  getShopperLanguage,
  getStorefrontLocale,
  getStorefrontMoneyLocale,
} from "./storefront-locale";
import { loadCheckoutProbabilityFromSessionStorage } from "./utils/checkout-probability";
import { recordCoverageWidgetsRendered } from "./utils/coverage-widget-rendered";
import { getMatchingSelectors } from "./utils/matching-selector";

import {
  DEFAULT_TOGGLE_CLICK_SELECTOR,
  getSubmitButtonSelector,
} from "./site-config/selectors";

import {
  ExtensionShopifyClientContext,
  isOnProductPage,
  shopifyProductHandle,
} from "./shopify";

import STYLE_MANAGER from "./style-manager";
import { CheckoutButtonInfoCardManager } from "./sub-managers/checkout-button-info-card-manager";
import { DoubleToggleManager } from "./sub-managers/double-toggle-manager";
import { SingleToggleManager } from "./sub-managers/single-toggle-manager";

import {
  CoverageFeeProductMatchType,
  isCoverageFeeProduct,
} from "@redotech/redo-return-coverage-common/is-coverage-fee-product";
import {
  REDO_DISABLE_TAGS,
  RedoProductToSell,
  getCartShadowRoot,
  isRedoItem,
  queryDocumentAndShadowRoot,
} from "./utils";

import {
  useBuyerIdentity,
  useCart,
  useSyncRedoMetadataCartToken,
} from "./utils/cart";
import { applyCartCountModificationsWithRetries } from "./utils/cart-count-modifications";
import { useBFCacheListener } from "./utils/checkout-buttons/on-page-refresh-hooks";
import { applySkipShopPay, isSkipShopPayEnabled } from "./utils/skip-shop-pay";

import { RedoEmittedDomEvent } from "./dom-events";
import { getCoverageInfoFromCoverageCalculators } from "./utils/coverage-calculations";
import {
  type PackageProtectionExposurePayload,
  markExposureFired,
  shouldFireExposure,
} from "./utils/package-protection-exposure";
import { useInStorePickup } from "./utils/use-in-store-pickup";

import {
  determineRedoProduct,
  determineRedoProductType,
  getCorrectlyPricedVariant,
  getVariantAndProduct,
} from "./utils/determine-redo-product";

import {
  PlacedWidgetHtmlElements,
  WidgetMatchingSelectorTargets,
  getPlacedRedoToggle,
  getPlacementLocationsForStandardToggles,
  getReactElementFromPlacement,
  resolveWidgetPlacements,
  widgetSortOrder,
} from "./utils/element-placement";

import { useHideRedoProductAndCheckoutButtons } from "./utils/hide-elements";
import { usePageChange } from "./utils/page-change";
import { useLeakyDebounce } from "./utils/use-leaky-debounce";

import {
  EnsurePromiseAction,
  PROTECTION_TOGGLE_STATE_KEY,
  REDO_REMOVED_REDO,
  RETURN_TOGGLE_STATE_KEY,
  SELLING_PLANS_ID,
  SINGLE_TOGGLE_STATE_KEY,
} from "./utils/signals";

import { isDef } from "@redotech/util/checks";
import { autocheckPlacementSettingsDiffer } from "./coverage-builder/coverage-builder-init";
import {
  clearHsaCoverageContributions,
  setHsaCoverageContributions,
} from "./hsa/hsa-checkout-api";
import { isHsaEnabled } from "./hsa/pre-init";
import { CoverageNotShowingReason } from "./storefront-debugger/coverage-debug-init";
import { coveragePriceCache } from "./utils/checkout-buttons/coverage-price-cache";
import { goToHsaStandardCheckout } from "./utils/checkout-buttons/on-click-logic";
import { useCheckoutButtonClicked } from "./utils/checkout-buttons/use-coverage-checkout-button-clicked";
import {
  coveragePricingInputsChanged,
  redoForciblyRemovedDuringEnsurePromise,
} from "./utils/coverage-ensure";
import { ensureCoverageFee } from "./utils/coverage-fee-ensure";
import { isDescendantOf } from "./utils/dom";
import {
  cacheBuyNowCoverageVariantId,
  extractProductFormData,
  getCachedBuyNowCoverageVariantId,
  useBuyNowCoverage,
} from "./utils/use-buy-now-coverage";

import {
  getObservedCoveragePlacements,
  getRenderedWidgetElements,
  reportCoverageLoaded,
  reportCoveragePlacementMetrics,
} from "./coverage-placement-reporter";

export function initialize(
  storefrontClient: ExtensionShopifyClient,
  shopifyStorefrontGraphqlClient: StorefrontClient | undefined,
  autocheck: WidgetAutocheck,
  cartEnabled: boolean,
  fees: WidgetFees,
  shopifyProducts: ShopifyProducts,
  shouldUseStorefrontGraphqlClientForRIC: boolean,
  treatmentId: string | null,
) {
  if (document.querySelector("#redo-container") || globalThis.blockRedo) {
    return;
  }
  StorefrontCoverageHtmlElement.register();
  const redoContainer = document.createElement("div");
  redoContainer.id = "redo-container";
  document.head.append(redoContainer);
  const root = createRoot(redoContainer);
  let previousAutocheck: WidgetAutocheck = autocheck;
  const renderTree = (currentAutocheck: WidgetAutocheck) => {
    const builderRefreshSymbol = Symbol();
    root.render(
      <RedoArbiterI18nProvider>
        <RedoRoot
          autocheck={currentAutocheck}
          extensionShopifyClient={storefrontClient}
          storeUrl={
            globalThis.redoStorefront?.storeUrl ??
            globalThis.Shopify?.shop ??
            globalThis.Shopify?.Checkout?.apiHost
          }
          widgetId={globalThis.redoWidgetId}
        >
          <RedoShopifyRpcClientContextProvider
            baseUrl={
              globalThis.redoStorefront?.env?.REDO_SHOPIFY_SERVER_URL ??
              process.env.REDO_SHOPIFY_SERVER_URL
            }
            storeUrl={
              globalThis.redoStorefront?.storeUrl ?? globalThis.Shopify?.shop
            }
            widgetId={globalThis.redoWidgetId}
          >
            <CoverageInfoModalOpenedTracker />
            <CoverageWidgetRenderedTracker />
          </RedoShopifyRpcClientContextProvider>
          <RedoManager
            autocheck={currentAutocheck}
            builderRefreshSymbol={builderRefreshSymbol}
            cartEnabled={cartEnabled}
            fees={fees}
            shopifyProducts={shopifyProducts}
            shopifyStorefrontGraphqlClient={shopifyStorefrontGraphqlClient}
            shouldUseStorefrontGraphqlClientForRIC={
              shouldUseStorefrontGraphqlClientForRIC
            }
            treatmentId={treatmentId}
          />
        </RedoRoot>
      </RedoArbiterI18nProvider>,
    );
  };
  renderTree(globalThis.redoStorefront?.newAutocheck ?? autocheck);

  document.addEventListener(RedoEmittedDomEvent.RefreshAutocheck, () => {
    const newAutocheck = globalThis.redoStorefront?.newAutocheck;
    if (!newAutocheck) {
      return;
    }

    // remove all old elements if placement settings have changed
    if (autocheckPlacementSettingsDiffer(newAutocheck, previousAutocheck)) {
      document.body.dispatchEvent(
        new CustomEvent(RedoEmittedDomEvent.RemoveAllElements),
      );
    }

    renderTree(newAutocheck);
    previousAutocheck = newAutocheck;
  });

  globalThis.removeRedo = () => {
    log("Removing redo");
    root.unmount();
    redoContainer.remove();
  };
}

interface RedoManagerProps {
  autocheck: WidgetAutocheck;
  cartEnabled: boolean;
  fees: WidgetFees;
  shopifyProducts: ShopifyProducts;
  shopifyStorefrontGraphqlClient: StorefrontClient | undefined;
  shouldUseStorefrontGraphqlClientForRIC: boolean;
  builderRefreshSymbol: symbol;
  treatmentId: string | null;
}

type AsyncEventHandler = (
  event: React.MouseEvent | React.TouchEvent,
) => Promise<void>;

const RedoManager = memo(function RedoManager({
  autocheck,
  cartEnabled,
  fees,
  shopifyProducts,
  shopifyStorefrontGraphqlClient,
  shouldUseStorefrontGraphqlClientForRIC,
  builderRefreshSymbol,
  treatmentId,
}: RedoManagerProps) {
  useEffect(() => {
    log("RedoManager mounted");
    return () => {
      log("RedoManager unmounted");
    };
  }, []);

  const locationManager = useLocationManager();
  const storefrontClient = useRequiredContext(ExtensionShopifyClientContext);
  const onTapcart = storefrontClient.type === ShopifyClientType.TAPCART;
  const redoShopifyExtensionClient = useRequiredContext(
    ShopifyExtensionClientContext,
  );
  const merchantPaid = autocheck.paidModel === "merchant_paid";

  const [placedWidgetHtmlElements, setPlacedWidgetHtmlElements] = useState<
    PlacedWidgetHtmlElements[]
  >([]);

  type pdpProductLoad =
    | {
        returnsValid: boolean;
        protectionValid: boolean;
        finalSaleReturnsValid: boolean;
        isValidProduct: boolean;
        product: ShopifyProduct | undefined;
      }
    | undefined;

  const buyNowRedoProduct = useRef<string | null>(null);
  const onBuyNowCoverageRef = useRef<AsyncEventHandler | null>(null);
  const pdpProductLoadRef = useRef<pdpProductLoad>(undefined);
  // Set by the checkout-button sub-manager (when mounted) to the existing-cart
  // HSA checkout handler, so `window.RedoHsa.goToHsaCheckout` reuses the exact
  // Checkout+ coverage-attach path. Null when no coverage manager is mounted —
  // the API falls back to flagging HSA priority and navigating.
  const onHsaExistingCartCheckoutRef = useRef<
    ((addCoverage: boolean, exclusive: boolean) => Promise<void>) | null
  >(null);
  const setOnBuyNowCoverage = (fn: AsyncEventHandler | null) => {
    onBuyNowCoverageRef.current = fn;
  };

  const setOnHsaExistingCartCheckout = (
    fn: ((addCoverage: boolean, exclusive: boolean) => Promise<void>) | null,
  ) => {
    onHsaExistingCartCheckoutRef.current = fn;
  };

  const setBuyNowRedoProduct = (productId: string | null) => {
    buyNowRedoProduct.current = productId;
  };

  const getBuyNowCoverageHandler = useHandler(
    () => onBuyNowCoverageRef.current,
  );
  const getBuyNowCoverageVariantId = useHandler(
    () => buyNowRedoProduct.current,
  );

  useBuyNowCoverage({
    shouldInterceptBuyNow: autocheck.useBuyNowCoverage,
    getBuyNowCoverageHandler,
    storefrontClient: shopifyStorefrontGraphqlClient,
    getBuyNowCoverageVariantId,
    buyNowCustomCss: autocheck.buyNow?.customCss,
  });

  // Initialize selling plan for redo state.
  useEffect(() => {
    if (!getLocalStorageWithExpiry(SELLING_PLANS_ID)) {
      setLocalStorageWithExpiry(SELLING_PLANS_ID, {});
    }
  }, []);

  const countryLoad = useLoad(
    async (signal) => {
      if (
        !autocheck.countries?.length &&
        !autocheck.countriesPackageProtection?.length &&
        !autocheck.packageProtection.pricingRuleSets?.some(
          (rule) => rule.noCoverage,
        ) &&
        !autocheck.internationalReturnsPricing?.some(
          (rule) => rule.noCoverage,
        ) &&
        !autocheck.countriesFinalSaleReturns?.length &&
        (!autocheck.localizationGroups?.length ||
          !autocheck.localizationTextOverrides?.length)
      ) {
        return null;
      }
      const result =
        (!autocheck.forceIPAddressLocation &&
          (globalThis.Shopify?.country || getStorefrontLocale().country)) ||
        (await locationManager.getCountry(signal));
      return result;
    },
    [autocheck, locationManager],
  );

  const shopperLanguage = useMemo(() => {
    if (!autocheck.localizationGroups?.length) {
      return undefined;
    }
    return getShopperLanguage();
  }, [autocheck.localizationGroups]);

  const returnCountries = getAllReturnEligibleCountries(
    autocheck.countries,
    autocheck.internationalReturnsPricing,
  );
  const countryLoadPending =
    (countryLoad.value === undefined && !countryLoad.error) ||
    countryLoad.pending;
  const validCountryReturns =
    countryLoad.value === null ||
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    returnCountries.includes(countryLoad.value!) ||
    returnCountries.length == 0;

  const redoLock = useRef(false);
  const checkboxState = useRef(autocheck.redoAutoCheck);
  const [checkedCart, setCheckedCart] = useState<ShopifyCart | undefined>(
    undefined,
  );
  const [redoInCart, setInCart] = useState<boolean | undefined>(undefined);
  const [singleToggleState, setSingleToggleVal] = useState(false);
  const [returnToggleState, setReturnToggleVal] = useState(false);
  const [protectionToggleState, setProtectionToggleVal] = useState(false);
  const [coverageInfo, setCoverageInfo] = useState<CoverageInfo | undefined>(
    undefined,
  );
  const [checkbox, setCheckbox] = useState<RedoCheckboxElement | null>(null);
  const [cartCurrency, setCartCurrency] = useState<Currency>(Currency.USD);
  const [packageProtectionInsuredValue, setPackageProtectionInsuredValue] =
    useState(0);
  const [cartRefreshSignal, setCartRefresh] = useState(Symbol());
  const { anyCheckoutButtonClicked, setAnyCheckoutButtonClicked } =
    useCheckoutButtonClicked(autocheck);
  const [cartSellingPlans, setCartSellingPlans] = useState<any[]>([]);
  const [pdpSelectedVariant, setPdpSelectedVariant] = useState<{
    variantId: number | string;
    quantity: number;
  }>({ variantId: 0, quantity: 1 });

  const [renderElementsSignal, setRenderElementsSignal] = useState(Symbol());
  const [
    renderElementsSignalSkipDebounce,
    setRenderElementsSignalSkipDebounce,
  ] = useState(Symbol());
  const [checkboxRefresh, setCheckboxRefresh] = useState(Symbol());
  const cartRefresh = useLeakyDebounce(cartRefreshSignal, { outputHz: 4 });
  const renderElementsDebounced = useLeakyDebounce(renderElementsSignal, {
    outputHz: 4,
  });
  const cart = useCart(cartRefresh);
  useSyncRedoMetadataCartToken(cart, autocheck, anyCheckoutButtonClicked);
  const insurerDisclosure = useMemo(() => {
    // The coverage price is in minor units on Shopify carts; Tapcart and the
    // insured value already use major units.
    const price = coverageInfo?.packageProtection.price ?? 0;
    return cartInsurerDisclosure({
      autocheck,
      country: countryLoad.value ?? undefined,
      packageProtectionPrice: onTapcart ? price : price / 100,
      insuredValue: packageProtectionInsuredValue,
      currency: cartCurrency,
      locale: getStorefrontMoneyLocale(),
    });
  }, [
    autocheck,
    countryLoad.value,
    coverageInfo,
    packageProtectionInsuredValue,
    cartCurrency,
    onTapcart,
  ]);

  const usingInStorePickup = useInStorePickup(cart);
  const buyerIdentity = useBuyerIdentity(
    shopifyStorefrontGraphqlClient,
    autocheck,
  );
  const cartItems = cart?.items;
  const cartChecked = !!cart && cart === checkedCart;
  const cartCheckedOnce = !!checkedCart;
  const shouldShowBuyNowElements =
    autocheck.useBuyNowCoverage &&
    !cart?.items.length &&
    pdpProductLoadRef.current?.isValidProduct;

  useBFCacheListener(useHandler(() => setAnyCheckoutButtonClicked(false)));
  useHideRedoProductAndCheckoutButtons(
    autocheck,
    fees,
    placedWidgetHtmlElements,
    cart,
  );

  const checkboxLabelOnly =
    cartEnabled ||
    autocheck.checkoutExtensionEnabled ||
    isAttachmentStrategyCheckoutExtensionEnabled[
      autocheck.attachmentStrategy
    ] ||
    merchantPaid;
  const hasTwoOptions =
    autocheck.attachmentStrategy === AttachmentStrategy.DOUBLE_TOGGLE ||
    autocheck.attachmentStrategy === AttachmentStrategy.DROP_DOWN;

  const invalidReturnProductTags = useMemo(
    () =>
      [...(autocheck.finalSaleTags || []), ...REDO_DISABLE_TAGS].map((s) =>
        s.toLowerCase(),
      ),

    [autocheck.finalSaleTags],
  );
  const invalidProtectionProductTags = useMemo(
    () =>
      autocheck.protectionExcludeTags
        ? autocheck.protectionExcludeTags.map((s) => s.toLowerCase())
        : [],

    [autocheck.protectionExcludeTags],
  );

  const mainRedoProduct = shopifyProducts.mainShopifyProduct;
  const returnRedoProduct = shopifyProducts.returnShopifyProduct;
  const packageRedoProduct = shopifyProducts.packageShopifyProduct;
  const bothRedoProduct = shopifyProducts.bothShopifyProduct;

  const productTypeMap = new Map<number | string, string>();

  if (mainRedoProduct && fees) {
    const productTypes = [
      { product: mainRedoProduct, type: fees.mainType },
      { product: returnRedoProduct, type: CartProductType.Return },
      { product: packageRedoProduct, type: CartProductType.PackageProtection },
      { product: bothRedoProduct, type: CartProductType.Both },
    ];
    for (const p of productTypes) {
      if (p.product) {
        productTypeMap.set(p.product.id, p.type);
      }
    }
  }

  const productIdToSellingPlanId = useLoad(async () => {
    if (!cartSellingPlans?.length || !fees) {
      return {};
    }

    const feesItems = [
      fees.returnProduct,
      fees.packageProduct,
      fees.bothProduct,
    ];

    const newMapping: Record<string, number> = {};

    for (const feesItem of feesItems) {
      if (feesItem?.sellingPlanGroups) {
        const sellingPlanId = await getMatchingRedoSellingPlanId(
          feesItem,
          cartSellingPlans,
        );

        if (sellingPlanId) {
          newMapping[String(feesItem.productId)] = sellingPlanId;
        }
      }
    }

    log({ sellingPlanIDs: newMapping });
    return newMapping;
  }, [cartSellingPlans, fees]);

  const redoProductToSell: RedoProductToSell | undefined = useMemo(
    () => {
      if (!fees || !mainRedoProduct || !coverageInfo) {
        return undefined;
      }

      const productType =
        determineRedoProductType({
          fees,
          autocheck,
          coverageInfo,
          toggleStates: { returnToggleState, protectionToggleState },
        }) ?? CartProductType.Return;
      let calculatedCoveragePrice = 0;

      const { variant, product } = getVariantAndProduct({
        coverageInfo,
        mainRedoProduct,
        returnRedoProduct,
        packageRedoProduct,
        bothRedoProduct,
        fees,
        autocheck,
        productTypeMap,
        toggleStates: { returnToggleState, protectionToggleState },
        country: countryLoad.value ?? undefined,
      });

      if (productType && product) {
        // tslint-disable-next-line @typescript-eslint/switch-exhaustiveness-check -- TODO: grandfather FIXME
        switch (productType) {
          case CartProductType.Return:
            calculatedCoveragePrice = coverageInfo.returns.price;
            break;
          case CartProductType.Both:
            calculatedCoveragePrice = coverageInfo.both.price;
            break;
          case CartProductType.PackageProtection:
            calculatedCoveragePrice = coverageInfo.packageProtection.price;
            break;
        }
      } else {
        log("Could not calculate coverage price for fee");
      }

      if (doesAttachmentStrategyUseCustomFee[autocheck.attachmentStrategy]) {
        const result = {
          variantId: 0,
          productId: 0,
          price: 0,
          rawCalculatedCoveragePrice: onTapcart
            ? calculatedCoveragePrice
            : calculatedCoveragePrice / 100,
          productType,
        };
        log(
          `Redo product to sell is ${result.productType} custom fee of price ${result.rawCalculatedCoveragePrice}`,
          result,
        );
        return result;
      } else {
        const result = {
          variantId: variant.id,
          productId: product.id,
          price: onTapcart ? variant.price : variant.price / 100,
          rawCalculatedCoveragePrice: onTapcart
            ? calculatedCoveragePrice
            : calculatedCoveragePrice / 100,
          productType,
        };
        log(
          `Redo product to sell is the ${result.productType} product with variant ${result.variantId} and price ${result.price}`,
        );
        return result;
      }
    },
    // FIXME can't have exhaustive deps because productTypeMap is set every render
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      fees,
      mainRedoProduct,
      cartChecked,
      returnRedoProduct,
      packageRedoProduct,
      bothRedoProduct,
      autocheck,
      coverageInfo,
      returnToggleState,
      protectionToggleState,
      countryLoad.value,
      onTapcart,
    ],
  );

  // Finds expected variant every time anything changes.
  const {
    variantId: expectedVariantID,
    productId: expectedProductId,
    feeAction: ensurePromiseFeeAction,
  } = useMemo(() => {
    const SKIP_ENSURE_PROMISE = {
      variantId: null,
      productId: null,
      price: null,
      calculatedCoveragePrice: null,
      productType: null,
      feeAction: EnsurePromiseAction.IGNORE,
    };
    const REDO_SHOULD_NOT_BE_IN_CART = {
      variantId: 0,
      productId: 0,
      price: 0,
      calculatedCoveragePrice: 0,
      productType: null,
      feeAction: EnsurePromiseAction.REMOVE,
    };

    if (!fees || !mainRedoProduct || !cartChecked || !redoProductToSell) {
      return SKIP_ENSURE_PROMISE;
    }

    if (autocheck.attachmentStrategy === AttachmentStrategy.CHECKBOX) {
      return {
        variantId: redoProductToSell.variantId,
        productId: redoProductToSell.productId,
        feeAction: EnsurePromiseAction.IGNORE,
      };
    }

    if (checkboxLabelOnly || !anyCheckoutButtonClicked) {
      const shouldIgnoreUntilButtonClicked =
        !anyCheckoutButtonClicked &&
        autocheck.attachmentStrategy ===
          AttachmentStrategy.CHECKOUT_BUTTON_PRODUCT &&
        autocheck.checkoutButtonsFeeProductBehavior ===
          CheckoutButtonsFeeProductBehavior.IGNORE_UNTIL_CHECKOUT;

      if (
        fees.splitProducts &&
        autocheck.packageProtection.coverageEnabled &&
        hasTwoOptions
      ) {
        if (!returnToggleState && !protectionToggleState) {
          return shouldIgnoreUntilButtonClicked
            ? SKIP_ENSURE_PROMISE
            : REDO_SHOULD_NOT_BE_IN_CART;
        }
      } else if (!singleToggleState) {
        return shouldIgnoreUntilButtonClicked
          ? SKIP_ENSURE_PROMISE
          : REDO_SHOULD_NOT_BE_IN_CART;
      }
    }

    const isAnyToggleEnabled =
      singleToggleState || returnToggleState || protectionToggleState;

    const useCustomFeeInsteadOfProduct =
      doesAttachmentStrategyUseCustomFee[autocheck.attachmentStrategy];

    return {
      variantId: useCustomFeeInsteadOfProduct ? 0 : redoProductToSell.variantId,
      productId: useCustomFeeInsteadOfProduct ? 0 : redoProductToSell.productId,
      feeAction:
        useCustomFeeInsteadOfProduct && isAnyToggleEnabled
          ? EnsurePromiseAction.ADD
          : EnsurePromiseAction.REMOVE,
    };
    // FIXME
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    fees,
    mainRedoProduct,
    returnRedoProduct,
    packageRedoProduct,
    bothRedoProduct,
    cartItems,
    redoInCart,
    coverageInfo,
    redoProductToSell,
    returnToggleState,
    protectionToggleState,
    singleToggleState,
    anyCheckoutButtonClicked,
  ]);

  const renderElementsHandler = useHandler(
    (placementTypeToRender?: PlacementType) => {
      if (!cartEnabled || merchantPaid) {
        return;
      }
      log("Rendering storefront coverage widgets");
      let widgetElementMatches: WidgetMatchingSelectorTargets[] = [];

      if (
        isAttachmentStrategyUsingCheckoutButtons[
          autocheck.attachmentStrategy
        ] &&
        autocheck.widgetConfigs?.length &&
        !onTapcart
      ) {
        // Determine if we should filter to PDP-only widgets
        const widgetConfigsForPlacement =
          placementTypeToRender === PlacementType.PDP
            ? autocheck.widgetConfigs.filter(
                (widgetConfig) =>
                  widgetConfig.placementType === placementTypeToRender,
              )
            : autocheck.widgetConfigs;

        const widgetConfigsToRender = widgetConfigsForPlacement.filter(
          (widgetConfig) =>
            widgetConfig.elementType !== WidgetElementType.CART_CHECKBOX ||
            isAnyWidgetAttachmentStrategy[autocheck.attachmentStrategy],
        );
        const incompatibleCartCheckboxCount =
          widgetConfigsForPlacement.length - widgetConfigsToRender.length;
        if (incompatibleCartCheckboxCount > 0) {
          log(
            "Skipping cart checkbox placement because the attachment strategy does not support it",
            {
              attachmentStrategy: autocheck.attachmentStrategy,
              incompatibleCartCheckboxCount,
            },
          );
        }

        for (const widgetConfig of widgetConfigsToRender) {
          // Resolve to one DOM placement per (widget, placement) pair, with
          // every field fully populated. Widgets that define `placement` get
          // one entry per descriptor; widgets that don't get a single entry
          // built from their legacy fields. The widget config travels through
          // unchanged — we never manufacture synthetic configs.
          //
          // Track elements already claimed by an earlier placement of THIS
          // widget so two overlapping selectors on the same widget can't
          // produce two toggles at the same anchor. First placement wins.
          const claimedByThisWidget = new Set<Element>();
          for (const [placementIndex, placement] of resolveWidgetPlacements({
            widgetConfig,
          }).entries()) {
            const allMatchingElements = getReactElementFromPlacement({
              widgetConfig,
              placement,
              autocheck,
            });
            const matchingElementsSafe = allMatchingElements.filter(
              (element) =>
                !isDescendantOf({
                  element,
                  ancestor: (el: Element) => {
                    return (
                      el.tagName.toLowerCase() ===
                      StorefrontCoverageHtmlElement.TAG.toLowerCase()
                    );
                  },
                }),
            );

            if (matchingElementsSafe.length !== allMatchingElements.length) {
              log(
                "WARNING: Some elements were filtered out because they were descendants of a Redo Toggle Element",
                {
                  allMatchingElements,
                  matchingElementsSafe,
                  widgetConfig,
                  placement,
                },
              );
            }

            const dedupedElements = matchingElementsSafe.filter(
              (element) => !claimedByThisWidget.has(element),
            );
            for (const element of dedupedElements) {
              claimedByThisWidget.add(element);
            }

            if (dedupedElements.length !== matchingElementsSafe.length) {
              log(
                "WARNING: Some elements were skipped because an earlier placement on the same widget config already matched them",
                {
                  matchingElementsSafe,
                  dedupedElements,
                  widgetConfig,
                  placement,
                },
              );
            }

            const shadowRootSelector =
              placement.shadowRootSelector ??
              widgetConfig.shadowRootSelector ??
              autocheck.cartToggle.cartShadowRootSelector;
            const [documentElements, shadowElements] = partition(
              dedupedElements,
              (element) => element.getRootNode() instanceof ShadowRoot,
            );
            widgetElementMatches.push({
              elements: documentElements,
              placementIndex,
              widgetConfig,
              placement: {
                cssSelector: placement.cssSelector,
                insertionPosition: placement.insertionPosition,
              },
            });
            if (shadowElements.length > 0) {
              widgetElementMatches.push({
                elements: shadowElements,
                placementIndex,
                widgetConfig,
                placement: { ...placement, shadowRootSelector },
              });
            }
          }
        }

        if (
          autocheck.attachmentStrategy ===
            AttachmentStrategy.ANY_WIDGET_PRODUCT ||
          autocheck.attachmentStrategy ===
            AttachmentStrategy.ANY_WIDGET_CUSTOM_FEE
        ) {
          for (const locations of getPlacementLocationsForStandardToggles({
            autocheck,
            onTapcart,
          })) {
            if (locations.elements.length > 0) {
              widgetElementMatches.push({
                ...locations,
                widgetConfig: {
                  elementType: WidgetElementType.SINGLE_TOGGLE,
                  placementSelector: "",
                },
              });
            }
          }
        }
      } else {
        widgetElementMatches = getPlacementLocationsForStandardToggles({
          autocheck,
          onTapcart,
        });
      }

      const placedWidgetHtmlElements: PlacedWidgetHtmlElements[] = [];

      const groupElementTogether =
        autocheck.groupNearbyToggleElementsTogether ?? true;
      if (!groupElementTogether) {
        // sort the elements so they render in the correct order
        widgetElementMatches.sort(
          (a, b) =>
            widgetSortOrder({
              widget: a.widgetConfig,
              placement: a.placement,
            }) -
            widgetSortOrder({ widget: b.widgetConfig, placement: b.placement }),
        );
      }

      const matchedWidgetElements = widgetElementMatches.map((match) => ({
        ...match,
        matchedSelectors: getMatchingSelectors(
          match.elements,
          onTapcart ? TAPCART_SELECTOR : match.placement.cssSelector,
        ),
      }));

      for (const {
        elements,
        widgetConfig,
        placement,
        placementIndex,
        matchedSelectors,
      } of matchedWidgetElements) {
        log("Rendering location.");
        placedWidgetHtmlElements.push({
          matchedSelectors,
          placementIndex,
          redoHtmlElements: elements.map(
            (container, index): StorefrontCoverageHtmlElement => {
              let toggle: StorefrontCoverageHtmlElement | undefined;

              switch (placement.insertionPosition) {
                case InsertionPosition.BEFORE:
                case InsertionPosition.AFTER:
                  toggle = getPlacedRedoToggle({
                    container: container.parentElement,
                    widgetConfig,
                    anyRedoToggle: groupElementTogether,
                  });
                  if (toggle) {
                    return toggle;
                  }
                  break;
                case InsertionPosition.PREPEND:
                case InsertionPosition.APPEND:
                  toggle = getPlacedRedoToggle({
                    container,
                    widgetConfig,
                    anyRedoToggle: groupElementTogether,
                  });
                  if (toggle) {
                    return toggle;
                  }
                  break;
                default:
                  assertNever(placement.insertionPosition);
                  break;
              }

              // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
              toggle = document.createElement(
                StorefrontCoverageHtmlElement.TAG,
              ) as StorefrontCoverageHtmlElement;
              toggle.setToggleClass(widgetConfig?.elementType);
              toggle.id = `redo-toggle-${randomHexString(nativeRandom, 8)}`;
              toggle.setAttribute("tabindex", "0");

              if (widgetConfig) {
                toggle.addEventListener("focus", () => {
                  const control =
                    toggle.root?.querySelector<HTMLElement>("input, button");
                  control?.focus();
                });
              }

              if (autocheck.openShadowRoot) {
                toggle.shadowRootMode = "open";
              }

              if (
                widgetConfig?.elementType ===
                  WidgetElementType.COVERAGE_CHECKOUT_BUTTON ||
                widgetConfig?.elementType ===
                  WidgetElementType.NON_COVERAGE_CHECKOUT_BUTTON
              ) {
                toggle.useShadowRoot = false;
              }
              toggle.setAttribute(
                "found-selector",
                matchedSelectors[index] || "",
              );

              const onDisconnect = () => {
                log("toggle disconnected");
                toggle.removeEventListener("disconnect", onDisconnect);

                setRenderElementsSignal(Symbol());
                setTimeout(() => setRenderElementsSignal(Symbol()), 1000);
              };
              toggle.addEventListener("disconnect", onDisconnect);

              // clean up toggles when removeRedo is dispatched
              const onRemoveRedo = () => {
                document.body.removeEventListener(
                  RedoEmittedDomEvent.RemoveAllElements,
                  onRemoveRedo,
                );
                toggle.removeEventListener("disconnect", onDisconnect);
                toggle.remove();
              };
              document.body.addEventListener(
                RedoEmittedDomEvent.RemoveAllElements,
                onRemoveRedo,
              );

              switch (placement.insertionPosition) {
                case InsertionPosition.BEFORE:
                  container.before(toggle);
                  break;
                case InsertionPosition.AFTER:
                  container.after(toggle);
                  break;
                case InsertionPosition.PREPEND:
                  container.prepend(toggle);
                  break;
                case InsertionPosition.APPEND:
                  container.append(toggle);
                  break;
                default:
                  assertNever(placement.insertionPosition);
                  break;
              }
              return toggle;
            },
          ),
          widgetConfig,
          placement,
        });
      }

      setPlacedWidgetHtmlElements(placedWidgetHtmlElements);
      if (autocheck.dispatchResizeAfterItemsPlaced) {
        window.dispatchEvent(new Event("resize"));
      }
    },
  );

  // attach mutation observer to rerender checkout buttons on dom change
  useEffect(() => {
    if (!autocheck.attachmentStrategy) {
      return;
    }

    log("Create mutation observer");
    const mutationObserver = new MutationObserver((event) => {
      if (!autocheck.noDebounceButtonRendering) {
        setRenderElementsSignal(Symbol());
        return;
      }

      if (
        coverageInfo?.returns.cartEligible ||
        coverageInfo?.packageProtection.cartEligible
      ) {
        renderElementsHandler();
      } else if (shouldShowBuyNowElements) {
        renderElementsHandler(PlacementType.PDP);
      }
    });

    if (
      isAttachmentStrategyUsingCheckoutButtons[autocheck.attachmentStrategy] ||
      globalThis.redoStorefront?.type == "bigcommerce"
    ) {
      mutationObserver.observe(document, { childList: true, subtree: true });
    } else {
      mutationObserver.disconnect();
    }

    return () => {
      mutationObserver.disconnect();
    };
  }, [
    autocheck.attachmentStrategy,
    autocheck.noDebounceButtonRendering,
    renderElementsHandler,
    coverageInfo,
    shouldShowBuyNowElements,
  ]);

  useEventListener(document, RedoListenedDomEvent.ReloadCart, () => {
    setCartRefresh(Symbol());
  });
  useEventListener(document, RedoListenedDomEvent.ReRenderElements, () => {
    setRenderElementsSignalSkipDebounce(Symbol());
  });
  useEventListener(document, ExternalListenedDomEvent.RebuyCartChange, () => {
    setCartRefresh(Symbol());
  });
  useEventListener(document, ExternalListenedDomEvent.UpcartCartLoad, () => {
    setCartRefresh(Symbol());
  });
  useEventListener(document, ExternalListenedDomEvent.UpcartCartUpdated, () => {
    setCartRefresh(Symbol());
  });

  const addRedo = useHandler(async (event?: Event, force = false) => {
    if (
      merchantPaid ||
      !coverageInfo ||
      (redoInCart && !force) ||
      redoLock.current === true ||
      !expectedVariantID ||
      doesAttachmentStrategyUseCustomFee[autocheck.attachmentStrategy]
    ) {
      return;
    }
    // If redo is in the cart and they are eligible for final sale, then they are paying for final sale.
    // FIXME: This will become a problem when we are splitting the products since finalSaleValue may be greater than 0 and they are not buying final sale coverage.
    const hasFinalSaleCoverage =
      coverageInfo.returns.cartEligible && coverageInfo.returns.isFinalSale;
    try {
      redoLock.current = true;
      setInCart(true);
      const cartParams = new URLSearchParams();
      if (!onTapcart) {
        // tslint-disable-next-line @typescript-eslint/switch-exhaustiveness-check -- TODO: grandfather FIXME
        switch (globalThis?.Shopify?.shop) {
          case "birdiethreads.myshopify.com":
            // cspell:disable-next-line
            cartParams.append("ref_icart", "true");
            break;
          case "thedressoutlet.myshopify.com":
            cartParams.append("sections", "cart-drawer,cart-icon-bubble");
            break;
        }

        if (
          globalThis?.Shopify?.shop === "the-vintage-gentlemen.myshopify.com" &&
          typeof Rebuy !== "undefined"
        ) {
          await new Promise((resolve) => setTimeout(resolve, 1000));
          Rebuy.Cart.addItem({
            id: expectedVariantID,
            quantity: 1,
            properties: hasFinalSaleCoverage
              ? { __final_sale_coverage: "true" }
              : {},
          });
          redoLock.current = false;
          return;
        }
      }
      log("adding redo", { expectedVariantID });
      setLocalStorageWithExpiry(REDO_REMOVED_REDO, false);

      event?.preventDefault();
      event?.stopPropagation();

      const itemsToAdd: { items: Partial<ShopifyCartItem>[] } = {
        items: [
          {
            id: expectedVariantID,
            variant_id: expectedVariantID,
            product_id: expectedProductId,
            quantity: 1,
            properties: hasFinalSaleCoverage
              ? { __final_sale_coverage: "true" }
              : {},
          },
        ],
      };

      // Add redo product to bottom of shopify cart if setting is enabled
      if (!onTapcart && autocheck.cartToggle?.cartReplaceItems) {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        await (storefrontClient as ShopifyAjaxClient).cartAddToEnd(
          itemsToAdd,
          cartParams,
        );
      } else {
        // Every client takes the coverage price; only Miva, which cannot encode
        // it in a variant, reads it.
        await storefrontClient.cartAdd(
          itemsToAdd,
          cartParams,
          undefined, // TODO: accept preventReload
          redoProductToSell?.rawCalculatedCoveragePrice,
        );
      }

      if (
        globalThis.redoStorefront?.type === "bigcommerce" ||
        globalThis.redoStorefront?.type === "miva"
      ) {
        // If we're on the checkout page for Bigcommerce we need to manually do cart modifications due to lack of a clear cart refresh solution. This may be safe to do on Shopify too, but didn't see a need to.
        // Miva writes go to json.mvc, which no cart-url pattern matches, so nothing else refetches.
        setCartRefresh(Symbol());
      }

      await renderCart(autocheck, storefrontClient);

      if (!event) {
        return;
      }

      console.debug(`Resubmitting event ${event.type}`);
      if (
        typeof Rebuy !== "undefined" ||
        globalThis?.Shopify?.shop === "megalashacademy.myshopify.com"
      ) {
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
      if (event.target instanceof HTMLElement && event.type === "click") {
        event.target.click();
      } else {
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        event.target!.dispatchEvent(new Event(event.type));
      }
    } catch (e) {
      console.error("Error adding redo to the cart", e);
      // Refresh the cart so we know if it's actually in there or not
      setCartRefresh(Symbol());
    } finally {
      redoLock.current = false;
    }
  });

  const onCheckboxChange = useHandler((value: boolean) => {
    log("checkbox changed", { value });
    checkboxState.current = value;
  });

  const onModalAdd = useHandler(async () => {
    if (!redoInCart) {
      await addRedo();
    }
  });

  const ensurePromise = useRef<Promise<any> | null>(null);
  /** cartCheckLoad bumps this on a forced removal; ensureRedoLoad snapshots it at cycle-start and skips re-adding if it changed mid-cycle. */
  const forcedRemovalAt = useRef(0);
  // Makes sure the correct variant of redo is in the cart.
  useLoad(
    async (signal) => {
      while (ensurePromise.current !== null) {
        try {
          await ensurePromise.current;
        } catch (e) {
          // Who cares
        }
      }
      if (signal.aborted) {
        return;
      }

      if (
        !cartChecked ||
        expectedVariantID === null ||
        !checkboxLabelOnly ||
        anyCheckoutButtonClicked ||
        (globalThis.redoStorefront?.type === "commercecloud" &&
          !isAnyWidgetAttachmentStrategy[autocheck.attachmentStrategy] &&
          CommercecloudStorefrontClient.isOnCheckoutPage() &&
          CommercecloudStorefrontClient.isOnPaymentSection()) ||
        // Never touch the basket on the SFCC confirmation page: re-adding coverage
        // there reloads it, and Order-Confirm's one-shot guard redirects to Cart-Show.
        (globalThis.redoStorefront?.type === "commercecloud" &&
          CommercecloudStorefrontClient.isOnConfirmationPage())
      ) {
        return;
      }

      let cartChanged = false;
      const removalSnapshot = forcedRemovalAt.current;
      ensurePromise.current = (async () => {
        log("Ensuring redo", { expectedVariantID });

        // Block checkout while we're making sure the correct variant is in the cart.
        let checkoutIntercepted = false;
        const checkoutInterceptor = autocheck.checkoutSelector
          ? (event: Event) => {
              if (
                event.target instanceof Element &&
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                (event.target.matches(autocheck.checkoutSelector!) ||
                  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                  event.target.closest(autocheck.checkoutSelector!))
              ) {
                event.preventDefault();
                event.stopPropagation();
                checkoutIntercepted = true;
                log("Checkout intercepted");
              }
            }
          : null;

        if (checkoutInterceptor) {
          log("Attaching checkout interceptor");
          // Listen on both the main document and the shadow root (if it exists) just in case
          document.addEventListener("click", checkoutInterceptor, {
            capture: true,
          });
          getCartShadowRoot(autocheck)?.addEventListener(
            "click",
            checkoutInterceptor,
            { capture: true },
          );
        }
        try {
          let foundCorrectVariant = false;

          // Fetching the cart from the API instead of using the useCart react state causes issues because they could be inconsistent.
          const useReactCartState =
            globalThis?.Shopify?.shop === "charming-and-main.myshopify.com" ||
            // if we're on any widget we need to fetch the cart fresh to avoid race conditions between buttons and toggles.
            (globalThis.redoStorefront?.type === "commercecloud" &&
              !isAnyWidgetAttachmentStrategy[autocheck.attachmentStrategy]) ||
            globalThis.redoStorefront?.type === "custom-lightopia";
          if (!useReactCartState) {
            datadogLog("info", "storefront:cart-get", {
              source: "cartCheckLoad",
              storefrontType: globalThis.redoStorefront?.type,
            });
          }
          const _cart = useReactCartState
            ? cart // For Charming and Main, experiment with using the useCart state instead
            : await storefrontClient.cartGet(signal); // For all other shops, continuing fetching from the API

          if (
            (globalThis.redoStorefront?.type === "commercecloud" ||
              globalThis.redoStorefront?.type === "bigcommerce") &&
            coveragePricingInputsChanged(
              cart,
              _cart,
              autocheck.coverageProductIds,
            )
          ) {
            log("Cart pricing inputs changed, refreshing before ensure");
            setCartRefresh(Symbol());
            return;
          }

          // Every client that can carry a custom fee (BigCommerce, Commerce Cloud)
          // goes through the same call, after the cart-freshness check.
          // No widgetSlug guard here on purpose: BigCommerce attach()/remove() return {changed:false} without a slug or cart id, so a misconfigured slug never aborts the rest of the ensure flow.
          // Only ADD is blocked by a forced removal; REMOVE should still proceed.
          const feeAddBlockedByForcedRemoval =
            ensurePromiseFeeAction === EnsurePromiseAction.ADD &&
            redoForciblyRemovedDuringEnsurePromise(
              autocheck,
              forcedRemovalAt.current,
              removalSnapshot,
            );
          if (
            storefrontClient.coverageFee &&
            doesAttachmentStrategyUseCustomFee[autocheck.attachmentStrategy] &&
            ensurePromiseFeeAction !== EnsurePromiseAction.IGNORE &&
            !feeAddBlockedByForcedRemoval
          ) {
            await ensureCoverageFee({
              coverageFee: storefrontClient.coverageFee,
              action: ensurePromiseFeeAction,
              autocheck,
              redoProductToSell,
              refresh: isBigcommerceCheckout()
                ? () => renderCart(autocheck, storefrontClient)
                : undefined,
            });
          }

          for (const item of _cart.items) {
            try {
              if (isRedoItem(item, autocheck.coverageProductIds)) {
                // Remove any incorrect variants
                if (item.variant_id !== expectedVariantID) {
                  log("removing incorrect variant", { item });
                  cartChanged = true;
                  await storefrontClient.removeItemFromCart(
                    item,
                    item.quantity,
                    signal,
                    autocheck.preventPageRefreshAfterCartAdd ||
                      isBigcommerceCheckout(),
                  );
                  if (
                    (globalThis.redoStorefront?.type === "bigcommerce" &&
                      !isBigcommerceCheckout()) ||
                    globalThis.redoStorefront?.type === "custom-lightopia"
                  ) {
                    await renderCart(autocheck, storefrontClient);
                    setCartRefresh(Symbol());
                  }
                  log("incorrect variant removed");
                  if (
                    (getLocalStorageWithExpiry(SINGLE_TOGGLE_STATE_KEY) ===
                      "enabled" ||
                      getLocalStorageWithExpiry(RETURN_TOGGLE_STATE_KEY) ===
                        "enabled" ||
                      getLocalStorageWithExpiry(PROTECTION_TOGGLE_STATE_KEY) ===
                        "enabled") &&
                    expectedVariantID === 0
                  ) {
                    setLocalStorageWithExpiry(REDO_REMOVED_REDO, true);
                  }
                } else {
                  foundCorrectVariant = true;
                  if (item.quantity > 1) {
                    // If there is more than one, make sure to fix that.
                    log("updating variant quantity", { item });
                    cartChanged = true;
                    await storefrontClient.removeItemFromCart(
                      item,
                      item.quantity - 1,
                      signal,
                      isBigcommerceCheckout(),
                    );
                    if (globalThis.redoStorefront?.type === "bigcommerce") {
                      // If we're on the checkout page for Bigcommerce we need to manually do cart modifications due to lack of a clear cart refresh solution. This may be safe to do on Shopify too, but didn't see a need to.
                      setCartRefresh(Symbol());
                    }
                  }
                }
              }
            } catch (e) {
              log("Error in ensure product", e);
              datadogLog("error", "Error in ensure product", { error: e });
            }
          }
          if (
            !foundCorrectVariant &&
            expectedVariantID !== 0 &&
            !redoForciblyRemovedDuringEnsurePromise(
              autocheck,
              forcedRemovalAt.current,
              removalSnapshot,
            )
          ) {
            cartChanged = true;
            await addRedo(undefined, true);
          }
          // Graviet uses cartAddToEnd, which when combined with their theme and renderCart,
          // causes a race condition where the cart state is not updated properly and all items are removed.
          if (cartChanged && globalThis?.Shopify?.shop !== "graviet.co") {
            await renderCart(autocheck, storefrontClient);

            if (
              globalThis.redoStorefront?.type === "bigcommerce" ||
              globalThis.redoStorefront?.type === "commercecloud" ||
              globalThis.redoStorefront?.type === "custom-lightopia" ||
              globalThis.redoStorefront?.type === "miva"
            ) {
              setCartRefresh(Symbol());
            }
          }
        } finally {
          // FIXME The checkout selector gets removed before the cart can be refreshed, so sometimes it doesn't block the customer from going to checkout before we update.
          if (checkoutInterceptor) {
            log("Removing checkout interceptor");
            document.removeEventListener("click", checkoutInterceptor, {
              capture: true,
            });
            getCartShadowRoot(autocheck)?.removeEventListener(
              "click",
              checkoutInterceptor,
              { capture: true },
            );

            // If a checkout click was intercepted, click the checkout button again
            // FIXME If there are double toggles, it is possible for a customer to turn them both off, click checkout,
            //   and for us to re-click the checkout button while the second toggle update is still processing, which
            //   will take the customer to the checkout page with one Redo product still in the cart.
            if (checkoutIntercepted) {
              if (isSkipShopPayEnabled()) {
                // Skip Shop Pay is on (HSA): the coverage product is already
                // ensured above, so go straight to the standard checkout
                // carrying skip_shop_pay instead of re-clicking the merchant
                // button (which, for JS-nav buttons like Rebuy, would navigate
                // without the parameter and bounce signed-in shoppers into Shop
                // Pay). This is the navigation that the merchant's old custom JS
                // performed. We navigate immediately because the cart writes
                // above are already awaited — no re-render wait is needed.
                log("Skip Shop Pay: navigating to standard checkout");
                location.href = applySkipShopPay(location.origin + "/checkout");
              } else {
                // Wait for 500ms for the cart to get re-rendered first
                await new Promise((resolve) => setTimeout(resolve, 500));

                log("Re-clicking checkout button");

                const checkoutElements = queryDocumentAndShadowRoot(
                  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                  autocheck.checkoutSelector!,
                  autocheck,
                );
                // Just in case there are multiple checkout buttons that match the selector,
                // find the first one that we can click on.
                for (const element of checkoutElements) {
                  if (element instanceof HTMLElement) {
                    element.click();
                    break;
                  }
                }
              }
            }
          }
        }
      })();

      try {
        if (document.body) {
          document.body.dispatchEvent(new CustomEvent("redo:cart-check:start"));
        }
        return await ensurePromise.current;
      } catch (e) {
        log("Error in ensureRedoLoad", e);
      } finally {
        if (document.body) {
          document.body.dispatchEvent(new CustomEvent("redo:cart-check:end"));
        }
        log("Finished ensuring redo", { expectedVariantID });
        ensurePromise.current = null;
      }
    },
    [
      expectedVariantID,
      ensurePromiseFeeAction,
      cartItems,
      anyCheckoutButtonClicked,
      redoProductToSell,
    ],
  );

  // Check current cart and render widgets.
  const cartCheckLoad = useLoad(
    async (signal) => {
      if (!fees || !mainRedoProduct || !cart || countryLoadPending) {
        // Data not loaded yet; the coverage check below sets REDO_REMOVED_REDO.
        log("skipping cart check", { fees, mainRedoProduct, cart });
        return;
      }

      coveragePriceCache.syncCartCoveragePriceCacheWithLocalStorage({ cart });

      setCartCurrency(isCurrency(cart.currency) ? cart.currency : Currency.USD);
      log("checking cart items", { cart });
      // Check if the cart has actually changed.
      let inCart = !!redoInCart;
      const inCartLastCheck = redoInCart === undefined ? true : !!redoInCart;
      const redoItems: ShopifyCartItem[] = [];
      const someCoverageEnabled =
        autocheck.coverageEnabled ||
        !!autocheck.finalSaleReturns?.coverageEnabled;
      const hasPackageAndSplit =
        autocheck.packageProtection.coverageEnabled &&
        autocheck.packageProtection.splitProducts;
      // Checks if cart line items have changed or if any selling plans have changed.

      // Set these to false until we actually check the cart.
      inCart = false;

      if (cart?.items?.length) {
        for (const item of cart.items) {
          if (isRedoItem(item, autocheck.coverageProductIds)) {
            inCart = true;
            redoItems.push(item);
            continue;
          }
        }
      }

      const {
        coverageInfo,
        stagecoachModelMetadata,
        cartHash,
        validCartItems,
        packageProtectionInsuredValue,
      } = await getCoverageInfoFromCoverageCalculators({
        autocheck,
        customerInfo: {
          country: countryLoad.value || "",
          customerTags: [],
          disableRedoForCustomer: autocheck.disableRedoForCustomer,
          isBusinessAccount: !!buyerIdentity?.purchasingCompany?.company,
          usingInStorePickup,
        },
        cart,
        shopifyClient: storefrontClient,
        redoClient: redoShopifyExtensionClient,
        onTapcart,
        storefrontGraphQLClient: shopifyStorefrontGraphqlClient,
      });

      // this is kind of unsafe
      const sellingPlanPromises = validCartItems
        .filter((item) => !isRedoItem(item, autocheck.coverageProductIds))
        .filter((item) => item.selling_plan_allocation?.selling_plan?.id)
        .map(
          async (item) =>
            await getSellingPlan(redoShopifyExtensionClient, {
              // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
              sellingPlanId: item.selling_plan_allocation!.selling_plan!.id,
            }),
        );

      const sellingPlans = await Promise.all(sellingPlanPromises);
      setCartSellingPlans(sellingPlans);

      log("cart items checked", {
        inCart,
        inCartLastCheck,
        redoItems,
        coverageInfo,
      });
      if (!redoItems.length) {
        setLocalStorageWithExpiry(SELLING_PLANS_ID, {});
      }

      if (inCart && redoItems.length) {
        let localStorageSellingPlans: any =
          getLocalStorageWithExpiry(SELLING_PLANS_ID) || {};

        for (const redoItem of redoItems) {
          // find the same item in fees
          const feesItem = [
            fees.returnProduct,
            fees.packageProduct,
            fees.bothProduct,
          ].find((e) => e?.productId === redoItem.product_id);

          if (!feesItem) {
            continue;
          }

          const sellingPlanId = sellingPlans?.length
            ? getMatchingRedoSellingPlanId(feesItem, sellingPlans)
            : null;

          const redoHasSellingPlan =
            !!redoItem?.selling_plan_allocation?.selling_plan?.id;
          const redoRemovedSellingPlan =
            localStorageSellingPlans[redoItem.product_id] === "removed";

          // If the customer removes the selling plan, we will skip updates
          if (
            sellingPlanId &&
            redoHasSellingPlan &&
            !redoRemovedSellingPlan &&
            localStorageSellingPlans[redoItem.product_id]
          ) {
            continue;
          }
          // If there is a selling plan for the item, add it to redo and add it to local storage
          // If the customer updates their selling plan, we will update the redo item and the local storage
          if (sellingPlanId) {
            localStorageSellingPlans = {
              ...localStorageSellingPlans,
              [redoItem.product_id]: sellingPlanId,
            };

            setLocalStorageWithExpiry(
              SELLING_PLANS_ID,
              localStorageSellingPlans,
            );

            log("updating selling plan", { redoItem, sellingPlanId });
            await storefrontClient.updateCartItemSellingPlan(
              redoItem,
              sellingPlanId,
            );
            // If there is no selling plan for the item but redo has a selling plan, remove it from redo and local storage
          } else if (redoHasSellingPlan) {
            log("removing selling plan", { redoItem });
            await storefrontClient.updateCartItemSellingPlan(redoItem, null);
          }

          if (!sellingPlanId && localStorageSellingPlans[redoItem.product_id]) {
            localStorageSellingPlans = {
              ...localStorageSellingPlans,
              [redoItem.product_id]: "removed",
            };

            setLocalStorageWithExpiry(
              SELLING_PLANS_ID,
              localStorageSellingPlans,
            );
          }
        }
      }
      const returnState =
        getLocalStorageWithExpiry(RETURN_TOGGLE_STATE_KEY) === "enabled";
      const protectionState =
        getLocalStorageWithExpiry(PROTECTION_TOGGLE_STATE_KEY) === "enabled";
      const singleState =
        getLocalStorageWithExpiry(SINGLE_TOGGLE_STATE_KEY) === "enabled";

      // For ANY_WIDGET strategies, default toggle states to off if unset
      // so we don't auto-enable them on first page load
      if (
        [
          AttachmentStrategy.ANY_WIDGET_CUSTOM_FEE,
          AttachmentStrategy.ANY_WIDGET_PRODUCT,
        ].includes(autocheck.attachmentStrategy)
      ) {
        if (getLocalStorageWithExpiry(SINGLE_TOGGLE_STATE_KEY) === null) {
          setLocalStorageWithExpiry(SINGLE_TOGGLE_STATE_KEY, "disabled");
        }
        if (getLocalStorageWithExpiry(RETURN_TOGGLE_STATE_KEY) === null) {
          setLocalStorageWithExpiry(RETURN_TOGGLE_STATE_KEY, "disabled");
        }
        if (getLocalStorageWithExpiry(PROTECTION_TOGGLE_STATE_KEY) === null) {
          setLocalStorageWithExpiry(PROTECTION_TOGGLE_STATE_KEY, "disabled");
        }
      }

      let redoForciblyRemoved = false;
      let hasEligibleProduct = false;

      if (
        !autocheck.packageProtection?.splitProducts &&
        (autocheck.coverageEnabled ||
          autocheck.finalSaleReturns?.coverageEnabled) &&
        autocheck.packageProtection?.coverageEnabled
      ) {
        hasEligibleProduct =
          coverageInfo?.returns.cartEligible &&
          coverageInfo?.packageProtection.cartEligible;
      } else {
        hasEligibleProduct =
          coverageInfo?.returns.cartEligible ||
          coverageInfo?.packageProtection.cartEligible;
      }

      // This check ALWAYS needs to happen AFTER async functions and BEFORE state is updated
      if (signal.aborted) {
        return;
      }

      // Make sure redo isn't in cart if no eligible products are in cart
      if (!hasEligibleProduct) {
        setSingleToggleVal(false);
        setReturnToggleVal(false);
        setProtectionToggleVal(false);
      }

      // Report timing for coverage eligibility check
      reportTiming("coverage.eligibilityChecked");

      // Cart contents can't imply removal when coverage is a custom fee
      const usesCustomFee =
        doesAttachmentStrategyUseCustomFee[autocheck.attachmentStrategy];
      const cartWasMerged = storefrontClient.consumeCartMerge?.() ?? false;
      const redoWasRemoved =
        !usesCustomFee &&
        !cartWasMerged &&
        !inCart &&
        hasEligibleProduct &&
        inCartLastCheck;
      const redoWasRemovedByRedo: boolean =
        getLocalStorageWithExpiry(REDO_REMOVED_REDO);
      if (hasPackageAndSplit && someCoverageEnabled && hasTwoOptions) {
        if ((returnState || protectionState) && redoWasRemoved) {
          redoForciblyRemoved = true;
        }
      } else if (singleState && redoWasRemoved && !redoWasRemovedByRedo) {
        redoForciblyRemoved = true;
      }

      // Skip ensureRedoLoad's next re-add instead of waiting for it to finish.
      if (redoForciblyRemoved) {
        forcedRemovalAt.current = Date.now();
        log("redo was forcibly removed or disabled from cart attribute", {
          redoWasRemoved,
          redoWasRemovedByRedo,
          hasEligibleProduct,
          usesCustomFee,
          inCart,
          inCartLastCheck,
          someCoverageEnabled,
          hasPackageAndSplit,
          hasTwoOptions,
        });
        if (hasPackageAndSplit && hasTwoOptions) {
          if (returnState) {
            setReturnToggleVal(false);
            setLocalStorageWithExpiry(RETURN_TOGGLE_STATE_KEY, "disabled");
          }
          if (protectionState) {
            setProtectionToggleVal(false);
            setLocalStorageWithExpiry(PROTECTION_TOGGLE_STATE_KEY, "disabled");
          }
        } else if (singleState) {
          setSingleToggleVal(false);
          setLocalStorageWithExpiry(SINGLE_TOGGLE_STATE_KEY, "disabled");
        }
      }

      const returnDisabled =
        getLocalStorageWithExpiry(RETURN_TOGGLE_STATE_KEY) === "disabled";
      const protectionDisabled =
        getLocalStorageWithExpiry(PROTECTION_TOGGLE_STATE_KEY) === "disabled";
      const singleDisabled =
        getLocalStorageWithExpiry(SINGLE_TOGGLE_STATE_KEY) === "disabled";

      // Stamp stagecoach config onto coverage price cache → redo_metadata → checkout.
      // Must be here (not in getCoverageInfoFromCoverageCalculators) because only
      // this path has the treatment-applied autocheck. Beta draw is already resolved
      // via in-place mutation by getCoverageInfoFromCoverageCalculators above.
      const mlModel = autocheck.packageProtection?.coverageMlModel;
      const isStagecoach = mlModel?.id === "stagecoach";
      const stagecoachConfig = isStagecoach
        ? mlModel.config?.stagecoachInferenceConfig
        : undefined;
      coveragePriceCache.setStagecoachConfigInCache(
        isStagecoach && stagecoachConfig
          ? {
              inferenceMode: mlModel.config?.inferenceMode ?? "disabled",
              stagecoachInferenceConfigVersion:
                stagecoachConfig.stagecoachInferenceConfigVersion,
              modelVersionId: stagecoachConfig.modelVersionId,
              betaSampleIndex: stagecoachConfig.betaSampleIndex,
              betaVector: stagecoachConfig.betaVector,
              posteriorSubsample: stagecoachConfig.posteriorSubsample,
              stagecoachFeatureOrdering:
                stagecoachConfig.stagecoachFeatureOrdering ?? [],
              featureComputationRules: stagecoachConfig.featureComputationRules,
              conversionVsPricingTradeoffConfig:
                stagecoachConfig.conversionVsPricingTradeoffConfig,
              priceSearchConfig: stagecoachConfig.priceSearchConfig,
              inferenceFeatureScaling: stagecoachConfig.inferenceFeatureScaling,
              expectedClaimCostDollars:
                stagecoachConfig.expectedClaimCostDollars,
            }
          : undefined,
      );

      setCoverageInfo(coverageInfo);
      setPackageProtectionInsuredValue(packageProtectionInsuredValue);

      const shouldRecordPackageProtectionExposure =
        !!autocheck.packageProtection?.shouldRecordPackageProtectionExposure;
      if (shouldRecordPackageProtectionExposure) {
        try {
          const checkoutProbability =
            getCheckoutProbabilityFromSessionStorage();
          const redoCoverageProductIds = new Set(
            [
              fees.productId,
              fees.returnProduct?.productId,
              fees.packageProduct?.productId,
              fees.bothProduct?.productId,
            ]
              .filter((id): id is number => id != null)
              .map((id) => id.toString()),
          );
          const nonRedoItems = cart.items.filter(
            (item) =>
              !isCoverageFeeProduct({
                product: {
                  vendor: item.vendor,
                  sku: item.sku,
                  title: item.title,
                  product_id: item.product_id?.toString(),
                },
                redoCoverageProductIds,
                matchType: CoverageFeeProductMatchType.REDO_ONLY,
              }),
          );
          const cartValueRaw = nonRedoItems.reduce(
            (sum, item) => sum + (item.line_price || 0),
            0,
          );
          const cartItemCount = nonRedoItems.reduce(
            (sum, item) => sum + item.quantity,
            0,
          );
          const treatmentId = cart.attributes?.redo_treatment_id || undefined;
          const anonymousId = storefrontShopperIdentity().getShopperId();
          const isStagecoachArm = !!stagecoachModelMetadata;

          const dedupeKey = {
            cartHash,
            treatmentId,
            modelVersionId: stagecoachModelMetadata?.modelVersionId,
            betaSampleIndex: stagecoachModelMetadata?.betaSampleIndex,
          };

          if (anonymousId && shouldFireExposure(dedupeKey)) {
            const payload: PackageProtectionExposurePayload = {
              anonymousId,
              treatmentId,
              isStagecoachArm,
              modelVersionId: stagecoachModelMetadata?.modelVersionId,
              betaSampleIndex: stagecoachModelMetadata?.betaSampleIndex,
              packageProtectionPriceDollars: onTapcart
                ? (coverageInfo?.packageProtection.price ?? 0)
                : (coverageInfo?.packageProtection.price ?? 0) / 100,
              returnsCoveragePriceDollars: onTapcart
                ? (coverageInfo?.returns.price ?? 0)
                : (coverageInfo?.returns.price ?? 0) / 100,
              cartValue: onTapcart ? cartValueRaw : cartValueRaw / 100,
              cartItemCount,
              cartHash,
              checkoutProbability,
            };

            // Defer to a macrotask so the tracker listener is mounted before fire.
            setTimeout(() => {
              try {
                window.dispatchEvent(
                  new CustomEvent(
                    RedoEmittedDomEvent.PackageProtectionExposure,
                    { detail: payload },
                  ),
                );
                markExposureFired(dedupeKey);
              } catch (error) {
                log("Error dispatching package protection exposure event", {
                  error,
                });
              }
            }, 0);
          }
        } catch (error) {
          log("Error processing package protection exposure tracking", {
            error,
          });
        }
      }

      const bothInCart =
        fees.bothProduct?.productId === redoItems[0]?.product_id;
      const returnInCart =
        bothInCart ||
        fees.returnProduct?.productId === redoItems[0]?.product_id;
      const packageInCart =
        bothInCart ||
        fees.packageProduct?.productId === redoItems[0]?.product_id;

      const shouldAutomaticallyRemoveRedoProductOnPageLoad = [
        AttachmentStrategy.CHECKOUT_BUTTON_PRODUCT,
        AttachmentStrategy.CHECKOUT_BUTTON_SHIPPING,
      ].includes(autocheck.attachmentStrategy);

      const coverageAlreadySelected = usesCustomFee
        ? singleState
        : inCart || (cartWasMerged && singleState);
      const shouldDefaultOn = autocheck.redoAutoCheck && !singleDisabled;

      if (
        cartEnabled &&
        !redoForciblyRemoved &&
        !shouldAutomaticallyRemoveRedoProductOnPageLoad
      ) {
        // If cart is eligible for adding a redo item, add it by changing toggles
        if (hasPackageAndSplit && someCoverageEnabled && hasTwoOptions) {
          if (
            coverageInfo?.returns.cartEligible &&
            !returnToggleState &&
            (returnInCart ||
              (cartWasMerged && returnState) ||
              (autocheck.redoAutoCheck && !returnDisabled))
          ) {
            setReturnToggleVal(true);
            setLocalStorageWithExpiry(RETURN_TOGGLE_STATE_KEY, "enabled");
          }
          if (
            coverageInfo?.packageProtection.cartEligible &&
            !protectionToggleState &&
            (packageInCart ||
              (cartWasMerged && protectionState) ||
              (autocheck.packageProtectionAutoCheck && !protectionDisabled))
          ) {
            setProtectionToggleVal(true);
            setLocalStorageWithExpiry(PROTECTION_TOGGLE_STATE_KEY, "enabled");
          }
        } else if (
          hasEligibleProduct &&
          !singleToggleState &&
          (coverageAlreadySelected || shouldDefaultOn)
        ) {
          setSingleToggleVal(true);
          setLocalStorageWithExpiry(SINGLE_TOGGLE_STATE_KEY, "enabled");
        }
      }

      setInCart(inCart);
      setCheckedCart(cart);

      if (cart?.items?.length) {
        // Set REDO_REMOVED_REDO based on coverage status
        setLocalStorageWithExpiry(REDO_REMOVED_REDO, !hasEligibleProduct);
      } else {
        // Set to true if cart is empty
        setLocalStorageWithExpiry(REDO_REMOVED_REDO, true);
        // ANY_WIDGET is opt-in via the upsell; reset toggles on an emptied
        // cart so a persisted "enabled" state can't silently re-add Redo.
        if (isAnyWidgetAttachmentStrategy[autocheck.attachmentStrategy]) {
          setLocalStorageWithExpiry(SINGLE_TOGGLE_STATE_KEY, "disabled");
          setLocalStorageWithExpiry(RETURN_TOGGLE_STATE_KEY, "disabled");
          setLocalStorageWithExpiry(PROTECTION_TOGGLE_STATE_KEY, "disabled");
        }
      }
    },
    [
      !!buyerIdentity?.purchasingCompany?.company,
      cartItems,
      fees,
      countryLoadPending,
      mainRedoProduct,
      usingInStorePickup,
    ],
  );

  useEffect(() => {
    if (cartCheckLoad.error) {
      log("error checking cart", { error: cartCheckLoad.error });
    }
  }, [cartCheckLoad.error]);

  const applyCartCountModificationsTrigger = useTriggerLoad(
    async (signal?: AbortSignal) => {
      if (!autocheck.hideRedoProduct?.enabled || !cart || !cartItems?.length) {
        return;
      }
      let redoProductPrice = 0;
      if (redoProductToSell) {
        redoProductPrice = redoProductToSell.price;
      }

      await applyCartCountModificationsWithRetries({
        autocheck,
        cart,
        redoProductPrice,
        redoShouldBeInCart: !!expectedVariantID,
        signal,
      });
    },
  )[1];

  const abortControllerRef = useRef<AbortController | null>(null);
  useEffect(() => {
    if (!autocheck.hideRedoProduct?.enabled || !cart || !cartItems?.length) {
      return;
    }

    // Cancel the previous request if it exists
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    // Create a new AbortController for this request
    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    applyCartCountModificationsTrigger(abortController.signal);

    // Cleanup: abort on unmount or when dependencies change
    return () => {
      if (abortControllerRef.current === abortController) {
        abortControllerRef.current.abort();
        abortControllerRef.current = null;
      }
    };

    // FIXME
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    cartItems,
    cartRefresh,
    cart?.total_price,
    singleToggleState,
    cart,
    expectedVariantID,
    autocheck.hideRedoProduct?.cartCountModifications,
    autocheck.hideRedoProduct?.enabled,
    autocheck.hideRedoProduct?.cartPriceModifications,
    autocheck.hideRedoProduct?.cartDiscountModifications,
  ]);

  // Listen for click events and refresh toggles.
  useEventListener(
    document,
    "click",
    (e: Event) => {
      if (
        e.target instanceof Element &&
        // Check if the click was one of the elements that could trigger a cart change or open.
        ((autocheck.cartToggle.cartClickListenerSelector &&
          e.target.matches(autocheck.cartToggle.cartClickListenerSelector)) ||
          e.target.matches(DEFAULT_TOGGLE_CLICK_SELECTOR))
      ) {
        for (let i = 1; i <= 5; i *= 2) {
          setTimeout(() => setCartRefresh(Symbol()), i * 500);
        }
      }
    },
    true,
  );

  const pageChange = usePageChange();
  // This will trigger the checkbox to be added if it needs to be, as well as re-rendering the toggle.
  useEffect(() => {
    if (!pageChange) {
      return;
    }
    setCheckboxRefresh(pageChange);
    setCartRefresh(pageChange);
  }, [pageChange]);

  // Add checkbox if on product page
  useEffect(() => {
    if (document.querySelector("redo-checkbox") || isOnProductPage(onTapcart)) {
      setCheckbox(addCheckbox(autocheck, onTapcart));
    } else if (checkbox) {
      setCheckbox(null);
    }
    // FIXME
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [checkboxRefresh, builderRefreshSymbol, renderElementsDebounced]);

  /**
   * pdpProductLoad is used for the PDP checkbox and buy now button. It detects if we are currently on a product page and if the product is valid for the coverage.
   */
  const pdpProductLoad = useLoad(
    async (signal) => {
      const handle = onTapcart
        ? // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
          Tapcart!.variables?.product?.handle
        : shopifyProductHandle(location.href);

      if (!handle) {
        return {
          isValidProduct: false,
          returnsValid: false,
          protectionValid: false,
          finalSaleReturnsValid: false,
          product: undefined,
        };
      }

      let product: ShopifyProduct;
      try {
        product = await storefrontClient.productGet(handle, signal);
      } catch (e) {
        log(
          "Error fetching product, likely because we're not on a product's page",
          { handle, error: e },
        );
        return {
          isValidProduct: false,
          returnsValid: false,
          protectionValid: false,
          finalSaleReturnsValid: false,
          product: undefined,
        };
      }

      const eligibility = await itemValidForReturnsFrontend({
        autocheck,
        item: {
          product_id: product.id,
          variant_id: product.variants[0]?.id ?? "",
          handle,
        },
        redoShopifyExtensionClient,
        shopifyClient: storefrontClient,
        signal,
        invalidReturnProductTags,
        invalidProtectionProductTags,
        shopifyProduct: product,
        onTapcart,
        storefrontGraphQLClient: shopifyStorefrontGraphqlClient,
      });
      log("pdp eligibility", eligibility);

      const country = countryLoad.value;
      if (
        country &&
        isCountryCoverageExcluded(
          country,
          autocheck.packageProtection.pricingRuleSets,
        )
      ) {
        eligibility.protectionValid = false;
      }

      if (
        country &&
        isCountryCoverageExcluded(
          country,
          autocheck.internationalReturnsPricing,
          autocheck.countries,
        )
      ) {
        eligibility.returnsValid = false;
      }

      const hasBothCoverage =
        (autocheck.coverageEnabled ||
          autocheck.finalSaleReturns?.coverageEnabled) &&
        autocheck.packageProtection?.coverageEnabled;

      let isValidProduct = false;

      if (hasBothCoverage && !autocheck.packageProtection?.splitProducts) {
        isValidProduct =
          (eligibility.returnsValid || eligibility.finalSaleReturnsValid) &&
          eligibility.protectionValid;
      } else {
        isValidProduct =
          eligibility.returnsValid ||
          eligibility.protectionValid ||
          eligibility.finalSaleReturnsValid;
      }

      if (
        (checkbox &&
          (document.querySelector("redo-checkbox") ||
            isOnProductPage(onTapcart))) ||
        autocheck.useBuyNowCoverage
      ) {
        return { isValidProduct, ...eligibility, product };
      }

      return { isValidProduct: false, ...eligibility, product };
    },
    [
      checkbox,
      checkboxRefresh,
      builderRefreshSymbol,
      cart?.items?.length,
      onTapcart,
      autocheck.coverageExcludeCollections,
      autocheck.finalSaleReturns.coverageEnabled,
      autocheck.finalSaleReturns.coverageValidTags,
      autocheck.finalSaleReturns.coverageValidCollections,
      invalidReturnProductTags,
      autocheck.packageProtection.pricingRuleSets,
      autocheck.internationalReturnsPricing,
      autocheck.countries,
      countryLoad.value,
    ],
  );

  useEffect(
    () => {
      const variant = extractProductFormData();
      if (
        variant &&
        (variant.variantId !== pdpSelectedVariant?.variantId ||
          variant.quantity !== pdpSelectedVariant?.quantity)
      ) {
        setPdpSelectedVariant(variant);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [pdpProductLoadRef.current, renderElementsDebounced],
  );

  useEffect(() => {
    if (pdpProductLoad.error) {
      console.error(pdpProductLoad.error);
    }
  }, [pdpProductLoad.error]);

  // Update ref so mutation observer can use validProductLoad value early
  useEffect(() => {
    pdpProductLoadRef.current = pdpProductLoad.value;
  }, [pdpProductLoad.value, renderElementsDebounced]);

  // Resolves the buy-now coverage variant for the given product variant — the
  // same pricing pipeline used for the wallet buy-now, parameterized by variant
  // so both the wallet path (via pdpSelectedVariant) and the standalone
  // window.RedoHsa.buyProductNowWithHsa button (via its passed variant) can
  // price coverage. Returns the coverage variant id, or null when coverage
  // doesn't apply (buy-now coverage off, product ineligible, variant unknown).
  // useHandler gives a stable identity that always runs against the latest
  // render's state, so the once-registered window.RedoHsa method reads fresh
  // values when invoked.
  const resolveBuyNowCoverageVariantId = useHandler(
    (
      variantId: string | number | undefined,
      quantity: number,
    ): string | null => {
      if (
        !mainRedoProduct ||
        !fees ||
        !autocheck.enabled ||
        !pdpProductLoadRef.current?.isValidProduct ||
        !variantId
      ) {
        return null;
      }

      if (cart) {
        coveragePriceCache.syncCartCoveragePriceCacheWithLocalStorage({ cart });
      }

      const shopifyVariant = pdpProductLoadRef.current.product?.variants.find(
        (variant) => String(variant.id) === String(variantId),
      );

      if (!shopifyVariant) {
        return null;
      }

      const coveragePriceCacheValue =
        coveragePriceCache.getCachedCoveragePrices({
          cartItems: cartItems ?? [],
          coverageProductIds: autocheck.coverageProductIds,
        });

      const checkoutProbability = getCheckoutProbabilityFromSessionStorage();

      // NOT compatible with Tapcart
      const price = shopifyVariant.price * 100;
      const coveragePrices = getCalculatedCoveragePrice({
        basePriceDollars: autocheck.pricePerOrder
          ? parseFloat(autocheck.pricePerOrder)
          : 0,
        autocheck,
        onTapcart,
        cartValueReturnableItems: pdpProductLoadRef.current.returnsValid
          ? price
          : 0,
        cartValuePackageProtectionItems: pdpProductLoadRef.current
          .protectionValid
          ? price
          : 0,
        finalSaleReturnsCartValue: pdpProductLoadRef.current
          .finalSaleReturnsValid
          ? price
          : 0,
        cartItems,
        numValidReturnProducts: pdpProductLoadRef.current.returnsValid
          ? quantity
          : 0,
        numValidPackageProtectionProducts: pdpProductLoadRef.current
          .protectionValid
          ? quantity
          : 0,
        country: countryLoad.value,
        cartHasSubscriptionItem: false,
        coveragePriceCacheValue,
        priceCalculationContext: { checkoutProbability },
      });

      const wasPriceShown =
        !autocheck.hideCheckboxPrice && !autocheck.hideCheckbox;
      if (wasPriceShown) {
        // Caching of coverage prices was built so customers don't see the
        // coverage price change without them taking any action. If they never
        // saw the price, delay caching until later when we have more context
        // to make a better pricing decision.
        coveragePriceCache.maybeCacheCoveragePrices({
          cartItems: cartItems ?? [],
          coveragePrices: coveragePrices.rawCoveragePrices,
          coverageProductIds: autocheck.coverageProductIds,
        });
      }

      const pdpCoverageInfo = {
        returns: {
          cartEligible: pdpProductLoadRef.current.returnsValid,
          price: coveragePrices.returnCost,
          isFinalSale: pdpProductLoadRef.current.finalSaleReturnsValid,
        },
        packageProtection: {
          cartEligible: pdpProductLoadRef.current.protectionValid,
          price: coveragePrices.packageProtectionCost,
        },
        both: {
          cartEligible:
            pdpProductLoadRef.current.returnsValid &&
            pdpProductLoadRef.current.protectionValid,
          price: coveragePrices.bothCost,
        },
      };

      const singleProduct = determineRedoProduct({
        mainRedoProduct,
        returnRedoProduct,
        packageRedoProduct,
        bothRedoProduct,
        fees,
        autocheck,
        coverageInfo: pdpCoverageInfo,
        toggleStates: { returnToggleState, protectionToggleState },
      });

      const singleProductVariant = getCorrectlyPricedVariant({
        product: singleProduct,
        productType: productTypeMap.get(singleProduct.id),
        coverageInfo: pdpCoverageInfo,
        country: countryLoad.value ?? undefined,
      });

      return singleProductVariant.id.toString();
    },
  );

  // Keep `buyNowRedoProduct` in sync for the wallet/Shop Pay buy-now
  // interception path (`useBuyNowCoverage`), using the variant resolved from the
  // PDP form.
  useEffect(
    () => {
      const variantId = pdpSelectedVariant?.variantId;
      const coverageVariantId = resolveBuyNowCoverageVariantId(
        variantId,
        pdpSelectedVariant?.quantity ?? 1,
      );
      if (coverageVariantId) {
        log("pdp buy now selected redo product", coverageVariantId);
        setBuyNowRedoProduct(coverageVariantId);
        cacheBuyNowCoverageVariantId(variantId, coverageVariantId);
        return;
      }
      // if we haven't resolved the coverage variant id yet, check the cache
      else {
        const cachedCoverageVariantId =
          getCachedBuyNowCoverageVariantId(variantId);
        if (cachedCoverageVariantId) {
          log("pdp buy now cached redo product", cachedCoverageVariantId);
          setBuyNowRedoProduct(cachedCoverageVariantId);
        }
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      pdpSelectedVariant,
      fees,
      autocheck,
      cartItems,
      invalidReturnProductTags,
      invalidProtectionProductTags,
      anyCheckoutButtonClicked,
      pdpProductLoadRef.current?.isValidProduct,
      pdpProductLoad.value?.isValidProduct,
    ],
  );

  // Contribute this island's coverage pricing / existing-cart checkout to the
  // HSA island's `window.RedoHsa` API, which owns the public methods.
  useEffect(() => {
    if (!isHsaEnabled({ autocheck })) {
      return;
    }
    setHsaCoverageContributions({
      resolveBuyNowCoverageVariantId,
      goToHsaExistingCartCheckout: async (exclusive: boolean) => {
        const handler = onHsaExistingCartCheckoutRef.current;
        if (handler) {
          await handler(checkboxState.current, exclusive);
          return;
        }
        await goToHsaStandardCheckout(storefrontClient, exclusive);
      },
    });
    return () => {
      clearHsaCoverageContributions();
    };
  }, [autocheck, resolveBuyNowCoverageVariantId, storefrontClient]);

  useEffect(() => {
    if (
      coverageInfo?.returns.cartEligible ||
      coverageInfo?.packageProtection.cartEligible
    ) {
      log(
        `Eligible for ${[coverageInfo?.returns.cartEligible ? "returns" : "", coverageInfo?.packageProtection.cartEligible ? "package protection" : ""].filter(Boolean).join(" and ")}.`,
      );
      renderElementsHandler();
    } else if (shouldShowBuyNowElements) {
      log("Eligible for the product page.");
      renderElementsHandler(PlacementType.PDP);
    } else {
      log(
        `Not eligible for any products: ${coverageInfo?.returns.reasonIneligible ? `${coverageInfo.returns.reasonIneligible}.` : ""} ${coverageInfo?.packageProtection.reasonIneligible ? `${coverageInfo.packageProtection.reasonIneligible}` : ""}`,
      );
    }
  }, [
    cart,
    cartRefresh,
    renderElementsDebounced,
    renderElementsSignalSkipDebounce,
    renderElementsHandler,
    coverageInfo,
    shouldShowBuyNowElements,
    builderRefreshSymbol,
  ]);

  const showCheckbox =
    (checkboxLabelOnly || !redoInCart) &&
    pdpProductLoad.value?.isValidProduct &&
    (cartCheckedOnce || merchantPaid) &&
    validCountryReturns;
  if (globalThis.redoStorefront) {
    globalThis.redoStorefront.coveragePdpEligible = pdpProductLoad.pending
      ? undefined
      : !!showCheckbox;
    globalThis.redoStorefront.coveragePdpWidgetsEligible =
      pdpProductLoad.pending
        ? undefined
        : cartEnabled &&
          !merchantPaid &&
          !!(
            coverageInfo?.returns.cartEligible ||
            coverageInfo?.packageProtection.cartEligible ||
            shouldShowBuyNowElements
          );
  }
  // Add checkbox event handlers
  useEffect(() => {
    if (!checkbox || !showCheckbox || checkboxLabelOnly) {
      return;
    }

    // Boolean to make sure we only add redo once for these handlers.
    // Once we add it, they will all be removed on the next re-render
    // because showCheckbox will be false.
    let added = false;
    const form = checkbox.closest("form");
    async function formEventHandler(e: SubmitEvent) {
      if (checkboxState.current && !added) {
        added = true;
        await addRedo(e);
      }
    }
    async function rebuyHandler(e: any): Promise<void> {
      if (checkboxState.current && !added) {
        added = true;
        // Don't add redo when we're already adding redo.
        if (String(e?.detail?.item?.variant_id) === String(fees?.variantId)) {
          return;
        }
        await addRedo();
      }
    }
    async function clickEventHandler(e: MouseEvent): Promise<void> {
      if (
        e.target instanceof Element &&
        globalThis?.Shopify?.theme?.name === "Dawn" &&
        e.target.closest(".shopify-payment-button__button")
      ) {
        // Buy it now button for the dawn theme
        const quantityElement = document.querySelector(
          '.quantity__input, input[type="number"]',
        ) as HTMLInputElement | null;
        const quantity = quantityElement?.value || "1";
        const currentSelectedVariant =
          // prettier-ignore
          (
            // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
            document.querySelector(
              ".product__pickup-availabilities",
            ) as HTMLElement
          ).dataset.variantId;
        e.preventDefault();
        e.stopPropagation();
        location.href = `https://${
          globalThis?.Shopify.shop
        }/cart/${currentSelectedVariant}:${quantity},${
          // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
          fees!.variantId
        }:1?traffic_source=buy_now`;
      } else if (
        e.target instanceof Element &&
        e.target.closest(getSubmitButtonSelector(autocheck)) &&
        checkboxState.current &&
        !added
      ) {
        added = true;
        await addRedo(e);
      }
    }

    form?.addEventListener("submit", formEventHandler);
    document.addEventListener("rebuy:cart.add", rebuyHandler);
    document.addEventListener("click", clickEventHandler, true);

    return () => {
      form?.removeEventListener("submit", formEventHandler);
      document.removeEventListener("rebuy:cart.add", rebuyHandler);
      document.removeEventListener("click", clickEventHandler);
    };
    // FIXME
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [checkbox, showCheckbox, cartEnabled]);

  useEffect(() => {
    const context = { autocheck, treatmentId };
    void reportCoverageLoaded(context);
    const standardElementType =
      autocheck.attachmentStrategy === AttachmentStrategy.DOUBLE_TOGGLE
        ? WidgetElementType.DOUBLE_TOGGLE
        : autocheck.attachmentStrategy === AttachmentStrategy.CART_CARD
          ? WidgetElementType.CART_CARD
          : WidgetElementType.SINGLE_TOGGLE;
    void reportCoveragePlacementMetrics(
      context,
      getObservedCoveragePlacements(
        placedWidgetHtmlElements,
        standardElementType,
      ),
    );
    recordCoverageWidgetsRendered(
      getRenderedWidgetElements(placedWidgetHtmlElements, standardElementType),
    );
  });

  if (!fees) {
    return null;
  }

  // In preview mode, bypass certain restrictions

  const isPreviewMode = (globalThis as any).redoMode === "preview"; // eslint-disable-line @typescript-eslint/no-unsafe-type-assertion

  if (
    !isPreviewMode &&
    !merchantPaid &&
    (autocheck.disableRedoForCustomer ||
      (autocheck.hideCheckbox && !autocheck.cartToggle.enabled && !onTapcart) ||
      !autocheck.enabled ||
      (autocheck.hideCheckbox && !cartCheckedOnce))
  ) {
    log("returning empty", {
      merchantPaid,
      disableRedoForCustomer: autocheck.disableRedoForCustomer,
      hideCheckbox: autocheck.hideCheckbox,
      cartToggleEnabled: autocheck.cartToggle.enabled,
      enabled: autocheck.enabled,
      cartChecked,
    });
    return null;
  }

  let showToggles = false;
  const hasBothCoverage =
    (autocheck.coverageEnabled ||
      autocheck.finalSaleReturns?.coverageEnabled) &&
    autocheck.packageProtection?.coverageEnabled;

  if (hasBothCoverage && !autocheck.packageProtection?.splitProducts) {
    showToggles = !!(
      coverageInfo?.returns.cartEligible &&
      coverageInfo?.packageProtection.cartEligible
    );
  } else {
    showToggles = !!(
      coverageInfo?.returns.cartEligible ||
      coverageInfo?.packageProtection.cartEligible
    );
  }

  if (!showToggles && coverageInfo) {
    log(
      `cart is not eligible: ${[coverageInfo.returns.reasonIneligible, coverageInfo.packageProtection.reasonIneligible].filter(Boolean).join(", ")}`,
    );
  }

  if (
    isAttachmentStrategyUsingCheckoutButtons[autocheck.attachmentStrategy] &&
    autocheck.hideRedoProduct
  ) {
    autocheck.hideRedoProduct.enabled = showToggles;
  }

  if (shouldShowBuyNowElements) {
    showToggles = true;
  }

  checkCoverageNotShowingReason(
    coverageInfo,
    showToggles,
    placedWidgetHtmlElements,
    cartItems,
  );

  const classicWidgetTheme = getClassicWidgetTheme({ autocheck });

  return (
    <InsurerDisclosureContext.Provider value={insurerDisclosure}>
      {checkbox && showCheckbox ? (
        <StyleShadowRoot
          shadowRoot={checkbox.root}
          styleManager={STYLE_MANAGER}
        >
          <ModalRootContext.Provider value={checkbox.modalContainer}>
            <RedoCheckbox
              checkboxText={autocheck.checkboxText}
              coverage={autocheck.coverage}
              finalSaleReturnsCoverageEnabled={
                autocheck.finalSaleReturns?.coverageEnabled ?? false
              }
              hideCheckbox={onTapcart ? false : autocheck.hideCheckbox}
              hidePrice={autocheck.hideCheckboxPrice}
              infoLink={autocheck.infoIconLink}
              initial={autocheck.redoAutoCheck}
              isFinalSaleProduct={!!pdpProductLoad.value?.finalSaleReturnsValid}
              labelOnly={checkboxLabelOnly}
              modalLogo={autocheck.modalLogo}
              modalTextAdjustments={autocheck.modalTextAdjustments}
              onAdd={onModalAdd}
              onChange={onCheckboxChange}
              packageProtectionEnabled={
                autocheck.packageProtection.coverageEnabled
              }
              packageProtectionPlusEnabled={
                autocheck.packageProtection.packageProtectionPlusEnabled
              }
              paymentModel={autocheck.paidModel}
              price={
                !autocheck.packageProtection.coverageEnabled
                  ? {
                      amount: redoProductToSell?.price || +fees.price,
                      currency: cartCurrency,
                    }
                  : undefined
              }
              returnsCoverageEnabled={autocheck.coverageEnabled}
              showInfo={
                !onTapcart &&
                (autocheck.coverageEnabled ||
                  autocheck.finalSaleReturns?.coverageEnabled)
              }
              theme={classicWidgetTheme}
            />
          </ModalRootContext.Provider>
        </StyleShadowRoot>
      ) : null}

      {isAttachmentStrategyUsingCheckoutButtons[autocheck.attachmentStrategy] &&
        coverageInfo &&
        showToggles &&
        redoProductToSell &&
        productIdToSellingPlanId.value && (
          <CheckoutButtonInfoCardManager
            anyCheckoutButtonClicked={anyCheckoutButtonClicked}
            autocheck={autocheck}
            cart={cart}
            cartCurrency={cartCurrency}
            country={countryLoad.value ?? undefined}
            coverageInfo={coverageInfo}
            fees={fees}
            language={shopperLanguage}
            placedWidgetHtmlElements={placedWidgetHtmlElements.filter(
              ({ widgetConfig }) => isCheckoutButtonsOrInfoCards(widgetConfig),
            )}
            productIdToSellingPlanId={productIdToSellingPlanId.value}
            redoClient={redoShopifyExtensionClient}
            redoProductToSell={redoProductToSell}
            setOnBuyNowCoverage={setOnBuyNowCoverage}
            setOnHsaExistingCartCheckout={setOnHsaExistingCartCheckout}
            shopifyClient={
              shouldUseStorefrontGraphqlClientForRIC
                ? (shopifyStorefrontGraphqlClient ?? storefrontClient)
                : storefrontClient
            }
            storefrontGraphqlClient={shopifyStorefrontGraphqlClient}
            triggerCartRefresh={() => setCartRefresh(Symbol())}
          />
        )}

      {showToggles &&
        redoProductToSell &&
        coverageInfo &&
        !(!!onTapcart && isOnProductPage(onTapcart)) &&
        singleCartToggleAttachmentStrategies.includes(
          autocheck.attachmentStrategy,
        ) && (
          <SingleToggleManager
            autocheck={autocheck}
            cartCurrency={cartCurrency}
            country={countryLoad.value ?? undefined}
            coverageInfo={coverageInfo}
            fees={fees}
            language={shopperLanguage}
            placedWidgetHtmlElements={placedWidgetHtmlElements.filter(
              ({ widgetConfig }) => !isCheckoutButtonsOrInfoCards(widgetConfig),
            )}
            redoProductToSell={redoProductToSell}
            setSingleToggleVal={setSingleToggleVal}
            singleToggleState={singleToggleState}
          />
        )}

      {showToggles &&
        coverageInfo &&
        autocheck.attachmentStrategy === AttachmentStrategy.DOUBLE_TOGGLE && (
          <DoubleToggleManager
            autocheck={autocheck}
            cartCurrency={cartCurrency}
            country={countryLoad.value ?? ""}
            coverageInfo={coverageInfo}
            fees={fees}
            language={shopperLanguage}
            onTapcart={onTapcart}
            packageRedoProduct={packageRedoProduct}
            placedWidgetHtmlElements={placedWidgetHtmlElements.filter(
              ({ widgetConfig }) => !isCheckoutButtonsOrInfoCards(widgetConfig),
            )}
            protectionToggleState={protectionToggleState}
            returnRedoProduct={returnRedoProduct}
            returnToggleState={returnToggleState}
            setProtectionToggleVal={setProtectionToggleVal}
            setReturnToggleVal={setReturnToggleVal}
          />
        )}
    </InsurerDisclosureContext.Provider>
  );
});

function getCheckoutProbabilityFromSessionStorage(): number | undefined {
  const stored = loadCheckoutProbabilityFromSessionStorage();
  if (isDef(stored?.cumulativeConversionProbability)) {
    // Convert from 0-1 scale to 0-100 scale
    return stored.cumulativeConversionProbability * 100;
  }
  return undefined;
}

function checkCoverageNotShowingReason(
  coverageInfo: CoverageInfo | undefined,
  showToggles: boolean,
  placedWidgetHtmlElements: PlacedWidgetHtmlElements[],
  cartItems: ShopifyCartItem[] | undefined,
) {
  if (!showToggles && coverageInfo) {
    log(
      `cart is not eligible: ${coverageInfo.returns.reasonIneligible ? `${coverageInfo.returns.reasonIneligible}.` : ""} ${coverageInfo.packageProtection.reasonIneligible ? `${coverageInfo.packageProtection.reasonIneligible}` : ""}`,
    );
    if (globalThis.redoStorefront) {
      globalThis.redoStorefront.coverageNotShowingReason = !cartItems?.length
        ? CoverageNotShowingReason.CART_EMPTY
        : CoverageNotShowingReason.CART_NOT_ELIGIBLE;
    }
  }

  if (
    showToggles &&
    (globalThis.redoStorefront?.coverageNotShowingReason ===
      CoverageNotShowingReason.CART_NOT_ELIGIBLE ||
      globalThis.redoStorefront?.coverageNotShowingReason ===
        CoverageNotShowingReason.CART_EMPTY)
  ) {
    globalThis.redoStorefront.coverageNotShowingReason = undefined;
  }
  const allTogglesEmpty = placedWidgetHtmlElements.every(
    (toggle) => toggle.redoHtmlElements.length === 0,
  );

  if (globalThis.redoStorefront && coverageInfo) {
    globalThis.redoStorefront.coverageInfo = coverageInfo;
  }

  if (showToggles && allTogglesEmpty && globalThis.redoStorefront) {
    globalThis.redoStorefront.coverageNotShowingReason =
      CoverageNotShowingReason.NO_TOGGLE_LOCATIONS_FOUND;
  }
  if (
    !allTogglesEmpty &&
    globalThis.redoStorefront?.coverageNotShowingReason ===
      CoverageNotShowingReason.NO_TOGGLE_LOCATIONS_FOUND
  ) {
    globalThis.redoStorefront.coverageNotShowingReason = undefined;
  }
}
