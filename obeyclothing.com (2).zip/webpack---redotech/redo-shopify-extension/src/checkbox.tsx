import { MerchantStyle } from "@redotech/arbiter/merchant-style";
import { Money } from "@redotech/money";
import { moneyFormat } from "@redotech/money/util";
import { useHandler } from "@redotech/react-util/hook";
import { Lazy } from "@redotech/react-util/init";
import {
  Coverage,
  PaymentModel,
} from "@redotech/redo-return-coverage-common/coverage";
import {
  fullCoverage,
  getHtml,
  getReturnType,
  texts,
} from "@redotech/redo-storefront-common/checkbox";
import htmlReactParser from "html-react-parser";
import {
  ChangeEvent,
  MouseEvent,
  ReactNode,
  Suspense,
  lazy,
  memo,
  useId,
  useLayoutEffect,
  useRef,
  useState,
} from "react";
import Check from "./check.svg";
import * as checkbox from "./checkbox.module.css";
import { RedoEmittedDomEvent, useFireEventOnRender } from "./dom-events";
import Info from "./info.svg";
import { ClassicWidgetTheme } from "./render-elements/classic-widget-theme";
import { recordCoverageInfoModalOpened } from "./utils/coverage-info-modal-opened";

const RedoModal = lazy(async () => {
  const { RedoModal } = await import("./modal");
  return { default: RedoModal };
});

const CheckboxLabel = ({
  children,
  color,
  coverage,
  price,
  checkboxText,
  checkboxTextAfterRedo,
  fontSize,
  labelId,
}: {
  children: ReactNode;
  color: string;
  coverage: Coverage;
  price?: string;
  checkboxText?: string | null;
  checkboxTextAfterRedo?: string | null;
  fontSize?: number;
  labelId: string;
}) => {
  const coverageKey =
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    `${+coverage.exchange}${+coverage.refund}${+coverage.storeCredit}` as `${0 | 1}${0 | 1}${0 | 1}`;
  const name = texts[coverageKey];
  return (
    <span
      className={checkbox.label}
      data-target="checkbox-label"
      id={labelId}
      style={{
        color,
        fontSize: fontSize ? `${fontSize}px` : "var(--redo-font-size-xs)",
      }}
    >
      {checkboxText ? (
        htmlReactParser(checkboxText)
      ) : (
        <>
          {children} {name !== fullCoverage && <>for {name} </>}
        </>
      )}
      {price && ` for ${price}`} {checkboxTextAfterRedo}
    </span>
  );
};

const Checkbox = memo(function Checkbox({
  color,
  value,
  onValue,
  labelId,
}: {
  color: string;
  value: boolean;
  onValue: (value: boolean) => void;
  labelId: string;
}) {
  const onChange = useHandler((e: ChangeEvent) => {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    onValue((e.target as HTMLInputElement).checked);
  });
  const [enableAnimation, setEnableAnimation] = useState(false);

  useLayoutEffect(() => setEnableAnimation(true), []);

  return (
    <span className={checkbox.checkboxWrapper} style={{ color }}>
      <label className={checkbox.checkbox} style={{ color }}>
        {/* design-allow: storefront widget injected into merchant pages; native checkbox required */}
        <input
          aria-labelledby={labelId}
          checked={value}
          className={checkbox.input}
          onChange={onChange}
          type="checkbox"
        />
        <span className={checkbox.box} style={{ borderColor: color }}>
          <Check
            className={checkbox.check}
            // design-allow: disable CSS check animation on first paint; no theme prop for this
            style={!enableAnimation ? { animationDuration: "0" } : undefined}
          />
        </span>
      </label>
    </span>
  );
});

export const RedoCheckbox = ({
  theme,
  coverage,
  checkboxText,
  initial,
  onAdd,
  onChange,
  paymentModel,
  price,
  hidePrice,
  hideCheckbox,
  modalTextAdjustments,
  modalLogo,
  labelOnly,
  infoLink,
  showInfo = true,
  packageProtectionPlusEnabled,
  packageProtectionEnabled,
  returnsCoverageEnabled,
  finalSaleReturnsCoverageEnabled,
  isFinalSaleProduct,
}: {
  theme: ClassicWidgetTheme;
  coverage: Coverage;
  checkboxText?: string | null;
  initial: boolean;
  onAdd?(): void | Promise<void>;
  onChange?(value: boolean): void;
  paymentModel: PaymentModel;
  price: Money | undefined;
  hidePrice?: boolean;
  hideCheckbox: boolean;
  labelOnly?: boolean;
  packageProtectionPlusEnabled?: boolean;
  packageProtectionEnabled?: boolean;
  modalTextAdjustments?: {
    text1: string;
    title1: string;
    text2: string;
    title2: string;
    text3: string;
    title3: string;
  };
  modalLogo?: string;
  infoLink?: string;
  showInfo?: boolean;
  returnsCoverageEnabled: boolean;
  finalSaleReturnsCoverageEnabled: boolean;
  isFinalSaleProduct: boolean;
}) => {
  useFireEventOnRender(RedoEmittedDomEvent.PdpCheckboxRendered);
  const {
    color,
    customPdpCss,
    fontSize,
    html,
    modalVersion,
    modalCustomizationsV2,
    toggleTextAfterRedo: checkboxTextAfterRedo,
    returnPolicyUrl,
  } = theme;

  const [modalOpen, setModalOpen] = useState(false);
  const [value, setValue] = useState(initial);
  const labelId = useId();
  const onValue = useHandler((value: boolean) => {
    if (labelOnly) {
      return;
    }
    setValue(value);
    onChange?.(value);
  });

  const handleAdd = useHandler(async () => {
    if (labelOnly) {
      return;
    }
    setValue(true);
    onChange?.(true);
    await onAdd?.();
  }); // TODO(paul): would be nice to add to cart
  const infoButtonRef = useRef<HTMLElement | null>(null);
  const onInfoClick = useHandler((e?: MouseEvent<HTMLElement>) => {
    if (infoLink) {
      open(infoLink, "_blank");
    } else {
      infoButtonRef.current = e?.currentTarget ?? null;
      setModalOpen(true);
      recordCoverageInfoModalOpened();
    }
  });
  const onModalClose = useHandler(() => setModalOpen(false));

  const label = (
    <CheckboxLabel
      checkboxText={checkboxText}
      checkboxTextAfterRedo={checkboxTextAfterRedo}
      color={color}
      coverage={coverage}
      fontSize={fontSize}
      labelId={labelId}
      price={
        paymentModel === "customer_paid" && price && !hidePrice
          ? moneyFormat(price)
          : undefined
      }
    >
      {html ? (
        htmlReactParser(getHtml(html, getReturnType(coverage)) ?? "")
      ) : (
        <strong>Free Unlimited Returns</strong>
      )}
    </CheckboxLabel>
  );

  let checkbox_: ReactNode;
  if (!labelOnly) {
    // tslint-disable-next-line @typescript-eslint/switch-exhaustiveness-check -- TODO: grandfather FIXME
    switch (paymentModel) {
      case "customer_paid":
        checkbox_ = (
          <Checkbox
            color={color}
            labelId={labelId}
            onValue={onValue}
            value={value}
          />
        );
        break;
      case "merchant_paid":
        checkbox_ = <span />;
        break;
    }
  }

  if (
    !isFinalSaleProduct &&
    Object.values(coverage).every((optionCovered) => !optionCovered)
  ) {
    return null;
  }

  return (
    <>
      <div
        className={checkbox.container}
        data-target="checkbox-root"
        style={{ color, display: hideCheckbox ? "none" : "" }}
      >
        <MerchantStyle css={customPdpCss} />
        {checkbox_}
        {label}
        {paymentModel !== "merchant_paid" && showInfo && (
          <span
            className={checkbox.modalTrigger}
            data-target="checkbox-info"
            style={{ color }}
          >
            {/* design-allow: storefront widget injected into merchant pages; native button required */}
            <button
              aria-haspopup="dialog"
              aria-label="More information about coverage"
              className={checkbox.info}
              data-target="checkbox-info-button"
              onClick={onInfoClick}
              type="button"
            >
              <Info aria-hidden className={checkbox.infoIcon} />
            </button>
          </span>
        )}
      </div>
      {!infoLink && (
        <Suspense>
          <Lazy init={modalOpen}>
            <RedoModal
              enableTopLayerModalApi={
                modalCustomizationsV2?.enableTopLayerModalApi
              }
              finalSaleReturnsCoverageEnabled={finalSaleReturnsCoverageEnabled}
              modalCustomizationsV2={modalCustomizationsV2}
              modalLogo={modalLogo}
              modalTextAdjustments={modalTextAdjustments}
              onAdd={!labelOnly ? handleAdd : undefined}
              onClose={onModalClose}
              open={modalOpen}
              packageProtectionEnabled={packageProtectionEnabled}
              packageProtectionPlusEnabled={packageProtectionPlusEnabled}
              returnFocusRef={infoButtonRef}
              returnPolicyUrl={returnPolicyUrl}
              returnsCoverage={coverage}
              returnsCoverageEnabled={returnsCoverageEnabled}
              version={modalVersion}
            />
          </Lazy>
        </Suspense>
      )}
    </>
  );
};
