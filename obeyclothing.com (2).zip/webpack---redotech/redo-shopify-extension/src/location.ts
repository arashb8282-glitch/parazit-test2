import { useRequiredContext } from "@redotech/react-util/context";
import { useMemo } from "react";
import {
  CountryCityLocation,
  LocationApiClient,
} from "./location/location-api-client";
import { LocationClientContext } from "./location/location-client-context";
import { log } from "./monitoring/log";

export class LocationManager {
  constructor(private readonly locationApiClient: LocationApiClient) {}

  async getCountry(signal: AbortSignal): Promise<string> {
    try {
      const value = await this.locationApiClient.getCountry(signal);
      return value;
    } catch (error) {
      log("Error getting country", error);
      return "";
    }
  }

  async getDetailedLocation(signal: AbortSignal): Promise<CountryCityLocation> {
    return this.locationApiClient.getDetailedLocation(signal);
  }
}

/**
 * Hook to create LocationManager using the LocationApiClient from context.
 */
export function useLocationManager(): LocationManager {
  const locationApiClient = useRequiredContext(LocationClientContext);

  return useMemo(
    () => new LocationManager(locationApiClient),
    [locationApiClient],
  );
}
