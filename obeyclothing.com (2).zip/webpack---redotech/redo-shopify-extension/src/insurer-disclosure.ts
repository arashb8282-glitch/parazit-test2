import { usesInternationalRuleSet } from "@redotech/redo-return-coverage-common/coverage-calculator/utils/determine-rule-set";
import {
  InsurerDisclosure,
  splitPackageProtectionPrice,
} from "@redotech/redo-storefront-widget-common/package-protection-insurance";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import { createContext } from "react";

/** Set once by the manager; the info modal footers read it wherever they render. */
export const InsurerDisclosureContext = createContext<
  InsurerDisclosure | undefined
>(undefined);

/**
 * Names UPS Capital in the cart modal when the team's flag published the
 * insurance block and the shopper's country prices from the international
 * rule set, the same test the checkout modal applies. Amounts are in major
 * units of `currency`.
 */
export function cartInsurerDisclosure({
  autocheck,
  country,
  packageProtectionPrice,
  insuredValue,
  currency,
  locale,
}: {
  autocheck: Pick<WidgetAutocheck, "packageProtection">;
  country: string | undefined;
  packageProtectionPrice: number;
  insuredValue: number;
  currency: string;
  locale: string | undefined;
}): InsurerDisclosure | undefined {
  const international = autocheck.packageProtection.internationalInsurance;
  if (
    !international ||
    !autocheck.packageProtection.packageProtectionPlusEnabled ||
    !usesInternationalRuleSet(
      autocheck.packageProtection.pricingRuleSets,
      country,
    )
  ) {
    return undefined;
  }
  const split = splitPackageProtectionPrice({
    price: packageProtectionPrice,
    insuredValue,
    ratePer100: international.ratePer100,
    minimumPremium: international.minimumPremium,
  });
  const format = currencyFormatter(currency, locale);
  return {
    name: international.providerName,
    url: international.termsUrl,
    insurance: split ? format(split.insurance) : undefined,
    technologyFee: split ? format(split.technologyFee) : undefined,
  };
}

function currencyFormatter(
  currency: string,
  locale: string | undefined,
): (amount: number) => string {
  try {
    const formatter = new Intl.NumberFormat(locale, {
      style: "currency",
      currency,
    });
    return (amount) => formatter.format(amount);
  } catch {
    return (amount) => `${amount.toFixed(2)} ${currency}`;
  }
}
