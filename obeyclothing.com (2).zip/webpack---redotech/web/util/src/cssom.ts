import { lazy } from "@redotech/util/cache";

export const cssStylesheetSupport: () => boolean = lazy(() => {
  try {
    // recording result of call in a variable to trick javascript into not minifying this code
    const x = new CSSStyleSheet(); // Safari does not support before 16.4
    void x.replace("body { color: red; }"); // Check for https://github.com/microsoft/clarity/issues/819
    return !!x;
  } catch {
    return false;
  }
});
