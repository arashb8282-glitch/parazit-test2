import { createContext } from "react";

/**
 * Container element for modals
 */
export const ModalRootContext = createContext<HTMLElement>(document.body);
