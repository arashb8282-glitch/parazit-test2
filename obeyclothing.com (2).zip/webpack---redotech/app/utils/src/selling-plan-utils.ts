import { parseGid } from "@redotech/redo-shopify-common/gid-utils";
import type { SellingPlanGroup } from "@redotech/redo-storefront-common/widget-selling-plan";
import { WidgetFees } from "@redotech/redo-storefront-widget-common/widget";
import { getSellingPlanInfo as getSellingPlanInfoApi } from "./redo-api";

import type { Shop } from "@shopify/ui-extensions/checkout";

type BillingPolicy = SellingPlanGroup["sellingPlans"][number]["billingPolicy"];

// Match interval and count when both sides have them. Fall back to the day
// equivalent for a payload that only has intervalDays.
function matchesCartPolicy(policy: BillingPolicy, cart: BillingPolicy[]) {
  const cartHasInterval = cart.some(
    (item) => item.interval && item.intervalCount,
  );
  if (cartHasInterval && policy.interval && policy.intervalCount) {
    return cart.some(
      (item) =>
        item.interval === policy.interval &&
        item.intervalCount === policy.intervalCount,
    );
  }
  return (
    policy.intervalDays != null &&
    cart.some((item) => item.intervalDays === policy.intervalDays)
  );
}

export const getMatchingRedoSellingPlanId = (
  redoProduct: { sellingPlanGroups: SellingPlanGroup[] },
  sellingPlans: { billingPolicy?: BillingPolicy }[],
) => {
  const redoSellingPlans = redoProduct.sellingPlanGroups.flatMap(
    (group) => group.sellingPlans,
  );
  const cartPolicies = sellingPlans.flatMap((plan) =>
    plan.billingPolicy ? [plan.billingPolicy] : [],
  );
  const matchingSellingPlans = redoSellingPlans.filter((plan) =>
    matchesCartPolicy(plan.billingPolicy, cartPolicies),
  );

  if (matchingSellingPlans.length === 0) {
    return null;
  }

  const highestFrequencySellingPlan = matchingSellingPlans.reduce(
    (shortest, plan) => {
      const planDays = plan.billingPolicy.intervalDays;
      const shortestDays = shortest.billingPolicy.intervalDays;
      if (planDays == null) {
        return shortest;
      }
      if (shortestDays == null || planDays < shortestDays) {
        return plan;
      }
      return shortest;
    },
  );

  try {
    const id = highestFrequencySellingPlan.id.split("/").slice(-1)[0];
    return id ? parseInt(id) : null;
  } catch (e) {
    console.error(e);
    return null;
  }
};

export const getSellingPlanInfo = async (
  sellingPlanIds: string[],
  fees: WidgetFees | undefined,
  shop: Shop,
  log: (...args: Parameters<typeof console.log>) => void,
) => {
  if (!fees || !sellingPlanIds.length) {
    return undefined;
  }

  const sellingPlanPromises: Promise<any>[] = [];
  for (const sellingPlanId of sellingPlanIds) {
    log(`getting selling plan info for id ${sellingPlanId}`);
    sellingPlanPromises.push(
      getSellingPlanInfoApi(
        shop.myshopifyDomain,
        parseInt(parseGid(sellingPlanId)),
      ),
    );
  }

  const sellingPlanInfo = await Promise.all(sellingPlanPromises);

  log({ sellingPlanInfo });

  if (sellingPlanInfo.length === 0) {
    return undefined;
  }

  const feesItems = [fees.returnProduct, fees.packageProduct, fees.bothProduct];

  const newMapping: Record<string, number> = {};

  for (const feesItem of feesItems) {
    if (feesItem?.sellingPlanGroups) {
      log({ feesSellingPlanGroups: feesItem.sellingPlanGroups });
      const sellingPlanId = getMatchingRedoSellingPlanId(
        feesItem,
        sellingPlanInfo,
      );

      if (sellingPlanId) {
        log({ sellingPlanId });
        newMapping[String(feesItem.productId)] = sellingPlanId;
      }
    }
  }
  log({ sellingPlanMap: newMapping });

  return newMapping;
};
