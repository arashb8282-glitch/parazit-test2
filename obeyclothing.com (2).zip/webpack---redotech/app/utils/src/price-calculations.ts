import { CoveragePriceResult } from "@redotech/redo-coverage-common";
import { returnCoverageCalculator } from "@redotech/redo-return-coverage-common/coverage-calculator/returns";
import { getFinalSaleReturnsPrice } from "@redotech/redo-return-coverage-common/coverage-calculator/utils/get-final-sale-returns-price";
import { getPackageProtectionPrice } from "@redotech/redo-return-coverage-common/coverage-calculator/utils/get-package-protection-price";
import { getCoverageMlModelInference } from "@redotech/redo-return-coverage-common/coverage-calculator/utils/get-price-bracket-price";
import { CoveragePriceCacheValue } from "@redotech/redo-storefront-common/cart-attributes";
import { autocheckToCoverageSettings } from "@redotech/redo-storefront-widget-common/autocheck-conversion";
import { WidgetAutocheck } from "@redotech/redo-storefront-widget-common/widget";
import { ShopifyCartItem } from "@redotech/shopify-client/ajax";

export function getCalculatedCoveragePrice({
  basePriceDollars,
  autocheck,
  onTapcart,
  cartValueReturnableItems,
  cartValuePackageProtectionItems,
  finalSaleReturnsCartValue,
  cartItems,
  numValidReturnProducts,
  numValidPackageProtectionProducts,
  country,
  cartHasSubscriptionItem,
  coveragePriceCacheValue,
  priceCalculationContext,
}: {
  basePriceDollars: number;
  autocheck: WidgetAutocheck;
  onTapcart: boolean;
  cartValueReturnableItems: number;
  cartValuePackageProtectionItems: number;
  finalSaleReturnsCartValue: number;
  cartItems: ShopifyCartItem[] | undefined;
  numValidReturnProducts: number;
  numValidPackageProtectionProducts: number;
  country?: string | null;
  cartHasSubscriptionItem: boolean;
  coveragePriceCacheValue: CoveragePriceCacheValue | undefined;
  priceCalculationContext?: { checkoutProbability: number | undefined };
}): {
  returnCost: number;
  packageProtectionCost: number;
  bothCost: number;
  rawCoveragePrices: {
    returns: CoveragePriceResult | undefined;
    packageProtection: CoveragePriceResult | undefined;
    finalSaleReturns: CoveragePriceResult | undefined;
  };
} {
  const returnCartValue = onTapcart
    ? cartValueReturnableItems
    : cartValueReturnableItems / 100;
  const fsrCartValue = onTapcart
    ? finalSaleReturnsCartValue
    : finalSaleReturnsCartValue / 100;
  const team = autocheckToCoverageSettings(autocheck);
  team.pricePerOrder ||= String(basePriceDollars);
  if (!cartItems && team.settings.returns) {
    team.settings.returns.dynamicPricing = undefined;
  }
  const returnsPrice = returnCoverageCalculator.calculateCoveragePrice({
    team,
    country: country ?? undefined,
    numProducts: numValidReturnProducts,
    amount: returnCartValue,
  }).price;
  let returnCost = onTapcart ? returnsPrice : returnsPrice * 100;

  if (autocheck.finalSaleReturns.coverageEnabled) {
    let { price: finalSaleReturnsCost } = getFinalSaleReturnsPrice({
      cartTotal: fsrCartValue,
      pricingRuleSets: autocheck.finalSaleReturns.pricingRuleSets,
      shippingLabelCoveragePrice:
        autocheck.finalSaleReturns.shippingLabelCoveragePrice,
      country,
      minPrice: autocheck.finalSaleReturns.minPrice,
      maxPrice: autocheck.finalSaleReturns.maxPrice,
      backupPercentage: autocheck.finalSaleReturns.percentage,
    });
    finalSaleReturnsCost = onTapcart
      ? finalSaleReturnsCost
      : finalSaleReturnsCost * 100;

    // if returns coverage is not enabled, we can simply use the final sale returns price
    if (!autocheck.coverageEnabled) {
      returnCost = finalSaleReturnsCost;
    } else {
      // Since final sale returns price bakes in the price for returns, we can simply take
      // the max of the two prices to determine how much to charge for returns on mixed carts.
      returnCost = Math.max(returnCost, finalSaleReturnsCost);
    }
  }

  // tapcart works in dollars so we don't want to round to the nearest dollar
  if (!onTapcart) {
    returnCost = Math.round(returnCost);
  }

  const packageProtectionCartValue = onTapcart
    ? cartValuePackageProtectionItems
    : cartValuePackageProtectionItems / 100;

  const coverageMlModel = getCoverageMlModelInference({
    mlModel: autocheck.packageProtection.coverageMlModel ?? undefined,
    sessionInferenceParams: {
      checkoutProbability: priceCalculationContext?.checkoutProbability,
    },
  });

  const { packageProtectionCost, rawPackageProtectionPriceResult } = (() => {
    const priceResult = getPackageProtectionPrice({
      pricingStrategy: autocheck.packageProtection.pricingStrategy,
      pricePerItem: autocheck.packageProtection.pricePerItem,
      numItems: numValidPackageProtectionProducts,
      cartTotal: packageProtectionCartValue,
      pricingRuleSets: autocheck.packageProtection.pricingRuleSets,
      country,
      minPrice: autocheck.packageProtection.minPrice,
      maxPrice: autocheck.packageProtection.maxPrice,
      backupPercentage: autocheck.packageProtection.percentage,
      fixedSubscriptionPrice:
        autocheck.packageProtection.fixedSubscriptionPrice,
      cartHasSubscriptionItem,
      coverageMlModel,
      priceOverrideForCoverageMlModelCacheOnly:
        coveragePriceCacheValue?.packageProtection,
    });
    if (onTapcart) {
      return {
        packageProtectionCost: priceResult.price,
        rawPackageProtectionPriceResult: priceResult,
      };
    }
    return {
      packageProtectionCost: Math.round(priceResult.price * 100), // round to nearest cent
      rawPackageProtectionPriceResult: priceResult,
    };
  })();

  return {
    returnCost,
    packageProtectionCost,
    bothCost: packageProtectionCost + returnCost,
    rawCoveragePrices: {
      returns: undefined, // unimplemented
      packageProtection: rawPackageProtectionPriceResult,
      finalSaleReturns: undefined, // unimplemented
    },
  };
}
