// binarySearch returns the element in the array that is closest to the target value rounded up (input: 2, list: [1,4], closest: 4).
// If a threshold is defined it will return the closest element only if it is within the threshold and the prev is not further from

// the target than the next (input: 2, list: [1,4], threshold: 2, closest: 1) (input: 6, list: [1,10], threshold: 2, closest: 10).
export function binarySearch<T>(
  items: T[],
  target: number,
  getValue: (item: T) => number,
  threshold?: number,
): T {
  let start = 0;
  let end = items.length - 1;
  while (start <= end) {
    const mid = Math.floor((start + end) / 2);
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    const value = getValue(items[mid]!);
    if (value === target) {
      start = mid;
      break;
    } else if (value < target) {
      start = mid + 1;
    } else {
      end = mid - 1;
    }
  }
  if (start >= items.length) {
    start = items.length - 1;
  }
  if (start === 0) {
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    return items[start]!;
  }
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  const next = items[start]!;
  if (threshold) {
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    const prev = items[Math.max(0, start - 1)]!;
    const nextDiff = Math.abs(getValue(next) - target);
    const prevDiff = Math.abs(getValue(prev) - target);
    if (nextDiff >= threshold && prevDiff < nextDiff) {
      return prev;
    }
  }
  return next;
}

const THRESHOLD_PERCENTAGE = 0.35;
const DEFAULT_THRESHOLD_DOLLARS = 1;
const DEFAULT_THRESHOLD_CENTS = 100;

export function getThreshold({
  country,
  unit,
  targetPrice,
}: {
  country: string | undefined;
  unit: "dollars" | "cents";
  targetPrice: number;
}): number {
  let baseThreshold: number | undefined;

  switch (unit) {
    case "cents":
      baseThreshold = DEFAULT_THRESHOLD_CENTS;
      break;
    case "dollars":
      baseThreshold = DEFAULT_THRESHOLD_DOLLARS;
      break;
  }

  if (country === "US") {
    return baseThreshold;
  }

  return Math.max(targetPrice * THRESHOLD_PERCENTAGE, baseThreshold);
}
