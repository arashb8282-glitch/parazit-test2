import { ContentTypeField, PostMethod } from "@redotech/http/semantics";
import { ApplicationJsonType } from "@redotech/json/mime";

export async function makePostRequest(full_url: string, body: object) {
  return await fetch(full_url, {
    method: PostMethod.name,
    body: JSON.stringify(body),
    headers: { [String(ContentTypeField.name)]: String(ApplicationJsonType) },
    keepalive: true,
  });
}
