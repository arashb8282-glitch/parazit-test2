import { CoverageButtonStyles } from "@redotech/redo-storefront-widget-common/widget";
import { createCssLine } from "../utils/generate-css-from-model-style";

export function generateCheckoutButtonCssFromStyle(
  style?: CoverageButtonStyles,
) {
  if (!style) {
    return "";
  }
  let generatedCssFromStyle = "";
  if (style?.color) {
    generatedCssFromStyle += createCssLine(
      "coverage-button",
      "background-color",
      style?.color,
    );
    generatedCssFromStyle += createCssLine(
      "coverage-button",
      "border-color",
      style?.color,
    );
  }
  if (style?.fontColor) {
    generatedCssFromStyle += createCssLine(
      "headline-text-container",
      "color",
      style?.fontColor,
    );
  }
  if (style?.subtitleFontColor) {
    generatedCssFromStyle += createCssLine(
      "subtitle-text-container",
      "color",
      style?.subtitleFontColor,
    );
  }
  if (style?.fontSize) {
    generatedCssFromStyle += createCssLine(
      "headline-text-container",
      "font-size",
      style?.fontSize.toString(),
      "px",
    );
  }
  if (style?.subtitleFontSize) {
    generatedCssFromStyle += createCssLine(
      "subtitle-text-container",
      "font-size",
      style?.subtitleFontSize.toString(),
      "px",
    );
  }
  if (style?.nonCoverageFontColor) {
    generatedCssFromStyle += createCssLine(
      "non-coverage-button",
      "color",
      style?.nonCoverageFontColor,
    );
  }
  if (style?.nonCoverageFontSize) {
    generatedCssFromStyle += createCssLine(
      "non-coverage-button",
      "font-size",
      style?.nonCoverageFontSize.toString(),
      "px",
    );
  }
  if (!style?.includeNonCoverageUnderline) {
    generatedCssFromStyle += createCssLine(
      "non-coverage-button",
      "text-decoration",
      "none",
    );
  }
  return generatedCssFromStyle;
}
