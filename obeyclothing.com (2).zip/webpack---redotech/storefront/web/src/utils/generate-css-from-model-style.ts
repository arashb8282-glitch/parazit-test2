export function createCssLine(
  dataTarget: string,
  property: string,
  value: string,
  postFix = "",
) {
  return `[data-target='${dataTarget}'] {
    ${property}: ${value}${postFix} !important;
  }`;
}
