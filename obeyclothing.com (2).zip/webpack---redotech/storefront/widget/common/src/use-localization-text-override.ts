import { WidgetAutocheck } from "./widget";

function copyObjectWithLocalizationTextOverrides<T extends object>(
  obj: T,
  localizationGroupId: string,
  localizationObjectId: string,
  overrides: WidgetAutocheck["localizationTextOverrides"],
): T {
  const filteredOverrides = overrides?.filter(
    (override) =>
      override.localizationGroupId === localizationGroupId &&
      override.localizationObjectId === localizationObjectId,
  );

  if (!filteredOverrides || filteredOverrides?.length === 0) {
    return obj;
  }

  // deep copy the object
  const result = JSON.parse(JSON.stringify(obj));

  for (const override of filteredOverrides) {
    const pathParts = override.path.split(".");
    let current: unknown = result;

    for (let i = 0; i < pathParts.length - 1; i++) {
      const part = pathParts[i];
      if (
        part === undefined ||
        current === null ||
        current === undefined ||
        typeof current !== "object"
      ) {
        current = undefined;
        break;
      }
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      current = (current as Record<string, unknown>)[part];
    }

    if (current != null && typeof current === "object") {
      const lastPart = pathParts[pathParts.length - 1];
      if (lastPart === undefined) {
        continue;
      }
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      const record = current as Record<string, unknown>;
      if (lastPart in record && typeof record[lastPart] === "string") {
        record[lastPart] = override.text;
      }
    }
  }

  return result;
}

export function applyLocalizationTextOverrides<T extends object>({
  obj,
  country,
  language,
  localizationGroups,
  localizationObjectId,
  localizationTextOverrides,
}: {
  obj: T;
  country?: string;
  language?: string;
  localizationGroups: WidgetAutocheck["localizationGroups"];
  localizationObjectId: string;
  localizationTextOverrides: WidgetAutocheck["localizationTextOverrides"];
}): T {
  if (!country && !language) {
    return obj;
  }

  const overrides = localizationTextOverrides ?? [];
  const groups = (localizationGroups ?? []).filter((group) =>
    overrides.some(
      (override) =>
        override.localizationGroupId === group._id &&
        override.localizationObjectId === localizationObjectId,
    ),
  );

  // Priority 1: find a group matching both country and language
  if (country && language) {
    const bothMatch = groups.find(
      (group) =>
        group.countries.includes(country) && group.languages.includes(language),
    );
    if (bothMatch) {
      return copyObjectWithLocalizationTextOverrides(
        obj,
        bothMatch._id,
        localizationObjectId,
        overrides,
      );
    }
  }

  // Priority 2: find a group matching only language (prioritized over country)
  if (language) {
    const languageMatch = groups.find(
      (group) =>
        group.languages.includes(language) && group.countries.length === 0,
    );
    if (languageMatch) {
      return copyObjectWithLocalizationTextOverrides(
        obj,
        languageMatch._id,
        localizationObjectId,
        overrides,
      );
    }
  }

  // Priority 3: find a group matching only the country
  if (country) {
    const countryMatch = groups.find(
      (group) =>
        group.countries.includes(country) && group.languages.length === 0,
    );
    if (countryMatch) {
      return copyObjectWithLocalizationTextOverrides(
        obj,
        countryMatch._id,
        localizationObjectId,
        overrides,
      );
    }
  }

  return obj;
}
