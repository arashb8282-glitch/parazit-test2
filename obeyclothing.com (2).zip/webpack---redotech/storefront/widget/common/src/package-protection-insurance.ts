/**
 * Served on the autocheck when a team may insure international shipments with
 * UPS Capital. The storefront shows it for carts priced from the merchant's
 * international pricing rule set, since the autocheck is cached per store.
 */
export interface PackageProtectionInternationalInsurance {
  providerName: string;
  termsUrl: string;
  /** Estimated premium per 100 units of insured value. */
  ratePer100: number;
  minimumPremium: number;
}

/** Which insurer backs package protection for this cart, with the price split already formatted. */
export interface InsurerDisclosure {
  name: string;
  url: string;
  insurance?: string;
  technologyFee?: string;
}

/** UPS Capital asks to be named by its insurance agency, UPSCIA, to shoppers. */
export const UPS_CAPITAL_PROVIDER_NAME = "UPSCIA";
export const UPS_CAPITAL_TERMS_URL =
  "https://www.insureshield.com/content/terms-and-conditions/REDO_TermsandConditions.pdf";

/**
 * Splits what the shopper pays for package protection into the estimated
 * insurance premium and the remainder, shown as platform access.
 */
export function splitPackageProtectionPrice({
  price,
  insuredValue,
  ratePer100,
  minimumPremium,
}: {
  price: number;
  insuredValue: number;
  ratePer100: number;
  minimumPremium: number;
}): { insurance: number; technologyFee: number } | null {
  if (!(price > 0)) {
    return null;
  }
  const estimate = Math.max(minimumPremium, (insuredValue * ratePer100) / 100);
  const insurance = Math.min(price, Math.round(estimate * 100) / 100);
  return {
    insurance,
    technologyFee: Math.round((price - insurance) * 100) / 100,
  };
}
