// Keep in sync with @redo/shopify/app/utils/product-types.ts and @redo/return/core/db/schema/src/CartProduct.ts
export enum CartProductType {
  Return = "return",
  PackageProtection = "package_protection",
  Both = "return,package_protection",
  ExtendedWarranty = "extended_warranty",
}
