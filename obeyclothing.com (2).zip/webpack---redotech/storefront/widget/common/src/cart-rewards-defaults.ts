export const cartRewardsDefaults = {
  approachingThresholdMessage:
    "You're only %remainingToRewardsTier% away from free shipping!",
  pastThresholdMessage: "Congratulations! Free shipping unlocked!",
};

export const getEvaluatedCartRewardsMessage = (
  message: string | undefined,
  defaultMessage: string,
  variables: { remainingToRewardsTier?: string } = {},
): string => {
  const finalMessage = message || defaultMessage;

  return finalMessage.replace(
    /%remainingToRewardsTier%/g,
    variables.remainingToRewardsTier || "$0.00",
  );
};
