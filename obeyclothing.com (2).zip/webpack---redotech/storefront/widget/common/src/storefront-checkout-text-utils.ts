import { Currency } from "@redotech/money/currencies";
import { moneyFormat } from "@redotech/money/util";
import { CoverageInfo } from "@redotech/redo-return-coverage-common/coverage-calculator/coverage-info-from-calculators";
import { CartProductType } from "./cart-product-types";
import {
  ButtonSettingPerProduct,
  CoverageText,
  NonCoverageButtonText,
  TitleSubtitle,
} from "./widget";

interface CartValuesForTemplate {
  currency: Currency;
  locale?: string;
  coveragePrice: number;
  cartTotal: number;
  cartTotalPreDiscount: number;
  dueLaterTotal: number;
  coverageCreditAmount: number;
  compareAtPrice: number;
}

export class StorefrontCheckoutTextUtils {
  private static handleCompareConditional(
    leftVariable: string,
    operator: string,
    rightVariable: string,
    numberVariables: Record<string, number>,
  ): boolean {
    const leftValue = numberVariables[leftVariable];
    const rightValue = numberVariables[rightVariable];

    if (leftValue === undefined || rightValue === undefined) {
      return false;
    }

    switch (operator) {
      case "<":
        return leftValue < rightValue;
      case "<=":
        return leftValue <= rightValue;
      case "==":
        return leftValue === rightValue;
      case "!=":
        return leftValue !== rightValue;
      case ">":
        return leftValue > rightValue;
      case ">=":
        return leftValue >= rightValue;
      default:
        return false;
    }
  }
  private static evaluateConditional({
    conditional,
    numberVariables,
    booleanVariables,
  }: {
    conditional: string;
    numberVariables: Record<string, number>;
    booleanVariables: Record<string, boolean>;
  }): boolean | undefined {
    const compareRegex = /(\w+)\s+(<=|>=|!=|==|<|>)\s+(\w+)/;
    const match = conditional.match(compareRegex);

    if (match && match.length === 4) {
      const [_, leftVariable, operator, rightVariable] = match;
      return this.handleCompareConditional(
        // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
        leftVariable,
        operator,
        rightVariable,
        numberVariables,
      );
    }

    const booleanMatch = conditional.match(/(\w+)/);
    if (booleanMatch && booleanMatch.length === 2) {
      const [_, variable] = booleanMatch;
      // @ts-expect-error TODO: noUncheckedIndexedAccess FIXME
      return booleanVariables[variable] ?? undefined;
    }

    return undefined;
  }

  // If someone touches this code in the next 2 years let me know so i can win / lose a bet with Josh Bosley
  private static evaluateIfStatements({
    text,
    coveragePrice,
    cartTotal,
    cartTotalPreDiscount,
    dueLaterTotal,
    coverageCreditAmount,
    compareAtPrice,
    coverageCredit,
  }: CartValuesForTemplate & {
    text: string;
    coverageCredit: boolean;
  }): string {
    const combinedPrice = coveragePrice + cartTotal - dueLaterTotal;
    const compareAtPricePlusRedo = compareAtPrice + coveragePrice;

    const variables: Record<string, boolean> = { coverageCredit };
    const numberVariables: Record<string, number> = {
      coveragePrice,
      cartTotal,
      cartTotalPreDiscount,
      dueLaterTotal,
      coverageCreditAmount,
      compareAtPrice,
      combinedPrice,
      compareAtPricePlusRedo,
    };

    const ifStatementRegex =
      /%if\s+(.*?)%([\s\S]*?)(?:%else%([\s\S]*?))?%endif%/g;
    return text.replace(
      ifStatementRegex,
      (match, conditional, ifText, elseText) => {
        const result = this.evaluateConditional({
          conditional,
          numberVariables,
          booleanVariables: variables,
        });

        if (result === undefined) {
          return match;
        }

        return result ? ifText.trim() : elseText ? elseText.trim() : "";
      },
    );
  }
  static fillTemplateVariables({
    text,
    currency,
    locale,
    coveragePrice,
    cartTotal,
    cartTotalPreDiscount,
    dueLaterTotal,
    coverageCreditAmount,
    compareAtPrice,
  }: CartValuesForTemplate & { text: string }): string {
    let textWithVariables = this.evaluateIfStatements({
      text,
      currency,
      coveragePrice,
      cartTotal,
      cartTotalPreDiscount,
      dueLaterTotal,
      coverageCreditAmount,
      compareAtPrice,
      coverageCredit: coverageCreditAmount > 0,
    });

    const formatMoney = (amount: number) =>
      moneyFormat({ amount, currency }, undefined, locale);

    textWithVariables = textWithVariables.replaceAll(
      "%price%",
      formatMoney(coveragePrice),
    );
    textWithVariables = textWithVariables.replaceAll(
      "%cartTotal%",
      formatMoney(cartTotal - dueLaterTotal),
    );
    textWithVariables = textWithVariables.replaceAll(
      "%combinedPrice%",
      formatMoney(coveragePrice + cartTotal - dueLaterTotal),
    );
    textWithVariables = textWithVariables.replaceAll(
      "%cartTotalPreDiscount%",
      formatMoney(cartTotalPreDiscount),
    );
    textWithVariables = textWithVariables.replaceAll(
      "%combinedPricePreDiscount%",
      formatMoney(cartTotalPreDiscount + coveragePrice),
    );
    textWithVariables = textWithVariables.replaceAll(
      "%coverageCreditAmount%",
      formatMoney(coverageCreditAmount),
    );
    textWithVariables = textWithVariables.replaceAll(
      "%compareAtPrice%",
      formatMoney(compareAtPrice),
    );
    textWithVariables = textWithVariables.replaceAll(
      "%compareAtPricePlusRedo%",
      formatMoney(compareAtPrice + coveragePrice),
    );

    return textWithVariables;
  }

  static getTextByProduct(
    textByProduct: NonCoverageButtonText | undefined,
    {
      mainProductType,
      hasProtectionReturnsAndSplit,
      coverageInfo,
      currency,
      locale,
      coveragePrice,
      cartTotal,
      cartTotalPreDiscount,
      dueLaterTotal,
      coverageCreditAmount,
      compareAtPrice,
    }: {
      mainProductType: Exclude<
        CartProductType,
        CartProductType.ExtendedWarranty
      >;
      hasProtectionReturnsAndSplit: boolean;
      coverageInfo: CoverageInfo;
    } & CartValuesForTemplate,
  ): string | undefined {
    if (!textByProduct) {
      return undefined;
    }

    const { returns, packageProtection, both } = textByProduct;

    let finalText: string | undefined;
    // tslint-disable-next-line @typescript-eslint/switch-exhaustiveness-check -- TODO: grandfather FIXME
    switch (mainProductType) {
      case "return": {
        finalText = returns;

        break;
      }
      case "return,package_protection": {
        finalText = both;

        break;
      }
      case "package_protection": {
        finalText = packageProtection;

        break;
      }
      // No default
    }

    if (hasProtectionReturnsAndSplit) {
      if (
        coverageInfo.returns.cartEligible &&
        coverageInfo.packageProtection.cartEligible
      ) {
        finalText = both;
      } else if (coverageInfo.packageProtection.cartEligible) {
        finalText = packageProtection;
      } else {
        finalText = returns;
      }
    }

    if (finalText) {
      finalText = this.fillTemplateVariables({
        text: finalText,
        currency,
        locale,
        coveragePrice,
        cartTotal,
        cartTotalPreDiscount,
        dueLaterTotal,
        coverageCreditAmount,
        compareAtPrice,
      });
    }

    return finalText;
  }

  static getCoverageTextAndSubtext(
    coverageText: CoverageText | undefined,
    textInfo: {
      mainProductType: Exclude<
        CartProductType,
        CartProductType.ExtendedWarranty
      >;
      hasProtectionReturnsAndSplit: boolean;
      coverageInfo: CoverageInfo;
    } & CartValuesForTemplate,
  ): TitleSubtitle {
    if (!coverageText) {
      return {};
    }

    const titleText: string | undefined = this.getTextByProduct(
      {
        returns: coverageText.returns?.titleText,
        packageProtection: coverageText.packageProtection?.titleText,
        both: coverageText.both?.titleText,
      },
      textInfo,
    );
    const subtitleText: string | undefined = this.getTextByProduct(
      {
        returns: coverageText.returns?.subtitleText,
        packageProtection: coverageText.packageProtection?.subtitleText,
        both: coverageText.both?.subtitleText,
      },
      textInfo,
    );

    return { titleText, subtitleText };
  }

  private static defaultCheckoutButtonTexts: TitleSubtitle = {
    titleText: "Checkout+ | %combinedPrice%",
    subtitleText: "",
  };

  /** Source of truth for storefront default text when the merchants' texts are empty. Also for AB test placeholders & coverage preview defaults. */
  static defaultCheckoutTexts: {
    coverageButtonText: CoverageText;
    nonCoverageButtonText: NonCoverageButtonText;
    cardText: CoverageText;
  } = {
    coverageButtonText: {
      returns: this.defaultCheckoutButtonTexts,
      packageProtection: this.defaultCheckoutButtonTexts,
      both: this.defaultCheckoutButtonTexts,
    },
    nonCoverageButtonText: {
      returns: "Checkout without free returns",
      packageProtection: "Checkout without package protection",
      both: "Checkout without free returns & package protection",
    },

    cardText: {
      returns: {
        titleText: "Checkout+",
        subtitleText: "Free returns on your order",
      },
      packageProtection: {
        titleText: "Checkout+",
        subtitleText: "Package protection on your order",
      },
      both: {
        titleText: "Checkout+",
        subtitleText: "Free returns + package protection",
      },
    },
  };

  static buttonSettingsPerProductToCoverageButtonText: Record<
    ButtonSettingPerProduct,
    keyof typeof StorefrontCheckoutTextUtils.defaultCheckoutTexts.coverageButtonText
  > = {
    [ButtonSettingPerProduct.RETURN]: "returns",
    [ButtonSettingPerProduct.PACKAGE_PROTECTION]: "packageProtection",
    [ButtonSettingPerProduct.BOTH]: "both",
  };

  static getDefaultInputTexts(
    buttonSettingPerProduct: ButtonSettingPerProduct,
  ): {
    defaultCoverageButtonTextToUse: TitleSubtitle;
    defaultNonCoverageButtonTextToUse: string;
    defaultCardTextToUse: TitleSubtitle;
  } {
    const defaultCoverageButtonTextToUse =
      this.defaultCheckoutTexts.coverageButtonText[
        this.buttonSettingsPerProductToCoverageButtonText[
          buttonSettingPerProduct
        ]
      ];
    const defaultNonCoverageButtonTextToUse =
      this.defaultCheckoutTexts.nonCoverageButtonText[
        this.buttonSettingsPerProductToCoverageButtonText[
          buttonSettingPerProduct
        ]
      ];
    const defaultCardTextToUse =
      this.defaultCheckoutTexts.cardText[
        this.buttonSettingsPerProductToCoverageButtonText[
          buttonSettingPerProduct
        ]
      ];

    /** We can guarantee the default texts are not undefined because we have a default text for each button setting per product */
    return {
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      defaultCoverageButtonTextToUse: defaultCoverageButtonTextToUse!,
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      defaultNonCoverageButtonTextToUse: defaultNonCoverageButtonTextToUse!,
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      defaultCardTextToUse: defaultCardTextToUse!,
    };
  }
}
