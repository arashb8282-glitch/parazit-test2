import { CoverageCalculatorOptions } from "@redotech/redo-return-coverage-common/coverage-calculator/index";
import { WidgetAutocheck } from "./widget";

export function autocheckToCoverageSettings(
  autocheck: WidgetAutocheck,
): CoverageCalculatorOptions {
  return {
    pricePerOrder: autocheck.pricePerOrder,
    settings: {
      enabled: autocheck.enabled,
      coverageEnabled: autocheck.coverageEnabled,
      paidModel: autocheck.paidModel,

      // Coverage exclusions

      // customer is handled with "disableRedoForCustomer" field
      coverageExcludeCustomerTags: [],
      coverageExcludeCentEnding: [], // this is only implemented for commentsold currently
      coverageExcludeDiscountCodes:
        autocheck.coverageExcludeDiscountCodes || [],
      coverageExcludeProperties: autocheck.coverageExcludeProperties || [],
      coverageExcludeCollections: autocheck.coverageExcludeCollections || [],
      coverageExcludeProductTags: autocheck.finalSaleTags || [],
      excludeCoverageIfAnyInvalidProduct:
        autocheck.excludeCoverageIfAnyInvalidProduct,
      discountCodePartialMatch: autocheck.discountCodePartialMatch,
      protectionExcludeTags: autocheck.protectionExcludeTags,

      // Country settings
      countries: autocheck.countries || [],

      // Returns specific settings
      returns: {
        enabled: autocheck.enabled && autocheck.coverageEnabled,
        dynamicPricing: autocheck.dynamicReturnsPricing,
        internationalPricing: autocheck.internationalReturnsPricing,
        finalSaleReturns: autocheck.finalSaleReturns
          ? {
              ...autocheck.finalSaleReturns,
              enabled: autocheck.finalSaleReturns.coverageEnabled,
              validProductTags:
                autocheck.finalSaleReturns.coverageValidTags || [],
              validCollectionTitles:
                autocheck.finalSaleReturns.coverageValidCollectionTitles || [],
              pricingRuleSet: autocheck.finalSaleReturns.pricingRuleSets,
              minPrice: autocheck.finalSaleReturns.minPrice || 0,
              eligibleDiscountThreshold:
                autocheck.finalSaleReturns.eligibleDiscountThreshold ??
                undefined,
            }
          : undefined,
        coverageExcludedVariantMetafields:
          autocheck.coverageExcludedVariantMetafields || [],
        returnsCoverageExcludedSkus:
          autocheck.returnsCoverageExcludedSkus || [],
      },

      // Package protection settings
      packageProtection: autocheck.packageProtection
        ? {
            ...autocheck.packageProtection,
            enabled: autocheck.packageProtection.coverageEnabled,
            coverage: autocheck.packageProtection.coverageEnabled,
            countries: autocheck.countriesPackageProtection || [],
            pricingRuleSet: autocheck.packageProtection.pricingRuleSets,
            coverageMlModel: autocheck.packageProtection.coverageMlModel,
          }
        : undefined,

      // Shopify extension settings
      shopifyExtension: {
        disableBusinessAccountInStorefront:
          autocheck.disableBusinessAccountInStorefront,
        cartValueCalculationMethod: autocheck.cartValueCalculationMethod,
        coverageExcludePickup: autocheck.excludePickup,
      },
      publicapi: {
        discountsAreFinalSales: autocheck.discountsAreFinalSales,
        couponedItemsDiscountThreshold:
          autocheck.couponedItemsDiscountThreshold,
      },
    },
  };
}
