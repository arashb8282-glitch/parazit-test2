/** How Checkout+ buttons send the shopper to checkout. */
export enum CheckoutMethod {
  /** Write the opt-in attributes and coverage line to the cart, then navigate to `/checkout`. */
  NAVIGATE_AFTER_ADD = "navigate_after_add",
  /**
   * Shopify only: navigate straight to a cart permalink carrying the shopper's
   * cart, the coverage line, and the Redo attributes, with no cart mutations
   * or network requests first. Falls back to `NAVIGATE_AFTER_ADD` for carts a
   * permalink can't represent.
   */
  CART_PERMALINK = "cart_permalink",
}

export const DEFAULT_CHECKOUT_METHOD = CheckoutMethod.NAVIGATE_AFTER_ADD;

export const checkoutMethodLabels: Record<CheckoutMethod, string> = {
  [CheckoutMethod.NAVIGATE_AFTER_ADD]: "Navigate after adding to cart",
  [CheckoutMethod.CART_PERMALINK]: "Shopify cart permalink",
};
