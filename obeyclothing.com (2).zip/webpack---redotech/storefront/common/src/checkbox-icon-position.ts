/** Where the info icon renders inside the cart checkbox widget. */
export const CheckboxIconPosition = [
  "title_right",
  "description_right",
] as const;
export type CheckboxIconPosition = (typeof CheckboxIconPosition)[number];

/** Matches the pre-setting behavior: the info icon rendered in the subtext row. */
export const DEFAULT_CHECKBOX_ICON_POSITION: CheckboxIconPosition =
  "description_right";
