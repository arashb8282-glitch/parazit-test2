import { validRawCoverageTreatmentId } from "@redotech/redo-ab-testing-common/coverage-treatment-id";
import * as z from "zod";
import { InsertionPosition } from "./insertion-position";
import { WidgetElementType } from "./widget-config";

export const coveragePlacementSchema = z.object({
  placementId: z
    .string()
    .regex(/^[a-f\d]{24}$/i)
    .nullable()
    .optional(),
  placementIndex: z.number().int().nonnegative().optional(),
  elementType: z.nativeEnum(WidgetElementType),
  selector: z
    .string()
    .min(1)
    .max(4096)
    .refine((selector) => selector.trim().length > 0),
  insertionPosition: z.nativeEnum(InsertionPosition),
  shadowRootSelector: z
    .string()
    .min(1)
    .max(4096)
    .refine((selector) => selector.trim().length > 0)
    .optional(),
});
export type CoveragePlacement = z.infer<typeof coveragePlacementSchema>;

export const coverageLoadedEventSchema = z.object({
  themeId: z.string().regex(/^\d+$/).max(32),
  treatmentId: z
    .string()
    .refine((id) => validRawCoverageTreatmentId(id) !== undefined)
    .nullable(),
  url: z.string().url().max(8192),
  path: z.string().max(2048),
  pageType: z.enum([
    "pdp",
    "collection",
    "cart",
    "homepage",
    "information-page",
    "unknown",
  ]),
});
export type CoverageLoadedEvent = z.infer<typeof coverageLoadedEventSchema>;

export const coveragePlacementEventSchema = coverageLoadedEventSchema.extend({
  placements: z.array(coveragePlacementSchema).min(1).max(50),
});
export type CoveragePlacementEvent = z.infer<
  typeof coveragePlacementEventSchema
>;

/** A placement last seen longer ago than this is reported as if never seen. */
export const COVERAGE_PLACEMENT_STALE_MINUTES = 30;

export type CoveragePlacementMetrics = Record<
  string,
  Record<
    string,
    {
      lastLoadedAt?: string;
      placements: Record<string, CoveragePlacement & { lastSeenAt: string }>;
    }
  >
>;

export function coverageTreatmentKey(treatmentId: string | null): string {
  return treatmentId ?? "default";
}

export function coveragePlacementKey(placement: CoveragePlacement): string {
  if (placement.placementId) {
    return JSON.stringify([
      placement.placementId,
      placement.placementIndex ?? 0,
      placement.shadowRootSelector ?? null,
    ]);
  }
  return JSON.stringify([
    placement.elementType,
    placement.selector,
    placement.insertionPosition,
    placement.shadowRootSelector ?? null,
  ]);
}
