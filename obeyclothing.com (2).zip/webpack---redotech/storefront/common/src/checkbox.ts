export const fullCoverage = "Return or Exchange";
export const texts = {
  "000": fullCoverage, // FSR
  "001": "Store Credit",
  "010": "Refunds",
  "011": "Refunds or Store Credit",
  "100": "Exchanges",
  "101": "Store Credit or Exchanges",
  "110": "Refunds or Exchanges",
  "111": fullCoverage,
} as const;

export const checkboxOptions = [
  "Free Return",
  "Free &amp; Easy Return",
  "Free &amp; Easy Return Coverage",
  "Try Risk Free with Free Returns",
  "Free Return Label",
];

export const fullCoverageOptions = [
  "Free Return or Exchange",
  "Free &amp; Easy Return or Exchange",
  "Free &amp; Easy Return or Exchange Coverage",
  "Try Risk Free with Free Returns or Exchanges",
  "Free Return or Exchange Label",
];

// Structural subset of `Coverage` (return-coverage-common) — kept inline so this
// storefront leaf does not depend on return-coverage-common (which depends back
// on this module via coverage-title-text). Any `Coverage` is assignable.
export function getReturnType(coverage: {
  exchange: boolean;
  refund: boolean;
  storeCredit: boolean;
}): string | undefined {
  return texts[
    // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
    `${+coverage.exchange}${+coverage.refund}${+coverage.storeCredit}` as keyof typeof texts
  ];
}

export function getHtml(
  value: string,
  returnType: string | undefined,
): string | undefined {
  if (returnType === "Return or Exchange" && checkboxOptions.includes(value)) {
    return fullCoverageOptions[checkboxOptions.indexOf(value)];
  } else if (
    returnType !== "Return or Exchange" &&
    fullCoverageOptions.includes(value)
  ) {
    return checkboxOptions[fullCoverageOptions.indexOf(value)];
  }

  return value;
}
