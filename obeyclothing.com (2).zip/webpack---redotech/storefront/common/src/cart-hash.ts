/**
 * Cart hashing shared between the checkout-UI extension (which writes the
 * `coverageTransformFunctionInfo` cart attribute) and the `dynamic-coverage-transform`
 * Shopify Function (`redo/shopify/app/dynamic-coverage-transform/src/run.rs`,
 * which reads it and reprices the Redo coverage line).
 *
 * The function trusts a price stamped on a cart attribute, so a shopper could
 * tamper with that attribute. To bind the price to the cart it was computed
 * for, the checkout-UI stamps `coverageTransformFunctionInfo` as
 * `[cartHash]:[base64(price)]`, and the function independently recomputes the
 * cart hash from the real cart and refuses to apply the price if it doesn't
 * match. The hash only covers data BOTH sides can read from the genuine cart:
 * each product-variant line's variant id and quantity. (Discount codes are not
 * exposed to the cart-transform Function input, so they cannot be verified and
 * are intentionally excluded.)
 *
 * This is an integrity binding, not authentication — there is no shared secret,
 * so the hash prevents replaying a price computed for a *different* cart, not a
 * determined forge. The algorithm here (FNV-1a, 32-bit) MUST stay byte-for-byte
 * in sync with `compute_cart_hash` / `fnv1a32_hex` in `run.rs`, including the
 * canonical-string construction (sorted `variantId:quantity` pairs joined by
 * `;`).
 */

export interface CartHashLine {
  /** Variant GID, e.g. `gid://shopify/ProductVariant/123`. */
  variantId: string;
  quantity: number;
}

/**
 * Deterministic, language-agnostic hash of the cart's variant ids + quantities.
 * Lines are reduced to `variantId:quantity` and sorted so ordering is
 * irrelevant. Returns an 8-char zero-padded lowercase hex string.
 */
export function computeCartHash(lines: CartHashLine[]): string {
  const canonical = lines
    .map((line) => `${line.variantId}:${line.quantity}`)
    .sort()
    .join(";");
  return fnv1a32Hex(canonical);
}

/** FNV-1a (32-bit). Input is ASCII (variant GIDs, digits, separators). */
export function fnv1a32Hex(input: string): string {
  let hash = 0x81_1c_9d_c5;
  for (let i = 0; i < input.length; i++) {
    hash = Math.imul(hash ^ input.charCodeAt(i), 0x01_00_01_93);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

/**
 * Encode the `coverageTransformFunctionInfo` attribute value: `[cartHash]:[base64(price)]`.
 * The hash is hex (no `:`) and the base64 price never contains `:`, so the
 * function can split on the first `:`.
 */
export function encodeTransformFunctionInfo(
  cartHash: string,
  price: number,
): string {
  return `${cartHash}:${base64Encode(String(price))}`;
}

const BASE64_CHARS =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

/** Standard base64 with padding. Input is ASCII (a numeric price string). */
function base64Encode(input: string): string {
  let output = "";
  for (let i = 0; i < input.length; i += 3) {
    const b0 = input.charCodeAt(i);
    const hasB1 = i + 1 < input.length;
    const hasB2 = i + 2 < input.length;
    const b1 = hasB1 ? input.charCodeAt(i + 1) : 0;
    const b2 = hasB2 ? input.charCodeAt(i + 2) : 0;
    output += BASE64_CHARS[b0 >> 2];
    output += BASE64_CHARS[((b0 & 0x03) << 4) | (b1 >> 4)];
    output += hasB1 ? BASE64_CHARS[((b1 & 0x0f) << 2) | (b2 >> 6)] : "=";
    output += hasB2 ? BASE64_CHARS[b2 & 0x3f] : "=";
  }
  return output;
}
